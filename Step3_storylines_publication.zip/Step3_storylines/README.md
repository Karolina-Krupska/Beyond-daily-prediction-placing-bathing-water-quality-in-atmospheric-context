# Step 3: first-order circulation storylines — publication revision

This package preserves the supplied four-family mapping and original
transition-perturbation mechanisms. It corrects boundary handling, makes the
experimental windows explicit and adds sensitivity checks and uncertainty
reporting. The original code and supplied outputs are retained in archive/.

## Do we have the necessary data?

Yes for circulation storylines and diagnostic summer rainfall:
- The original classification CSV contains all 2,379 April–September days in
  2012–2024, supplying 2,366 valid within-season next-day pairs.
- The rainfall input contains the 1,940 source-reconstructable SWEW summer dates
  retained in the final Step 1 package. All 20 family–month pools are populated.

The newly attached RAIN_S~1.XLS is an XLSX-format workbook with a misleading
extension. It contains 1,969 May–September records and no April rainfall.
The older fullrange workbook contains 390 processed April rainfall dates,
but their histogram sources have not been verified in this work.

No April rainfall is needed for the circulation generator. This package does
not attach rainfall in April, substitute summer rainfall for April, or
initialise antecedent rainfall/soil-moisture drivers. Those are later-step
requirements. Summer rainfall here is a diagnostic attachment, not the final
multivariate driver sampler.

## Scientific changes from the original

1. Weather runs and switching are calculated within observed seasons, not
   across September-to-April gaps.
2. Monthly transition fitting includes month-boundary pairs and uses the
   origin-day month. The counts are April 390, May 403, June 390, July 403,
   August 403 and September 377.
3. Initialisation uses observed April 1 families, rather than all April days.
   April-occupancy and stationary initialisations are sensitivity cases.
4. April is a 30-day circulation warm-up. Primary diagnostics refer to the
   153-day May–September bathing season. Original 183-day seasonal results
   are therefore not directly numerically comparable.
5. The primary generator is pooled first order, following the earlier finding
   that more complex models were not consistently better. Monthly first
   order is retained as a sensitivity analysis; it is not claimed superior.
6. The original perturbation functions are copied unchanged into code/perturbations.py.
   New code exports the actual matrices and final net changes: sequential
   increments redistribute mass and must not be described as identical to
   the final diagonal changes.
7. All non-settled circulation is labelled non-settled. The separate
   cyclonic/showery fraction is also reported. Neither is observed rainfall
   occurrence or the radar pixel–time wet fraction.
8. Baseline is labelled Baseline simulation. Convective interruptions are
   not assumed to be local storm events.
9. Original 5th–95th ranges were central 90% simulation ranges, not 95%
   confidence intervals. New central 95% ranges and parameter intervals
   are reported separately.
10. All 13 observed summers and held-out baseline checks replace reliance
    on four selected anchor years as evidence of general adequacy.

## Primary experiment

The baseline is fitted on April–September 2012–2024 classifications. Each
storyline generates 5,000 separate 183-day sequences. April is retained in the
export for later use, while this package evaluates May–September only.

Six storyline codes are retained for downstream compatibility, with precise
display labels:
- baseline: Baseline simulation.
- persistent_wet: Cyclonic/showery persistence.
- persistent_dry: Settled favouring.
- dry_with_bursts: Settled with convective interruptions.
- flip_wet_to_dry: Cyclonic/showery → settled.
- flip_dry_to_wet: Settled → cyclonic/showery.

The baseline perturbations retain the original amplitudes: persistence 0.10,
settled-entry 0.07, settled-to-convective 0.12 and convective-to-settled 0.12.
The original wet-component cross-family increment is 0.3 times the persistence
amplitude. These are prescribed probability-mass adjustments, not relative
percentage changes, climate projections or independently calibrated extremes.
Final net matrix changes are exported.

The primary change date remains 1 July. The transition entering that date uses
the late component; monthly matrices are indexed by the origin day.
No actual family switch is forced on that date.

**Timing interpretation:** May–June contains 61 days and July–September 92.
The two opposite transition storylines can differ in both temporal order and
seasonal composition. They are not controlled experiments holding composition
fixed, and outcome differences must not be attributed solely to timing.
June and August change dates are sensitivity cases.

## Sensitivity checks

All use shared random uniforms to reduce Monte Carlo noise in mean differences:
- Perturbation multipliers 0, 0.5, 1 and 1.5.
- Pooled versus monthly first-order matrices.
- Monthly row prior counts kappa=0, 5 and 20. Positive kappa adds that many
  pseudo-observations distributed according to the pooled row. Empty monthly
  rows explicitly fall back to the pooled row.
- Change dates 1 June, 1 July and 1 August.
- April 1, April occupancy and stationary initialisation.
- Both cyclonic/showery and non-settled occupancy definitions are reported.
- A 1,000-season prefix versus the full 5,000-season ensemble is exported as a
  Monte Carlo convergence diagnostic, not an independent validation sample.

The zero-strength storylines coincide exactly with baseline under paired
uniforms. The selected designed effect directions persist across the tested
non-zero configurations. This demonstrates implementation and conditional
sensitivity; directions are partly imposed by design and are not discoveries
of causal effects.

## Uncertainty

**Simulation ranges:** the 2.5th and 97.5th percentiles across the 5,000
simulated seasons describe stochastic seasonal variation conditional on fitted
parameters. They are not confidence intervals or assigned storyline likelihoods.

**Transition-parameter intervals:** 1,000 whole observed April–September
seasons are resampled at the year level, drawing 13 years with replacement
for each refit. Each refitted primary generator is evaluated with 250 paired
inner simulations per storyline. Approximate pointwise percentile intervals
are exported for circulation ensemble means and scenario-minus-baseline
mean differences.

These intervals include finite inner Monte Carlo noise. They assume
approximately exchangeable seasons, condition on the fixed mapping and
prescribed perturbations, and do not include classification construction,
rainfall-pool uncertainty, radar measurement error or climate uncertainty.
The small number of observed years limits interpretation. No significance
stars or p-value tests are used to validate imposed storyline differences.

Common random numbers identify a computational pairing, not matched observed
counterfactual seasons.

## Rainfall attachment

Rainfall is sampled independently conditional on the simulated family and
calendar month from the 1,940 verified summer records. There is no automatic
file discovery, no geographic averaging across other regions, no missing-pool
fallback and no April rainfall sampling.

The regional high-depth-day threshold is the empirical 95th percentile of
the retained daily domain-average depth, with >= used consistently. It is
not an operational heavy-rain threshold, an intensity threshold, or a
microbiological exceedance threshold.

This IID attachment does not preserve rainfall serial dependence, antecedent
catchment wetness, multivariate driver dependence or local storm occurrence.
No parameter confidence intervals are assigned to its rainfall metrics.
Observed comparisons use available-day rainfall fractions and include coverage
counts, rather than treating missing dates as dry.

## Findings and permitted claims

Read results/findings.txt and the manuscript text files for reporting.
Selected circulation responses are directionally stable over the tested
settings. Convective interruptions increase settled–convective transitions;
they do not necessarily increase mean rainfall or the frequency of regional
high-depth days.

The new April-warm-up baseline has its own leave-one-year-out check. It fits
the other 12 April–September seasons, generates full sequences and evaluates
the omitted May–September season. Its conditional pointwise interval counts
are descriptive and not formal simultaneous goodness-of-fit tests.

Perturbation values are exploratory. Neither changed matrices nor selected
anchor overlays establish physical plausibility, reasonable-worst-case
bounds, return periods or scenario probabilities. This step does not validate
modified sequences as physically complete weather, contamination duration,
illness prevention or operational warning performance. It performs no Top-k
alert selection or bathing-water model fitting.

## Files and reproduction

Use Python 3.11 or later:

```bash
python -m pip install -r requirements.txt
python code/test_step3.py
python code/step3.py
python code/report_step3.py
python code/verify_results.py
```

All outputs are already included. The default analysis uses 5,000 seasons,
1,000 transition bootstrap refits and 250 inner simulations per refit; it can
take several minutes. Optional CLI controls are --n-sim, --n-bootstrap and
--inner-sim. Numerical outputs from different settings should not be silently
mixed with the supplied figures.

Key outputs:
- ensemble_summary.csv: all scenario/configuration means and simulation ranges.
- scenario_minus_baseline.csv: paired mean differences and Monte Carlo SEs.
- directional_sensitivity_checks.csv: specific direction checks.
- sensitivity_design.csv: every parameter configuration.
- primary_transition_matrices.csv: pooled component matrices and net changes.
- configured_transition_matrices.csv: actual matrices for every configuration.
- primary_sequences_AprSep.npz: all six primary 5,000 × 183 state arrays;
  state indices 0–3 follow the four families in the supplied mapping.
- primary_individual_seasons.csv: individual 153-day diagnostic metrics.
- transition_bootstrap_means.csv: every refit mean and mean contrast.
- transition_bootstrap_year_weights.csv: the observed-year multiplicities for every refit.
- transition_parameter_intervals.csv: approximate circulation parameter intervals.
- observed_year_metrics.csv: all observed summers and rainfall coverage.
- baseline_heldout_check.csv: the new warm-up baseline evaluation.
- review_and_corrections.csv: audit of the supplied approach.
- manuscript_methods.txt and manuscript_results.txt: copy-ready text.
- findings.txt and metadata.json: interpretations, settings and limits.

Five figure sets are provided as 600 dpi PNG plus PDF/SVG with captions.
They show primary diagnostics, transition-parameter uncertainty, perturbation
strength sensitivity, actual primary matrices and held-out baseline checks.
The code can regenerate them; the original figure uploads were unnecessary.

The active perturbation functions in code/perturbations.py are copied unchanged
from the original supplied script. Archived files are provenance only and are
not active inputs. Output schemas have been revised; retained storyline codes
do not imply automatic compatibility with older downstream scripts.
