import unittest
import numpy as np
from step3 import DATES,SUMMER,fit,annual_counts,matrices,simulate,metrics,attach_rain


class StorylineTests(unittest.TestCase):
    def fixtures(self):
        a=np.tile(np.arange(4),46)[:183]
        return np.stack([a,np.roll(a,1)])

    def test_month_boundaries_are_retained(self):
        c=annual_counts(self.fixtures())
        self.assertEqual(c.sum(),2*182)
        self.assertEqual(c.sum(axis=(0,2,3)).tolist(),[60,62,60,62,62,58])

    def test_summer_metrics_exclude_april(self):
        states=np.zeros((1,183),dtype=int);states[:,SUMMER]=1
        result=metrics(states)
        self.assertEqual(result["days_0"][0],0)
        self.assertEqual(result["days_1"][0],153)
        self.assertEqual(result["maxrun_1"][0],153)

    def test_phase_applies_to_transition_entering_change_date(self):
        p=np.zeros((4,4));p[:,0]=1
        q=np.zeros((4,4));q[:,3]=1
        mats={"flip_component_wet":(p,None),"flip_component_dry":(q,None)}
        result=simulate(mats,np.array([1,0,0,0]),np.full((1,183),.5),"flip_wet_to_dry")
        july=np.flatnonzero(DATES==np.datetime64("2001-07-01"))[0]
        self.assertEqual(result[0,july-1],0);self.assertEqual(result[0,july],3)

    def test_zero_strength_is_identical_under_paired_uniforms(self):
        states=self.fixtures();counts=annual_counts(states)
        po,pm,start=fit(counts,states,np.array([1,1]))
        mat=matrices(po,pm,0)
        u=np.random.default_rng(4).random((20,183))
        baseline=simulate(mat,start,u,"baseline")
        self.assertTrue(np.array_equal(baseline,simulate(mat,start,u,"flip_wet_to_dry")))
        self.assertTrue(np.array_equal(baseline,simulate(mat,start,u,"persistent_dry")))

    def test_no_rainfall_pool_fallback(self):
        with self.assertRaises(KeyError):
            attach_rain(np.zeros((1,183),int),{},np.zeros((1,153)),10.)


if __name__=="__main__":unittest.main(verbosity=2)
