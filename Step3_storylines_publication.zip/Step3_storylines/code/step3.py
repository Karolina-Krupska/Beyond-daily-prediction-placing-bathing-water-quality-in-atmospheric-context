"""First-order circulation storylines: April warm-up, May–September diagnostics.

The supplied transition-perturbation functions are retained, with explicit
season boundaries, prescribed change dates, sensitivity and parameter bootstrap.
Rainfall is a summer-only conditional IID attachment, not an antecedent driver model.
"""
from pathlib import Path
import json
import argparse
import hashlib
import numpy as np
import pandas as pd

import perturbations as old
ROOT=Path(__file__).resolve().parents[1]
GROUPS=old.GROUP_ORDER
STORIES=["baseline","persistent_wet","persistent_dry","dry_with_bursts","flip_wet_to_dry","flip_dry_to_wet"]
LABELS=["Baseline simulation","Cyclonic/showery persistence","Settled favouring",
        "Settled with convective interruptions","Cyclonic/showery → settled","Settled → cyclonic/showery"]
DATES=pd.date_range("2001-04-01","2001-09-30")
MONTHS=DATES.month.to_numpy()
SUMMER=MONTHS>=5


def load(root):
    c=pd.read_csv(root/"data/classifications.csv",comment="#")
    c["date"]=pd.to_datetime(c[["year","month","day"]])
    c=c[c.year.between(2012,2024)&c.month.between(4,9)].sort_values("date").copy()
    if c.date.duplicated().any():raise ValueError("Duplicate weather dates")
    c["state"]=c.regime.map(old.REGIME_TO_GROUP_4).map({g:i for i,g in enumerate(GROUPS)})
    if c.state.isna().any():raise ValueError("Unmapped family")
    years=sorted(c.year.unique())
    arrays=[]
    for year in years:
        d=c[c.year.eq(year)]
        if not np.array_equal(d.date.to_numpy(),pd.date_range(f"{year}-04-01",f"{year}-09-30").to_numpy()):
            raise ValueError("Incomplete April–September weather season")
        arrays.append(d.state.to_numpy(dtype=np.int8))
    rain=pd.read_csv(root/"data/rainfall_MaySep_1940.csv",parse_dates=["date"])
    if len(rain)!=1940 or rain.date.duplicated().any():raise ValueError("Unexpected rainfall input")
    if not np.isfinite(rain.daily_depth_mm).all():raise ValueError("Missing eligible rainfall value")
    check=rain.merge(c[["date","state","regime"]],on="date",validate="one_to_one",suffixes=("","_weather"))
    if not check.regime.eq(check.regime_weather).all():raise ValueError("Rainfall/weather regime mismatch")
    check["state"]=check.state.astype(int)
    return c,np.array(years),np.stack(arrays),check


def annual_counts(states):
    counts=np.zeros((len(states),6,4,4),dtype=int)
    for y,a in enumerate(states):
        np.add.at(counts[y],(MONTHS[:-1]-4,a[:-1],a[1:]),1)
    return counts


def fit(counts,states,weights,mode="overall",kappa=5.,init="first_day"):
    cm=np.einsum("y,ymij->mij",weights,counts)
    co=cm.sum(axis=0)
    if (co.sum(axis=1)==0).any():raise ValueError("Unobserved pooled origin family")
    po=co/co.sum(axis=1,keepdims=True)
    pm={}
    for j,m in enumerate(range(4,10)):
        p=np.empty((4,4))
        for g in range(4):
            total=cm[j,g].sum()
            p[g]=(cm[j,g]+kappa*po[g])/(total+kappa) if total+kappa else po[g]
        pm[m]=p
    if init=="first_day":
        start=np.bincount(states[:,0],weights=weights,minlength=4)
    elif init=="april_occupancy":
        start=np.array([((states[:,:30]==g).sum(axis=1)*weights).sum() for g in range(4)])
    else:start=old.stationary_dist(pm[4] if mode=="monthly" else po)
    start=start/start.sum()
    return po,pm if mode=="monthly" else None,start


def matrices(po,pm,strength):
    return old.make_storyline_matrices(po,pm,pm is not None,list(range(4,10)),
        .10*strength,.12*strength,.12*strength,.07*strength)


def simulate(mats,start,u,story,flip="07-01"):
    n,L=u.shape
    out=np.empty((n,L),dtype=np.int8)
    cumulative=np.cumsum(start);cumulative[-1]=1
    out[:,0]=np.searchsorted(cumulative,u[:,0],side="right")
    flipdate=pd.Timestamp("2001-"+flip)
    for t in range(1,L):
        m=int(MONTHS[t-1])
        if story.startswith("flip_"):
            early="flip_component_wet" if story=="flip_wet_to_dry" else "flip_component_dry"
            late="flip_component_dry" if story=="flip_wet_to_dry" else "flip_component_wet"
            code=early if DATES[t]<flipdate else late
        else:code=story
        po,pm=mats[code]
        p=po if pm is None else pm[m]
        cumulative=np.cumsum(p[out[:,t-1]],axis=1);cumulative[:,-1]=1
        out[:,t]=(u[:,t,None]>=cumulative).sum(axis=1)
    return out


def metrics(states,flip="07-01"):
    x=states[:,SUMMER];n,L=x.shape
    counts=np.stack([(x==g).sum(axis=1) for g in range(4)],axis=1)
    starts=np.r_[True,(x.ravel()[1:]!=x.ravel()[:-1])]
    starts[::L]=True
    indices=np.flatnonzero(starts)
    lengths=np.diff(np.r_[indices,n*L]);row=indices//L;g=x.ravel()[indices]
    maxrun=np.zeros((n,4));nruns=np.zeros((n,4))
    np.maximum.at(maxrun,(row,g),lengths);np.add.at(nruns,(row,g),1)
    out={f"days_{g}":counts[:,g].astype(float) for g in range(4)}
    out.update({f"maxrun_{g}":maxrun[:,g] for g in range(4)})
    out["switching_rate"]=(x[:,1:]!=x[:,:-1]).mean(axis=1)
    out["convective_runs"]=nruns[:,2]
    out["mean_convective_run"]=np.divide(counts[:,2],nruns[:,2],out=np.full(n,np.nan),where=nruns[:,2]>0)
    out["settled_to_convective"]=((x[:,:-1]==3)&(x[:,1:]==2)).sum(axis=1).astype(float)
    out["convective_to_settled"]=((x[:,:-1]==2)&(x[:,1:]==3)).sum(axis=1).astype(float)
    dates=DATES[SUMMER];before=dates<pd.Timestamp("2001-"+flip)
    for label,validstates in [("cyclonic_showery",[0,1]),("nonsettled",[0,1,2])]:
        occupied=np.isin(x,validstates)
        out[label+"_fraction"]=occupied.mean(axis=1)
        out[label+"_before"]=occupied[:,before].mean(axis=1)
        out[label+"_after"]=occupied[:,~before].mean(axis=1)
        out[label+"_before_minus_after"]=out[label+"_before"]-out[label+"_after"]
    return out


def pools(rain):
    result={}
    for g in range(4):
        for m in range(5,10):
            vals=rain.loc[rain.state.eq(g)&rain.month.eq(m),"daily_depth_mm"].to_numpy()
            if not len(vals):raise ValueError(f"Missing summer rainfall pool: family{g}, month{m}")
            result[g,m]=np.sort(vals)
    return result


def attach_rain(states,pool,u,threshold,flip="07-01"):
    x=states[:,SUMMER];n,L=x.shape
    rain=np.empty((n,L))
    for t,m in enumerate(MONTHS[SUMMER]):
        for g in range(4):
            select=x[:,t]==g;vals=pool[g,int(m)]
            rain[select,t]=vals[np.minimum((u[select,t]*len(vals)).astype(int),len(vals)-1)]
    before=DATES[SUMMER]<pd.Timestamp("2001-"+flip)
    return {"rain_mean":rain.mean(axis=1),"rain_before":rain[:,before].mean(axis=1),
        "rain_after":rain[:,~before].mean(axis=1),
        "rain_before_minus_after":rain[:,before].mean(axis=1)-rain[:,~before].mean(axis=1),
        "heavy_rain_fraction":(rain>=threshold).mean(axis=1)}


def summaries(values,story,config):
    rows=[]
    for key,v in values.items():
        valid=v[np.isfinite(v)]
        rows.append({"configuration":config,"storyline":story,"metric":key,
            "mean":valid.mean() if len(valid) else np.nan,
            "simulation_p025":np.quantile(valid,.025) if len(valid) else np.nan,
            "simulation_p975":np.quantile(valid,.975) if len(valid) else np.nan,
            "n_defined":len(valid)})
    return rows


def run(root=ROOT,n=5000,n_boot=1000,n_inner=250,seed=42):
    root=Path(root);out=root/"results";out.mkdir(exist_ok=True,parents=True)
    c,years,states,rain=load(root);counts=annual_counts(states);w=np.ones(len(years),int)
    assert counts.sum()==2366
    assert counts.sum(axis=(0,2,3)).tolist()==[390,403,390,403,403,377]
    pool=pools(rain);threshold=float(rain.daily_depth_mm.quantile(.95))
    rng=np.random.default_rng(seed)
    u=rng.random((n,183));ur=rng.random((n,153))
    configs=[("primary",1.,"overall",5.,"07-01","first_day"),
             ("strength_zero",0.,"overall",5.,"07-01","first_day"),
             ("strength_half",.5,"overall",5.,"07-01","first_day"),
             ("strength_high",1.5,"overall",5.,"07-01","first_day"),
             ("monthly_k5",1.,"monthly",5.,"07-01","first_day"),
             ("monthly_k0",1.,"monthly",0.,"07-01","first_day"),
             ("monthly_k20",1.,"monthly",20.,"07-01","first_day"),
             ("flip_June",1.,"overall",5.,"06-01","first_day"),
             ("flip_August",1.,"overall",5.,"08-01","first_day"),
             ("initial_occupancy",1.,"overall",5.,"07-01","april_occupancy"),
             ("initial_stationary",1.,"overall",5.,"07-01","stationary")]
    allrows=[];differences=[];primary={};sequence_export={};matrixrows=[];configured=[]
    for name,strength,mode,kappa,flip,init in configs:
        po,pm,start=fit(counts,states,w,mode,kappa,init);mat=matrices(po,pm,strength)
        for component,(p,mp) in mat.items():
            entries={"pooled_summary":p} if mp is None else {str(m):v for m,v in mp.items()}
            for month,matrix in entries.items():
                if not np.isfinite(matrix).all() or (matrix<0).any() or not np.allclose(matrix.sum(axis=1),1):
                    raise AssertionError("Invalid transition matrix")
                reference=po if mp is None else pm[int(month)]
                for i in range(4):
                    for j in range(4):configured.append({"configuration":name,"component":component,"month":month,
                        "from_state":i,"to_state":j,"probability":matrix[i,j],"baseline_probability":reference[i,j],
                        "net_change":matrix[i,j]-reference[i,j]})
        base=None
        for story in STORIES:
            seq=simulate(mat,start,u,story,flip);vals=metrics(seq,flip)
            vals.update(attach_rain(seq,pool,ur,threshold,flip))
            allrows.extend(summaries(vals,story,name))
            if story=="baseline":base=vals
            else:
                for key,v in vals.items():
                    delta=v-base[key];valid=delta[np.isfinite(delta)]
                    differences.append({"configuration":name,"storyline":story,"metric":key,
                        "mean_difference":valid.mean(),"monte_carlo_se":valid.std(ddof=1)/np.sqrt(len(valid))})
                    if strength==0 and not np.allclose(delta,0,equal_nan=True):raise AssertionError("Zero-strength null failed")
            if name=="primary":
                primary[story]=vals;sequence_export[story]=seq
                for code,(p,_) in mat.items():
                    if story=="baseline":
                        for i in range(4):
                            for j in range(4):matrixrows.append({"storyline_component":code,"from_family":GROUPS[i],
                                "to_family":GROUPS[j],"probability":p[i,j],"baseline_probability":po[i,j],
                                "net_change":p[i,j]-po[i,j]})
        print("Completed sensitivity:",name,flush=True)
    pd.DataFrame(allrows).to_csv(out/"ensemble_summary.csv",index=False)
    pd.DataFrame(differences).to_csv(out/"scenario_minus_baseline.csv",index=False)
    pd.DataFrame(matrixrows).to_csv(out/"primary_transition_matrices.csv",index=False)
    pd.DataFrame(configured).to_csv(out/"configured_transition_matrices.csv",index=False)
    np.savez_compressed(out/"primary_sequences_AprSep.npz",**sequence_export,month=MONTHS)
    seasons=[];convergence=[]
    for story,vals in primary.items():
        d=pd.DataFrame(vals);d.insert(0,"simulation_id",np.arange(n));d.insert(0,"storyline",story);seasons.append(d)
        for key,v in vals.items():
            prefix=v[:min(1000,n)]
            convergence.append({"storyline":story,"metric":key,"prefix_n":len(prefix),"full_n":n,
                "prefix_mean":np.nanmean(prefix),"full_mean":np.nanmean(v),
                "full_mean_mc_se":np.nanstd(v,ddof=1)/np.sqrt(np.isfinite(v).sum())})
    pd.concat(seasons,ignore_index=True).to_csv(out/"primary_individual_seasons.csv",index=False)
    pd.DataFrame(convergence).to_csv(out/"monte_carlo_convergence.csv",index=False)
    pd.DataFrame([{ "configuration":a,"strength":b,"transition_mode":d,"monthly_prior_count":e,
                   "change_date":f,"initialisation":g} for a,b,d,e,f,g in configs]).to_csv(out/"sensitivity_design.csv",index=False)
    # All observed years, not selected anchors. Coverage is explicit for rainfall.
    observed=metrics(states)
    obsrows=[]
    for y,year in enumerate(years):
        d=rain[rain.year.eq(year)];before=d.date.dt.month.lt(7)
        row={"year":int(year),"rainfall_days_available":len(d),"summer_calendar_days":153,
             "rainfall_days_before":int(before.sum()),"rainfall_days_after":int((~before).sum()),
             "calendar_days_before":61,"calendar_days_after":92}
        row.update({key:vals[y] for key,vals in observed.items()})
        row.update({"rain_mean":d.daily_depth_mm.mean(),"heavy_rain_fraction":d.daily_depth_mm.ge(threshold).mean(),
                    "rain_before":d.loc[before,"daily_depth_mm"].mean(),"rain_after":d.loc[~before,"daily_depth_mm"].mean()})
        obsrows.append(row)
    pd.DataFrame(obsrows).to_csv(out/"observed_year_metrics.csv",index=False)
    # Fit uncertainty: whole years are resampled. Inner simulation noise is retained and disclosed.
    bootrng=np.random.default_rng(seed+100);bootrows=[];bootweights=[]
    for b in range(n_boot):
        draw=bootrng.integers(0,len(years),len(years));weights=np.bincount(draw,minlength=len(years))
        bootweights.append([b,*weights.tolist()])
        po,pm,start=fit(counts,states,weights);mat=matrices(po,pm,1.)
        ub=bootrng.random((n_inner,183));base=None
        for story in STORIES:
            vals=metrics(simulate(mat,start,ub,story))
            means={key:np.nanmean(v) for key,v in vals.items()}
            if story=="baseline":base=means
            for key,mean in means.items():bootrows.append({"replicate":b,"storyline":story,"metric":key,
                "ensemble_mean":mean,"mean_difference_from_baseline":mean-base[key]})
        if (b+1)%100==0:print("Bootstrap fits:",b+1,flush=True)
    boots=pd.DataFrame(bootrows);boots.to_csv(out/"transition_bootstrap_means.csv",index=False)
    pd.DataFrame(bootweights,columns=["replicate",*map(str,years)]).to_csv(out/"transition_bootstrap_year_weights.csv",index=False)
    ci=[]
    for (story,key),d in boots.groupby(["storyline","metric"],sort=False):
        means=d.ensemble_mean.to_numpy();diff=d.mean_difference_from_baseline.to_numpy()
        target=np.nanmean(primary[story][key]);baseline=np.nanmean(primary["baseline"][key])
        ci.append({"storyline":story,"metric":key,"estimate":target,
            "parameter_ci_lower":np.quantile(means,.025),"parameter_ci_upper":np.quantile(means,.975),
            "difference_estimate":target-baseline,"difference_ci_lower":np.quantile(diff,.025),
            "difference_ci_upper":np.quantile(diff,.975),"n_bootstrap":n_boot})
    pd.DataFrame(ci).to_csv(out/"transition_parameter_intervals.csv",index=False)
    # New April-warm-up baseline has its own held-out check; earlier Step 2 did not validate April.
    held=[]
    for k,year in enumerate(years):
        weights=np.ones(len(years),int);weights[k]=0
        po,pm,start=fit(counts,states,weights);mat=matrices(po,pm,0)
        ug=np.random.default_rng(seed+200+int(year)).random((n,183))
        sim=metrics(simulate(mat,start,ug,"baseline"))
        for key,vals in sim.items():
            vals=vals[np.isfinite(vals)];low,high=np.quantile(vals,[.025,.975]);ob=observed[key][k]
            held.append({"heldout_year":int(year),"metric":key,"observed":ob,"simulation_low":low,
                "simulation_high":high,"inside":bool(low<=ob<=high),"n_defined":len(vals)})
    pd.DataFrame(held).to_csv(out/"baseline_heldout_check.csv",index=False)
    metadata={"fit_window":"April–September 2012–2024","weather_days":len(c),"transition_pairs":int(counts.sum()),
        "simulation_days":183,"April_warmup_days":30,"analysis_window":"May–September;153 days",
        "primary_model":"Pooled first-order; monthly first-order is a sensitivity analysis",
        "initialisation":"Observed April 1 states, not all April days",
        "phase_rule":"Transition entering the change date uses the late component; baseline month is origin month",
        "n_simulations":n,"seed":seed,"n_transition_bootstrap":n_boot,"inner_simulations_per_bootstrap":n_inner,
        "rainfall_records":len(rain),"rainfall_pools":len(pool),"rainfall_april_used":False,
        "heavy_threshold_quantile":.95,"heavy_threshold_mm":threshold,"heavy_operator":">=",
        "uncertainty":{"simulation_ranges":"Central95% (2.5–97.5), conditional on fitted matrix and empirical rainfall pools",
            "parameter_intervals":"Approximate pointwise percentile intervals of mean circulation metrics;13-season bootstrap; finite inner Monte Carlo noise included",
            "rainfall_intervals":"Simulation ranges only; no confidence intervals for empirical rainfall-pool uncertainty",
            "paired_contrasts":"Common random numbers reduce Monte Carlo noise; not matched observed counterfactual seasons"},
        "limits":["Fixed family mapping; no classification-construction or radar-measurement uncertainty",
            "13 seasons treated approximately exchangeable; no modelled between-year dependence or trends",
            "Storylines are prescribed stress tests, not probabilistic forecasts or assigned scenario likelihoods",
            "Convective family occurrence is not proof of a local storm; non-settled is not observed wetness",
            "IID family-month rainfall sampling does not preserve rainfall serial dependence or catchment memory",
            "No April rainfall or antecedent-driver initialisation is provided by this step",
            "All conclusions refer to circulation and diagnostic summer rain, not contamination/advisory duration"],
        "input_hashes":{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/"data/classifications.csv",root/"data/rainfall_MaySep_1940.csv"]}}
    (out/"metadata.json").write_text(json.dumps(metadata,indent=2)+"\n")
    print("Completed Step 3",flush=True)


if __name__=="__main__":
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root",type=Path,default=ROOT);ap.add_argument("--n-sim",type=int,default=5000)
    ap.add_argument("--n-bootstrap",type=int,default=1000);ap.add_argument("--inner-sim",type=int,default=250)
    a=ap.parse_args();run(a.root,a.n_sim,a.n_bootstrap,a.inner_sim)
