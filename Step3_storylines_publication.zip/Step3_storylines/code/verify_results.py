"""Check saved Step 3 outputs and independently reconstruct selected runs."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from step3 import ROOT,STORIES,load,annual_counts,SUMMER,fit,matrices,simulate,metrics


def verify(root=ROOT):
    root=Path(root);r=root/"results";meta=json.loads((r/"metadata.json").read_text())
    weather,years,states,rain=load(root)
    counts=annual_counts(states)
    assert len(weather)==2379 and counts.sum()==2366 and len(rain)==1940
    assert counts.sum(axis=(0,2,3)).tolist()==[390,403,390,403,403,377]
    individual=pd.read_csv(r/"primary_individual_seasons.csv")
    assert len(individual)==6*meta["n_simulations"]
    assert np.array_equal(individual[[f"days_{g}" for g in range(4)]].sum(axis=1),np.full(len(individual),153))
    with np.load(r/"primary_sequences_AprSep.npz",allow_pickle=False) as data:
        for story in STORIES:
            seq=data[story];assert seq.shape==(meta["n_simulations"],183)
            saved=individual[individual.storyline.eq(story)].set_index("simulation_id")
            for i in [0,min(42,len(seq)-1),len(seq)-1]:
                x=seq[i,SUMMER];runs={g:[] for g in range(4)}
                previous=int(x[0]);length=1
                for state in x[1:]:
                    if state==previous:length+=1
                    else:runs[previous].append(length);previous=int(state);length=1
                runs[previous].append(length)
                for g in range(4):
                    assert saved.loc[i,f"days_{g}"]==int((x==g).sum())
                    assert saved.loc[i,f"maxrun_{g}"]==max(runs[g],default=0)
                assert np.isclose(saved.loc[i,"switching_rate"],sum(a!=b for a,b in zip(x,x[1:]))/152)
    allmats=pd.read_csv(r/"configured_transition_matrices.csv")
    assert allmats.probability.ge(0).all() and allmats.probability.le(1).all()
    assert np.allclose(allmats.groupby(["configuration","component","month","from_state"]).probability.sum(),1)
    summary=pd.read_csv(r/"ensemble_summary.csv")
    null=summary[summary.configuration.eq("strength_zero")]
    for metric,d in null.groupby("metric"):
        assert np.allclose(d["mean"],d["mean"].iloc[0],equal_nan=True),metric
    primary=summary[summary.configuration.eq("primary")].set_index(["storyline","metric"])
    boots=pd.read_csv(r/"transition_bootstrap_means.csv")
    weights=pd.read_csv(r/"transition_bootstrap_year_weights.csv")
    assert len(weights)==meta["n_transition_bootstrap"]
    assert weights.drop(columns="replicate").sum(axis=1).eq(len(years)).all()
    rng=np.random.default_rng(meta["seed"]+100)
    for b in range(2):
        draw=rng.integers(0,len(years),len(years));expected=np.bincount(draw,minlength=len(years))
        assert np.array_equal(expected,weights.iloc[b,1:].to_numpy())
        ub=rng.random((meta["inner_simulations_per_bootstrap"],183))
        po,pm,start=fit(counts,states,expected);mat=matrices(po,pm,1.)
        for story in ["baseline","persistent_wet","flip_dry_to_wet"]:
            vals=metrics(simulate(mat,start,ub,story))
            for key in ["days_0","maxrun_0","cyclonic_showery_before_minus_after"]:
                stored=boots.loc[boots.replicate.eq(b)&boots.storyline.eq(story)&boots.metric.eq(key),"ensemble_mean"].iloc[0]
                assert np.isclose(np.nanmean(vals[key]),stored)
    cis=pd.read_csv(r/"transition_parameter_intervals.csv")
    for _,a in cis.iterrows():
        d=boots[boots.storyline.eq(a.storyline)&boots.metric.eq(a.metric)]
        assert d.replicate.nunique()==meta["n_transition_bootstrap"]
        assert np.allclose(np.quantile(d.ensemble_mean,[.025,.975]),[a.parameter_ci_lower,a.parameter_ci_upper])
        assert np.allclose(np.quantile(d.mean_difference_from_baseline,[.025,.975]),[a.difference_ci_lower,a.difference_ci_upper])
        assert np.isclose(a.estimate,primary.loc[(a.storyline,a.metric),"mean"])
    observed=pd.read_csv(r/"observed_year_metrics.csv")
    assert observed.rainfall_days_available.sum()==1940 and observed.summer_calendar_days.eq(153).all()
    assert meta["rainfall_april_used"] is False
    print("Verified: 2,379 weather days / 2,366 origin-month pairs / 1,940 rainfall dates;")
    print("153-day sums, selected run lengths and switching reconstructed independently;")
    print("all transition rows, zero-strength null, bootstrap interval limits and rainfall coverage checked.")


if __name__=="__main__":verify()
