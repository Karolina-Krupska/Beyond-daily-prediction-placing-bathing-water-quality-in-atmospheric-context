"""Original perturbation functions retained unchanged from the supplied Step 3 script."""

from __future__ import annotations

from typing import Dict,List,Tuple,Optional

import numpy as np

REGIME_TO_GROUP_4: Dict[int, str] = {
    1: "Cyclonic Atlantic (frontal)",
    2: "Showery maritime / unsettled",
    3: "Convective extremes",
    4: "Showery maritime / unsettled",
    5: "Cyclonic Atlantic (frontal)",
    6: "Convective extremes",
    7: "Cyclonic Atlantic (frontal)",
    8: "Cyclonic Atlantic (frontal)",
    9: "Convective extremes",
    10: "Convective extremes",
    11: "Cyclonic Atlantic (frontal)",
    12: "Convective extremes",
    13: "Settled anticyclonic quiet",
    14: "Showery maritime / unsettled",
    15: "Showery maritime / unsettled",
    16: "Convective extremes",
    17: "Convective extremes",
    18: "Convective extremes",
    19: "Cyclonic Atlantic (frontal)",
    20: "Showery maritime / unsettled",
    21: "Cyclonic Atlantic (frontal)",
    22: "Cyclonic Atlantic (frontal)",
    23: "Settled anticyclonic quiet",
    24: "Cyclonic Atlantic (frontal)",
    25: "Settled anticyclonic quiet",
    26: "Showery maritime / unsettled",
    27: "Convective extremes",
    28: "Cyclonic Atlantic (frontal)",
    29: "Cyclonic Atlantic (frontal)",
    30: "Cyclonic Atlantic (frontal)",
}

GROUP_ORDER = [
    "Cyclonic Atlantic (frontal)",
    "Showery maritime / unsettled",
    "Convective extremes",
    "Settled anticyclonic quiet",
]

def safe_renormalize_row(row: np.ndarray) -> np.ndarray:
    row = np.clip(row, 0.0, None)
    s = row.sum()
    if s <= 0:
        return np.ones_like(row) / len(row)
    return row / s

def boost_diagonal(P: np.ndarray, idx: int, delta: float) -> np.ndarray:
    """Increase P[idx, idx] by delta and take mass proportionally from other cols."""
    P2 = P.copy()
    n = P.shape[1]
    delta = float(delta)
    if delta <= 0:
        return P2
    non_diag = [j for j in range(n) if j != idx]
    available = P2[idx, non_diag].sum()
    if available <= 1e-12:
        return P2
    take = min(delta, available)
    P2[idx, non_diag] *= (available - take) / available
    P2[idx, idx] += take
    P2[idx, :] = safe_renormalize_row(P2[idx, :])
    return P2

def boost_transition(P: np.ndarray, i: int, j: int, delta: float) -> np.ndarray:
    """Increase P[i, j] by delta and take mass proportionally from other destinations (excluding j)."""
    P2 = P.copy()
    n = P.shape[1]
    delta = float(delta)
    if delta <= 0:
        return P2
    others = [k for k in range(n) if k != j]
    available = P2[i, others].sum()
    if available <= 1e-12:
        return P2
    take = min(delta, available)
    P2[i, others] *= (available - take) / available
    P2[i, j] += take
    P2[i, :] = safe_renormalize_row(P2[i, :])
    return P2

def stationary_dist(P: np.ndarray, tol: float = 1e-12, max_iter: int = 10000) -> np.ndarray:
    """Compute stationary distribution for a row-stochastic Markov matrix P."""
    n = P.shape[0]
    x = np.ones(n) / n
    for _ in range(max_iter):
        x2 = x @ P
        if np.max(np.abs(x2 - x)) < tol:
            return safe_renormalize_row(x2)
        x = x2
    return safe_renormalize_row(x)

def make_storyline_matrices(
    baseline_overall: np.ndarray,
    baseline_monthly: Optional[Dict[int, np.ndarray]],
    use_monthly: bool,
    months: List[int],
    delta_persist: float,
    delta_burst: float,
    delta_return: float,
    delta_dry_entry: Optional[float] = None,
) -> Dict[str, Tuple[np.ndarray, Optional[Dict[int, np.ndarray]]]]:
    """
    Build perturbed transition matrices for storylines.

    delta_dry_entry controls the strength of "entry" into Settled from other states in the dry storylines.
    If None, it defaults to 0.7*delta_persist.

    Returns a dict mapping storyline codes to (P_overall, P_monthly_or_None).
    Also returns two component matrices used for two-phase seasons:
      - flip_component_wet: persistence boosted for Cyclonic + Showery
      - flip_component_dry: persistence boosted for Settled
    """
    idx = {name: i for i, name in enumerate(GROUP_ORDER)}
    i_cyc = idx["Cyclonic Atlantic (frontal)"]
    i_show = idx["Showery maritime / unsettled"]
    i_conv = idx["Convective extremes"]
    i_set = idx["Settled anticyclonic quiet"]

    def apply_to_matrix(P: np.ndarray, fn) -> np.ndarray:
        P2 = fn(P.copy())
        for r in range(P2.shape[0]):
            P2[r] = safe_renormalize_row(P2[r])
        return P2

    def per_month_apply(fn):
        if not use_monthly or baseline_monthly is None:
            return None
        return {m: apply_to_matrix(baseline_monthly[m], fn) for m in months}

    story: Dict[str, Tuple[np.ndarray, Optional[Dict[int, np.ndarray]]]] = {}

    # 1) Observed transition (baseline)
    story["baseline"] = (
        baseline_overall.copy(),
        {m: baseline_monthly[m].copy() for m in months} if (use_monthly and baseline_monthly) else None,
    )

    # Helper perturbations
    def fn_wet(P):
        # Boost persistence in Cyclonic and Showery, and encourage swapping within wet family
        P = boost_diagonal(P, i_cyc, delta_persist)
        P = boost_diagonal(P, i_show, delta_persist)
        P = boost_transition(P, i_cyc, i_show, delta_persist * 0.3)
        P = boost_transition(P, i_show, i_cyc, delta_persist * 0.3)
        return P

    def fn_dry(P):
        # Option B dry storyline: shift toward anticyclonic dominance by increasing BOTH:
        #  (i) persistence of Settled (stay Settled once there), and
        #  (ii) transitions INTO Settled from other states (enter Settled more often).
        P = boost_diagonal(P, i_set, delta_persist)

        entry = (0.7 * delta_persist) if (delta_dry_entry is None) else float(delta_dry_entry)
        # Pull probability mass toward Settled from the other states.
        # Strongest for Cyclonic and Showery; weaker for Convective.
        P = boost_transition(P, i_cyc, i_set, entry)
        P = boost_transition(P, i_show, i_set, entry)
        P = boost_transition(P, i_conv, i_set, 0.5 * entry)
        return P

    def fn_dry_with_bursts(P):
        # Start from the dry-dominant matrix, then increase Settled→Convective bursts.
        P = fn_dry(P)
        # Storm outbreaks: encourage breakdown from Settled to Convective, and quick return to Settled.
        P = boost_transition(P, i_set, i_conv, delta_burst)
        P = boost_transition(P, i_conv, i_set, delta_return)
        return P

    # 2) Persistent wet
    story["persistent_wet"] = (apply_to_matrix(baseline_overall, fn_wet), per_month_apply(fn_wet))

    # 3) Persistent dry
    story["persistent_dry"] = (apply_to_matrix(baseline_overall, fn_dry), per_month_apply(fn_dry))

    # 4) Dry with storm outbreaks
    story["dry_with_bursts"] = (apply_to_matrix(baseline_overall, fn_dry_with_bursts), per_month_apply(fn_dry_with_bursts))

    # Components for two-phase seasons
    story["flip_component_wet"] = (apply_to_matrix(baseline_overall, fn_wet), per_month_apply(fn_wet))
    story["flip_component_dry"] = (apply_to_matrix(baseline_overall, fn_dry), per_month_apply(fn_dry))

    return story
