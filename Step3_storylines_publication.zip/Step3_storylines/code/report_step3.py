"""Tables, figures and interpretations from the completed Step 3 outputs."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from step3 import ROOT,GROUPS,STORIES,LABELS,load,annual_counts,fit,matrices,simulate,metrics

SHORT=["Baseline","Cyclonic/showery\npersistence","Settled\nfavouring","Convective\ninterruptions","Cyclonic/showery\n→ settled","Settled →\ncyclonic/showery"]
COLOURS=["#0072B2","#009E73","#D55E00","#777777"]


def report(root=ROOT):
    root=Path(root);r=root/"results";f=root/"figures";f.mkdir(exist_ok=True)
    summary=pd.read_csv(r/"ensemble_summary.csv")
    delta=pd.read_csv(r/"scenario_minus_baseline.csv")
    ci=pd.read_csv(r/"transition_parameter_intervals.csv")
    meta=json.loads((r/"metadata.json").read_text())
    primary=summary[summary.configuration.eq("primary")].set_index(["storyline","metric"])
    ciindex=ci.set_index(["storyline","metric"])
    plt.rcParams.update({"font.size":8,"pdf.fonttype":42,"svg.fonttype":"none"})

    def save(fig,name,caption):
        for ext in ["png","pdf","svg"]:fig.savefig(f/f"{name}.{ext}",dpi=600)
        plt.close(fig);(f/f"{name}_caption.txt").write_text(caption+"\n",encoding="utf-8")

    def errorpoints(ax,metric,offset=0,colour="#0072B2",label=None):
        table=primary.xs(metric,level="metric").reindex(STORIES)
        x=np.arange(6)+offset
        ax.vlines(x,table.simulation_p025,table.simulation_p975,color=colour,lw=1)
        ax.scatter(x,table["mean"],color=colour,s=18,label=label,zorder=3)

    def labels(ax):
        ax.set_xticks(np.arange(6),SHORT,rotation=28,ha="right",fontsize=7)
        ax.spines[["top","right"]].set_visible(False);ax.grid(axis="y",alpha=.15)

    fig,axes=plt.subplots(2,2,figsize=(8,7.8));x=np.arange(6);bottom=np.zeros(6)
    for g in range(4):
        vals=primary.xs(f"days_{g}",level="metric").reindex(STORIES)["mean"].to_numpy()
        axes[0,0].bar(x,vals,bottom=bottom,color=COLOURS[g],label=GROUPS[g]);bottom+=vals
    axes[0,0].set_ylabel("Days, May–September");axes[0,0].set_ylim(0,153);axes[0,0].set_title("a  Mean circulation composition")
    errorpoints(axes[0,1],"maxrun_0",-.10,COLOURS[0],"Cyclonic")
    errorpoints(axes[0,1],"maxrun_3",.10,COLOURS[3],"Settled")
    axes[0,1].set_ylabel("Maximum family run (days)");axes[0,1].set_title("b  Maximum runs");axes[0,1].legend(fontsize=7)
    errorpoints(axes[1,0],"switching_rate");axes[1,0].set_ylim(0,1)
    axes[1,0].set_ylabel("Proportion of next-day transitions");axes[1,0].set_title("c  Switching")
    errorpoints(axes[1,1],"cyclonic_showery_before",-.1,COLOURS[0],"May–June")
    errorpoints(axes[1,1],"cyclonic_showery_after",.1,COLOURS[1],"July–September")
    axes[1,1].set_ylim(0,1);axes[1,1].set_ylabel("Cyclonic/showery fraction")
    axes[1,1].set_title("d  Timing around 1 July");axes[1,1].legend(fontsize=7)
    for ax in axes.ravel():labels(ax)
    handles,labs=axes[0,0].get_legend_handles_labels()
    fig.legend(handles,labs,loc="lower center",ncol=2,frameon=False,fontsize=7)
    fig.tight_layout(rect=(0,.065,1,1))
    save(fig,"storyline_diagnostics","Circulation storyline diagnostics for May–September after an April warm-up. "
         f"Bars show mean composition; points show ensemble means and lines central 95% simulation ranges from {meta['n_simulations']:,} seasons. "
         "These are not confidence intervals. The timing panels describe cyclonic/showery circulation occupancy, not measured wet days. "
         "Primary simulations use the pooled first-order baseline and a 1 July prescribed change date.")

    fig,axes=plt.subplots(2,2,figsize=(8,7.4))
    for ax,key,title,unit in zip(axes.ravel(),["days_0","days_3","maxrun_0","cyclonic_showery_before_minus_after"],
        ["a  Cyclonic days","b  Settled days","c  Maximum cyclonic run","d  Circulation timing balance"],
        ["Difference in days","Difference in days","Difference in days","Difference in early–late fraction"]):
        d=ciindex.xs(key,level="metric").reindex(STORIES)
        ax.axhline(0,color="black",lw=.7)
        ax.vlines(x,d.difference_ci_lower,d.difference_ci_upper,color=COLOURS[0])
        ax.scatter(x,d.difference_estimate,color=COLOURS[0],s=20)
        ax.set_title(title);ax.set_ylabel(unit);labels(ax)
    fig.tight_layout()
    save(fig,"transition_parameter_uncertainty","Storyline-minus-baseline differences in ensemble-mean circulation metrics. "
         f"Lines show approximate pointwise 95% percentile intervals from {meta['n_transition_bootstrap']:,} whole-season transition refits, each estimated "
         f"using {meta['inner_simulations_per_bootstrap']:,} paired simulations per storyline. Intervals include finite inner Monte Carlo noise and condition on "
         "the fixed family mapping and prescribed perturbations. They are not probabilities of the storylines or tests of a physical causal effect.")

    fig,axes=plt.subplots(2,2,figsize=(8,7.3))
    for ax,key,title,unit in zip(axes.ravel(),["days_0","days_3","settled_to_convective","cyclonic_showery_before_minus_after"],
        ["a  Cyclonic persistence scenario","b  Settled-favouring scenario","c  Convective-interruption scenario","d  Timing scenarios"],
        ["Cyclonic-day difference","Settled-day difference","Settled → convective count difference","Early–late fraction difference"]):
        stories=["persistent_wet"] if key=="days_0" else ["persistent_dry"] if key=="days_3" else ["dry_with_bursts"] if key=="settled_to_convective" else ["flip_wet_to_dry","flip_dry_to_wet"]
        for k,story in enumerate(stories):
            d=delta[delta.metric.eq(key)&delta.storyline.eq(story)].set_index("configuration")
            names=["strength_zero","strength_half","primary","strength_high"]
            ax.plot([0,.5,1,1.5],d.loc[names,"mean_difference"],marker="o",label=LABELS[STORIES.index(story)],color=COLOURS[k])
        ax.axhline(0,color="black",lw=.6);ax.set_xlabel("Multiplier of prescribed perturbations");ax.set_ylabel(unit);ax.set_title(title)
        ax.spines[["top","right"]].set_visible(False);ax.grid(alpha=.15)
        if len(stories)>1:ax.legend(fontsize=6)
    fig.tight_layout()
    save(fig,"perturbation_strength_sensitivity","Sensitivity of selected mean storyline-minus-baseline differences to common perturbation-strength multipliers. "
         "The zero-strength cases coincide exactly with baseline under shared random numbers. These curves assess implementation and "
         "response to prescribed changes; they do not calibrate physical plausibility or scenario likelihood.")

    mats=pd.read_csv(r/"primary_transition_matrices.csv")
    fig,axes=plt.subplots(2,2,figsize=(6.7,6.0))
    for ax,code,title in zip(axes.ravel(),STORIES[:4],LABELS[:4]):
        d=mats[mats.storyline_component.eq(code)]
        arr=d.pivot(index="from_family",columns="to_family",values="probability").reindex(index=GROUPS,columns=GROUPS).to_numpy()
        im=ax.imshow(arr,vmin=0,vmax=1,cmap="cividis")
        for i in range(4):
            for j in range(4):ax.text(j,i,f"{arr[i,j]:.2f}",ha="center",va="center",color="white" if arr[i,j]<.4 else "black",fontsize=8)
        ax.set_xticks(range(4),["CA","SM","CE","SA"]);ax.set_yticks(range(4),["CA","SM","CE","SA"]);ax.set_title(title,fontsize=9)
        ax.set_xlabel("Next family");ax.set_ylabel("Current family")
    fig.tight_layout()
    save(fig,"primary_transition_matrices","Actual pooled transition matrices used in the primary simulations. Rows denote current and columns next-day family. "
         "CA: Cyclonic Atlantic; SM: Showery maritime; CE: Convective extremes; SA: Settled anticyclonic. "
         "Two-phase scenarios use the cyclonic/showery and settled-favouring components in opposite order. "
         "Sequential perturbations redistribute probability mass; final net changes are exported explicitly.")

    h=pd.read_csv(r/"baseline_heldout_check.csv")
    fig,axes=plt.subplots(2,2,figsize=(8,5.6))
    for ax,key,title in zip(axes.ravel(),["days_0","days_3","maxrun_0","maxrun_2"],
        ["a  Cyclonic days","b  Settled days","c  Maximum cyclonic run","d  Maximum convective run"]):
        d=h[h.metric.eq(key)].sort_values("heldout_year")
        ax.fill_between(d.heldout_year,d.simulation_low,d.simulation_high,color=COLOURS[0],alpha=.18,label="95% simulation range")
        ax.plot(d.heldout_year,d.observed,"o-",color="black",lw=.6,ms=3,label="Observed")
        ax.set_title(title);ax.set_ylabel("Days");ax.set_xticks([2012,2016,2020,2024]);ax.spines[["top","right"]].set_visible(False)
    handles,labs=axes[0,0].get_legend_handles_labels();fig.legend(handles,labs,loc="lower center",ncol=2,frameon=False)
    fig.tight_layout(rect=(0,.06,1,1))
    save(fig,"baseline_heldout_check","Held-out checks of the pooled April–September baseline with April warm-up and May–September evaluation. "
         "Each band is the pointwise 95% simulation range after fitting the other 12 years. Parameters are fixed within each held-out simulation. "
         "These comparisons do not validate perturbed scenarios, rainfall dependence or contamination duration.")

    # Machine-readable audit of the original approach and exact available input coverage.
    audits=[
        ("Observed switching and run summaries","Original computed these on concatenated years","Calculate each observed summer separately; exclude seasonal gaps"),
        ("Monthly transition fitting","Original excluded all cross-month pairs","Use origin-month pairs; 2,366 April–September pairs including 65 month-boundary pairs"),
        ("Starting states","Original observed_start_month used every April day","Primary initialisation uses the 13 observed April 1 states; occupancy and stationary sensitivities supplied"),
        ("Rainfall coverage","Attached workbook has 1,969 summer records and no April rainfall","Use the 1,940 source-verified summer dates; no April rainfall attachment or fallback"),
        ("Wet terminology","Original wetness means all non-settled circulation families","Report non-settled and cyclonic/showery fractions explicitly; neither is a measured wet-day fraction"),
        ("Baseline label","Original Observed transition is a simulated baseline","Use Baseline simulation"),
        ("Uncertainty","Original 5th–95th percentiles are central 90% simulation ranges","Use labelled central 95% simulation ranges; separate approximate transition-parameter intervals"),
        ("Storm outbreaks","Convective-family occurrence alone does not establish local storms","Use convective interruptions and retain rainfall diagnostics as conditional illustrative attachments"),
        ("Plausibility","Four selected anchor years and matrix perturbations do not establish physical plausibility","Report all 13 observed summers and held-out baseline checks; prescribed scenarios remain stress tests"),
        ("April availability","The older fullrange workbook contains 390 April rainfall metrics, but their source histograms have not been audited here","April driver initialisation remains a later-step data requirement; no synthetic summer substitute is inserted")]
    pd.DataFrame(audits,columns=["item","original_issue_or_limit","revision"]).to_csv(r/"review_and_corrections.csv",index=False)
    # Report both expected and achieved directions without treating designed differences as discoveries.
    targets=[("persistent_wet","days_0",1),("persistent_dry","days_3",1),
             ("dry_with_bursts","settled_to_convective",1),("flip_wet_to_dry","cyclonic_showery_before_minus_after",1),
             ("flip_dry_to_wet","cyclonic_showery_before_minus_after",-1)]
    checks=[];lines=["STEP 3 REVIEW AND FINDINGS","",
        "The revised outputs describe 153-day May–September seasons after a 30-day April circulation warm-up. "
        "The original 183-day outputs are not numerically interchangeable with these results.","",
        "PRIMARY STORYLINE EFFECTS (mean differences from baseline)"]
    for story,key,direction in targets:
        d=delta[delta.storyline.eq(story)&delta.metric.eq(key)&~delta.configuration.eq("strength_zero")]
        for _,a in d.iterrows():checks.append({"storyline":story,"metric":key,"configuration":a.configuration,
            "difference":a.mean_difference,"designed_direction_retained":bool(a.mean_difference*direction>0)})
        a=ciindex.loc[(story,key)]
        lines.append(f"{LABELS[STORIES.index(story)]}; {key}: {a.difference_estimate:.4f}; "
                     f"approximate transition-bootstrap interval {a.difference_ci_lower:.4f} to {a.difference_ci_upper:.4f}; "
                     f"designed direction retained in {int((d.mean_difference*direction>0).sum())}/{len(d)} non-zero sensitivity configurations.")
    pd.DataFrame(checks).to_csv(r/"directional_sensitivity_checks.csv",index=False)
    lines.extend(["", "INTERPRETATION AND LIMITS",
        "The selected circulation responses remain directionally consistent across the tested perturbation strengths, "
        "baseline transition formulations, initialisations and change dates. This confirms implementation and "
        "conditional sensitivity to prescribed changes; the response direction is partly imposed by design. "
        "It is not an empirical test that circulation causes contamination or that future seasons have these probabilities.",
        "The interruption scenario increases settled occupancy and transitions between settled and convective families. "
        "It need not increase total rainfall or high-depth-day frequency; family identity does not guarantee a local storm.",
        "The opposite timing scenarios do not hold seasonal composition fixed. With a 1 July change date, "
        "the evaluated periods have 61 and 92 days; differences reflect both order and composition, not timing alone.",
        "Rainfall is sampled independently conditional on family and month, only for May–September. This retains empirical "
        "conditional distributions but does not preserve multi-day rainfall dependence, soil moisture or catchment memory. "
        "It is not the final multivariate driver-resampling procedure. April antecedent rainfall is not supplied.",
        f"Parameter intervals use {meta['n_transition_bootstrap']:,} whole-season refits with {meta['inner_simulations_per_bootstrap']:,} inner simulations per scenario. They include "
        "finite inner Monte Carlo noise, assume approximately exchangeable years and condition on fixed family membership "
        "and prescribed perturbations. Rainfall-pool uncertainty is not included in those intervals, which apply to "
        "circulation metrics only. Central simulation ranges are different from confidence intervals.",
        "The strength multipliers are exploratory choices, not calibrated return periods, climate projections, "
        "scenario probabilities or independently established reasonable-worst-case bounds. No automatic p-value tests "
        "are used to declare prescribed storylines statistically significant."])
    (r/"findings.txt").write_text("\n".join(lines)+"\n",encoding="utf-8")
    methods=("First-order circulation storylines retained the previously defined four-family mapping and transition "
        "perturbation mechanisms. Pooled April–September 2012–2024 transitions formed the primary baseline; "
        "month-specific estimates were examined in sensitivity tests. April was retained as a 30-day circulation "
        f"warm-up, and diagnostics were calculated for May–September. For each storyline, {meta['n_simulations']:,} seasons were "
        "simulated using common random numbers for paired mean comparisons. Sensitivity checks varied "
        "perturbation strength, monthly regularisation, initialisation and the prescribed change date. Central "
        "95% simulation ranges were distinguished from approximate pointwise intervals for ensemble-mean "
        f"circulation metrics, obtained from {meta['n_transition_bootstrap']:,} whole-season transition refits with {meta['inner_simulations_per_bootstrap']:,} inner simulations "
        "per storyline. These intervals include finite inner Monte Carlo noise and condition on the fixed "
        "family mapping and prescribed perturbations. Summer rainfall was attached independently from "
        "family–month pools using 1,940 source-reconstructable daily records; no April rainfall was imputed. "
        "This attachment was diagnostic and did not preserve antecedent rainfall dependence or initialise "
        "catchment wetness. Storylines were interpreted as prescribed stress tests, without assigned "
        "occurrence probabilities or claims of validated contamination duration.")
    (r/"manuscript_methods.txt").write_text(methods+"\n",encoding="utf-8")
    results=("The cyclonic/showery-persistence scenario increased mean cyclonic occupancy by "
        f"{ciindex.loc[('persistent_wet','days_0'),'difference_estimate']:.1f} days relative to the simulated baseline. "
        "The settled-favouring scenario increased mean settled occupancy by "
        f"{ciindex.loc[('persistent_dry','days_3'),'difference_estimate']:.1f} days. "
        "The prescribed transition scenarios shifted the timing of cyclonic/showery occupancy in opposite "
        "directions, and the selected response directions persisted across the evaluated sensitivity settings. "
        "These are conditional responses to designed transition changes, rather than independent evidence "
        "of physical plausibility or operational forecast benefit.")
    (r/"manuscript_results.txt").write_text(results+"\n",encoding="utf-8")
    print("Reports and five figure sets written.")


if __name__=="__main__":report()
