RUNNING ON WINDOWS
Install dependencies once: python -m pip install numpy pandas matplotlib
Run: python prevalence_publication.py
The default input path is the exact Windows path supplied in this request.
Outputs are created in a new prevalence_publication_outputs folder beside the CSV.
Override paths: python prevalence_publication.py --input "YOUR.csv" --output "YOUR_FOLDER"
The supplied results were generated from the uploaded CSV, whose filename differs from the Windows filename. Verify that your local CSV contains the same data.

FIGURE
PNG: 260 x 65 mm, 600 dpi (6141 x 1535 pixels approximately), opaque white background.
PDF and SVG: vector alternatives, preferred when the journal accepts them.
Colour-blind-friendly sequential viridis palette; adaptive text contrast; zero cells explicitly shown.
Cell numbers omit percent symbols because the shared colourbar supplies the unit.
The title and study dates belong in the caption, avoiding duplication inside the figure.
This is a publication-oriented layout, not a claim of compliance with every journal's current specifications.

METHODS: PREVALENCE EQUATION
P_(m,r) = 100 N_(m,r) / sum_(k=1)^30 N_(m,k).
Use k as the summation index, avoiding reuse of the free index r.
N_(m,r) counts days assigned to pattern r in calendar month m, pooled over 2012–2024.
The denominator is the total number of classified days in that month across all 13 years.
Each month sums to 100% before rounding. There are 403 days in May, July and August, and 390 in June and September.
Season-wide prevalence is calculated directly from all 1,989 days, not an unweighted average of the five monthly percentages.

OPTIONAL METHODS ADDITION
To describe concentration, we calculated the combined prevalence of the five most frequent weather patterns within each month. We also calculated Shannon entropy, H_m = -sum_r p_(m,r) ln(p_(m,r)), and its exponential, exp(H_m), where p_(m,r) = P_(m,r)/100 and zero terms contribute zero. The latter is the effective number of equally frequent patterns and increases as the distribution becomes broader. Exploratory uncertainty intervals were obtained using 10,000 whole-year bootstrap replicates (seed 42), resampling the 13 years with replacement and retaining their complete May–September sequences. The same sampled years were used for all months, enabling paired comparisons. The five most frequent patterns were reselected within each bootstrap replicate.

INTERPRETATION CAUTION
These are descriptive statistics for a 13-year study-period baseline. The bootstrap intervals assume representative, independent years and do not establish a causal seasonal effect. Entropy estimates and their percentile intervals can be biased downward when resampled years omit rare patterns; use effective numbers primarily as descriptive summaries. Pairwise intervals are exploratory, unadjusted for multiplicity, and must not be presented as confirmatory significance tests. July has the highest observed concentration, but its difference from June and August remains uncertain.
The daily data alone do not verify circulation descriptions, the four-family grouping, or what your separate Markov code uses. The statement about the Markov model should be checked against that code.

UPDATED RESULTS DRAFT (circulation descriptions omitted pending catalogue verification)
Bathing-season circulation varied in both the composition and concentration of weather patterns (Figure 4). In May, WP9 was most frequent (8.2%), followed by WP10 (6.7%) and WP1 and WP7 (6.5% each). June was led by WP2 (10.3%) and WP7 (9.0%). July had the highest observed concentration: WP1 accounted for 11.7% of days, followed by WP7 (9.7%), WP8 (9.4%), WP5 (8.4%) and WP6 (8.2%). In August, WP2 (10.9%) and WP7 (9.7%) were most frequent, whereas September was led by WP10 (9.0%) and WP6 (8.5%).
The five most frequent patterns accounted for 34.0% of May days, 39.2% in June, 47.4% in July, 42.4% in August and 33.8% in September. Consistent with this pattern, the effective number of weather patterns decreased from 24.8 in May to 17.4 in July, before increasing to 25.3 in September. July's top-five share exceeded May's by 13.4 percentage points (exploratory 95% year-bootstrap interval: 4.5–19.9) and September's by 13.5 points (8.2–19.5). Its differences from June and August were less clearly resolved.
Across all 1,989 May–September days, the most frequent patterns were WP2 (7.4%), WP7 (7.2%), WP1 (7.1%), WP6 (6.8%) and WP10 (6.6%). Together, these accounted for 35.1% of study days; no individual pattern dominated the season as a whole. These frequencies provide context for subsequent exceedance associations by distinguishing commonly encountered circulation patterns from patterns represented by relatively few days.
