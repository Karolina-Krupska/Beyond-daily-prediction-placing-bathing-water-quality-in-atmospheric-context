"""Daily Decider prevalence, validated calendar, publication figures and summaries.
Run: python prevalence_publication.py
Or: python prevalence_publication.py --input calendar.csv --output results
Requires: numpy pandas matplotlib (pip install numpy pandas matplotlib).
"""
from pathlib import Path
import argparse, json, calendar
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize

DEFAULT = r'C:\Users\earth\OneDrive - University of Reading\PHD 2\Chapters\Paper 2\Codes 2\1. Prevelance\classifications_30regimes(21) (4).csv'
MONTHS = [5,6,7,8,9]
YEARS = np.arange(2012,2025)
REGIMES = np.arange(1,31)

def concentration(p):
    """Rows are probability distributions; zero terms contribute zero entropy."""
    with np.errstate(divide='ignore', invalid='ignore'):
        entropy = -np.where(p>0, p*np.log(p), 0).sum(axis=-1)
    return np.sort(p,axis=-1)[...,-5:].sum(axis=-1)*100, entropy, np.exp(entropy)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', default=DEFAULT)
    parser.add_argument('--output', default=None)
    parser.add_argument('--bootstrap',type=int,default=10000)
    args=parser.parse_args()
    if args.bootstrap < 100: raise ValueError('Use at least 100 bootstrap replicates.')
    source=Path(args.input)
    out=Path(args.output) if args.output else source.parent/'prevalence_publication_outputs'
    out.mkdir(parents=True, exist_ok=True)
    df=pd.read_csv(source,comment='#',sep=None,engine='python')
    df.columns=df.columns.str.strip().str.lower()
    for c in ['year','month','day','regime']:
        if c not in df: raise ValueError(f'Missing column: {c}')
        df[c]=pd.to_numeric(df[c],errors='raise')
    # Do not silently discard invalid dates, unknown patterns or duplicate days.
    df['date']=pd.to_datetime(df[['year','month','day']],errors='raise')
    df=df[df.year.between(2012,2024)&df.month.isin(MONTHS)].copy()
    if df.date.duplicated().any(): raise ValueError('Duplicate study dates detected.')
    if not df.regime.isin(REGIMES).all(): raise ValueError('Missing or invalid regime in study period.')
    expected=pd.date_range('2012-01-01','2024-12-31')
    expected=expected[expected.month.isin(MONTHS)]
    missing=expected.difference(df.date)
    if len(missing): raise ValueError(f'{len(missing)} study dates missing: {missing[:10].tolist()}')
    counts=pd.crosstab(df.month,df.regime).reindex(index=MONTHS,columns=REGIMES,fill_value=0)
    prevalence=counts.div(counts.sum(axis=1),axis=0)*100
    assert np.allclose(prevalence.sum(axis=1),100)
    counts.to_csv(out/'monthly_counts.csv',index_label='month')
    prevalence.to_csv(out/'monthly_prevalence_percent.csv',index_label='month',float_format='%.8f')
    annual=np.zeros((13,5,30),dtype=int)
    for iy,y in enumerate(YEARS):
        annual[iy]=pd.crosstab(df.loc[df.year==y,'month'],df.loc[df.year==y,'regime']).reindex(index=MONTHS,columns=REGIMES,fill_value=0).to_numpy()
    long=pd.MultiIndex.from_product([YEARS,MONTHS,REGIMES],names=['year','month','regime']).to_frame(index=False)
    long['count']=annual.ravel()
    long['prevalence_percent']=(annual/annual.sum(axis=2,keepdims=True)*100).ravel()
    long.to_csv(out/'annual_monthly_prevalence.csv',index=False)
    # Resample WHOLE YEARS, preserving daily persistence and cross-month dependence.
    rng=np.random.default_rng(42)
    indices=rng.integers(0,len(YEARS),size=(args.bootstrap,len(YEARS)))
    bc=annual[indices].sum(axis=1)
    bp=bc/bc.sum(axis=2,keepdims=True)
    ci=np.percentile(bp*100,[2.5,97.5],axis=0)
    table=prevalence.stack().rename('prevalence_percent').reset_index()
    table['count']=counts.to_numpy().ravel()
    table['ci_lower_percent']=ci[0].ravel(); table['ci_upper_percent']=ci[1].ravel()
    table.to_csv(out/'monthly_prevalence_with_year_bootstrap_CI.csv',index=False)
    p=prevalence.to_numpy()/100
    top5,h,eff=concentration(p)
    bt,bh,be=concentration(bp)
    rows=[]
    for im,m in enumerate(MONTHS):
        order=np.lexsort((REGIMES,-p[im]))
        cutoff=p[im,order[4]]
        rows.append(dict(month=calendar.month_name[m],days=int(counts.iloc[im].sum()),
            top_five_patterns='; '.join(f'WP{REGIMES[j]} ({p[im,j]*100:.2f}%)' for j in order[:5]),
            tied_at_fifth='; '.join(f'WP{REGIMES[j]}' for j in range(30) if p[im,j]==cutoff),
            top5_share_percent=top5[im],top5_ci_lower=np.percentile(bt[:,im],2.5),top5_ci_upper=np.percentile(bt[:,im],97.5),
            shannon_entropy_nats=h[im],effective_number_patterns=eff[im],
            effective_number_ci_lower=np.percentile(be[:,im],2.5),effective_number_ci_upper=np.percentile(be[:,im],97.5)))
    summary=pd.DataFrame(rows);summary.to_csv(out/'monthly_concentration_summary.csv',index=False)
    comparisons=[]
    for i in range(5):
        for j in range(i+1,5):
            delta=bt[:,i]-bt[:,j]
            comparisons.append(dict(month_a=calendar.month_name[MONTHS[i]],month_b=calendar.month_name[MONTHS[j]],
                top5_difference_percentage_points=top5[i]-top5[j],ci_lower=np.percentile(delta,2.5),ci_upper=np.percentile(delta,97.5)))
    pd.DataFrame(comparisons).to_csv(out/'paired_month_concentration_differences.csv',index=False)
    overall=counts.sum(axis=0).rename('days').to_frame()
    overall['prevalence_percent']=overall.days/overall.days.sum()*100
    overall.sort_values(['days'],ascending=False,kind='stable').to_csv(out/'overall_seasonal_ranking.csv',index_label='regime')
    # Fixed final dimensions: 183 mm wide, 8 pt labels. 600 dpi PNG plus vector files.
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.labelsize':8,
        'xtick.labelsize':7,'ytick.labelsize':8,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none'})
    fig=plt.figure(figsize=(260/25.4,65/25.4))
    ax=fig.add_axes([.125,.22,.755,.73]); cax=fig.add_axes([.90,.22,.013,.73])
    norm=Normalize(0,np.ceil(prevalence.to_numpy().max()))
    cmap=plt.get_cmap('viridis')
    im=ax.imshow(prevalence.to_numpy(),aspect='auto',cmap=cmap,norm=norm,interpolation='nearest')
    ax.set_xticks(np.arange(30),REGIMES);ax.set_yticks(np.arange(5),[calendar.month_name[m] for m in MONTHS])
    ax.set_xlabel('Weather pattern');ax.tick_params(length=2,width=.5)
    ax.set_xticks(np.arange(-.5,30,1),minor=True);ax.set_yticks(np.arange(-.5,5,1),minor=True)
    ax.grid(which='minor',color='white',linewidth=.25,alpha=.5);ax.tick_params(which='minor',bottom=False,left=False)
    for spine in ax.spines.values():spine.set_linewidth(.5)
    for i in range(5):
        for j in range(30):
            v=prevalence.iloc[i,j];rgba=cmap(norm(v))
            # Select text colour using relative luminance for legibility.
            rgb=np.array(rgba[:3]);linear=np.where(rgb<=.04045,rgb/12.92,((rgb+.055)/1.055)**2.4)
            lum=linear@np.array([.2126,.7152,.0722])
            color='black' if (lum+.05)/.05 >= 1.05/(lum+.05) else 'white'
            ax.text(j,i,f'{v:.1f}' if v>0 else '0',ha='center',va='center',fontsize=5.1,color=color)
    cb=fig.colorbar(im,cax=cax);cb.set_label('Days within month (%)',labelpad=4);cb.outline.set_linewidth(.5)
    for ext in ['png','pdf','svg']:fig.savefig(out/f'weather_pattern_prevalence_2012_2024.{ext}',dpi=600,facecolor='white')
    plt.close(fig)
    lines=['DATA CHECKS',f'Study days: {len(df)}; missing dates: {len(missing)}; duplicate dates: 0.',
           'Period: May–September 2012–2024 inclusive. All 30 patterns retained, including zero cells.',
           'Monthly percentages sum to 100 before display rounding. Counts are pooled across years.',
           '',summary.to_string(index=False),'','OVERALL RANKING',overall.sort_values('days',ascending=False).to_string(),
           '', 'STATISTICAL INTERPRETATION',
           f'95% percentile intervals use {args.bootstrap:,} whole-year bootstrap replicates, seed 42 (13 years).',
           'Each bootstrap draw uses the same sampled years for every month. Daily observations are not treated as independent.',
           'Top-five membership is recalculated in every replicate; intervals describe concentration, not a fixed set of patterns.',
           'Entropy H = -sum(p log p), effective number = exp(H); larger effective numbers mean a broader mixture.',
           'Pairwise intervals are exploratory and unadjusted for multiple comparisons. They are not significance tests.',
           'Only 13 year blocks are available; intervals may be unstable and assume years are representative and independent.',
           'Results describe this 2012–2024 period, not long-term climatology or a causal seasonal effect.',
           'No circulation descriptions are inferred from pattern IDs; check descriptions against the cited Decider catalogue.',
           '', 'FIGURE CAPTION',
           'Monthly prevalence of the 30 Met Office weather patterns during May–September 2012–2024. Cell values show the percentage of all available days within each calendar month assigned to each pattern, pooled across 13 years. Rows sum to 100% before rounding; zero denotes no recorded occurrence. The analysis includes 1,989 days (403 each in May, July and August; 390 each in June and September).']
    (out/'analysis_report.txt').write_text('\n'.join(lines),encoding='utf-8')
    (out/'run_metadata.json').write_text(json.dumps({'input':str(source),'years':[2012,2024],'months':MONTHS,'bootstrap_replicates':args.bootstrap,'seed':42,'numpy':np.__version__,'pandas':pd.__version__,'matplotlib':matplotlib.__version__},indent=2))
    print('\n'.join(lines[:7]));print(f'\nOutput: {out.resolve()}')

if __name__=='__main__': main()
