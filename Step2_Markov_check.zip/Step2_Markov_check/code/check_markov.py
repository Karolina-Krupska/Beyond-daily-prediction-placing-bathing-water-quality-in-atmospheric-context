"""Corrected first-order circulation generator: matched-horizon and held-out checks.

Run python code/check_markov.py. No rainfall or microbiological data are used.
Intervals are conditional simulation intervals, not parameter confidence limits.
"""
from pathlib import Path
import argparse
import json
import hashlib
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
GROUPS = ["Cyclonic Atlantic (frontal)", "Showery maritime / unsettled",
          "Convective extremes", "Settled anticyclonic quiet"]
METRICS = ["fraction", "same_family_probability", "mean_run", "p95_run", "max_run", "runs_ge7", "runs_ge10"]


def fit(seasons):
    counts = np.zeros((5, 4, 4), dtype=int)
    starts = np.zeros(4, dtype=int)
    for states, months in seasons:
        starts[states[0]] += 1
        for a, b, month in zip(states[:-1], states[1:], months[:-1]):
            counts[month - 5, a, b] += 1
    overall = counts.sum(axis=0)
    if (overall.sum(axis=1) == 0).any():
        raise ValueError("An overall transition row is unobserved; an explicit fallback is required.")
    p = overall / overall.sum(axis=1, keepdims=True)
    monthly = np.empty((5, 4, 4))
    fallback = []
    for m in range(5):
        for g in range(4):
            total = counts[m, g].sum()
            monthly[m, g] = counts[m, g] / total if total else p[g]
            if not total:
                fallback.append({"month": m + 5, "group": GROUPS[g]})
    return p, monthly, starts / starts.sum(), counts, fallback


def simulate(calendars, model, monthly, n, rng):
    p, pm, start, _, _ = model
    output = np.empty((n, len(calendars), 153), dtype=np.int8)
    for y, (_, months) in enumerate(calendars):
        state = np.searchsorted(np.cumsum(start), rng.random(n), side="right")
        output[:, y, 0] = state
        for t in range(1, 153):
            matrix = pm[months[t - 1] - 5] if monthly else p
            cumulative = np.cumsum(matrix[state], axis=1)
            cumulative[:, -1] = 1.
            state = (rng.random(n)[:, None] >= cumulative).sum(axis=1)
            output[:, y, t] = state
    return output


def statistics(samples):
    """Each row is a separate, equally long dataset; season boundaries always reset runs."""
    n, ny, nd = samples.shape
    flat = samples.reshape(n, ny * nd)
    previous, following = samples[:, :, :-1], samples[:, :, 1:]
    output = {metric: np.full((n, 4), np.nan) for metric in METRICS}
    output["switching_rate"] = (previous != following).mean(axis=(1, 2))
    for g in range(4):
        output["fraction"][:, g] = (flat == g).mean(axis=1)
        denominator = (previous == g).sum(axis=(1, 2))
        numerator = ((previous == g) & (following == g)).sum(axis=(1, 2))
        output["same_family_probability"][:, g] = np.divide(
            numerator, denominator, out=np.full(n, np.nan), where=denominator > 0)
    for r in range(n):
        change = np.r_[True, flat[r, 1:] != flat[r, :-1]]
        change[::nd] = True
        starts = np.flatnonzero(change)
        lengths = np.diff(np.r_[starts, ny * nd])
        families = flat[r, starts]
        for g in range(4):
            vals = lengths[families == g]
            output["runs_ge7"][r, g] = (vals >= 7).sum()
            output["runs_ge10"][r, g] = (vals >= 10).sum()
            if len(vals):
                output["mean_run"][r, g] = vals.mean()
                output["p95_run"][r, g] = np.quantile(vals, .95)
                output["max_run"][r, g] = vals.max()
    return output


def comparison(observed, simulated, model, scope, heldout_year=None):
    rows = []
    for metric, values in simulated.items():
        names = ["All families"] if values.ndim == 1 else GROUPS
        for i, family in enumerate(names):
            sims = values if values.ndim == 1 else values[:, i]
            obs = observed[metric][0] if values.ndim == 1 else observed[metric][0, i]
            valid = sims[np.isfinite(sims)]
            low, median, high = np.quantile(valid, [.025, .5, .975]) if len(valid) else [np.nan] * 3
            rows.append({"model": model, "scope": scope, "heldout_year": heldout_year,
                "group": family, "metric": metric, "observed": obs,
                "sim_median": median, "sim_lower_95": low, "sim_upper_95": high,
                "n_sim_valid": len(valid), "n_sim_without_defined_metric": len(sims)-len(valid),
                "observed_in_interval": bool(low <= obs <= high) if np.isfinite(obs) else None,
                "observed_below_interval": bool(obs < low) if np.isfinite(obs) else None,
                "observed_above_interval": bool(obs > high) if np.isfinite(obs) else None})
    return rows


def run(root=ROOT, n_sim=5000, seed=42):
    root = Path(root)
    weather = pd.read_csv(root / "data/weather_calendar.csv", parse_dates=["date"])
    if weather.date.duplicated().any() or set(weather.group) != set(GROUPS):
        raise ValueError("Invalid weather-calendar keys or families.")
    seasons, years = [], []
    for year, block in weather.groupby("year", sort=True):
        block = block.sort_values("date")
        expected = pd.date_range(f"{year}-05-01", f"{year}-09-30")
        if not np.array_equal(block.date.to_numpy(), expected.to_numpy()):
            raise ValueError("This validation requires complete 153-day May–September seasons.")
        states = block.group.map({g: i for i, g in enumerate(GROUPS)}).to_numpy(dtype=np.int8)
        seasons.append((states, block.date.dt.month.to_numpy()))
        years.append(int(year))
    out = root / "results"
    out.mkdir(exist_ok=True, parents=True)
    observed = statistics(np.stack([a for a, _ in seasons])[None, :, :])
    model = fit(seasons)
    assert model[3].sum() == 1976
    assert model[3].sum(axis=(1, 2)).tolist() == [403, 390, 403, 403, 377]
    rng_seeds = np.random.SeedSequence(seed).spawn(2 * (len(years) + 1))
    rows, heldout, fallbacks, zeros = [], [], [], []
    stored = {}
    for k, monthly in enumerate([False, True]):
        name = "Monthly" if monthly else "Overall"
        samples = simulate(seasons, model, monthly, n_sim, np.random.default_rng(rng_seeds[k]))
        summaries = statistics(samples)
        rows.extend(comparison(observed, summaries, name, "Matched 13-season fitting-data check"))
        for metric, vals in summaries.items():
            stored[name.lower() + "_" + metric] = vals
        for y, year in enumerate(years):
            training = [s for j, s in enumerate(seasons) if j != y]
            fitted = fit(training)
            fallbacks.extend({"model": name, "heldout_year": year, **f} for f in fitted[4] if monthly)
            one = [seasons[y]]
            sample = simulate(one, fitted, monthly, n_sim, np.random.default_rng(rng_seeds[2 + k * len(years) + y]))
            obs = statistics(one[0][0][None, None, :])
            heldout.extend(comparison(obs, statistics(sample), name, "Held-out single season", year))
            states, months = one[0]
            zero_count = 0
            for a, b, month in zip(states[:-1], states[1:], months[:-1]):
                p = fitted[1][month-5] if monthly else fitted[0]
                zero_count += p[a, b] == 0
            zeros.append({"model": name, "heldout_year": year, "zero_probability_observed_transitions": int(zero_count)})
    frame = pd.DataFrame(rows)
    held = pd.DataFrame(heldout)
    frame.to_csv(out / "matched_horizon_check.csv", index=False)
    held.to_csv(out / "heldout_season_check.csv", index=False)
    coverage = held.groupby(["model", "group", "metric"], sort=False).agg(
        n_seasons_defined=("observed_in_interval", "count"),
        n_inside=("observed_in_interval", "sum"),
        n_observed_below=("observed_below_interval", "sum"),
        n_observed_above=("observed_above_interval", "sum")).reset_index()
    coverage.to_csv(out / "heldout_interval_counts.csv", index=False)
    pd.DataFrame(zeros).to_csv(out / "heldout_zero_probability_transitions.csv", index=False)
    pd.DataFrame(fallbacks, columns=["model", "heldout_year", "month", "group"]).to_csv(out / "fallbacks.csv", index=False)
    for month, counts in zip(range(5, 10), model[3]):
        pd.DataFrame(counts, index=GROUPS, columns=GROUPS).to_csv(out / f"transition_counts_month_{month:02d}.csv")
        pd.DataFrame(model[1][month-5], index=GROUPS, columns=GROUPS).to_csv(out / f"transition_probs_month_{month:02d}.csv")
    pd.DataFrame(model[3].sum(axis=0), index=GROUPS, columns=GROUPS).to_csv(out / "transition_counts_overall.csv")
    pd.DataFrame(model[0], index=GROUPS, columns=GROUPS).to_csv(out / "transition_probs_overall.csv")
    np.savez_compressed(out / "matched_horizon_simulated_statistics.npz", **stored)
    metadata = {"n_simulations_per_check": n_sim, "seed": seed, "calendar_days": len(weather),
        "n_seasons": len(years), "season_length": 153, "transition_pairs": int(model[3].sum()),
        "source_month_transition_counts": model[3].sum(axis=(1, 2)).tolist(),
        "month_rule": "Origin day; includes within-season month boundaries",
        "initial_state": "Empirical first-day family distribution from training seasons only",
        "smoothing": "None; unobserved individual transitions retain probability zero",
        "zero_row_fallback": "Training overall row if a monthly origin row is unobserved; every fallback logged",
        "matched_horizon": "Each replicate has 13 separate 153-day seasons; statistics calculated separately per replicate",
        "held_out": "Fit 12 summers; simulate only omitted summer; repeat for each year and both generators",
        "interval_type": "Pointwise 95% central simulation intervals conditional on fitted parameters; not confidence intervals",
        "limits": ["13 held-out years; counts are descriptive, not formal simultaneous goodness-of-fit tests",
                   "Simulation intervals omit parameter-estimation uncertainty and unmodelled interannual variability",
                   "Boundary runs can be truncated; observed and simulated windows are matched",
                   "Runs of 7 and 10 days are descriptive duration thresholds, not public-health thresholds",
                   "Circulation-only check; no conclusion about rainfall realism, contamination duration or warning performance"],
        "weather_csv_sha256": hashlib.sha256((root / "data/weather_calendar.csv").read_bytes()).hexdigest()}
    (out / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
    print(frame.loc[frame.metric.isin(["p95_run", "max_run"]),
                    ["model", "group", "metric", "observed", "sim_median", "sim_lower_95", "sim_upper_95", "observed_in_interval"]].to_string(index=False))
    print("\nHeld-out zero-probability transitions:", pd.DataFrame(zeros).groupby("model").zero_probability_observed_transitions.sum().to_dict())
    return frame, held, coverage


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", type=Path, default=ROOT)
    p.add_argument("--n-sim", type=int, default=5000)
    p.add_argument("--seed", type=int, default=42)
    a = p.parse_args()
    run(a.root, a.n_sim, a.seed)
