"""Report saved Markov adequacy checks without refitting."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]


def report(root=ROOT):
    root = Path(root)
    r = root / "results"
    full = pd.read_csv(r / "matched_horizon_check.csv")
    held = pd.read_csv(r / "heldout_season_check.csv")
    zeros = pd.read_csv(r / "heldout_zero_probability_transitions.csv")
    meta = json.loads((r / "metadata.json").read_text())
    lines = ["FIRST-ORDER MARKOV CHECK: FINDINGS", "",
        f"Both overall and source-month-specific generators were evaluated with {meta['n_simulations_per_check']:,} "
        "replicates per check. Each fitting-data replicate contained 13 separate 153-day seasons, "
        "matching the historical exposure. Held-out evaluation fitted 12 summers and simulated the omitted summer. "
        "Initial-state frequencies came from training seasons only. Matrices were not smoothed.", "",
        "POOLED LONG RUNS"]
    for model in ["Overall", "Monthly"]:
        for metric in ["p95_run", "max_run"]:
            subset = full[(full.model == model) & (full.metric == metric)]
            lines.append(f"{model}; {metric}: all {int(subset.observed_in_interval.sum())} of "
                         f"{len(subset)} observed family statistics within the conditional 95% simulation intervals.")
            for _, a in subset.iterrows():
                lines.append(f"  {a.group}: observed {a.observed:.2f}; simulated median {a.sim_median:.2f}; "
                             f"interval {a.sim_lower_95:.2f}–{a.sim_upper_95:.2f} days.")
    lines.extend(["", "HELD-OUT YEARS"])
    for model in ["Overall", "Monthly"]:
        for metric in ["p95_run", "max_run"]:
            subset = held[(held.model == model) & (held.metric == metric)]
            lines.append(f"{model}; {metric}: {int(subset.observed_in_interval.sum())} of "
                         f"{subset.observed_in_interval.count()} family-year values within the pointwise intervals.")
    failures = held.loc[held.metric.isin(["p95_run", "max_run"]) & ~held.observed_in_interval.fillna(True)]
    lines.extend(["", "Long-run discrepancies (descriptive; not multiplicity-adjusted tests):"])
    for _, a in failures.iterrows():
        lines.append(f"{a.model}, {int(a.heldout_year)}, {a.group}, {a.metric}: "
                     f"observed {a.observed:.2f}, interval {a.sim_lower_95:.2f}–{a.sim_upper_95:.2f}.")
    lines.extend(["", "SPARSE TRANSITIONS"])
    for model, sub in zeros.groupby("model"):
        lines.append(f"{model}: {int(sub.zero_probability_observed_transitions.sum())} held-out observed "
                     "transitions were assigned probability zero by the unsmoothed training matrices.")
    lines.extend(["", "INTERPRETATION",
        "The matched-horizon checks do not show a systematic inability to generate the selected pooled "
        "long-run features. This is limited evidence of adequacy, not proof of a correct circulation model. "
        "Held-out discrepancies occur for both generators, and the monthly model has sparse-transition "
        "limitations; it is not demonstrated to be superior. A few observations outside pointwise intervals "
        "are expected across numerous comparisons and are not, alone, formal evidence of model rejection. "
        "Monthly sparse cells require an explicit, documented treatment before relying on them for unseen "
        "transitions. These results do not currently require a higher-order or semi-Markov model.", "",
        "The simulation intervals condition on fitted parameters and training start-state frequencies. "
        "They omit parameter-estimation uncertainty, and only 13 summers are available. Run-quantile "
        "intervals are conditional on a family occurring in a replicate; valid replicate counts are supplied. "
        "Observed and simulated boundary runs are both season-bounded. Counts of interval inclusion "
        "are descriptive, correlated across metrics and not formal significance tests. The check does not "
        "validate modified storyline matrices, rainfall resampling, contamination duration or forecast benefits."])
    (r / "findings.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    text = (
        "Baseline first-order circulation generators were checked against observed May–September sequences "
        "using simulations with matched seasonal boundaries and exposure. For both overall and monthly "
        "transition matrices, the observed family-specific P95 and maximum run lengths lay within the "
        "pointwise 95% simulation intervals for 13-season datasets. Held-out-season checks nevertheless "
        "identified departures in individual summers, including convective persistence in 2013 and "
        "shorter cyclonic runs in 2018. Monthly matrices did not demonstrate consistently better reproduction "
        "and assigned zero probability to seven held-out transitions under unsmoothed estimation. These "
        "checks support cautious use of the baseline generators for selected circulation characteristics, "
        "while providing no validation of contamination duration or operational forecast performance. "
        "Modified storyline sequences require separate plausibility checks."
    )
    (r / "manuscript_wording.txt").write_text(text + "\n", encoding="utf-8")
    groups = full.loc[full.group.ne("All families"), "group"].drop_duplicates().tolist()
    labels = ["Cyclonic\nAtlantic", "Showery\nmaritime", "Convective\nextremes", "Settled\nanticyclonic"]
    fig, axes = plt.subplots(2, 2, figsize=(7.5, 6.5))
    for i, model in enumerate(["Overall", "Monthly"]):
        for j, metric in enumerate(["p95_run", "max_run"]):
            ax = axes[j, i]
            sub = full[full.model.eq(model) & full.metric.eq(metric)].set_index("group").loc[groups]
            y = np.arange(4)
            ax.hlines(y, sub.sim_lower_95, sub.sim_upper_95, color="#0072B2", lw=2)
            ax.scatter(sub.sim_median, y, color="#0072B2", s=24, label="Simulation median")
            ax.scatter(sub.observed, y, color="black", marker="D", s=24, label="Observed", zorder=4)
            ax.set_yticks(y, labels, fontsize=8)
            ax.invert_yaxis()
            ax.set_xlim(0, 31 if metric == "max_run" else 13)
            ax.set_title(f"{model}: {'P95 run' if metric == 'p95_run' else 'maximum run'}", fontsize=10)
            ax.set_xlabel("Consecutive days", fontsize=9)
            ax.grid(axis="x", alpha=.2)
            ax.spines[["top", "right"]].set_visible(False)
    handles, labels_legend = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels_legend, loc="lower center", ncol=2, frameon=False)
    fig.tight_layout(rect=(0, .06, 1, 1))
    folder = root / "figures"
    folder.mkdir(exist_ok=True)
    for ext in ["png", "pdf", "svg"]:
        fig.savefig(folder / f"matched_long_run_check.{ext}", dpi=600)
    plt.close(fig)
    (folder / "caption.txt").write_text(
        "Observed family run-length P95 and maxima compared with baseline Markov simulations. "
        "Diamonds show observations; circles show simulation medians; lines show pointwise central "
        "95% simulation intervals. Each replicate contains 13 separate 153-day seasons. Intervals "
        "condition on fitted parameters and are not confidence intervals or formal goodness-of-fit tests.\n")


if __name__ == "__main__":
    report()
