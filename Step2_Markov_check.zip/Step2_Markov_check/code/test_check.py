import unittest
import numpy as np
from check_markov import fit, statistics, simulate


class BoundaryTests(unittest.TestCase):
    def test_runs_reset_at_each_season(self):
        samples = np.array([[[0, 0, 0], [0, 0, 0]]])
        stats = statistics(samples)
        self.assertEqual(stats["mean_run"][0, 0], 3)
        self.assertEqual(stats["max_run"][0, 0], 3)
        self.assertEqual(stats["switching_rate"][0], 0)

    def test_source_month_includes_boundary_transition(self):
        states = np.array([0, 1, 2, 3, 0])
        months = np.array([5, 5, 6, 6, 6])
        result = fit([(states, months)])
        self.assertEqual(result[3][0, 1, 2], 1)
        self.assertEqual(result[3].sum(), 4)
        self.assertEqual(result[3][1].sum(), 2)

    def test_simulated_persistence_is_empirical_not_fitted_value(self):
        data = np.array([[[0, 0, 1, 1, 1, 0]]])
        summary = statistics(data)
        self.assertAlmostEqual(summary["same_family_probability"][0, 0], .5)
        self.assertAlmostEqual(summary["same_family_probability"][0, 1], 2/3)
        self.assertEqual(summary["max_run"][0, 1], 3)


if __name__ == "__main__":
    unittest.main(verbosity=2)
