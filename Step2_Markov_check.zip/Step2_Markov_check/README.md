# Step 2: corrected first-order Markov adequacy check

This diagnostic package evaluates overall and month-specific first-order generators using the 1,989-day May–September 2012–2024 circulation calendar. Rainfall and microbiological observations are not inputs.

## Corrections

- All 1,976 valid next-day pairs contribute to fitting. Monthly pairs belong to the origin month, including month-boundary transitions.
- Simulation uses the origin day's month.
- Each fitting-data replicate contains 13 separate 153-day seasons. Maxima are compared over matched exposure, not pooled across all simulation repetitions.
- Runs reset at every seasonal boundary.
- Simulated persistence and switching are measured directly from simulated sequences.
- Held-out checks fit 12 summers and generate the omitted summer, including training-only first-day state frequencies.
- Both models use 5,000 simulation replicates per check, with fixed seed 42 and separate reproducible random streams.
- Matrices are unsmoothed. Unobserved monthly rows fall back to the training overall row and all such events are recorded. Individual zero cells remain zero and are assessed on held-out transitions.

## Results

See results/findings.txt for the full interpretation, results/manuscript_wording.txt for suggested wording and figures/matched_long_run_check.png for the matched-exposure comparison.

All observed family P95 and maximum runs fall within the pointwise 95% simulation intervals for matched 13-season datasets under both models. This does not establish a formal goodness-of-fit pass or validate other properties of the generator.

Held-out P95 run lengths fall within their simulation intervals in 49 of 52 family-year comparisons, and maxima in 51 of 52, for each generator. Exceptions include long convective runs in 2013 and short cyclonic runs in 2018. These are correlated, pointwise comparisons; some observations outside the intervals are expected, and the inclusion counts are not significance tests or a comparison proving model superiority.

The unsmoothed monthly model assigns probability zero to seven held-out observed transitions; the overall model assigns probability zero to none. Month-specific fitting has not demonstrated superior performance here. Sparse-cell treatment needs an explicit decision before relying on monthly matrices for unseen transitions. No higher-order model is justified automatically by these results.

Intervals condition on estimated parameters and omit parameter-estimation uncertainty. Run-statistic intervals omit replicates in which that family has no run; the number of valid and undefined replicates is reported. Thirteen held-out summers provide limited evidence of generalisation.

Only baseline circulation generators were checked. Changed storyline matrices, climate perturbations, driver resampling, physical rainfall sequences, contamination persistence and operational forecasting benefits require their own evaluation.

## Reproduce

Python 3.11 or later, with NumPy, Pandas and Matplotlib installed:

```bash
python code/test_check.py
python code/check_markov.py
python code/report.py
```

The defaults use 5,000 simulations and seed 42. Results are written under results/ and figures/. The original supplied Step 2 script remains in archive/; run the corrected check in code/.

## Contents

- data/weather_calendar.csv: complete dated calendar and fixed family assignments from final Step 1.
- code/check_markov.py: fitting, simulation and matched-horizon/held-out checks.
- code/test_check.py: boundary, month-assignment and empirical-statistic tests.
- code/report.py: reports and figures from saved results.
- results/matched_horizon_check.csv: observed versus conditional simulation summaries over 13 seasons.
- results/heldout_season_check.csv: every held-out-year result.
- results/heldout_interval_counts.csv: descriptive interval-inclusion counts.
- results/heldout_zero_probability_transitions.csv: unsupported held-out transitions.
- results/fallbacks.csv: any monthly zero-row fallback events.
- results/transition_*: corrected overall and monthly matrices.
- results/matched_horizon_simulated_statistics.npz: saved ensemble statistics.
- results/metadata.json: exact assumptions, horizon, seed and input hash.
- figures/: 600 dpi PNG and vector PDF/SVG, with caption.
