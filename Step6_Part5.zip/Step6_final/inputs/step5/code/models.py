"""Single model registry and training-only logistic pipelines."""
import numpy as np
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LogisticRegression

MET=['wind_speed','uvb_Wm2','ssrd_Wm2','t2m_C']
MEM=['swvl1_roll','p7_mm','api']
RAIN=['intensity_q95_mmph','depth_mm']
REGISTRY={
 'A':(RAIN[:1],[]),'B':(RAIN[1:],[]),'C':(RAIN,[]),'D':([],['family']),
 'E':(RAIN,['family']),'F':(MET+MEM,['family']),
 'G':(RAIN+MET+MEM,['family']),'H':(MEM,[]),'I':(MET,[]),
 'J':(MET+MEM,[]),'K':(RAIN+MET+MEM,[])}
PAIRS=[('E','C'),('F','J'),('G','K')]
LABELS={'A':'Intensity','B':'Depth','C':'Rainfall','D':'Four families',
 'E':'Rainfall + WP','F':'Met + memory + WP','G':'Full + WP',
 'H':'Soil + rainfall memory','I':'Meteorology','J':'Met + memory','K':'Full without WP'}

def features(letter):
    return REGISTRY[letter][0]+REGISTRY[letter][1]

def pipeline(letter,weight='balanced'):
    num,cat=REGISTRY[letter];steps=[]
    if num:steps.append(('numeric',Pipeline([('imputer',SimpleImputer(strategy='median')),
        ('scale',StandardScaler())]),num))
    if cat:steps.append(('family',Pipeline([('imputer',SimpleImputer(strategy='most_frequent')),
        ('encode',OneHotEncoder(handle_unknown='ignore',sparse_output=False))]),cat))
    return Pipeline([('preprocess',ColumnTransformer(steps)),('logistic',LogisticRegression(
        C=1.0,solver='lbfgs',max_iter=5000,tol=1e-4,random_state=42,
        class_weight=None if weight=='unweighted' else 'balanced'))])

def fit_base(frame,letter,weight):
    cols=features(letter)
    if frame.y_exceed.nunique()!=2:raise ValueError('Training outcomes must include both classes')
    if frame[cols].isna().all().any():raise ValueError('A training feature is entirely missing')
    model=pipeline(letter,weight);model.fit(frame[cols],frame.y_exceed.to_numpy())
    if model.named_steps['logistic'].n_iter_.max()>=5000:raise RuntimeError('Logistic fit did not converge')
    return model

def fit_calibrator(scores,y):
    if not np.isfinite(scores).all():raise ValueError('Calibration requires complete cross-fitted scores')
    return LogisticRegression(C=1.0,max_iter=2000,solver='lbfgs',random_state=42).fit(
        np.asarray(scores).reshape(-1,1),np.asarray(y))

def nested_loyo(frame,letters,weight='balanced',setting='primary'):
    """Inner LOYO within each outer training sample. No outer-year fitting."""
    import pandas as pd
    from scipy.special import expit
    rows=[];audit=[]
    years=sorted(frame.year.unique())
    for year in years:
        train=frame[frame.year.ne(year)];test=frame[frame.year.eq(year)]
        print(f'{setting}: outer {year}; train={len(train)}, test={len(test)}',flush=True)
        for letter in letters:
            inner=np.full(len(train),np.nan)
            for inner_year in sorted(train.year.unique()):
                mask=train.year.eq(inner_year).to_numpy()
                fit=train.iloc[np.flatnonzero(~mask)];valid=train.iloc[np.flatnonzero(mask)]
                assert year not in set(fit.year) and inner_year not in set(fit.year)
                fitted=fit_base(fit,letter,weight)
                inner[mask]=fitted.decision_function(valid[features(letter)])
            calibrator=fit_calibrator(inner,train.y_exceed)
            base=fit_base(train,letter,weight);scores=base.decision_function(test[features(letter)])
            pred=test[['row_id','site_id','date','year','y_exceed']].copy()
            pred['model']=letter;pred['setting']=setting;pred['score_raw']=scores
            pred['p_raw']=expit(scores)
            pred['p_cal']=calibrator.predict_proba(scores.reshape(-1,1))[:,1]
            pred['p_prevalence']=train.y_exceed.mean();rows.append(pred)
            audit.append(dict(setting=setting,model=letter,held_out_year=int(year),
                n_train=len(train),n_test=len(test),inner_folds=len(train.year.unique()),
                outer_year_used_for_fitting=False,inner_scores_complete=bool(np.isfinite(inner).all()),
                training_prevalence=train.y_exceed.mean(),calibration_slope=calibrator.coef_[0,0],
                calibration_intercept=calibrator.intercept_[0]))
    return pd.concat(rows,ignore_index=True),pd.DataFrame(audit)
