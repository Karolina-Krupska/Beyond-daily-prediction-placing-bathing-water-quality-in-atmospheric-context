"""Current Step 4 reconstruction, predictions and explicitly pooled selection budgets."""
from pathlib import Path
import json,gzip
import numpy as np,pandas as pd,joblib
from scipy.special import expit
from models import REGISTRY

STORIES=['baseline','persistent_wet','persistent_dry','dry_with_bursts','flip_wet_to_dry','flip_dry_to_wet']
DATES=pd.date_range('2001-04-01','2001-09-30');SUMMER=DATES.month>=5
BUDGETS=[.01,.05,.10,.25,.50]

def reconstruct(lib,donor,alpha=.85):
    cols=['depth_mm','intensity_q95_mmph','wind_speed','uvb_Wm2','ssrd_Wm2','t2m_C','swvl1','ssr_Wm2']
    arrays={c:lib[c].to_numpy()[donor] for c in cols};n,L=donor.shape
    for c in ['p7_before_mm','p7_mm','api','swvl1_roll']:arrays[c]=np.full((n,L),np.nan)
    api=np.zeros(n)
    for t in range(L):
        api=alpha*api+arrays['depth_mm'][:,t];arrays['api'][:,t]=api
        if t>=7:arrays['p7_before_mm'][:,t]=arrays['depth_mm'][:,t-7:t].sum(axis=1)
        if t>=6:
            arrays['p7_mm'][:,t]=arrays['depth_mm'][:,t-6:t+1].sum(axis=1)
            arrays['swvl1_roll'][:,t]=arrays['swvl1'][:,t-6:t+1].mean(axis=1)
    return arrays

def daily_frame(lib,donor,states,alpha=.85):
    a=reconstruct(lib,donor,alpha)
    d=pd.DataFrame({k:v[:,SUMMER].ravel() for k,v in a.items()})
    d['family']=lib.family.to_numpy()[donor[:,SUMMER]].ravel()
    return d

def run_metrics(selected):
    x=np.asarray(selected,bool)
    if x.ndim!=2:raise ValueError('Expected seasons by consecutive evaluation days')
    n,L=x.shape;total=x.sum(axis=1);starts=x&~np.column_stack([np.zeros(n,bool),x[:,:-1]])
    clusters=starts.sum(axis=1);current=np.zeros(n,int);maximum=current.copy()
    for t in range(L):current=np.where(x[:,t],current+1,0);maximum=np.maximum(maximum,current)
    first=x.argmax(axis=1);last=L-1-x[:,::-1].argmax(axis=1)
    gaps=np.divide(last-first+1-total,clusters-1,out=np.full(n,np.nan),where=clusters>1)
    mean=np.divide(total,clusters,out=np.zeros(n,float),where=clusters>0)
    return np.column_stack([total,clusters,maximum,mean,gaps])

METRIC_NAMES=['selected_days','clusters','max_run_days','mean_run_days','mean_interrun_gap_days']

def run_storylines(root,out):
    target=root/'simulation_probabilities';target.mkdir(exist_ok=True)
    selectiondir=target/'selection_masks';selectiondir.mkdir(exist_ok=True)
    inputdir=root/'inputs/step4/completed_run'
    lib=pd.read_csv(inputdir/'prepared/historical_donor_library.csv',parse_dates=['date'],float_precision='round_trip')
    meta=json.loads((inputdir/'run_metadata.json').read_text());alpha=meta['api_alpha']
    n=5000;L=153;letters=list(REGISTRY)
    # Temporary exact probabilities preserve float64 ranking; final portable prediction storage is float32.
    tmp=root/'temporary_exact_probabilities.npy'
    exact=np.lib.format.open_memmap(tmp,mode='w+',dtype='float64',shape=(len(letters),6,n,L))
    precision=[];coverage=[]
    for s,story in enumerate(STORIES):
        print('Predicting current storyline',story,flush=True)
        with np.load(inputdir/f'simulations/{story}_AprSep.npz') as z:
            donor=z['donor_row'];states=z['states']
        assert donor.shape==states.shape==(n,183)
        assert donor.min()>=0 and donor.max()<len(lib)
        assert np.array_equal(lib.state.to_numpy()[donor],states)
        assert np.array_equal(lib.month.to_numpy()[donor],np.broadcast_to(DATES.month.to_numpy(),donor.shape))
        frame=daily_frame(lib,donor,states,alpha);raw=[];cal=[]
        for k,letter in enumerate(letters):
            model=joblib.load(root/f'fitted_models/{letter}.joblib')
            scores=model['base'].decision_function(frame[model['features']]);pr=expit(scores)
            pc=model['calibrator'].predict_proba(scores.reshape(-1,1))[:,1]
            assert np.isfinite(pr).all() and np.isfinite(pc).all()
            raw.append(pr.reshape(n,L).astype(np.float32));cal.append(pc.reshape(n,L).astype(np.float32))
            exact[k,s]=pc.reshape(n,L)
            precision.append(dict(storyline=story,model=letter,n_probabilities=len(pr),
                max_absolute_storage_error_raw=float(np.max(np.abs(pr-raw[-1].ravel()))),
                max_absolute_storage_error_calibrated=float(np.max(np.abs(pc-cal[-1].ravel())))))
        np.savez_compressed(target/f'{story}_probabilities.npz',
          models=np.array(letters),p_raw=np.stack(raw),p_cal=np.stack(cal),sim=np.arange(n),
          evaluation_dates=DATES[SUMMER].strftime('%Y-%m-%d').to_numpy(dtype='U10'))
        coverage.append(dict(storyline=story,n_simulations=n,n_days_per_season=L,n_models=len(letters),
            rows_per_model=n*L,all_state_family_month_checks_passed=True))
    exact.flush()
    pd.DataFrame(precision).to_csv(out/'probability_storage_precision.csv',index=False)
    pd.DataFrame(coverage).to_csv(out/'simulation_coverage.csv',index=False)
    summaries=[];budgetaudit=[];stored={};firstwrite=True
    tie_uniform=np.random.default_rng(np.random.SeedSequence([42,5,700])).random(6*n*L)
    with gzip.open(out/'selected_day_metrics_by_season.csv.gz','wt',encoding='utf-8',newline='') as handle:
      for k,letter in enumerate(letters):
        print('Selecting calibrated model days',letter,flush=True)
        p=np.asarray(exact[k]);flat=p.ravel();order=np.lexsort((tie_uniform,-flat))
        for budget in BUDGETS+[None]:
            rule=f'topk_{int(budget*100):02d}' if budget is not None else 'probability_ge_0.5'
            if budget is not None:
                selected=np.zeros(flat.size,bool);count=int(np.ceil(budget*flat.size));selected[order[:count]]=True
                boundary=float(flat[order[count-1]])
                budgetaudit.append(dict(model=letter,rule=rule,pool_days=flat.size,k=count,
                  selected_days=int(selected.sum()),boundary_probability=boundary,
                  n_days_tied_at_boundary=int(np.sum(flat==boundary)),tie_rule='Common random uniforms, SeedSequence[42,5,700], secondary to exact probability'))
            else:selected=flat>=.5
            selected=selected.reshape(6,n,L)
            np.savez_compressed(selectiondir/f'{letter}_{rule}.npz',packed=np.packbits(selected.ravel(),bitorder='little'),
                shape=np.array(selected.shape),bitorder=np.array('little'))
            for s,story in enumerate(STORIES):
                m=run_metrics(selected[s]);stored[(letter,rule,story)]=m
                frame=pd.DataFrame(m,columns=METRIC_NAMES);frame.insert(0,'sim',np.arange(n));frame.insert(0,'storyline',story)
                frame.insert(0,'rule',rule);frame.insert(0,'model',letter)
                frame.to_csv(handle,index=False,header=firstwrite);firstwrite=False
                for j,name in enumerate(METRIC_NAMES):
                    vals=m[:,j];vals=vals[np.isfinite(vals)]
                    summaries.append(dict(model=letter,rule=rule,storyline=story,metric=name,n_defined=len(vals),
                       mean=np.mean(vals) if len(vals) else np.nan,
                       simulation_p025=np.quantile(vals,.025) if len(vals) else np.nan,
                       simulation_p975=np.quantile(vals,.975) if len(vals) else np.nan,
                       monte_carlo_se_mean=np.std(vals,ddof=1)/np.sqrt(len(vals)) if len(vals)>1 else np.nan))
    pd.DataFrame(summaries).to_csv(out/'selected_day_metrics_summary.csv',index=False)
    split_season_tables(out)
    pd.DataFrame(budgetaudit).to_csv(out/'pooled_topk_budget_audit.csv',index=False)
    from models import PAIRS
    pairs=[]
    for wp,base in PAIRS:
      for budget in BUDGETS+[None]:
        rule=f'topk_{int(budget*100):02d}' if budget is not None else 'probability_ge_0.5'
        for story in STORIES:
          delta=stored[(wp,rule,story)]-stored[(base,rule,story)]
          for j,name in enumerate(METRIC_NAMES):
            v=delta[:,j];v=v[np.isfinite(v)]
            pairs.append(dict(comparison=f'{wp}-{base}',rule=rule,storyline=story,metric=name,
              n_paired=len(v),mean_difference=np.mean(v) if len(v) else np.nan,
              simulation_difference_p025=np.quantile(v,.025) if len(v) else np.nan,
              simulation_difference_p975=np.quantile(v,.975) if len(v) else np.nan,
              monte_carlo_se_mean_difference=np.std(v,ddof=1)/np.sqrt(len(v)) if len(v)>1 else np.nan))
    pd.DataFrame(pairs).to_csv(out/'storyline_paired_model_differences.csv',index=False)
    del exact;tmp.unlink()
    (target/'STORAGE_AND_SELECTION.txt').write_text(
      'p_raw and p_cal are separate float32 arrays ordered model, simulation, evaluation day. '
      'Maximum actual rounding errors are reported in results/probability_storage_precision.csv. '
      'All summaries and Top-k ranking were computed using float64 probabilities BEFORE storage rounding. '
      'Exact selection masks are saved separately. Full-precision probabilities can be regenerated with '
      'export_probabilities.py --full-precision from the supplied fitted models and Step 4 drivers. '
      'Top-k budgets are pooled over all six scenarios (4,590,000 days per model), not fixed per season or storyline. '
      'Exact probability ties use common pseudorandom uniforms across models and budgets, SeedSequence[42,5,700]. '
      'The probability>=0.5 rule is a separate diagnostic. '
      'Scenario contrasts, ranges and Monte Carlo errors are conditional on the fitted models, generator and supplied ensembles; '
      'they do not quantify environmental or model-fitting uncertainty.\n',encoding='utf-8')
    run_tie_sensitivity(root,out)

def split_season_tables(out):
    """Excel-sized per-model tables in addition to the complete combined CSV."""
    folder=out/'per_model_season_metrics';folder.mkdir(exist_ok=True)
    for block in pd.read_csv(out/'selected_day_metrics_by_season.csv.gz',chunksize=180000,float_precision='round_trip'):
        if block.model.nunique()!=1 or len(block)!=180000:raise ValueError('Unexpected combined seasonal table ordering')
        letter=block.model.iloc[0];block.to_csv(folder/f'{letter}_season_metrics.csv.gz',index=False)

def run_tie_sensitivity(root,out):
    """Bounded diagnostic for the coarse four-family model's extensive exact ties."""
    source=root/'inputs/step4/completed_run'
    lib=pd.read_csv(source/'prepared/historical_donor_library.csv')
    mapping=lib[['state','family']].drop_duplicates().sort_values('state').family.to_numpy()
    model=joblib.load(root/'fitted_models/D.joblib')
    score=model['base'].decision_function(pd.DataFrame({'family':mapping}))
    values=model['calibrator'].predict_proba(score.reshape(-1,1))[:,1]
    states=[]
    for story in STORIES:
        with np.load(source/f'simulations/{story}_AprSep.npz') as z:states.append(z['states'][:,SUMMER])
    probs=values[np.stack(states)].ravel();rows=[]
    primary=pd.read_csv(out/'selected_day_metrics_summary.csv')
    for seed in [700,701,702]:
        uniform=np.random.default_rng(np.random.SeedSequence([42,5,seed])).random(len(probs))
        order=np.lexsort((uniform,-probs))
        for budget in BUDGETS:
            selected=np.zeros(len(probs),bool);selected[order[:int(np.ceil(budget*len(probs)))]]=True
            selected=selected.reshape(6,5000,153);rule=f'topk_{int(budget*100):02d}'
            for s,story in enumerate(STORIES):
                m=run_metrics(selected[s])
                for j,name in enumerate(METRIC_NAMES):
                    v=m[:,j];point=float(np.nanmean(v));ref=primary[(primary.model=='D')&(primary.rule==rule)&(primary.storyline==story)&(primary.metric==name)]['mean'].iloc[0]
                    if seed==700:np.testing.assert_allclose(point,ref,rtol=1e-12,atol=1e-12,equal_nan=True)
                    rows.append(dict(model='D',tie_seed_component=seed,rule=rule,storyline=story,
                      metric=name,mean=point,change_from_primary=point-ref,n_seasons=5000,
                      scope='Only the exact-tie random allocation changes; no model refitting'))
    pd.DataFrame(rows).to_csv(out/'D_exact_tie_seed_sensitivity.csv',index=False)
