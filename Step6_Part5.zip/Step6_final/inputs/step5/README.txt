STEP 5 | BATHING WATER EXCEEDANCE MODELS

Step 5 estimates the daily probability of an intestinal enterococci exceedance. It evaluates eleven models (A-K) against sampled bathing water site-days, then applies the fitted models to the six weather storylines from Step 4. The corrected API inputs and the completed Step 5 results are included. Extract the ZIP fully before opening the files.

Where to start
- verification_output/comparison/ contains comparisons with the Step 5 package supplied before the API correction.
- results/performance_pooled.csv gives historical model scores. The setting “primary” identifies the main evaluation. See results/performance_by_year.csv for each held-out year and results/paired_bootstrap_intervals.csv for the three weather pattern comparisons.
- results/audit/predictor_missingness.csv gives missingness by sampled site-day and by sampling date. results/modelling_dataset.csv contains the predictors and observed outcomes.
- figures/ contains the predictive and storyline figures in PNG, PDF and SVG. Figure_Step5_combined brings the historical model comparisons and seasonal results together.
- results/selected_day_metrics_summary.csv summarises the number, clustering and maximum run length of model-selected days. results/storyline_paired_model_differences.csv compares models on the same simulated seasons.
- For individual seasons, use results/per_model_season_metrics/ (one compressed CSV for each model). The combined seasonal file contains 1,980,000 rows, beyond the capacity of a single Excel worksheet.
- model_registry.json lists the predictors for every model. METHODS_AND_LIMITATIONS.txt explains the analysis. FIGURE_CAPTIONS.txt describes the figures.

Inputs
The bathing water workbook is in inputs/bathing_water_records_2012_2024.xlsx. The input folder also contains the Step 4 daily historical calendar, donor library, circulation-family mapping and six sets of simulated donor sequences. Their locations under inputs/step4/ follow the structure of the corrected Step 4 package. INPUT_MANIFEST.csv lists the input file hashes checked at the start of each run.

The historical end-of-day API restarts when rainfall measurements resume after a gap. Missing rainfall on the sampling day leaves the observed API missing. The primary models handle such gaps using values estimated from the training years. Simulated API is calculated independently along the complete rainfall sequence for each simulated season.

Run on Windows
Open PowerShell in the extracted Step5_final folder, alongside run_step5.py. Use Python 3.12 and the pinned dependencies.

  py -3.12 -m venv .venv
  .\.venv\Scripts\python.exe -m pip install -r requirements.txt
  .\.venv\Scripts\python.exe verify_package.py
  .\.venv\Scripts\python.exe -m unittest discover -s code -p "test*.py" -v
  .\.venv\Scripts\python.exe run_step5.py

The last command fits the models, evaluates them, predicts across the storylines and produces the ten main and supplementary figure sets. When a completed run already exists, it writes to a new timestamped folder under runs/ and prints its location. For the two additional publication figures and integration checks in that fresh run, stay in the same PowerShell window:

  $python = (Resolve-Path .\.venv\Scripts\python.exe).Path
  $latest = Get-ChildItem .\runs -Directory -Filter 'Step5_*' | Sort-Object Name -Descending | Select-Object -First 1
  Push-Location $latest.FullName
  & $python .\code\plot_additional_publication_figures.py
  & $python .\verify_results.py
  Pop-Location

To inspect the delivered results you can open the CSVs and figures directly. To run the integration checks on the delivered results, run .\.venv\Scripts\python.exe verify_results.py in Step5_final. The check tests the saved predictions and selections and runs small daily exports for all six scenarios.

Use the simulated predictions
simulation_probabilities/ contains one NPZ file per scenario with raw and calibrated probabilities for 11 models, 5,000 seasons and 153 evaluation days. The files use float32 storage. Day selection used the full-precision probabilities, and the exact selections are saved in simulation_probabilities/selection_masks/. The final fitted classifiers and calibrators are in fitted_models/.

For a small full-precision CSV export from the delivered results:

  .\.venv\Scripts\python.exe export_probabilities.py --scenario baseline --n-seasons 2 --full-precision

The output appears in exported_probabilities/. Omit --n-seasons 2 to export all 5,000 seasons for that scenario, or omit --full-precision to export the stored probabilities. Scenario names are listed in config.json.
