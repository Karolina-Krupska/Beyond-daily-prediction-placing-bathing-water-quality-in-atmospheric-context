"""Run conditional Step 6 inference from included inputs, or redraw its figures.

Examples
--------
python run_inference.py
python run_inference.py --figures-only

No microbiological models are fitted and no weather ensembles are regenerated.
"""
from pathlib import Path
import argparse
import contextlib
import datetime
import json
import sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'code'))


class Tee:
    def __init__(self,*handles):self.handles=handles
    def write(self,value):
        for handle in self.handles:handle.write(value);handle.flush()
    def flush(self):
        for handle in self.handles:handle.flush()


def run_pipeline(root=ROOT,figures_only=False,workers=3):
    """Execute inference, figures and independent verification in that order.

    ``figures_only`` requires existing inference tables and bootstrap draws.
    It never falls back to numerical resampling if an input is missing.
    """
    root=Path(root).resolve()
    if workers<1:raise ValueError('workers must be positive')
    if figures_only:
        needed=['mean_confidence_intervals.csv','paired_tests.csv',
                'model_mean_bootstrap_replicates.npz','paired_bootstrap_replicates.npz',
                'INFERENCE_METADATA.json']
        missing=[name for name in needed if not (root/'results/inference'/name).is_file()]
        if missing:raise FileNotFoundError('Existing inference inputs required for --figures-only: '+', '.join(missing))
    logs=root/'logs';logs.mkdir(parents=True,exist_ok=True)
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d_%H%M%S_%f')
    log_path=logs/f'inference_execution_{stamp}.log'
    with log_path.open('w',encoding='utf-8') as handle:
        stdout=Tee(sys.stdout,handle);stderr=Tee(sys.stderr,handle)
        with contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
            print('Inference pipeline started',datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
            print('Mode:', 'existing inference figures only' if figures_only else 'conditional bootstrap, figures and verification',flush=True)
            if not figures_only:
                from inference_step6 import run
                run(root,workers=workers)
            from inference_figures_step6 import make_inference_figures
            make_inference_figures(root)
            from publish_inference_figures import publish
            publish(root)
            from verify_inference_step6 import verify
            verification=verify(root,require_figures=True)
            from write_inference_reports import write_reports
            write_reports(root)
            result={'status':'completed','figures_only':bool(figures_only),
                    'models_refitted':False,'weather_regenerated':False,
                    'log':str(log_path.relative_to(root)),
                    'verification':verification}
            print('Inference pipeline completed',datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
            return result


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=ROOT,help='Step6 package/output root with included scientific inputs/results')
    parser.add_argument('--workers',type=int,default=3,help='Processes used for bootstrap prediction summaries')
    parser.add_argument('--figures-only',action='store_true',help='Redraw existing inference tables and verify; no bootstrap or prediction reconstruction')
    args=parser.parse_args()
    result=run_pipeline(args.root,args.figures_only,args.workers)
    print(json.dumps(result,indent=2))
