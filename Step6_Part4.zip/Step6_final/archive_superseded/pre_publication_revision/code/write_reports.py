"""Create copy-ready reporting from the current, verified result tables."""
from pathlib import Path
import json
import numpy as np
import pandas as pd

def write_reports(root):
    root=Path(root);out=root/'results';reports=root/'reports';reports.mkdir(exist_ok=True)
    summary=pd.read_csv(out/'seasonal_summary.csv',float_precision='round_trip')
    pairs=pd.read_csv(out/'paired_model_differences.csv',float_precision='round_trip')
    match=pd.read_csv(out/'matched_count_paired_differences.csv',float_precision='round_trip')
    tie=pd.read_csv(out/'tie_seed_sensitivity.csv',float_precision='round_trip')
    mtie=pd.read_csv(out/'matched_count_tie_sensitivity.csv',float_precision='round_trip')
    validation=json.loads((out/'VERIFICATION.json').read_text())
    units=json.loads((out/'UNIT_TEST_STATUS.json').read_text())
    meta=json.loads((out/'EXECUTION_METADATA.json').read_text())
    sources=json.loads((root/'inputs/provenance/SOURCE_ARCHIVES.json').read_text())
    registry=json.loads((root/'inputs/step5/model_registry.json').read_text())
    rows=[]
    for letter,entry in registry.items():
        rows.append(dict(model=letter,label='WP' if letter=='D' else entry['label'],
            numerical_predictors='; '.join(entry['numerical']),categorical_predictors='; '.join(entry['categorical'])))
    pd.DataFrame(rows).to_csv(out/'model_registry.csv',index=False)
    def value(model,rule,story,metric):
        return float(summary[(summary.model==model)&(summary.rule==rule)&(summary.storyline==story)&(summary.metric==metric)]['mean'].iloc[0])
    def rng(frame,col):return f"{frame[col].min():.4f} to {frame[col].max():.4f}"
    gm=match[(match.comparison=='G-K')&(match.metric=='max_run_days')]
    gc=match[(match.comparison=='G-K')&(match.metric=='clusters')]
    pp=pairs[(pairs.comparison=='G-K')&(pairs.rule=='topk_10')&(pairs.metric=='max_run_days')]
    visual_note=('Both were visually inspected in this delivery.' if (reports/'FIGURE_QA.json').exists()
                 else 'Manual visual inspection is not recorded for this run.')
    assembly_note=('The initial assembly invocation completed analysis and figure generation before its verifier module was available; that import failure is retained in the initial log. After the module was supplied, the final figure/verification invocation completed successfully without replacing the scientific results.'
                   if (root/'logs/analysis_and_initial_figure_execution.log').exists() else '')
    methods="""STEP 6 — TEMPORAL ORGANISATION OF MODEL-SELECTED DAYS

Calibrated probabilities from the final Step 5 models were evaluated for six atmospheric scenarios, each comprising 5,000 simulated May–September seasons following April initialisation. The 2001 calendar provided synthetic date labels only. No microbiological model was refitted, no calibrator was re-estimated and no weather ensemble was regenerated. Existing exact selection masks were retained and independently reproduced from float64 predictions using the supplied fitted models and final Step 4 donor sequences.

For each model separately, daily probabilities were ranked across all six equally sized scenario ensembles (4,590,000 evaluation days). All five fractions (1%, 5%, 10%, 25% and 50%) were evaluated. At the author's request, Top 10% is the main-paper illustration and 1%, 5%, 25% and 50% are supplementary. Exact ties used the saved shared pseudorandom priorities, SeedSequence[42,5,700]. The pooled selected total was fixed for each model, while selected totals within scenarios and seasons could differ. These fractions are analytical selection budgets, not operational warning thresholds.

Three outcomes were calculated within each 153-day season: selected days, number of uninterrupted selected-day clusters, and maximum consecutive run length. All outcomes were zero in seasons without selected days. Isolated selected days counted as one cluster; runs could not cross season boundaries. Means and 5th–95th percentiles describe central 90% conditional simulation ranges. Percentiles use NumPy's default linear interpolation and may consequently be fractional, although individual-season outcomes are integers.

The principal WP comparison was G minus K; E minus C and F minus J were supporting comparisons. These pairs shared numerical predictors and evaluation records and differed in inclusion of the four-family WP predictor. Differences were calculated on the same scenario and simulated-season records. Scenario–baseline differences used the supplied common-random-number coupling: Step 4 shares donor-selection uniforms by simulation index. This is a numerical coupling, not observational or causal pairing.

To distinguish temporal organisation from differences in selected-day counts, a secondary analysis selected exactly eight or sixteen days in every season for each comparison model. These counts are ceil(0.05×153) and ceil(0.10×153), corresponding to actual fractions of 5.23% and 10.46%. Daily ranking remained calibrated-probability based; shared within-season priorities used SeedSequence[42,6,800]. This changes the estimand and removes seasonal count differences by construction. Approximate 95% Monte Carlo intervals for paired mean differences were mean±1.96×SD/√5000, conditional on the fitted models, generator and per-season selection scheme; they are pointwise numerical-precision intervals, not intervals for real-world effects. Degenerate selected-day differences of zero in this sensitivity arise by design.

The original descriptive tables retain fixed-cutoff Monte Carlo errors and twenty disjoint 250-season batches as diagnostics. Current inference is supplied separately in results/inference: 4,000 paired whole-simulation-bundle bootstrap replicates, with exact pooled Top-k selection repeated in every draw. Mean and paired-difference confidence intervals are pointwise 95% normal-approximation conditional Monte Carlo intervals. Approximate two-sided normal/Wald tests use bootstrap standard errors, with Holm adjustment across 270 prespecified comparisons. Original 5th–95th seasonal ranges remain separate. Boundary-tie and matched-count priority-stream sensitivities are retained. Full inference methods, normal-approximation diagnostics and limitations are in INFERENCE_METHODS_AND_LIMITATIONS.txt.
"""
    limitations="""INTERPRETATION AND LIMITATIONS

These experiments describe organisation of model-selected days under the specified simulated conditions. They do not validate observed contamination duration, actual advice against bathing, prospective forecast lead time or public-health benefit. Historical Step 5 discrimination and calibration evidence is supplied separately and is not relabelled as Step 6 simulation validation.

Seasonal ranges quantify variability within the fitted simulation system. Neither those ranges nor the matched-count Monte Carlo intervals propagate uncertainty in the historical observations, microbiological-model fitting, calibration, transition probabilities or donor-library construction. Increasing the number of simulated seasons reduces numerical error, not these structural uncertainties. The pooled cut-offs are estimated from the same ensemble being summarised. The new whole-season bootstrap repeats pooled selection to incorporate their conditional Monte Carlo variation. Its normal-approximation intervals and tests remain approximate; they do not include historical parameter or structural uncertainty.

Rainfall persistence remains underestimated in Step 4; the historical input retains 74 missing rainfall dates, and rare donor pools constrain support. Soil and rainfall-memory indicators are resampled or derived rather than governed by a dynamical water balance. Regional predictors and retrospective full-day inputs further limit operational interpretation. More selected days can themselves produce longer runs; only the secondary matched-count analysis controls that count difference. It does not establish a causal circulation effect. No independent observed daily contamination-episode validation was completed in this step.

The former 'recovery' measure was a gap between the last selection and season end. It was removed because it did not measure microbial recovery or forecast lead time. Zero-selection frequencies are supplied as a table rather than binary-quantile error bars. Model D is labelled WP in the current registry display while retaining the original four-family predictor.
"""
    results=f"""STEP 6 — COPY-READY RESULTS

The main-paper Top-10% analysis retained exactly 459,000 selected days per model across the six scenario ensembles. For model G, mean selected days were {value('G','topk_10','persistent_wet','selected_days'):.2f} under persistent wet conditions and {value('G','topk_10','flip_dry_to_wet','selected_days'):.2f} under dry-to-wet conditions, compared with {value('G','topk_10','baseline','selected_days'):.2f} for baseline, {value('G','topk_10','persistent_dry','selected_days'):.2f} for persistent dry conditions and {value('G','topk_10','dry_with_bursts','selected_days'):.2f} for dry conditions with storm outbreaks. These differences redistribute a fixed pooled selection budget; they do not represent observed contamination frequencies.

Adding WP to the full hydrometeorological model produced small, scenario-dependent changes in the primary analysis. G−K differences in mean maximum run length ranged from {rng(pp,'mean_difference')} days, with both positive and negative changes. A common increase in persistence across all primary storylines was therefore not demonstrated.

At equal selected-day counts of eight or sixteen per season, G produced fewer clusters than K across all six scenarios. Mean cluster differences ranged from {rng(gc,'mean_difference')}, while maximum runs increased by {rng(gm,'mean_difference')} days. This supports a small change in simulated temporal organisation at a controlled count, conditional on the fitted model and generator. It does not establish improved warning accuracy or operational benefit. The corresponding pointwise Monte Carlo intervals quantify simulation precision only.

Budget dependence, supporting E−C/F−J comparisons, zero-selection frequencies and tie sensitivities are available in the result tables. Some outcomes change direction across budgets; broad-budget results must not be substituted for the primary analysis because they appear stronger.
"""
    review=f"""STEP 6 — REVIEW REPORT

SOURCE AND SCOPE
Supplied Step 5: Step5_final (2).zip; SHA-256 {sources['Step5_final (2).zip']['sha256']}.
Supplied Step 4: Step4_final(1).zip; SHA-256 {sources['Step4_final(1).zip']['sha256']}.
All 23 Step 4 members embedded in Step 5 were byte-identical to the supplied final Step 4 counterparts. The corrected source workbook is included unchanged for cohort provenance only; it was not used to refit models in Step 6. Its SHA-256 is c4dea14f2223bde55297e0eb9085e50cafd08d36e8f9a435536c55e114e70f62.

CONFIRMED CORRECTIONS
Both original scripts were read; see ORIGINAL_STEP6_CODE_REVIEW.md and their inactive archive. The later calibrated-all-models script provided the appropriate scientific starting concept, but both CSV-era readers required replacement for the current six-scenario/A–K outputs. The revised modular code preserves the three agreed metrics and saved calibrated selections. It adds K, baseline, exact full-precision reconciliation and explicit zero-season handling. The original significance stars were based on unadjusted p-values even though FDR values were saved separately. They are not carried forward. The season-end gap is no longer described as recovery or lead time.

EXECUTED CHECKS
All 55 pooled masks were reproduced exactly from full-precision calibrated predictions. All 1,650,000 primary seasonal metric records match Step 5 for the three retained outcomes. The matched-count sensitivity contains 360,000 model-budget-scenario-season records, with exactly 8 or 16 selected days in every season. Independent verification reports {validation['checks_passed']} passed integration checks; details are in results/VERIFICATION.json. {units['tests_run']} focused unit tests cover metric definitions, boundaries, count control, ties and nesting; their actual execution log is supplied. Check success establishes numerical consistency, not physical or operational validation.

SENSITIVITY FINDINGS
Across all scenarios and both matched-count budgets, G−K cluster differences range {rng(gc,'mean_difference')}; maximum-run changes range {rng(gm,'mean_difference')} days. These are small changes. Pooled Top-10% maximum-run changes have mixed signs. Pooled tie sensitivities tested {', '.join(sorted(tie.model.unique()))}; the full numerical G/K comparison has no consequential tied boundary allocation. Largest tested pooled mean shifts were {tie.loc[tie.metric=='selected_days','change_from_primary'].abs().max():.4f} selected days, {tie.loc[tie.metric=='clusters','change_from_primary'].abs().max():.4f} clusters and {tie.loc[tie.metric=='max_run_days','change_from_primary'].abs().max():.4f} maximum-run days. Across all matched comparison models, the largest tested mean shift was {mtie.mean_change.abs().max():.4f}. These finite alternative seeds provide a bounded check, not exhaustive tie uncertainty.

FIGURES
The main-paper figure is Main_publication/Figure_Main_Top10: a three-panel G/K comparison at 1200 dpi plus PDF/SVG. Other selection fractions are in Supplementary. Legacy_style_updated provides 15 grouped-bar comparisons across all models and five fractions. Original supplied images are clearly marked reference-only. The earlier Top-1% compatibility plot and paired budget-sensitivity figure are also retained. Both were generated directly from verified tables and exported at 600 dpi plus PDF/SVG. {visual_note} All 306 core plotted records reconcile to the current source tables. The added All_percentages folder contains the same absolute G/K comparison at 1%, 5%, 10%, 25% and 50%, with 180 separately checked records and a five-page PDF. The 1% page duplicates the earlier Top-1% figure, now supplementary. All A–K outcomes remain in tables. The all-model grouped-bar figures were added at the author's request as supporting comparisons, not main-paper figures.

UNRESOLVED LIMITATIONS
No full pipeline refitting, generator-parameter uncertainty or prospective episode validation was attempted. Historical uncertainty from Step 5 is provided as context only. The original descriptive Monte Carlo errors condition on fixed cut-offs. Current bootstrap intervals repeat exact pooled selection; normal/Wald inference remains approximate and conditional. Read INFERENCE_REVIEW.txt for completed tests, diagnostic flags and current figure locations. Rainfall persistence bias, 74 historical rainfall gaps, donor support, absence of a dynamical water balance and retrospective predictor timing remain. No guaranteed journal acceptance or 'reviewer-proof' claim is made.

EXECUTION
Elapsed analysis time: {meta['elapsed_seconds']:.1f} seconds. Model fitting: none. Weather regeneration: none. Full-precision prediction reconstruction and selection verification were performed. {assembly_note}
"""
    for name,text in [('METHODS.txt',methods),('LIMITATIONS.txt',limitations),('RESULTS_WORDING.txt',results),('REVIEW_REPORT.txt',review)]:
        (reports/name).write_text(text,encoding='utf-8')
    if (out/'inference/INFERENCE_METADATA.json').exists():
        current_review=(reports/'REVIEW_REPORT.txt').read_text()
        start=current_review.find('FIGURES\n')
        end=current_review.find('UNRESOLVED LIMITATIONS\n',start)
        if start>=0 and end>start:
            current_review=current_review[:start]+('FIGURES\nThe current annotated delivery contains42canonical figure sets in figures/Inference, all inPNG/PDF/SVG. Top10% is the main-paper display (1200dpi plus600dpi copy), with paired-difference95%CIs. Fifteen old-style all-model bars have95%mean CIs and corrected significance; another15retain the original90%seasonal ranges with the same tests. All five percentages have G/K comparisons and individual heatmaps; the combined3x3heatmap covers all270contrasts. Familiar folder aliases point to these current files. Earlier unannotated versions are explicitly inactive. See figures/INDEX.html and reports/FIGURE_QA_INFERENCE.json.\n\n')+current_review[end:]
            (reports/'REVIEW_REPORT.txt').write_text(current_review,encoding='utf-8')
    if (out/'INDEPENDENT_REPRODUCTION.json').exists():
        rep=json.loads((out/'INDEPENDENT_REPRODUCTION.json').read_text())
        if rep.get('status')=='passed':
            note=f"\nINPUTS-ONLY REPRODUCTION\nA clean execution from an isolated directory containing only the included inputs, code and settings completed successfully. All {len(rep['table_comparisons'])} result CSV tables (including decompressed seasonal tables) and both PNG figures were identical. See results/INDEPENDENT_REPRODUCTION.json and logs/independent_inputs_only_reproduction.log.\n"
            with (reports/'REVIEW_REPORT.txt').open('a',encoding='utf-8') as handle:handle.write(note)
    readme="""STEP 6 — TEMPORAL ORGANISATION OF MODEL-SELECTED DAYS

OPEN THESE FIRST
figures/Main_publication/Figure_Main_Top10.png — MAIN PAPER, 1200 dpi.
figures/00_START_HERE.txt — current main/supplement/reference figure guide.
figures/Figure_Step6_All_percentages.pdf — five pages: 1%, 5%, 10%, 25%, 50%.
figures/All_percentages/ — individual PNG/PDF/SVG files for every fraction.
figures/Main_publication/Figure_Main_Top10.png — main-paper three-panel G/K figure, 1200 dpi.
figures/Main_publication/Figure_Main_Top10.pdf and .svg — editable vector main figure.
figures/Supplementary/ — Top 1%, 5%, 25%, 50% and paired-budget sensitivity.
figures/Legacy_style_updated/ — earlier grouped-bar style with current A–K results.
figures/Original_reference_NOT_FOR_PUBLICATION/ — unchanged original old-data images, reference only.
figures/Figure_Step6_Storyline_behaviour.png — earlier Top-1% compatibility plot, now supplementary.
figures/Figure_Step6_Paired_budget_sensitivity.png — supporting model pairs and budgets.
reports/RESULTS_WORDING.txt — current copy-ready results.
reports/REVIEW_REPORT.txt — corrections, completed checks and remaining limits.
reports/METHODS.txt and LIMITATIONS.txt — copy-ready reporting.

THIS IS ONE SELF-CONTAINED STEP 6 PACKAGE
All required Step 5 models, exact masks, final Step 4 driver sequences and donor data are included. The corrected historical workbook is retained for provenance. No external Step 4/5 folder, old modelling CSV, raw ERA5 files, refitting or weather regeneration is required. Model binaries are the user's supplied fitted models; load only trusted copies of this package.

The large original raw/calibrated float32 probability archives are not duplicated. Step 6 reconstructs float64 calibrated probabilities temporarily from the included fitted models and driver inputs, verifies all exact saved masks, then removes the temporary array. This preserves precision while reducing download size. Full per-day probability archives remain in the supplied Step 5 package. The original three primary metrics are unchanged; the equal-count sensitivity is new.

RUN ON WINDOWS
Extract the ZIP completely. Open a terminal in Step6_final. Use Python 3.12 and the recorded dependency versions:

  py -3.12 -m venv .venv
  .venv\\Scripts\\python.exe -m pip install -r requirements.txt
  .venv\\Scripts\\python.exe run_step6.py

This single entry point calls the included helper modules and produces data tables, the core figures, absolute figures for all five selection fractions and verification reports. It does not call a model-fitting routine. It may require a few GB of available RAM and approximately 0.5 GB of temporary disk space. A completed delivery is protected: the default creates a new isolated runs/Step6_timestamp folder. Use --output PATH for another destination. The explicit --overwrite-results option replaces current result tables. --figures-only regenerates figures and verification from existing tables without reconstructing predictions. To reproduce only the new conditional inference from existing Step 6 inputs/results, use run_inference.py. To redraw only its figures without new bootstrap calculations, use run_inference.py --figures-only. The complete run_step6.py pipeline now also runs the new inference and all annotated figure exports.

OPTIONAL FAST CHECKS
  .venv\\Scripts\\python.exe -m unittest discover -s code -p test_step6.py -v
  .venv\\Scripts\\python.exe code/verify_step6.py

DATA TABLES
results/seasonal_metrics.csv.gz: all A–K pooled-budget season metrics (1,650,000 rows).
results/seasonal_summary.csv: means, medians, seasonal percentiles and zero fractions.
results/paired_model_differences.csv: E−C, F−J, G−K within the same simulated seasons.
results/scenario_baseline_differences.csv: coupled scenario-minus-baseline differences.
results/matched_count_*: six comparison models at exactly 8/16 selected days per season.
results/tie_seed_sensitivity.csv and matched_count_tie_sensitivity.csv: priority-stream checks.
results/simulation_batch_stability.csv: disjoint 250-season batch diagnostics.
results/zero_selection_seasons.csv: zero-season frequencies and conditional run summaries.
results/budget_and_precision_audit.csv: exact pooled totals, boundaries and reconciliation.
results/upstream_*: historical Step 5 predictive evidence, separate from simulation uncertainty.
results/model_registry.csv: all current model definitions; D labelled WP.

The primary combined table exceeds Excel's worksheet row limit. Use Python or the small summary tables. Gzip files can be read directly with pandas.read_csv. Inputs/provenance contains hashes and byte comparisons. Old scripts are inactive in archive_superseded. Figures use the current results, not screenshots or old plotting values.

INTERPRETATION
The main-paper Top-10% selection is pooled over all six equally sized scenarios separately for each model. The total is fixed, but seasonal/scenario selected counts vary. Percentile whiskers show simulated variation, not confidence in real-world effects. Matched-count Monte Carlo intervals quantify numerical precision under fixed models and generator. Current figures show Holm-adjusted approximate normal/Wald p-values and 95% conditional Monte Carlo confidence intervals. These are not operational warning validation. The 90% seasonal-range versions are retained separately; see reports/INFERENCE_METHODS_AND_LIMITATIONS.txt. The 2001 dates are synthetic calendar labels. See limitations before using any manuscript wording.

SETTINGS
config.json records the agreed specification; it is not a general parameter-search interface. Change settings and the corresponding code together, retain provenance and rerun into a separate output directory. Requirements are pinned to the actual execution environment because fitted sklearn models depend on compatible versions.
"""
    if (out/'inference/INFERENCE_METADATA.json').exists():
        imeta=json.loads((out/'inference/INFERENCE_METADATA.json').read_text())
        current=('CURRENT SIGNIFICANCE AND CONFIDENCE-INTERVAL UPDATE\n\n'
                 'Open figures/INDEX.html or figures/00_START_HERE.txt.\n'
                 'Main paper: figures/Main_publication/Figure_Main_Top10.png.\n'
                 'All-model annotated bars with 95% CIs: figures/Legacy_style_updated/Top01, Top05, Top10, Top25, Top50.\n'
                 'Original-style seasonal ranges plus corrected stars: figures/Inference/Grouped_bars_90ranges/.\n'
                 'Combined and individual heatmaps: figures/Inference/Heatmaps/.\n'
                 'All PNG/PDF/SVG exports and source data: figures/Inference/.\n'
                 'New inference methods and review: reports/INFERENCE_METHODS_AND_LIMITATIONS.txt and INFERENCE_REVIEW.txt.\n\n')
        readme=current+readme
        reports_note=(f"\nCURRENT INFERENCE UPDATE\n{imeta['replicates']:,} whole-season bundle bootstrap draws completed. "
                      f"{imeta['significance_count']}/270 contrasts have Holm-adjusted p<0.05. "
                      f"{imeta['normal_approximation_flagged_contrasts']} diagnostic flags require caution. "
                      'See the two INFERENCE reports for current figures, exact testing scope and limitations. '
                      'Earlier numerical point estimates are unchanged.\n')
        with (reports/'REVIEW_REPORT.txt').open('a',encoding='utf-8') as handle:handle.write(reports_note)
    (root/'README.txt').write_text(readme,encoding='utf-8')

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent.parent)
    write_reports(p.parse_args().root)
