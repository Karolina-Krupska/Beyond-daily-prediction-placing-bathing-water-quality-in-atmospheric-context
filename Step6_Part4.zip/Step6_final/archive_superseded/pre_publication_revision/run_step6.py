"""Reproduce Step 6 from included inputs only. No fitting or upstream reruns."""
from pathlib import Path
import argparse,sys,contextlib,datetime,json,shutil
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'code'))

class Tee:
    def __init__(self,*handles):self.handles=handles
    def write(self,s):
        for h in self.handles:h.write(s);h.flush()
    def flush(self):
        for h in self.handles:h.flush()

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--figures-only',action='store_true')
    p.add_argument('--output',type=Path,help='Optional separate reproducible output directory')
    p.add_argument('--overwrite-results',action='store_true',help='Explicitly replace this folder results rather than create a fresh run')
    a=p.parse_args();target=a.output.resolve() if a.output else ROOT
    if not a.figures_only and target==ROOT and (ROOT/'results/COMPLETION.json').exists() and not a.overwrite_results:
        target=ROOT/'runs'/datetime.datetime.now().strftime('Step6_%Y%m%d_%H%M%S')
    if target!=ROOT:
        target.mkdir(parents=True,exist_ok=True)
        for name in ['inputs','code','config.json','run_step6.py','run_inference.py','requirements.txt','archive_superseded']:
            q=ROOT/name
            if q.is_dir():shutil.copytree(q,target/name,dirs_exist_ok=True)
            else:shutil.copy2(q,target/name)
    for name in ['results','figures','logs']:(target/name).mkdir(parents=True,exist_ok=True)
    with (target/'logs/execution.log').open('w',encoding='utf-8') as log,contextlib.redirect_stdout(Tee(sys.stdout,log)),contextlib.redirect_stderr(Tee(sys.stderr,log)):
        print('Started',datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
        if not a.figures_only:
            from analysis_step6 import run
            run(target)
        from figures_step6 import make_figures
        make_figures(target)
        import unittest
        suite=unittest.defaultTestLoader.discover(str(target/'code'),pattern='test*.py')
        with (target/'logs/unit_tests.log').open('w',encoding='utf-8') as unit_log:
            tests=unittest.TextTestRunner(stream=Tee(sys.stdout,unit_log),verbosity=2).run(suite)
        (target/'results/UNIT_TEST_STATUS.json').write_text(json.dumps({'status':'passed' if tests.wasSuccessful() else 'failed',
            'tests_run':tests.testsRun,'failures':len(tests.failures),'errors':len(tests.errors),
            'log':'logs/unit_tests.log','scope':'Numerical definitions and selection logic; not physical validation'},indent=2))
        if not tests.wasSuccessful():raise RuntimeError('Step 6 unit tests failed')
        from verify_step6 import verify
        verify(target)
        from run_inference import run_pipeline
        run_pipeline(target,figures_only=a.figures_only)
        from write_reports import write_reports
        write_reports(target)
        (target/'results/COMPLETION.json').write_text(json.dumps({'status':'completed','UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'models_refitted':False,'weather_regenerated':False,'output_directory':str(target)},indent=2))
        print('Completed',target,flush=True)
