from pathlib import Path
import argparse
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
p=argparse.ArgumentParser();p.add_argument('--results',type=Path,default=Path('/workspace/scratch/6f69e635a082/work_step6/Step6_final/results/inference'));a=p.parse_args();out=Path(__file__).resolve().parent
m=pd.read_csv(a.results/'mean_confidence_intervals.csv');t=pd.read_csv(a.results/'paired_tests.csv');m=m[(m.rule=='topk_10')&m.model.isin(['G','K'])];t=t[(t.rule=='topk_10')&(t.comparison=='G-K')]
stories=['baseline','persistent_wet','flip_wet_to_dry','dry_with_bursts','persistent_dry','flip_dry_to_wet'];labels=['Baseline','Persistent wet','Wet to dry','Dry with storm\noutbreaks','Persistent dry','Dry to wet'];metrics=['selected_days','clusters','max_run_days'];titles=['Selected days','Clusters','Maximum run length'];col={'G':'#0072B2','K':'#D55E00'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','pdf.fonttype':42})
fig,axes=plt.subplots(3,2,figsize=(7.2,9.1));fig.subplots_adjust(left=.22,right=.94,top=.89,bottom=.115,hspace=.56,wspace=.57)
y=np.arange(6)
for j,(metric,title) in enumerate(zip(metrics,titles)):
 ax,bx=axes[j]
 for row in [0,2,4]:
  for q in [ax,bx]:q.axhspan(row-.48,row+.48,color='#F3F5F6',lw=0)
 for model,offset,marker in [('G',-.12,'o'),('K',.12,'D')]:
  v=m[(m.model==model)&(m.metric==metric)].set_index('storyline').loc[stories]
  ax.hlines(y+offset,v.ci95_lower,v.ci95_upper,color=col[model],lw=1.2)
  ax.plot(v['mean'],y+offset,marker,ms=4,color=col[model],mec='white',mew=.3)
 ax.set_yticks(y,labels);ax.set_xlim(left=0);ax.set_xlabel('Clusters per season' if metric=='clusters' else 'Days per season');ax.set_title(title,loc='left',fontsize=10,pad=10)
 v=t[t.metric==metric].set_index('storyline').loc[stories]
 bx.axvline(0,color='#777777',ls='--',lw=.8);bx.hlines(y,v.ci95_lower,v.ci95_upper,color=col['G'],lw=1.3);bx.plot(v.mean_difference,y,'o',color=col['G'],ms=4)
 bx.set_yticks(y,[]);bx.set_xlabel('Difference ('+('clusters' if metric=='clusters' else 'days')+')');bx.set_title(title,loc='left',fontsize=10,pad=10)
 for i,s in enumerate(stories):bx.text(1.055,i,v.loc[s,'stars'],transform=bx.get_yaxis_transform(),fontsize=8,ha='left',va='center')
 for k,q in enumerate([ax,bx]):
  q.set_ylim(5.55,-.55);q.grid(axis='x',color='#dfe4e7',lw=.5);q.set_axisbelow(True);q.spines['left'].set_visible(False);q.tick_params(axis='y',length=0,pad=7);q.text(-.09,1.12,chr(97+2*j+k),transform=q.transAxes,fontweight='bold',fontsize=11)
fig.text(.22,.94,'Seasonal outcomes',fontsize=11,fontweight='bold');fig.text(.66,.94,'Effect of adding WP',fontsize=11,fontweight='bold')
fig.legend([Line2D([],[],color=col['G'],marker='o',ls='none'),Line2D([],[],color=col['K'],marker='D',ls='none')],['G: with WP','K: without WP'],loc='upper center',bbox_to_anchor=(.47,.997),ncol=2,frameon=False,fontsize=9)

fig.text(.22,.045,'Top 10% | Points: means | Lines: 95% confidence intervals',fontsize=7.5)
fig.text(.22,.022,'G − K: * adjusted p < 0.05; ** < 0.01; *** < 0.001; ns: not significant',fontsize=7)
for ext in ['png','pdf','svg']:fig.savefig(out/f'Figure_GK_outcomes_and_differences_Top10.{ext}',dpi=600)
fig.savefig(out/'preview.png',dpi=150)
caption='Figure. Seasonal outcomes and the effect of adding weather-pattern information at a pooled Top-10% selection fraction. Left panels show mean selected days (a), clusters (c) and maximum run length (e) for the full model with WP (G) and the same numerical predictors without WP (K), across six atmospheric scenarios. Right panels show the corresponding paired mean differences, G minus K (b, d, f); the dashed line denotes zero difference. Lines are pointwise95% conditional Monte Carlo confidence intervals from4,000 whole-season bundle bootstrap resamples, repeating exact pooled Top-k selection within every resample. Symbols denote approximate two-sided normal/Wald tests adjusted by Holm across270 prespecified contrasts: *p<0.05, **p<0.01, ***p<0.001; ns, not significant. Pointwise confidence intervals and multiplicity-adjusted significance need not agree. Inference conditions on fitted models, calibrators, donor library and weather generator and excludes uncertainty in their estimation. Selected days are model selections, not issued advisories or observed contamination episodes. WP denotes the four-family predictor.\n'
caption=caption.replace('pointwise95','pointwise 95').replace('from4','from 4').replace('across270','across 270').replace('*p','* p')
(out/'Caption.txt').write_text(caption);m.to_csv(out/'Mean_source_Top10.csv',index=False);t.to_csv(out/'Difference_source_Top10.csv',index=False)
assert len(m)==36 and len(t)==18 and np.isfinite(m[['mean','ci95_lower','ci95_upper']]).all().all()
print('Exported six panels from36mean and18paired records; no model fitting or statistical recalculation.')
