#Season-level deltas: Δ = (WP model) − (non-WP model) per season, per storyline, per rate

#Paired block bootstrap tests on Δ within each storyline: Δmean + 95% CI + p

#FDR (Benjamini–Hochberg) correction within each comparison (E–C separately from F–J) across (rate × storyline × metric)

#Interaction (optional) permutation test: do Δ effects differ across storylines? (per metric & rate)

#Publishable summary heatmaps (Δmean with */** overlay) across storylines × rates, for each metric and each comparison

#Keeps your existing main bar figures with bracket stars for E–C and F–J (as before)

#Stars on plots follow exactly what you asked:

#* p < 0.05

#** p < 0.01#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

from pathlib import Path
import os
import time
import zlib
from typing import Dict, List, Tuple, Optional

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# ============================================================
# USER SETTINGS
# ============================================================

MASTER_SIM_FILE = Path(
    r"C:\Users\earth\OneDrive - University of Reading\PHD 2\Chapters\Paper 2\Codes 2\Analytical procedure\Step 5 Models A-J\probabilities for models A - J mastersheet_20260518_195853\sim_with_predictions.csv.gz"
)

OUT_BASE_DIR = Path(
    r"C:\Users\earth\OneDrive - University of Reading\PHD 2\Chapters\Paper 2\Codes 2\Analytical procedure\Step 6 Storylines behaviour"
)

# Selection fractions to run. The manuscript uses Top-10% as the primary
# comparison, with Top-1%, Top-5% and Top-25% as sensitivity analyses.
# Top-50% is deliberately excluded from this final production script.
TOP_FRACS = [0.25, 0.10, 0.05, 0.01]

# FINAL ANALYSIS RULE: use calibrated probabilities consistently for ALL models A-J.
# No model-specific raw-probability override is permitted.
USE_CALIBRATED = True
REQUIRE_CALIBRATED_FOR_ALL = True

# Chunked reading to avoid memory issues
CHUNKSIZE = 80_000

# Use python engine to avoid "C error: out of memory" on some large gz files
ENGINE = "python"

# Tie-breaking:
# - "hash" is recommended (prevents bias when probabilities are discrete / many ties).
# - "ordered" uses storyline/sim/day ordering (can bias ties).
TIEBREAK = "hash"  # "hash" or "ordered"

# Histogram binning for boundary finding (memory-stable at extreme rates like top-1%)
PROB_HIST_BINS = 65_536

# Bootstrap settings for p-values (paired by season)
BOOT_N = 10_000
BOOT_SEED = 42

# Interaction permutation test (optional; set to 0 to disable)
INTERACTION_N_PERM = 5000
INTERACTION_SEED = 123

DPI = 200

# Pre-specified WP incremental contrasts (exactly what you described)
SIG_PAIRS = [("E", "C"), ("F", "J")]

# ============================================================

MODEL_ORDER = list("ABCDEFGHIJ")

MODEL_LABELS = {
    "A": "A: intensity",
    "B": "B: depth",
    "C": "C: intensity + depth",
    "D": "D: WP",
    "E": "E: WP + intensity + depth",
    "F": "F: WP + wind + UV + SSRD + t2m + soil/API",
    "G": "G: WP + depth + intensity + wind + UV + SSRD + t2m + soil/API",
    "H": "H: soil / API",
    "I": "I: wind + UV + SSRD + t2m",
    "J": "J: wind + UV + SSRD + t2m + soil/API",
}

MODEL_LONG_NAMES = {
    "A": "A_intensity_only",
    "B": "B_depth_only",
    "C": "C_intensity_plus_depth",
    "D": "D_WP",
    "E": "E_WP_plus_intensity_plus_depth",
    "F": "F_WP_plus_wind_UV_SSRD_t2m_soil_API",
    "G": "G_full_WP_plus_depth_intensity_plus_wind_UV_SSRD_t2m_soil_API",
    "H": "H_soil_API_only",
    "I": "I_wind_UV_SSRD_t2m_only",
    "J": "J_wind_UV_SSRD_t2m_plus_soil_API",
}

# Muted, publication-friendly palette
MODEL_COLORS = {
    "A": "#4E79A7",
    "B": "#F28E2B",
    "C": "#59A14F",
    "D": "#E15759",
    "E": "#B07AA1",
    "F": "#9C755F",
    "G": "#EDC948",
    "H": "#79706E",
    "I": "#76B7B2",
    "J": "#FF9DA7",
}

STORYLINE_ORDER = [
    "persistent_wet",
    "wet_to_dry",
    "dry_with_storm_outbreaks",
    "persistent_dry",
    "dry_to_wet",
]
STORY_ID_MAP = {s: i + 1 for i, s in enumerate(STORYLINE_ORDER)}
ID_TO_STORY = {v: k for k, v in STORY_ID_MAP.items()}

METRIC_COLS = [
    "any_high_risk",
    "high_risk_days",
    "clusters",
    "max_run",
    "end_recovery_days",
]


# ------------------------ helpers ------------------------

def timestamp() -> str:
    return time.strftime("%Y%m%d_%H%M%S")


def safe_mkdir_unique(base: Path) -> Path:
    base.parent.mkdir(parents=True, exist_ok=True)
    if not base.exists():
        base.mkdir(parents=True, exist_ok=False)
        return base
    for i in range(1, 10_000):
        cand = Path(str(base) + f"_{i}")
        if not cand.exists():
            cand.mkdir(parents=True, exist_ok=False)
            return cand
    raise RuntimeError("Could not create a unique output folder.")


def _win_long_path(p: Path) -> str:
    """Return a Windows-safe path (handles long paths via \\?\ prefix)."""
    s = str(p.resolve())
    if os.name != "nt":
        return s
    if s.startswith("\\\\?\\"):
        return s
    if s.startswith("\\\\"):
        return "\\\\?\\UNC\\" + s[2:]
    return "\\\\?\\" + s


def story_order(stories: List[str]) -> List[str]:
    sset = set(stories)
    out = [s for s in STORYLINE_ORDER if s in sset]
    out += [s for s in sorted(stories) if s not in out]
    return out


def story_to_id(story: str) -> int:
    if story in STORY_ID_MAP:
        return STORY_ID_MAP[story]
    return int(zlib.crc32(story.encode("utf-8")) & 0xFFFF)


def pack_season_key(story_id: np.ndarray, sim: np.ndarray) -> np.ndarray:
    return (story_id.astype(np.int64) << 32) | (sim.astype(np.int64) & 0xFFFFFFFF)


def pack_day_key(season_key: np.ndarray, day: np.ndarray) -> np.ndarray:
    return (season_key.astype(np.int64) << 16) | (day.astype(np.int64) & 0xFFFF)


def splitmix64(u: np.ndarray) -> np.ndarray:
    """Deterministic 'random-looking' hash for tie-breaking."""
    x = u.astype(np.uint64)
    x = x + np.uint64(0x9E3779B97F4A7C15)
    x = (x ^ (x >> np.uint64(30))) * np.uint64(0xBF58476D1CE4E5B9)
    x = (x ^ (x >> np.uint64(27))) * np.uint64(0x94D049BB133111EB)
    x = x ^ (x >> np.uint64(31))
    x = x & np.uint64(0x7FFFFFFFFFFFFFFF)
    return x.astype(np.int64)


def run_lengths_from_sorted_days(days_sorted: np.ndarray) -> np.ndarray:
    if days_sorted.size == 0:
        return np.array([], dtype=int)
    if days_sorted.size == 1:
        return np.array([1], dtype=int)
    gaps = np.diff(days_sorted)
    breaks = np.where(gaps > 1)[0]
    starts = np.r_[0, breaks + 1]
    ends = np.r_[breaks, len(days_sorted) - 1]
    return (ends - starts + 1).astype(int)


def read_header_cols(path: Path) -> List[str]:
    hdr = pd.read_csv(path, compression="gzip", nrows=0, engine=ENGINE)
    return list(hdr.columns)


def pick_prob_cols(cols: List[str]) -> Dict[str, str]:
    """
    Pick probability columns for A-J.

    Supports both older short names, e.g. p_A / pcal_A, and the newer Step 5
    long names, e.g. p_A_intensity_only / pcal_A_intensity_only.
    """
    out = {}
    missing = []
    for m in MODEL_ORDER:
        long_name = MODEL_LONG_NAMES.get(m, m)

        raw_candidates = [f"p_{m}", f"p_{long_name}"]
        cal_candidates = [f"pcal_{m}", f"pcal_{long_name}"]

        raw_col = next((c for c in raw_candidates if c in cols), None)
        cal_col = next((c for c in cal_candidates if c in cols), None)

        if USE_CALIBRATED:
            if cal_col is not None:
                out[m] = cal_col
            elif REQUIRE_CALIBRATED_FOR_ALL:
                missing.append(m)
            elif raw_col is not None:
                out[m] = raw_col
            else:
                missing.append(m)
        else:
            if raw_col is not None:
                out[m] = raw_col
            else:
                missing.append(m)

    if missing:
        if USE_CALIBRATED and REQUIRE_CALIBRATED_FOR_ALL:
            raise ValueError(
                f"Missing CALIBRATED probability columns for models: {missing}. "
                "This final Step 6 requires pcal_* columns for every model A-J so all "
                "models are compared on the same probability treatment. Re-run Step 5 "
                "only if those calibrated columns are absent from sim_with_predictions.csv.gz."
            )
        raise ValueError(
            f"Missing probability columns for models: {missing}. "
            f"Expected short columns like p_A/pcal_A or long Step 5 columns like "
            f"p_A_intensity_only/pcal_A_intensity_only in sim_with_predictions."
        )
    return out


def chunk_reader(path: Path, usecols: List[str]):
    return pd.read_csv(
        path,
        compression="gzip",
        usecols=usecols,
        chunksize=CHUNKSIZE,
        engine=ENGINE,
    )


def summarise(byseason: pd.DataFrame, metric_cols: List[str]) -> pd.DataFrame:
    rows = []
    for (story, model), sub in byseason.groupby(["storyline", "model"], observed=True):
        for met in metric_cols:
            v = pd.to_numeric(sub[met], errors="coerce").to_numpy()
            v = v[np.isfinite(v)]
            if v.size == 0:
                continue
            rows.append({
                "storyline": story,
                "model": model,
                "metric": met,
                "mean": float(np.mean(v)),
                "p05": float(np.percentile(v, 5)),
                "p95": float(np.percentile(v, 95)),
                "n_seasons": int(len(sub)),
            })
    return pd.DataFrame(rows)


def paired_bootstrap_on_diff(diff: np.ndarray, n_boot=BOOT_N, seed=BOOT_SEED):
    """
    Paired block bootstrap across seasons, applied to a precomputed difference array.
    Returns: delta_mean, ci_low, ci_high, p_value
    """
    rng = np.random.default_rng(seed)
    diff = np.asarray(diff, dtype=float)
    diff = diff[np.isfinite(diff)]
    if diff.size < 10:
        return np.nan, np.nan, np.nan, np.nan

    obs = float(np.mean(diff))
    boots = rng.choice(diff, size=(n_boot, diff.size), replace=True).mean(axis=1)
    ci_low, ci_high = np.percentile(boots, [2.5, 97.5])
    p = 2.0 * min(np.mean(boots <= 0.0), np.mean(boots >= 0.0))
    p = float(min(max(p, 0.0), 1.0))
    return obs, float(ci_low), float(ci_high), p


def sig_star(p: float) -> str:
    if not np.isfinite(p):
        return ""
    if p < 0.01:
        return "**"
    if p < 0.05:
        return "*"
    return ""


def bh_fdr(pvals: np.ndarray) -> np.ndarray:
    """
    Benjamini-Hochberg FDR correction.
    Returns q-values aligned with input pvals.
    """
    pvals = np.asarray(pvals, dtype=float)
    q = np.full_like(pvals, np.nan, dtype=float)
    m = np.sum(np.isfinite(pvals))
    if m == 0:
        return q

    idx = np.where(np.isfinite(pvals))[0]
    pv = pvals[idx]
    order = np.argsort(pv)
    pv_sorted = pv[order]
    ranks = np.arange(1, pv_sorted.size + 1, dtype=float)

    q_sorted = pv_sorted * (pv_sorted.size / ranks)
    # enforce monotonicity
    q_sorted = np.minimum.accumulate(q_sorted[::-1])[::-1]
    q_sorted = np.clip(q_sorted, 0.0, 1.0)

    q[idx[order]] = q_sorted
    return q


def permutation_anova_pvalue(values: np.ndarray, groups: np.ndarray, n_perm: int, seed: int):
    """
    Permutation test for whether mean(values) differs across groups (storylines).
    Returns p-value based on F-statistic.
    """
    rng = np.random.default_rng(seed)
    values = np.asarray(values, dtype=float)
    groups = np.asarray(groups)

    mask = np.isfinite(values)
    values = values[mask]
    groups = groups[mask]

    unique = np.unique(groups)
    k = unique.size
    n = values.size
    if k < 2 or n < (k + 5):
        return np.nan

    def f_stat(v, g):
        overall = v.mean()
        ssb = 0.0
        ssw = 0.0
        for uu in unique:
            vv = v[g == uu]
            if vv.size == 0:
                continue
            mu = vv.mean()
            ssb += vv.size * (mu - overall) ** 2
            ssw += np.sum((vv - mu) ** 2)
        if ssw <= 0.0:
            return np.inf
        return (ssb / (k - 1)) / (ssw / (n - k))

    f_obs = f_stat(values, groups)
    if not np.isfinite(f_obs):
        return np.nan

    cnt = 0
    for _ in range(n_perm):
        gp = rng.permutation(groups)
        fp = f_stat(values, gp)
        if fp >= f_obs:
            cnt += 1

    return float((cnt + 1) / (n_perm + 1))


def _prob_to_bin(p: np.ndarray, bins: int) -> np.ndarray:
    pc = np.clip(p, 0.0, 1.0)
    b = (pc * bins).astype(np.int64)
    b = np.minimum(b, bins - 1)
    return b


def compute_story_ids(story: pd.Series) -> np.ndarray:
    sid = story.map(STORY_ID_MAP)
    if sid.isna().any():
        sid = sid.fillna(story.apply(story_to_id))
    return sid.astype(np.int64).to_numpy()


def bitmask_from_days(days: np.ndarray) -> int:
    bm = 0
    for d in days:
        di = int(d)
        if di <= 0:
            continue
        bm |= (1 << (di - 1))
    return bm


def days_from_bitmask(bm: int) -> np.ndarray:
    if bm == 0:
        return np.array([], dtype=int)
    out = []
    x = bm
    while x:
        lsb = x & -x
        idx = lsb.bit_length() - 1
        out.append(idx + 1)
        x ^= lsb
    return np.array(out, dtype=int)


def plot_metric(summary: pd.DataFrame,
                metric: str,
                out_png: Path,
                top_frac: float,
                sig_df: Optional[pd.DataFrame] = None) -> None:
    """
    Main bar figures + bracket stars for E–C and F–J (publishable, minimal clutter).
    Stars are based on unadjusted paired bootstrap p-values.
    """
    out_png.parent.mkdir(parents=True, exist_ok=True)
    sub = summary[summary["metric"] == metric].copy()
    if sub.empty:
        return

    stories = story_order(sorted(sub["storyline"].astype(str).unique().tolist()))
    models = [m for m in MODEL_ORDER if m in sub["model"].unique().tolist()]
    n_models = len(models)

    x = np.arange(len(stories))
    width = 0.85 / max(n_models, 1)

    plt.figure(figsize=(14, 6))

    pos_map: Dict[Tuple[str, str], float] = {}
    top_map: Dict[Tuple[str, str], float] = {}

    global_max_top = 0.0

    for i, m in enumerate(models):
        ss = sub[sub["model"] == m].set_index("storyline")
        means, e_low, e_high = [], [], []
        for s in stories:
            if s in ss.index:
                row = ss.loc[s]
                mu = float(row["mean"])
                p05 = float(row["p05"])
                p95 = float(row["p95"])
                means.append(mu)
                e_low.append(max(0.0, mu - p05))
                e_high.append(max(0.0, p95 - mu))
            else:
                means.append(np.nan)
                e_low.append(0.0)
                e_high.append(0.0)

        pos = x + (i - (n_models - 1) / 2.0) * width
        color = MODEL_COLORS.get(m, None)

        plt.bar(
            pos,
            means,
            width=width,
            yerr=[e_low, e_high],
            capsize=2,
            color=color,
            alpha=0.88,
            edgecolor="0.25",
            linewidth=0.6,
            error_kw={"ecolor": "0.2", "elinewidth": 1.0},
            label=MODEL_LABELS.get(m, m),
            zorder=3,
        )

        for j, s in enumerate(stories):
            if np.isfinite(means[j]):
                pos_map[(m, s)] = float(pos[j])
                top = float(means[j] + e_high[j])
                top_map[(m, s)] = top
                global_max_top = max(global_max_top, top)

    pct = int(round(float(top_frac) * 100))
    cal_label = "pcal_* for all models" if USE_CALIBRATED else "p_* for all models"

    pretty = {
        "any_high_risk": "Fraction of seasons with ≥1 high-risk day",
        "high_risk_days": "High-risk days per season",
        "clusters": "High-risk clusters per season",
        "max_run": "Maximum run length of high-risk days",
        "end_recovery_days": "End-of-season recovery days (lead-time proxy; conditional on ≥1 high-risk day)",
    }.get(metric, metric)

    plt.title(
        f"{pretty} (Top-{pct}% selection)\n"
        f"Global exact Top-k (hist boundary) — tie-safe | tiebreak={TIEBREAK} | using {cal_label}\n"
        f"Bars=mean; whiskers=5–95% across simulated seasons | stars: * p<0.05, ** p<0.01 (E–C, F–J)"
    )

    if metric == "any_high_risk":
        plt.ylabel("Fraction")
        plt.ylim(0, 1.12)
        y_step = 0.03
    else:
        plt.ylabel("Days" if ("day" in metric or "run" in metric) else "Count per season")
        y_step = max(0.03 * max(1.0, global_max_top), 0.5)

    plt.xticks(x, [s.replace("_", " ") for s in stories], rotation=0)
    plt.grid(axis="y", alpha=0.25, zorder=0)
    plt.legend(title="Model", fontsize=8, bbox_to_anchor=(1.02, 1), loc="upper left",
               borderaxespad=0, frameon=True, framealpha=0.95)

    # significance brackets
    if sig_df is not None and not sig_df.empty:
        ssub = sig_df[sig_df["metric"] == metric].copy()

        line_color = "0.15"
        lw = 1.1
        used_max_y = global_max_top

        for story in stories:
            levels_used = 0
            for (m1, m2) in SIG_PAIRS:
                row = ssub[
                    (ssub["storyline"] == story) &
                    (ssub["model_1"] == m1) &
                    (ssub["model_2"] == m2)
                ]
                if row.empty:
                    continue
                p = float(row["p_value"].iloc[0])
                stars = sig_star(p)
                if not stars:
                    continue
                if (m1, story) not in pos_map or (m2, story) not in pos_map:
                    continue

                x1 = pos_map[(m1, story)]
                x2 = pos_map[(m2, story)]
                y1 = top_map.get((m1, story), np.nan)
                y2 = top_map.get((m2, story), np.nan)
                if not (np.isfinite(y1) and np.isfinite(y2)):
                    continue

                y = max(y1, y2) + (levels_used + 1) * y_step
                h = 0.35 * y_step

                plt.plot([x1, x1, x2, x2], [y, y + h, y + h, y],
                         color=line_color, linewidth=lw, zorder=5)
                plt.text((x1 + x2) / 2.0, y + h + 0.15 * y_step, stars,
                         ha="center", va="bottom", fontsize=11, color="0.1", zorder=6)

                used_max_y = max(used_max_y, y + h + 0.5 * y_step)
                levels_used += 1

        if metric != "any_high_risk":
            ymin, ymax = plt.ylim()
            if used_max_y > ymax:
                plt.ylim(ymin, used_max_y * 1.05)

    plt.tight_layout()
    plt.savefig(_win_long_path(out_png), dpi=DPI, bbox_inches="tight")
    plt.close()


def plot_wp_delta_heatmap(wp_tests: pd.DataFrame,
                          pair: str,
                          metric: str,
                          out_png: Path) -> None:
    """
    Heatmap of Δmean (WP - noWP) across storylines (rows) x alert rates (cols),
    with * / ** overlay from unadjusted p-values.
    """
    out_png.parent.mkdir(parents=True, exist_ok=True)

    df = wp_tests[(wp_tests["pair"] == pair) & (wp_tests["metric"] == metric)].copy()
    if df.empty:
        return

    stories = story_order(sorted(df["storyline"].unique().tolist()))
    rates = sorted(df["top_frac"].unique().tolist(), reverse=True)  # 25%,10%,5%,1%

    mat = np.full((len(stories), len(rates)), np.nan, dtype=float)
    pmat = np.full_like(mat, np.nan, dtype=float)

    for i, s in enumerate(stories):
        for j, r in enumerate(rates):
            sub = df[(df["storyline"] == s) & (df["top_frac"] == r)]
            if sub.empty:
                continue
            mat[i, j] = float(sub["delta_mean"].iloc[0])
            pmat[i, j] = float(sub["p_value"].iloc[0])

    plt.figure(figsize=(10.5, 4.8))
    im = plt.imshow(mat, aspect="auto", interpolation="nearest", cmap="RdBu_r")
    plt.colorbar(im, fraction=0.046, pad=0.04, label="Δmean (WP − noWP)")

    plt.xticks(np.arange(len(rates)), [f"{int(round(100*r))}%" for r in rates])
    plt.yticks(np.arange(len(stories)), [s.replace("_", " ") for s in stories])

    pretty_metric = {
        "any_high_risk": "Any high-risk season (fraction)",
        "high_risk_days": "High-risk days per season",
        "clusters": "High-risk clusters per season",
        "max_run": "Max run length of high-risk days",
        "end_recovery_days": "End-of-season recovery days",
    }.get(metric, metric)

    plt.title(
        f"WP incremental effect heatmap: {pair} | {pretty_metric}\n"
        f"Cells show Δmean; stars: * p<0.05, ** p<0.01 (paired bootstrap by season, within storyline)"
    )

    # star overlay
    for i in range(mat.shape[0]):
        for j in range(mat.shape[1]):
            p = pmat[i, j]
            stars = sig_star(p)
            if stars:
                plt.text(j, i, stars, ha="center", va="center", fontsize=11, color="0.1")

    plt.tight_layout()
    plt.savefig(_win_long_path(out_png), dpi=DPI, bbox_inches="tight")
    plt.close()


# ------------------------ main ------------------------

def main() -> None:
    if not MASTER_SIM_FILE.exists():
        raise FileNotFoundError(f"Input not found: {MASTER_SIM_FILE}")

    out_root = safe_mkdir_unique(OUT_BASE_DIR / f"multiRate_WP_increment_{timestamp()}")
    (out_root / "STATUS_running.txt").write_text("RUNNING...\n", encoding="utf-8")

    cols = read_header_cols(MASTER_SIM_FILE)
    for r in ["storyline", "sim", "day_of_season"]:
        if r not in cols:
            raise ValueError(f"Missing required column '{r}' in sim_with_predictions.")

    prob_cols = pick_prob_cols(cols)

    # Reviewer/reproducibility audit: record exactly which probability column is
    # used for each model and fail above if any calibrated column is unavailable.
    print("[CONFIG] Probability columns used:")
    for m in MODEL_ORDER:
        print(f"  {m}: {prob_cols[m]}")

    config_lines = [
        "FINAL Step 6 analysis configuration",
        f"MASTER_SIM_FILE={MASTER_SIM_FILE}",
        f"TOP_FRACS={TOP_FRACS}",
        f"USE_CALIBRATED={USE_CALIBRATED}",
        f"REQUIRE_CALIBRATED_FOR_ALL={REQUIRE_CALIBRATED_FOR_ALL}",
        f"TIEBREAK={TIEBREAK}",
        f"PROB_HIST_BINS={PROB_HIST_BINS}",
        f"BOOT_N={BOOT_N}",
        f"INTERACTION_N_PERM={INTERACTION_N_PERM}",
        "Probability columns:",
    ] + [f"  {m}={prob_cols[m]}" for m in MODEL_ORDER]
    (out_root / "analysis_configuration.txt").write_text("\n".join(config_lines) + "\n", encoding="utf-8")

    # =========================================================
    # PASS 1 (once): season max-day + valid counts + probability histograms
    # =========================================================
    print("[PASS 1] Counting valid probabilities + season lengths + prob histograms (chunked)...")
    usecols1 = ["storyline", "sim", "day_of_season"] + list(prob_cols.values())

    season_maxday: Dict[int, int] = {}
    season_storyid: Dict[int, int] = {}
    n_valid: Dict[str, int] = {m: 0 for m in MODEL_ORDER}
    hists: Dict[str, np.ndarray] = {m: np.zeros(PROB_HIST_BINS, dtype=np.int64) for m in MODEL_ORDER}

    for ci, chunk in enumerate(chunk_reader(MASTER_SIM_FILE, usecols1), start=1):
        sim = pd.to_numeric(chunk["sim"], errors="coerce")
        day = pd.to_numeric(chunk["day_of_season"], errors="coerce")
        story = chunk["storyline"].astype(str)

        ok = sim.notna() & day.notna()
        if ok.any():
            simv = sim[ok].astype(np.int64).to_numpy()
            dayv = day[ok].astype(np.int64).to_numpy()
            sidv = compute_story_ids(story[ok])

            sk = pack_season_key(sidv, simv)

            tmp = pd.DataFrame({"sk": sk, "day": dayv, "sid": sidv})
            g = tmp.groupby("sk", observed=True)["day"].max()
            for k, md in g.items():
                k = int(k)
                md = int(md)
                prev = season_maxday.get(k)
                if prev is None or md > prev:
                    season_maxday[k] = md
                    season_storyid[k] = int(tmp.loc[tmp["sk"] == k, "sid"].iloc[0])

        for m, pc in prob_cols.items():
            p = pd.to_numeric(chunk[pc], errors="coerce").to_numpy(dtype=float)
            finite = np.isfinite(p)
            if not finite.any():
                continue
            pv = p[finite]
            n_valid[m] += int(pv.size)
            bidx = _prob_to_bin(pv, PROB_HIST_BINS)
            hists[m] += np.bincount(bidx, minlength=PROB_HIST_BINS).astype(np.int64)

        if ci % 10 == 0:
            print(f"  chunks={ci:,} seasons={len(season_maxday):,}")

    print("[PASS 1] Done.")
    (out_root / "STATUS_running.txt").write_text("PASS 1 complete.\n", encoding="utf-8")

    seasons = np.array(list(season_maxday.keys()), dtype=np.int64)
    maxday = np.array([season_maxday[int(sk)] for sk in seasons], dtype=np.int64)
    story_id = np.array([season_storyid[int(sk)] for sk in seasons], dtype=np.int64)
    sim_id = (seasons & 0xFFFFFFFF).astype(np.int64)

    season_df = pd.DataFrame({
        "season_key": seasons,
        "story_id": story_id,
        "sim": sim_id,
        "storyline": [ID_TO_STORY.get(int(s), f"unknown_{int(s)}") for s in story_id],
        "season_max_day": maxday,
    })
    season_df_idx = season_df.set_index("season_key")

    pd.DataFrame([{"model": m, "prob_col": prob_cols[m], "n_valid": int(n_valid[m])} for m in MODEL_ORDER]) \
      .to_csv(out_root / "n_valid_by_model.csv", index=False)

    # =========================================================
    # New folder for the WP incremental value analysis
    # =========================================================
    wp_dir = safe_mkdir_unique(out_root / "WP_incremental_value")
    (wp_dir / "README_wp_incremental.txt").write_text(
        "WP incremental value outputs:\n"
        "- wp_deltas_byseason.csv: season-level deltas (WP - noWP)\n"
        "- wp_incremental_tests.csv: within-storyline paired bootstrap tests + FDR q-values (per pair)\n"
        "- wp_interaction_tests.csv: permutation tests for heterogeneity across storylines (optional)\n"
        "- delta_heatmaps/: Δmean heatmaps across storylines x alert rates with * / ** overlay\n",
        encoding="utf-8"
    )
    (wp_dir / "delta_heatmaps").mkdir(parents=True, exist_ok=True)

    # Collect across all rates so we can apply FDR across (rate × storyline × metric) per pair
    all_wp_tests = []
    all_wp_deltas = []
    all_interactions = []

    # =========================================================
    # Per rate loop: select top-k, compute metrics, plot main figures, compute Δ and tests
    # =========================================================
    usecols2 = ["storyline", "sim", "day_of_season"] + list(prob_cols.values())

    for TOP_FRAC in TOP_FRACS:
        pct = int(round(TOP_FRAC * 100))
        rate_dir = safe_mkdir_unique(out_root / f"top{pct}")
        fig_dir = rate_dir / "fig"
        fig_dir.mkdir(parents=True, exist_ok=True)

        print(f"\n==================== TOP {pct}% ====================")
        (rate_dir / "STATUS_running.txt").write_text(f"RUNNING top{pct}%...\n", encoding="utf-8")

        # ----- Determine k and boundary bin for each model -----
        k_map: Dict[str, int] = {}
        boundary_info: Dict[str, Dict[str, int]] = {}

        for m in MODEL_ORDER:
            nv = int(n_valid[m])
            k = int(np.ceil(TOP_FRAC * nv))
            k = max(1, min(k, nv))
            k_map[m] = k

            hist = hists[m]
            cum = 0
            bbin = None
            above = None
            take_in_bin = None

            for b in range(PROB_HIST_BINS - 1, -1, -1):
                cnt = int(hist[b])
                if cum + cnt >= k:
                    bbin = b
                    above = cum
                    take_in_bin = k - cum
                    break
                cum += cnt

            if bbin is None:
                bbin, above, take_in_bin = 0, 0, 0

            boundary_info[m] = {
                "boundary_bin": int(bbin),
                "above_count": int(above),
                "take_in_bin": int(take_in_bin),
                "k_exact": int(k),
                "n_valid": int(nv),
            }

        pd.DataFrame([{"model": m, "prob_col": prob_cols[m], "top_frac": TOP_FRAC, **boundary_info[m]} for m in MODEL_ORDER]) \
          .to_csv(rate_dir / "diagnostics_boundary_bin.csv", index=False)

        # ----- PASS 2: collect boundary-bin values only -----
        print("[PASS 2] Collecting boundary-bin values (chunked)...")

        store_p: Dict[str, List[np.ndarray]] = {m: [] for m in MODEL_ORDER}
        store_t: Dict[str, List[np.ndarray]] = {m: [] for m in MODEL_ORDER}

        for ci, chunk in enumerate(chunk_reader(MASTER_SIM_FILE, usecols2), start=1):
            sim = pd.to_numeric(chunk["sim"], errors="coerce")
            day = pd.to_numeric(chunk["day_of_season"], errors="coerce")
            story = chunk["storyline"].astype(str)

            ok = sim.notna() & day.notna()
            if not ok.any():
                continue

            simv = sim[ok].astype(np.int64).to_numpy()
            dayv = day[ok].astype(np.int64).to_numpy()
            sidv = compute_story_ids(story[ok])

            season_key = pack_season_key(sidv, simv)
            day_key = pack_day_key(season_key, dayv)

            tie = splitmix64(day_key.astype(np.uint64)) if TIEBREAK == "hash" else day_key.astype(np.int64)

            for m in MODEL_ORDER:
                pc = prob_cols[m]
                p = pd.to_numeric(chunk.loc[ok, pc], errors="coerce").to_numpy(dtype=float)
                finite = np.isfinite(p)
                if not finite.any():
                    continue
                pv = p[finite]
                tv = tie[finite]
                bidx = _prob_to_bin(pv, PROB_HIST_BINS)

                bbin = boundary_info[m]["boundary_bin"]
                in_bin = (bidx == bbin)
                if not in_bin.any():
                    continue

                store_p[m].append(pv[in_bin])
                store_t[m].append(tv[in_bin])

            if ci % 10 == 0:
                print(f"  chunks={ci:,}")

        print("[PASS 2] Done.")
        (rate_dir / "STATUS_running.txt").write_text("PASS 2 complete.\n", encoding="utf-8")

        # ----- Exact boundary key per model -----
        boundary_key: Dict[str, Tuple[float, int]] = {}
        diag_rows = []

        for m in MODEL_ORDER:
            p_all = np.concatenate(store_p[m]) if store_p[m] else np.array([], dtype=float)
            t_all = np.concatenate(store_t[m]) if store_t[m] else np.array([], dtype=np.int64)

            take = int(boundary_info[m]["take_in_bin"])
            bbin = int(boundary_info[m]["boundary_bin"])

            if take <= 0:
                b_prob = (bbin + 1) / PROB_HIST_BINS
                b_tie = -9_223_372_036_854_775_808
                boundary_key[m] = (float(b_prob), int(b_tie))
                diag_rows.append({"model": m, "top_frac": TOP_FRAC, "boundary_bin": bbin,
                                  "boundary_p": float(b_prob), "boundary_tie": int(b_tie),
                                  "n_in_boundary_bin": int(p_all.size), "take_in_bin": int(take)})
                continue

            if p_all.size == 0:
                b_prob = (bbin + 1) / PROB_HIST_BINS
                b_tie = 9_223_372_036_854_775_807
                boundary_key[m] = (float(b_prob), int(b_tie))
                diag_rows.append({"model": m, "top_frac": TOP_FRAC, "boundary_bin": bbin,
                                  "boundary_p": float(b_prob), "boundary_tie": int(b_tie),
                                  "n_in_boundary_bin": 0, "take_in_bin": int(take)})
                continue

            if take > p_all.size:
                take = int(p_all.size)

            order = np.lexsort((t_all, -p_all))  # p desc, tie asc
            cut_idx = order[take - 1]
            b_prob = float(p_all[cut_idx])
            b_tie = int(t_all[cut_idx])

            boundary_key[m] = (b_prob, b_tie)
            diag_rows.append({"model": m, "top_frac": TOP_FRAC, "boundary_bin": bbin,
                              "boundary_p": b_prob, "boundary_tie": b_tie,
                              "n_in_boundary_bin": int(p_all.size), "take_in_bin": int(take)})

        pd.DataFrame(diag_rows).to_csv(rate_dir / "diagnostics_boundary_key.csv", index=False)

        # ----- PASS 3: select days -> bitmask per season per model -----
        print("[PASS 3] Selecting days + computing per-season bitmasks (chunked)...")

        masks_by_model: Dict[str, Dict[int, int]] = {m: {} for m in MODEL_ORDER}

        for ci, chunk in enumerate(chunk_reader(MASTER_SIM_FILE, usecols2), start=1):
            sim = pd.to_numeric(chunk["sim"], errors="coerce")
            day = pd.to_numeric(chunk["day_of_season"], errors="coerce")
            story = chunk["storyline"].astype(str)

            ok = sim.notna() & day.notna()
            if not ok.any():
                continue

            simv = sim[ok].astype(np.int64).to_numpy()
            dayv = day[ok].astype(np.int64).to_numpy()
            sidv = compute_story_ids(story[ok])

            season_key = pack_season_key(sidv, simv)
            day_key = pack_day_key(season_key, dayv)

            tie = splitmix64(day_key.astype(np.uint64)) if TIEBREAK == "hash" else day_key.astype(np.int64)

            for m in MODEL_ORDER:
                pc = prob_cols[m]
                p = pd.to_numeric(chunk.loc[ok, pc], errors="coerce").to_numpy(dtype=float)
                finite = np.isfinite(p)
                if not finite.any():
                    continue

                pv = p[finite]
                skv = season_key[finite]
                dyv = dayv[finite]
                tv = tie[finite]

                b_prob, b_tie = boundary_key[m]
                sel = (pv > b_prob) | ((pv == b_prob) & (tv <= b_tie))
                if not sel.any():
                    continue

                sk_sel = skv[sel]
                dy_sel = dyv[sel]

                tmp = pd.DataFrame({"sk": sk_sel.astype(np.int64), "day": dy_sel.astype(np.int64)})
                g = tmp.groupby("sk", observed=True)["day"].apply(lambda s: np.unique(s.to_numpy(dtype=int)))

                mdict = masks_by_model[m]
                for sk, days_u in g.items():
                    bm = bitmask_from_days(days_u)
                    prev = mdict.get(int(sk), 0)
                    mdict[int(sk)] = prev | bm

            if ci % 10 == 0:
                print(f"  chunks={ci:,}")

        print("[PASS 3] Done.")
        (rate_dir / "STATUS_running.txt").write_text("PASS 3 complete.\n", encoding="utf-8")

        # ----- Compute season metrics from bitmasks -----
        metrics_rows = []

        for m in MODEL_ORDER:
            mdict = masks_by_model[m]
            met = []
            for sk in seasons:
                sk_int = int(sk)
                bm = mdict.get(sk_int, 0)
                days_sorted = days_from_bitmask(bm)
                high_days = int(days_sorted.size)

                runs = run_lengths_from_sorted_days(days_sorted)
                clusters = int(runs.size)
                max_run = int(runs.max()) if runs.size else 0

                season_max = int(season_df_idx.loc[sk_int, "season_max_day"])
                end_recovery = float(season_max - int(days_sorted.max())) if high_days > 0 else np.nan

                met.append({
                    "season_key": sk_int,
                    "any_high_risk": float(high_days > 0),
                    "high_risk_days": float(high_days),
                    "clusters": float(clusters),
                    "max_run": float(max_run),
                    "end_recovery_days": float(end_recovery),
                })

            metdf = pd.DataFrame(met)
            out = season_df.merge(metdf, on="season_key", how="left")
            out["model"] = m
            out["any_high_risk"] = out["any_high_risk"].fillna(0.0)
            out["high_risk_days"] = out["high_risk_days"].fillna(0.0)
            out["clusters"] = out["clusters"].fillna(0.0)
            out["max_run"] = out["max_run"].fillna(0.0)
            metrics_rows.append(out[["storyline", "sim", "model"] + METRIC_COLS])

        byseason = pd.concat(metrics_rows, ignore_index=True)
        byseason.to_csv(rate_dir / f"burden_byseason_global_topk_top{pct}_tiesafe.csv", index=False)

        summary = summarise(byseason, METRIC_COLS)
        summary.to_csv(rate_dir / f"burden_summary_global_topk_top{pct}_tiesafe.csv", index=False)

        # ----- WP incremental deltas + paired bootstrap tests (within storyline) -----
        # Δ = metric(WP) - metric(noWP)
        wp_test_rows = []
        wp_delta_rows = []

        for metric in METRIC_COLS:
            piv = byseason.pivot(index=["storyline", "sim"], columns="model", values=metric)

            for (m_wp, m_nowp) in SIG_PAIRS:
                pair = f"{m_wp}-{m_nowp}"
                if m_wp not in piv.columns or m_nowp not in piv.columns:
                    continue

                delta_series = (piv[m_wp] - piv[m_nowp]).dropna()
                if delta_series.empty:
                    continue

                # store season-level deltas (for tables / possible extra plots)
                tmp = delta_series.reset_index().rename(columns={0: "delta", metric: "delta"})
                tmp["metric"] = metric
                tmp["pair"] = pair
                tmp["top_frac"] = TOP_FRAC
                wp_delta_rows.append(tmp[["top_frac", "pair", "metric", "storyline", "sim", "delta"]])

                # within-storyline tests
                for story in delta_series.index.get_level_values("storyline").unique():
                    dd = delta_series.loc[story].to_numpy(dtype=float)
                    dmu, lo, hi, p = paired_bootstrap_on_diff(dd)

                    wp_test_rows.append({
                        "top_frac": TOP_FRAC,
                        "pair": pair,
                        "metric": metric,
                        "storyline": story,
                        "n_seasons": int(np.isfinite(dd).sum()),
                        "delta_mean": dmu,
                        "ci_low": lo,
                        "ci_high": hi,
                        "p_value": p,
                    })

        wp_tests_rate = pd.DataFrame(wp_test_rows)
        wp_deltas_rate = pd.concat(wp_delta_rows, ignore_index=True) if wp_delta_rows else pd.DataFrame()

        # keep for global FDR + heatmaps
        if not wp_tests_rate.empty:
            all_wp_tests.append(wp_tests_rate)
        if not wp_deltas_rate.empty:
            all_wp_deltas.append(wp_deltas_rate)

        # Also keep main-figure significance info at this rate (for brackets)
        # (This uses the same paired bootstrap p-values as above, but in "model_1/model_2" shape.)
        sig_rows_for_bars = []
        if not wp_tests_rate.empty:
            for _, rrow in wp_tests_rate.iterrows():
                m1, m2 = rrow["pair"].split("-")
                sig_rows_for_bars.append({
                    "top_frac": float(rrow["top_frac"]),
                    "storyline": rrow["storyline"],
                    "metric": rrow["metric"],
                    "model_1": m1,
                    "model_2": m2,
                    "delta_mean": float(rrow["delta_mean"]),
                    "ci_low": float(rrow["ci_low"]),
                    "ci_high": float(rrow["ci_high"]),
                    "p_value": float(rrow["p_value"]),
                })
        sig_df = pd.DataFrame(sig_rows_for_bars)

        # ----- Plot main figures with bracket stars -----
        plot_metric(summary, "any_high_risk", fig_dir / "F0_any_event.png", top_frac=TOP_FRAC, sig_df=sig_df)
        plot_metric(summary, "high_risk_days", fig_dir / "F1_high_risk_days.png", top_frac=TOP_FRAC, sig_df=sig_df)
        plot_metric(summary, "clusters", fig_dir / "F2_clusters.png", top_frac=TOP_FRAC, sig_df=sig_df)
        plot_metric(summary, "max_run", fig_dir / "F3_max_run.png", top_frac=TOP_FRAC, sig_df=sig_df)
        plot_metric(summary, "end_recovery_days", fig_dir / "F4_end_recovery.png", top_frac=TOP_FRAC, sig_df=sig_df)

        # ----- Optional interaction test: does Δ vary across storylines? -----
        if INTERACTION_N_PERM > 0 and not wp_deltas_rate.empty:
            for metric in METRIC_COLS:
                for pair in wp_deltas_rate["pair"].unique():
                    sub = wp_deltas_rate[(wp_deltas_rate["metric"] == metric) & (wp_deltas_rate["pair"] == pair)]
                    if sub.empty:
                        continue
                    p_int = permutation_anova_pvalue(
                        sub["delta"].to_numpy(dtype=float),
                        sub["storyline"].astype(str).to_numpy(),
                        n_perm=INTERACTION_N_PERM,
                        seed=INTERACTION_SEED
                    )
                    all_interactions.append({
                        "top_frac": TOP_FRAC,
                        "pair": pair,
                        "metric": metric,
                        "p_interaction": p_int,
                        "n_total": int(np.isfinite(sub["delta"]).sum()),
                        "n_perm": int(INTERACTION_N_PERM),
                    })

        (rate_dir / "STATUS_running.txt").write_text("DONE.\n", encoding="utf-8")
        print(f"[DONE top{pct}%] Outputs written to: {rate_dir}")

    # =========================================================
    # AFTER all rates: write WP incremental outputs + FDR + heatmaps
    # =========================================================
    wp_tests_all = pd.concat(all_wp_tests, ignore_index=True) if all_wp_tests else pd.DataFrame()
    wp_deltas_all = pd.concat(all_wp_deltas, ignore_index=True) if all_wp_deltas else pd.DataFrame()
    interactions_all = pd.DataFrame(all_interactions) if all_interactions else pd.DataFrame()

    if not wp_deltas_all.empty:
        wp_deltas_all.to_csv(wp_dir / "wp_deltas_byseason.csv", index=False)

    if not wp_tests_all.empty:
        # Apply BH-FDR within each comparison (pair) across (rate × storyline × metric)
        wp_tests_all["q_value"] = np.nan
        for pair in wp_tests_all["pair"].unique():
            mask = (wp_tests_all["pair"] == pair)
            wp_tests_all.loc[mask, "q_value"] = bh_fdr(wp_tests_all.loc[mask, "p_value"].to_numpy())

        wp_tests_all.to_csv(wp_dir / "wp_incremental_tests.csv", index=False)

        # Heatmaps (publishable summary) for each pair × metric
        for pair in wp_tests_all["pair"].unique():
            for metric in METRIC_COLS:
                out_png = wp_dir / "delta_heatmaps" / f"heatmap_{pair.replace('-', 'minus')}_{metric}.png"
                plot_wp_delta_heatmap(wp_tests_all, pair=pair, metric=metric, out_png=out_png)

    if not interactions_all.empty:
        # optional BH on interactions too (within each pair)
        interactions_all["q_interaction"] = np.nan
        for pair in interactions_all["pair"].unique():
            mask = (interactions_all["pair"] == pair)
            interactions_all.loc[mask, "q_interaction"] = bh_fdr(interactions_all.loc[mask, "p_interaction"].to_numpy())

        interactions_all.to_csv(wp_dir / "wp_interaction_tests.csv", index=False)

    (out_root / "STATUS_running.txt").write_text("ALL DONE.\n", encoding="utf-8")
    print("\n[ALL DONE] Root outputs:", out_root)
    print("  WP incremental folder:", wp_dir)


if __name__ == "__main__":
    main()
