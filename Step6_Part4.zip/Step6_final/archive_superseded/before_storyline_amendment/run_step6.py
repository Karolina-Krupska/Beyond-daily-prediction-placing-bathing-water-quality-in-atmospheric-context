"""Current Step6 publication entry point: saved tables and draws only."""
from run_publication_revision import run,ROOT
import argparse
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=__import__('pathlib').Path,default=ROOT);p.add_argument('--skip-retained-redraw',action='store_true');a=p.parse_args();run(a.root,not a.skip_retained_redraw)
