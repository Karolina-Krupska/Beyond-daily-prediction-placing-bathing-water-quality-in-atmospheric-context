UPDATED GROUPED-BAR COMPARISONS

These figures recreate the earlier all-model bar layout using current A-K results and all six scenarios. There are three retained outcomes at each of five pooled selection fractions. The manuscript main figure is supplied separately in Main_publication. All bars and true percentile endpoints come directly from seasonal_summary.csv. The former significance stars and recovery/lead-time interpretation are not reproduced. Means can lie outside a central percentile range, so whiskers are drawn independently.
