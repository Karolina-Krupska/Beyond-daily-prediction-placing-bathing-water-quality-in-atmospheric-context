"""Targeted scientific regression tests; run with python -m unittest discover -s code."""
import unittest
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf
from bathing_water_exceedance_associations import (
    classify_ie, aggregate_site_days, bh_fdr, validate_regimes,
    two_way_cluster_cov, global_wald_test, contrast_stats)


class ScientificChecks(unittest.TestCase):
    def test_threshold_inclusive(self):
        self.assertEqual(classify_ie(62)[0],0)
        self.assertEqual(classify_ie(63)[0],1)
        self.assertEqual(classify_ie(64)[0],1)

    def test_censoring_exactly_classifiable(self):
        for s in ['<10','<26','<32','<63','<=62']:
            self.assertEqual(classify_ie(s)[0],0)
        for s in ['>63','>=63','>10000']:
            self.assertEqual(classify_ie(s)[0],1)

    def test_censoring_crosses_threshold(self):
        for s in ['<64','<=63','>62','>=62']:
            self.assertTrue(np.isnan(classify_ie(s)[0]))
            self.assertEqual(classify_ie(s)[3],'threshold_indeterminate')

    def test_missing_never_negative(self):
        for s in [None,np.nan,'','N/A']:
            self.assertTrue(np.isnan(classify_ie(s)[0]))

    def test_invalid_not_silently_accepted(self):
        self.assertEqual(classify_ie('bad')[3],'unrecognised')
        self.assertEqual(classify_ie(-1)[3],'invalid')

    def test_any_evaluable_site_day(self):
        d=pd.DataFrame(dict(site_id=['a','a','b','b','c','c'],Date=pd.to_datetime(['2020-05-01']*6),
                            site_name=['a','a','b','b','c','c'],record_id=range(6),
                            exceedance=[0,1,np.nan,np.nan,0,np.nan],routine_MS=[True]*6))
        g=aggregate_site_days(d).set_index('site_id')
        self.assertEqual(len(g),3);self.assertEqual(g.loc['a','exceedance'],1)
        self.assertTrue(np.isnan(g.loc['b','exceedance']))
        self.assertEqual(g.loc['c','exceedance'],0)
        self.assertTrue(g.loc['c','partially_missing'])

    def test_duplicate_calendar_dates_fail(self):
        d=pd.DataFrame({'Date':pd.to_datetime(['2020-05-01']*2),'regime':[1,2]})
        with self.assertRaises(ValueError):validate_regimes(d)

    def test_invalid_pattern_fails(self):
        d=pd.DataFrame({'Date':pd.to_datetime(['2020-05-01']),'regime':[31]})
        with self.assertRaises(ValueError):validate_regimes(d)

    def test_bh_known_values_and_missing(self):
        np.testing.assert_allclose(bh_fdr([.01,.04,.03,np.nan]),[.03,.04,.04,np.nan],equal_nan=True)

    def test_indefinite_wald_is_withheld(self):
        class Res:params=pd.Series([1.,1.],index=['effect_a','effect_b'])
        v=pd.DataFrame([[1.,2.],[2.,1.]],index=Res.params.index,columns=Res.params.index)
        ans=global_wald_test(Res(),v,'effect')
        self.assertTrue(np.isnan(ans['p']))
        self.assertNotEqual(ans['status'],'ok')

    def test_negative_contrast_variance_is_not_zeroed(self):
        ans=contrast_stats([0],np.array([[-1.]]),np.array([1.]))
        self.assertTrue(np.isnan(ans['p']));self.assertNotEqual(ans['status'],'ok')

    def test_covariance_and_reference_invariance(self):
        # Fixed synthetic binary panel; no random simulation is needed for this check.
        n=300
        df=pd.DataFrame({'y':((np.arange(n)*7)%19<5).astype(int),
                         'x':np.tile(['a','b','c'],n//3),
                         'site':np.arange(n)%15,'date':np.arange(n)//10})
        df['day']=pd.Timestamp('2020-05-01')+pd.to_timedelta(df.date,unit='D')
        a=smf.glm("y ~ C(x, Treatment(reference='a'))",df,family=sm.families.Poisson()).fit()
        b=smf.glm("y ~ C(x, Treatment(reference='b'))",df,family=sm.families.Poisson()).fit()
        # The covariance function checks against statsmodels on every call.
        va=two_way_cluster_cov(a,df.site,df.day)
        self.assertEqual(va.shape,(3,3))
        np.testing.assert_allclose(a.fittedvalues,b.fittedvalues,rtol=1e-10,atol=1e-10)


if __name__=='__main__':unittest.main()
