"""Regenerate the combined publication figure from existing results; no refitting.

Run from the package folder:
    python code/plot_family_combined.py
For a different results directory:
    python code/plot_family_combined.py --results path/to/results
"""
import argparse
from pathlib import Path
import pandas as pd
from bathing_water_exceedance_associations import plot_family_combined,ROOT


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results',type=Path,default=ROOT/'results')
    args=parser.parse_args()
    primary=args.results/'models/primary_family'
    probabilities=pd.read_csv(primary/'marginal_probabilities.csv')
    ratios=pd.read_csv(primary/'ratios_vs_reference.csv')
    plot_family_combined(probabilities,ratios,args.results)
    print('Saved PNG (600 dpi), vector PDF, SVG and figure data in:',args.results)


if __name__=='__main__':main()
