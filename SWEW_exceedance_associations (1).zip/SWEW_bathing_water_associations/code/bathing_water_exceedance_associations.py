"""Publication revision of the supplied bathing-water association script.

Core retained: IE >=63, fixed four-family mapping, WP25 reference, modified
Poisson regression, month/year adjustment, site/date sandwich covariance,
adjusted marginal means, joint tests and pairwise family contrasts.
See CHANGELOG.md for scientific and reporting changes. No forecast models here.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import itertools
import json
import platform
import re
import sys
import warnings
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter, NullFormatter
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd
import patsy
from scipy.stats import norm, chi2
import statsmodels.api as sm
import statsmodels.formula.api as smf
from statsmodels.stats.sandwich_covariance import cov_cluster_2groups

ROOT = Path(__file__).resolve().parents[1]
FAMILY_ORDER = ['Cyclonic Atlantic (frontal)', 'Showery maritime / unsettled',
                'Convective extremes', 'Settled anticyclonic quiet']
BASELINE_FAMILY = FAMILY_ORDER[-1]
BASELINE_REGIME = 25
THRESHOLD = 63.0
Z = norm.ppf(0.975)
COLOURS = dict(zip(FAMILY_ORDER, ['#0072B2', '#009E73', '#D55E00', '#7A6C99']))
SHORT = dict(zip(FAMILY_ORDER, ['Cyclonic Atlantic', 'Showery maritime',
                               'Convective extremes', 'Settled anticyclonic']))
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9,
                     'axes.labelsize': 10, 'axes.titlesize': 11,
                     'axes.spines.top': False, 'axes.spines.right': False,
                     'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none',
                     'savefig.facecolor': 'white'})


def save_csv(df, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False, float_format='%.12g')


def classify_ie(value, threshold=THRESHOLD):
    """Classify the reported result directly, without replacing censored values.

    Return (binary outcome or NaN, censor qualifier, reported bound, status).
    Ambiguous limits crossing the threshold are not silently classified.
    """
    if pd.isna(value) or str(value).strip().lower() in {'', 'nan', 'na', 'n/a'}:
        return np.nan, '', np.nan, 'missing'
    s = str(value).strip().replace(',', '').replace('≤', '<=').replace('≥', '>=')
    match = re.fullmatch(r'([<>]=?|=)?\s*([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)', s)
    if match is None:
        return np.nan, '', np.nan, 'unrecognised'
    op, bound = match.group(1) or '=', float(match.group(2))
    if not np.isfinite(bound) or bound < 0:
        return np.nan, op, bound, 'invalid'
    if op == '=':
        return float(bound >= threshold), op, bound, 'evaluable'
    if op == '<' and bound <= threshold or op == '<=' and bound < threshold:
        return 0., op, bound, 'evaluable'
    if op in {'>', '>='} and bound >= threshold:
        return 1., op, bound, 'evaluable'
    return np.nan, op, bound, 'threshold_indeterminate'


def bh_fdr(pvals):
    """BH correction over finite p values; preserve missing inference as missing."""
    p = np.asarray(pvals, dtype=float)
    ans = np.full(p.shape, np.nan)
    valid = np.isfinite(p)
    pv = p[valid]
    if not len(pv):
        return ans
    order = np.argsort(pv)
    adjusted = np.minimum.accumulate((pv[order] * len(pv) / np.arange(1, len(pv)+1))[::-1])[::-1]
    unsorted = np.empty(len(pv)); unsorted[order] = np.minimum(adjusted, 1.)
    ans[valid] = unsorted
    return ans


def validate_regimes(reg):
    if reg.Date.isna().any() or reg.regime.isna().any():
        raise ValueError('Invalid dates or missing regimes in the classification calendar.')
    if reg.Date.duplicated().any():
        raise ValueError('Duplicate classification dates would multiply sample records.')
    if not reg.regime.between(1, 30).all() or not np.equal(reg.regime, np.floor(reg.regime)).all():
        raise ValueError('Classification values must be integer weather patterns 1 to 30.')
    return reg.assign(regime=reg.regime.astype(int))


def read_regimes(path):
    lines = Path(path).read_text(encoding='utf-8-sig').splitlines()
    header = next((i for i, s in enumerate(lines)
                   if {'day','month','year','regime'} <= set(s.lower().split(','))), None)
    if header is None:
        raise ValueError('Cannot locate the daily classification header.')
    d = pd.read_csv(path, skiprows=header)
    d['Date'] = pd.to_datetime(d[['year', 'month', 'day']], errors='coerce')
    d['regime'] = pd.to_numeric(d.regime, errors='coerce')
    return validate_regimes(d[['Date', 'regime']])


def read_family_assignments(path):
    f = pd.read_csv(path)
    if not {'regime', 'group_final4'} <= set(f.columns):
        raise ValueError('Mapping must include explicit regime and group_final4 columns.')
    r = pd.to_numeric(f.regime, errors='coerce')
    if len(f) != 30 or r.isna().any() or r.duplicated().any() or set(r) != set(range(1,31)):
        raise ValueError('Family mapping must contain exactly one explicit row for each WP1 to WP30.')
    f = f.assign(regime=r.astype(int), group_4=f.group_final4.str.strip())
    if set(f.group_4) != set(FAMILY_ORDER):
        raise ValueError('Unexpected or incomplete four-family labels.')
    return f[['regime','group_4']].sort_values('regime')


def aggregate_site_days(samples):
    """One outcome per supplied site identity and day: any evaluable sample >=63.

    Days with no evaluable result are missing, never non-exceedances. Partially
    observed days use measured results and are explicitly counted and exported.
    """
    group = samples.groupby(['site_id', 'Date'], sort=True, observed=True)
    d = group.agg(site_name=('site_name', 'first'), n_records=('record_id','size'),
                  n_evaluable=('exceedance','count'), exceedance=('exceedance','max'),
                  any_routine=('routine_MS','max'),
                  record_ids=('record_id', lambda s: ';'.join(map(str,s)))).reset_index()
    d['n_unevaluable'] = d.n_records-d.n_evaluable
    d['partially_missing'] = d.n_evaluable.gt(0) & d.n_unevaluable.gt(0)
    d['month'] = d.Date.dt.month; d['year'] = d.Date.dt.year
    return d


def build_df(bw_path, regime_path, family_path, out):
    raw = pd.read_excel(bw_path, sheet_name='Records')
    required = {'site_id','SMPT_SHORT_NAME','Date','3723 IE Conf (CFU/0_1l)',
                'lat','lon','SAMP_PURPOSE_CODE'}
    if not required <= set(raw.columns):
        raise ValueError(f'Missing fields: {required-set(raw.columns)}')
    raw['record_id'] = np.arange(2, len(raw)+2)  # row of Records sheet
    raw['Date'] = pd.to_datetime(raw.Date, errors='coerce').dt.normalize()
    if raw.Date.isna().any() or raw.site_id.isna().any():
        raise ValueError('Missing/invalid date or supplied site identity requires author resolution.')
    # Use the curated stable site_id; do not invent IDs or filter names heuristically.
    raw['site_id'] = raw.site_id.astype(str).str.strip()
    if raw.site_id.eq('').any():
        raise ValueError('Blank site identity.')
    domain = raw.lat.between(49,52,inclusive='both') & raw.lon.between(-6,-2,inclusive='both')
    if not domain.all():
        save_csv(raw.loc[~domain],out/'audit/domain_failures.csv')
        raise ValueError('Records sheet includes missing/out-of-domain coordinates. See domain_failures.csv.')
    inside = raw.Date.dt.year.between(2012,2024) & raw.Date.dt.month.isin(range(5,10))
    save_csv(raw.loc[~inside],out/'audit/outside_study_season.csv')
    d = raw.loc[inside].copy()
    parsed = pd.DataFrame([classify_ie(v) for v in d['3723 IE Conf (CFU/0_1l)']],
                          columns=['exceedance','IE_qualifier','IE_bound','IE_status'], index=d.index)
    d = pd.concat([d,parsed],axis=1)
    save_csv(d[d.IE_status.ne('evaluable')],out/'audit/unevaluable_IE_records.csv')
    if d.IE_status.isin(['unrecognised','invalid']).any():
        raise ValueError('Unrecognised/invalid IE results need resolution; audit exported.')
    d['site_name'] = d.SMPT_SHORT_NAME
    d['routine_MS'] = d.SAMP_PURPOSE_CODE.astype(str).str.strip().eq('MS')
    d['month'] = d.Date.dt.month; d['year'] = d.Date.dt.year
    reg = read_regimes(regime_path); fam = read_family_assignments(family_path)
    def attach(frame):
        frame = frame.merge(reg,on='Date',how='left',validate='many_to_one').merge(fam,on='regime',how='left',validate='many_to_one')
        if frame[['regime','group_4']].isna().any().any():
            save_csv(frame[frame.regime.isna() | frame.group_4.isna()],out/'audit/unmatched_weather_patterns.csv')
            raise ValueError('Unmatched weather-pattern dates or families; no silent dropping.')
        return frame
    days_all = aggregate_site_days(d)
    days = attach(days_all[days_all.n_evaluable.gt(0)].copy())
    samples = attach(d[d.exceedance.notna()].copy())
    routine = aggregate_site_days(d[d.routine_MS].copy())
    routine = attach(routine[routine.n_evaluable.gt(0)].copy())
    save_csv(d,out/'audit/all_in_season_records.csv')
    save_csv(days_all,out/'audit/all_site_days_before_IE_exclusion.csv')
    save_csv(days,out/'analysis_data/site_day_analysis.csv')
    save_csv(samples,out/'analysis_data/sample_level_sensitivity.csv')
    save_csv(routine,out/'analysis_data/routine_MS_site_days.csv')
    save_csv(fam,out/'audit/family_mapping_used.csv')
    save_csv(d.groupby(['year','SAMP_PURPOSE_CODE'],dropna=False).size().rename('n_records').reset_index(),out/'audit/sampling_purposes.csv')
    # Lab reference is not assumed globally unique: retain repeats and provenance.
    lab = d[d.SAMP_LAB_REF_NO.notna()].copy()
    save_csv(lab[lab.duplicated(['site_id','Date','SAMP_LAB_REF_NO'],keep=False)],out/'audit/repeated_nonmissing_site_date_lab.csv')
    save_csv(days[days.n_records.gt(1)],out/'audit/multiple_record_site_days.csv')
    save_csv(days[days.partially_missing],out/'audit/partially_missing_site_days.csv')
    annual = days.groupby('year').agg(n_site_days=('Date','size'), n_sites=('site_id','nunique'),
               n_sampling_dates=('Date','nunique'), n_exceedances=('exceedance','sum')).reset_index()
    annual['exceedance_proportion'] = annual.n_exceedances/annual.n_site_days
    annual = annual.merge(samples.groupby('year').size().rename('n_evaluable_samples'),on='year')
    save_csv(annual,out/'tables/annual_cohort.csv')
    save_csv(days.groupby('site_id').agg(site_name=('site_name','first'),n_site_days=('Date','size'),
             n_exceedances=('exceedance','sum'),first_date=('Date','min'),last_date=('Date','max')).reset_index(),out/'tables/site_cohort.csv')
    counts = {'input_Records_rows':len(raw),'out_of_season_records':int((~inside).sum()),
              'in_season_records':len(d),'in_season_sites':d.site_id.nunique(),
              'missing_IE_records':int(d.IE_status.eq('missing').sum()),
              'threshold_indeterminate_records':int(d.IE_status.eq('threshold_indeterminate').sum()),
              'evaluable_samples':len(samples),'sample_exceedances':int(samples.exceedance.sum()),
              'site_days_before_IE_exclusion':len(days_all),
              'site_days_no_evaluable_IE':int(days_all.n_evaluable.eq(0).sum()),
              'evaluable_site_days':len(days),'site_day_exceedances':int(days.exceedance.sum()),
              'site_day_exceedance_proportion':float(days.exceedance.mean()),
              'sites_in_primary_analysis':days.site_id.nunique(), 'sampling_dates':days.Date.nunique(),
              'multiple_record_site_days':int(days_all.n_records.gt(1).sum()),
              'partially_missing_evaluable_site_days':int(days.partially_missing.sum()),
              'routine_MS_records':int(d.routine_MS.sum()),'routine_MS_site_days':len(routine),
              'routine_MS_site_day_exceedances':int(routine.exceedance.sum()),
              'unmatched_weather_pattern_records':0,'records_outside_domain':0}
    counts = {k:(int(v) if isinstance(v,np.integer) else v) for k,v in counts.items()}
    (out/'cohort_summary.json').write_text(json.dumps(counts,indent=2))
    calendar = reg[reg.Date.dt.year.between(2012,2024) & reg.Date.dt.month.isin(range(5,10))]
    full_dates = pd.date_range('2012-01-01','2024-12-31')
    expected_dates = full_dates[full_dates.month.isin(range(5,10))]
    if set(calendar.Date) != set(expected_dates):
        raise ValueError('The weather calendar does not cover every study-season date.')
    calendar = calendar.merge(fam,on='regime',validate='many_to_one')
    save_csv(calendar,out/'audit/study_weather_calendar.csv')
    for key,stem in [('group_4','family'),('regime','weather_pattern')]:
        coverage=calendar.groupby(key).size().rename('n_calendar_days').to_frame()
        coverage=coverage.join(days.groupby(key).agg(n_sampled_calendar_days=('Date','nunique'),
                       n_site_days=('Date','size'),n_exceedances=('exceedance','sum')))
        coverage=coverage.join(samples.groupby(key).size().rename('n_evaluable_samples'))
        save_csv(coverage.reset_index(),out/f'tables/{stem}_sampling_coverage.csv')
    return days,samples,routine,counts


def _cluster_meat(score_obs, clusters, correction=True):
    codes, unique = pd.factorize(clusters)
    if (codes < 0).any():
        raise ValueError('Missing cluster label.')
    n,k = score_obs.shape; g = len(unique)
    if g <= 1 or n <= k:
        raise ValueError('Insufficient clusters or observations for covariance.')
    sums = np.zeros((g,k)); np.add.at(sums,codes,score_obs)
    factor = g/(g-1)*(n-1)/(n-k) if correction else 1.
    return factor*(sums.T@sums)


def two_way_cluster_cov(res, site_ids, dates, correction=True):
    """Retained score sandwich, with explicit finite-cluster correction.

    V=B(M_site+M_date-M_intersection)B, B=(-H)^(-1).
    Each M is scaled by G/(G-1)*(N-1)/(N-K) when correction=True.
    Cross-checked against statsmodels cov_cluster_2groups on every fitted model.
    """
    score = res.model.score_obs(res.params)
    bread = np.linalg.inv(-res.model.hessian(res.params))
    sites = np.asarray(site_ids).astype(str)
    dates = pd.to_datetime(dates).to_numpy(dtype='datetime64[D]').astype(str)
    intersection = pd.MultiIndex.from_arrays([sites,dates])
    meat = (_cluster_meat(score,sites,correction)+_cluster_meat(score,dates,correction)
            -_cluster_meat(score,intersection,correction))
    cov = bread@meat@bread
    cov = (cov+cov.T)/2
    official = cov_cluster_2groups(res,pd.factorize(sites)[0],pd.factorize(dates)[0],use_correction=correction)[0]
    if not np.allclose(cov,official,rtol=1e-7,atol=1e-10):
        raise AssertionError('Score sandwich differs from statsmodels reference implementation.')
    return pd.DataFrame(cov,index=res.params.index,columns=res.params.index)


def contrast_stats(beta,cov,contrast):
    estimate = float(contrast@np.asarray(beta)); var = float(contrast@np.asarray(cov)@contrast)
    if not np.isfinite(var) or var <= 0:
        return dict(estimate=estimate,ratio=np.exp(estimate),lo=np.nan,hi=np.nan,p=np.nan,
                    status='nonpositive_or_nonfinite_contrast_variance')
    se = np.sqrt(var)
    return dict(estimate=estimate,ratio=np.exp(estimate),lo=np.exp(estimate-Z*se),
                hi=np.exp(estimate+Z*se),p=2*norm.sf(abs(estimate/se)),status='ok')


def global_wald_test(res,cov,prefix):
    terms = [t for t in res.params.index if str(t).startswith(prefix)]
    V = cov.loc[terms,terms].to_numpy(); b = res.params.loc[terms].to_numpy()
    rank = int(np.linalg.matrix_rank(V)); eig = np.linalg.eigvalsh(V)
    ans = dict(chi2=np.nan,df=len(terms),p=np.nan,rank=rank,min_eigenvalue=float(eig.min()),status='ok')
    if rank < len(terms) or eig.min() <= 0:
        ans['status'] = 'withheld_singular_or_indefinite_test_covariance'
        return ans
    stat = float(b@np.linalg.solve(V,b)); ans.update(chi2=stat,p=chi2.sf(stat,len(terms)))
    return ans


def marginal_mean_and_ci(res,cov,X):
    """Empirical standardisation; delta-method CI on log of the mean.

    Standardisation averages over the observed analytic rows, holding month/year
    (and site in site-FE sensitivity) at their observed values. No CI clipping.
    """
    X = np.asarray(X); mu = np.exp(X@res.params.to_numpy()); m = float(mu.mean())
    grad = (mu[:,None]*X).mean(axis=0)
    var = float(grad@cov.to_numpy()@grad)
    if not np.isfinite(var) or var <= 0:
        return m,np.nan,np.nan,'nonpositive_or_nonfinite_marginal_variance'
    se_log = np.sqrt(var)/m
    return m,m*np.exp(-Z*se_log),m*np.exp(Z*se_log),'ok'


def fit_model(df,predictor,label,out,adjusted=True,site_fe=False):
    df = df.copy().reset_index(drop=True)
    if predictor == 'group_4':
        levels = FAMILY_ORDER; baseline = BASELINE_FAMILY
        df[predictor] = pd.Categorical(df[predictor],categories=levels)
        term = f"C(group_4, Treatment(reference={baseline!r}))"
    else:
        levels = list(range(1,31)); baseline = BASELINE_REGIME
        if set(df.regime) != set(levels):
            raise ValueError('Not all 30 weather patterns represented; model needs explicit reconsideration.')
        term = 'C(regime, Treatment(reference=25))'
    formula = 'exceedance ~ '+term+(' + C(month) + C(year)' if adjusted else '')+(' + C(site_id)' if site_fe else '')
    print(f'Fitting {label}: {len(df):,} rows; {formula}',flush=True)
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter('always')
        res = smf.glm(formula,data=df,family=sm.families.Poisson(),missing='raise').fit(maxiter=100,tol=1e-10)
    X = res.model.exog
    rank = np.linalg.matrix_rank(X)
    if not res.converged or rank != X.shape[1] or int(res.nobs) != len(df):
        raise ValueError(f'{label}: nonconvergence, rank deficiency or silent record dropping.')
    cov = two_way_cluster_cov(res,df.site_id,df.Date)
    savedir = out/'models'/label; savedir.mkdir(parents=True,exist_ok=True)
    save_csv(cov.rename_axis('term').reset_index(),savedir/'covariance_two_way.csv')
    save_csv(pd.DataFrame({'term':res.params.index,'coefficient':res.params.to_numpy()}),savedir/'coefficients.csv')
    effects=[]
    def vector(level):
        v = np.zeros(len(res.params))
        if level != baseline:
            name = term+f'[T.{level}]'
            v[list(res.params.index).index(name)] = 1.
        return v
    for level in levels:
        sub = df[df[predictor].eq(level)]
        if not len(sub):
            raise ValueError(f'No observations for {level}')
        stat = contrast_stats(res.params,cov,vector(level)) if level != baseline else dict(ratio=1.,lo=np.nan,hi=np.nan,p=np.nan,status='reference')
        effects.append(dict(level=level,n=len(sub),exceedances=int(sub.exceedance.sum()),
                            RR=stat['ratio'],rr_lo=stat['lo'],rr_hi=stat['hi'],p=stat['p'],status=stat['status']))
    rr = pd.DataFrame(effects); rr['q_bh_vs_reference'] = bh_fdr(rr.p)
    rr['reference'] = str(baseline)
    save_csv(rr,savedir/'ratios_vs_reference.csv')
    wald = global_wald_test(res,cov,term)
    (savedir/'global_wald.json').write_text(json.dumps(wald,indent=2,default=float))
    pair=[]
    if predictor == 'group_4':
        for a,b in itertools.combinations(levels,2):
            st = contrast_stats(res.params,cov,vector(a)-vector(b))
            pair.append(dict(numerator=a,denominator=b,RR=st['ratio'],lo=st['lo'],hi=st['hi'],p=st['p'],status=st['status']))
        pair = pd.DataFrame(pair); pair['q_bh_six_pairs'] = bh_fdr(pair.p)
        save_csv(pair,savedir/'pairwise_family_contrasts.csv')
    margins=[]
    # Use the fitted design_info to guarantee identical columns and reference coding.
    for level in levels:
        tmp = df.copy()
        tmp[predictor] = level
        if predictor == 'group_4': tmp[predictor] = pd.Categorical(tmp[predictor],categories=levels)
        design = patsy.build_design_matrices([res.model.data.design_info],tmp,return_type='dataframe')[0]
        m,lo,hi,status = marginal_mean_and_ci(res,cov,design)
        margins.append(dict(level=level,n=int(df[predictor].eq(level).sum()),p=m,lo=lo,hi=hi,status=status))
    margins = pd.DataFrame(margins)
    save_csv(margins,savedir/'marginal_probabilities.csv')
    # Audit all original-data fitted probabilities. Poisson log link is not bounded by 1.
    fitted = np.asarray(res.fittedvalues)
    eig = np.linalg.eigvalsh(cov)
    diag = dict(label=label,formula=formula,n=len(df),n_sites=df.site_id.nunique(),n_dates=df.Date.nunique(),
                n_parameters=len(res.params),design_rank=rank,converged=bool(res.converged),
                min_covariance_eigenvalue=float(eig.min()),covariance_indefinite=bool(eig.min() < -1e-10),
                min_fitted_probability=float(fitted.min()),max_fitted_probability=float(fitted.max()),
                fitted_probabilities_over_one=int((fitted>1).sum()),
                marginal_CI_upper_over_one=int(margins.hi.gt(1).sum()),
                invalid_RR_variances=int((~rr.status.isin(['ok','reference'])).sum()),
                global_test_status=wald['status'],finite_cluster_correction=True,
                inference='Asymptotic normal scalar tests and chi-squared joint Wald tests',
                warnings=list(dict.fromkeys(str(w.message) for w in captured)))
    (savedir/'diagnostics.json').write_text(json.dumps(diag,indent=2,default=lambda x:int(x) if isinstance(x,np.integer) else float(x)))
    return dict(rr=rr,margins=margins,wald=wald,pairwise=pair,diagnostics=diag)


def save_figure_all_formats(fig,outbase):
    outbase=Path(outbase); outbase.parent.mkdir(parents=True,exist_ok=True)
    # Save also the underlying plotting data separately in every figure function.
    fig.savefig(outbase.with_suffix('.png'),dpi=600,bbox_inches='tight',pad_inches=0.12)
    fig.savefig(outbase.with_suffix('.pdf'),bbox_inches='tight',pad_inches=0.12)
    fig.savefig(outbase.with_suffix('.svg'),bbox_inches='tight',pad_inches=0.12)
    plt.close(fig)


def plot_family_panels(observed,adjusted,out):
    fig,axes=plt.subplots(1,2,figsize=(7.25,3.1),sharey=True,sharex=True,layout='constrained')
    for ax,table,title in zip(axes,[observed,adjusted],['a  Observed','b  Month and year adjusted']):
        d=table.set_index('level').loc[FAMILY_ORDER]
        for i,(lev,row) in enumerate(d.iterrows()):
            ax.errorbar(row.p,i,xerr=[[row.p-row.lo],[row.hi-row.p]],fmt='o',
                        color=COLOURS[lev],capsize=3,ms=5,lw=1.2)
        ax.set_yticks(range(4),[SHORT[g] for g in FAMILY_ORDER])
        ax.set_title(title,loc='left'); ax.set_xlabel('IE exceedance probability')
        ax.xaxis.set_major_formatter(PercentFormatter(1,decimals=0))
        ax.grid(axis='x',alpha=.18)
    axes[0].set_xlim(0,max(observed.hi.max(),adjusted.hi.max())*1.13)
    axes[0].invert_yaxis()
    save_figure_all_formats(fig,out/'figures/Figure_1_family_probabilities')
    save_csv(observed,out/'figure_data/Figure_1a_observed.csv');save_csv(adjusted,out/'figure_data/Figure_1b_adjusted.csv')


def plot_family_combined(adjusted,ratios,out):
    """Reference-style two-panel figure; uses saved primary family results only.

    Panel a: empirical-standardised probabilities and log-mean delta-method CIs.
    Panel b: adjusted probability ratios versus the whole settled family.
    This function does not fit models or change the estimates.
    """
    probability=adjusted.set_index('level').loc[FAMILY_ORDER].reset_index()
    ratio=ratios.set_index('level').loc[FAMILY_ORDER].reset_index()
    if not np.array_equal(probability.n.to_numpy(),ratio.n.to_numpy()):
        raise ValueError('Probability and ratio panels have different site-day counts.')
    if not probability.status.eq('ok').all() or not ratio.status.isin(['ok','reference']).all():
        raise ValueError('Cannot plot invalid primary inference as publication results.')
    figure_data=probability.rename(columns={'p':'adjusted_probability','lo':'probability_lo','hi':'probability_hi','status':'probability_status'})
    figure_data=figure_data.merge(ratio.drop(columns=['n']),on='level',validate='one_to_one')
    fig,(ax_a,ax_b,ax_text)=plt.subplots(1,3,figsize=(11.5,4.15),sharey=True,
        gridspec_kw={'width_ratios':[1.6,1.12,.83]},layout='constrained')
    y=np.arange(4)
    labels=[f'{g}\n(n={int(n):,})' for g,n in zip(FAMILY_ORDER,probability.n)]
    # The blue styling follows the supplied reference figure. The diamond is
    # a coding reference, with no spurious zero-width uncertainty interval.
    blue='#0072B2'
    ax_a.errorbar(probability.p,y,xerr=[probability.p-probability.lo,probability.hi-probability.p],
                   fmt='o',color=blue,ms=4.7,capsize=3,lw=1.05)
    for i,row in enumerate(probability.itertuples()):
        ax_a.annotate(f'{row.p:.1%}',(row.p,i),xytext=(0,10),textcoords='offset points',
                      ha='center',va='bottom',fontsize=9)
    ax_a.set_yticks(y,labels);ax_a.tick_params(axis='y',labelsize=8.5,length=0,pad=5)
    ax_a.xaxis.set_major_formatter(PercentFormatter(1,decimals=0))
    ax_a.set_xlim(0,max(.18,float(probability.hi.max())*1.10))
    ax_a.set_xlabel('Adjusted IE exceedance probability (%)',fontsize=9)
    ax_a.set_title('a',loc='left',fontweight='bold',fontsize=11,pad=10)
    for i,row in enumerate(ratio.itertuples()):
        if row.status=='reference':
            ax_b.plot(1,i,marker='D',color='#D55E00',ms=4.5,ls='')
            value='Reference'
        else:
            ax_b.errorbar(row.RR,i,xerr=[[row.RR-row.rr_lo],[row.rr_hi-row.RR]],
                          fmt='o',color=blue,ms=4.7,capsize=3,lw=1.05)
            value=f'Ratio {row.RR:.2f} ({row.rr_lo:.2f}–{row.rr_hi:.2f})'
        ax_text.text(0,i,value,va='center',ha='left',fontsize=9)
    ax_b.set_yticks(y,labels);ax_b.tick_params(axis='y',labelleft=True,labelsize=8.5,length=0,pad=5)
    ax_b.axvline(1,color=blue,ls='--',lw=.9)
    ax_b.set_xscale('log');ax_b.set_xlim(.78,2.8);ratio_ticks(ax_b)
    ax_b.set_xlabel('Adjusted probability ratio versus settled',fontsize=9)
    ax_b.set_title('b',loc='left',fontweight='bold',fontsize=11,pad=10)
    ax_text.axis('off');ax_text.set_xlim(0,1)
    for ax in [ax_a,ax_b]:
        ax.grid(axis='x',color='#E6E6E6',lw=.6);ax.set_axisbelow(True)
        ax.tick_params(axis='x',labelsize=9)
    ax_a.set_ylim(3.6,-.60)
    save_figure_all_formats(fig,Path(out)/'figures/Figure_family_adjusted_combined')
    save_csv(figure_data,Path(out)/'figure_data/Figure_family_adjusted_combined.csv')


def ratio_ticks(ax):
    low,high=ax.get_xlim()
    candidates=[.1,.2,.25,.5,.75,1.,1.5,2.,3.,4.,5.,8.,10.,20.]
    ticks=[v for v in candidates if low<=v<=high]
    if len(ticks)>8:
        ticks=[v for v in [.1,.25,.5,1.,2.,4.,8.,20.] if low<=v<=high]
    ax.set_xticks(ticks,[f'{v:g}' for v in ticks])
    ax.xaxis.set_minor_formatter(NullFormatter())


def plot_rr_forest(rr,outbase,family=True):
    d=rr.copy()
    if family: d=d.set_index('level').loc[FAMILY_ORDER].reset_index()
    else: d=d.sort_values('level')
    height=3.1 if family else 9.5
    fig,(ax,txt)=plt.subplots(1,2,figsize=(7.25,height),sharey=True,
                            gridspec_kw={'width_ratios':[2.3,1.25]},layout='constrained')
    for i,row in enumerate(d.itertuples()):
        reference=row.status=='reference'
        colour=COLOURS[row.level] if family else '#0072B2'
        if reference: ax.plot(1,i,'D',color='#555555',ms=4)
        else: ax.errorbar(row.RR,i,xerr=[[row.RR-row.rr_lo],[row.rr_hi-row.RR]],fmt='o',color=colour,capsize=3,ms=4)
        value='1.00 (reference)' if reference else f'{row.RR:.2f} ({row.rr_lo:.2f}, {row.rr_hi:.2f})'
        txt.text(0,i,value,va='center',fontsize=8)
    labels=[f'{SHORT[r.level] if family else "WP "+str(r.level).zfill(2)}  (n={r.n:,})' for r in d.itertuples()]
    ax.set_yticks(np.arange(len(d)),labels);ax.invert_yaxis();ax.axvline(1,color='#777777',ls='--',lw=.8)
    ax.set_xscale('log');ratio_ticks(ax);ax.set_xlabel('Exceedance probability ratio')
    ax.grid(axis='x',alpha=.15);txt.axis('off');txt.set_xlim(0,1)
    txt.set_title('Ratio (95% confidence interval)',fontsize=9)
    save_figure_all_formats(fig,outbase)


def plot_wp_probabilities(observed,adjusted,out,fam):
    fig,axes=plt.subplots(1,2,figsize=(7.25,9.5),sharey=True,sharex=True,layout='constrained')
    mapping=fam.set_index('regime').group_4
    for ax,table,title in zip(axes,[observed,adjusted],['a  Observed','b  Month and year adjusted']):
        d=table.sort_values('level')
        for i,row in enumerate(d.itertuples()):
            ax.errorbar(row.p,i,xerr=[[row.p-row.lo],[row.hi-row.p]],fmt='o',capsize=2,ms=4,color=COLOURS[mapping.loc[row.level]])
        ax.set_yticks(range(30),[f'WP {r:02d}' for r in range(1,31)])
        ax.set_title(title,loc='left');ax.set_xlabel('IE exceedance probability')
        ax.xaxis.set_major_formatter(PercentFormatter(1,decimals=0));ax.grid(axis='x',alpha=.15)
    axes[0].set_xlim(0,max(observed.hi.max(),adjusted.hi.max())*1.08)
    handles=[Line2D([0],[0],marker='o',ls='',color=COLOURS[g],label=SHORT[g]) for g in FAMILY_ORDER]
    fig.legend(handles=handles,loc='outside lower center',ncol=2,frameon=False,fontsize=8)
    axes[0].invert_yaxis();save_figure_all_formats(fig,out/'figures/Figure_S2_weather_pattern_probabilities')
    save_csv(observed,out/'figure_data/Figure_S2a_observed.csv');save_csv(adjusted,out/'figure_data/Figure_S2b_adjusted.csv')


def plot_sensitivity(results,out):
    names=list(results); fig,ax=plt.subplots(figsize=(7.25,3.9),layout='constrained')
    ybase=np.arange(3); offsets=np.linspace(-.27,.27,len(names))
    markers=['o','s','^','D','v']
    for shift,(name,result),marker in zip(offsets,results.items(),markers):
        d=result['rr'].set_index('level').loc[FAMILY_ORDER[:3]]
        ax.errorbar(d.RR,ybase+shift,xerr=[d.RR-d.rr_lo,d.rr_hi-d.RR],fmt=marker,
                    capsize=2,ms=4,label=name)
    ax.set_yticks(ybase,[SHORT[g] for g in FAMILY_ORDER[:3]]);ax.invert_yaxis()
    ax.axvline(1,color='#777777',ls='--',lw=.8);ax.set_xscale('log');ratio_ticks(ax)
    ax.set_xlabel('Exceedance probability ratio versus settled anticyclonic')
    ax.legend(loc='upper center',bbox_to_anchor=(.5,-.19),ncol=2,fontsize=8,frameon=False)
    save_figure_all_formats(fig,out/'figures/Figure_S3_family_sensitivity')
    save_csv(pd.concat([r['rr'].assign(analysis=name) for name,r in results.items()],ignore_index=True),out/'figure_data/Figure_S3_sensitivity.csv')


def report(out,counts,results,annual):
    p=results['primary_family']; rr=p['rr'].set_index('level'); pr=p['margins'].set_index('level')
    lines=['# Bathing water exceedance associations','',
        'This package reruns the supplied association analysis on the supplied consolidated workbook. '
        'The primary unit is the site-day; the original individual-sample unit is retained as a sensitivity analysis.',
        '', '## Cohort verified from the supplied files','',
        f"The Records sheet contains {counts['input_Records_rows']:,} records. Restricting to May to September 2012 to 2024 excludes {counts['out_of_season_records']:,} records. "
        f"The {counts['in_season_records']:,} retained records include {counts['missing_IE_records']} missing IE results and {counts['threshold_indeterminate_records']} indeterminate censored results. "
        f"There are {counts['evaluable_samples']:,} evaluable samples and {counts['evaluable_site_days']:,} evaluable site-days from {counts['sites_in_primary_analysis']} supplied site identities, "
        f"with {counts['site_day_exceedances']:,} site-day exceedances ({counts['site_day_exceedance_proportion']:.1%}).",
        '',f"Of the evaluable site-days, {counts['partially_missing_evaluable_site_days']} contain both measured and missing results. The primary outcome uses the measured samples; a complete-result-day sensitivity excludes these days. "
        'No missing IE value is imputed as a negative result. The supplied site identities are used unchanged; their legal designation histories are not independently verified.',
        '', '## Methods suitable for manuscript adaptation','',
        'Intestinal enterococci exceedance was defined as a reported concentration ≥63 CFU 100 mL⁻¹. '
        'Censored values were classified only where their reported bound established exceedance or non-exceedance. '
        'Within each supplied bathing-water identity and sampling date, the outcome was one if any evaluable sample exceeded the threshold and zero if all evaluable samples were below it. '
        'Dates without an evaluable result were excluded. The fixed rainfall-family mapping was recovered unchanged from the earlier audited rainfall-family package, independently of these microbiological outcomes.',
        '', 'Separate modified Poisson regressions with a log link related the binary outcome to the four rainfall families and the 30 weather patterns, adjusting for categorical month and year. '
        'The reference levels were settled anticyclonic conditions and WP25, respectively. WP25 is a retained coding reference within that family, rather than a demonstrated optimum or a uniquely representative anticyclonic pattern. '
        'Exponentiated coefficients describe exceedance probability ratios. Two-way sandwich covariance was calculated by site and sampling date with component-specific finite-cluster corrections. '
        'Joint Wald tests used the same covariance; invalid or singular test covariance was flagged rather than repaired silently. '
        'Marginal probabilities were standardised to the empirical month/year distribution of the analytic site-days. '
        'Confidence intervals were calculated by the delta method on the log mean scale, without clipping. '
        'Observed-proportion uncertainty used unadjusted saturated Poisson models with the same two-way covariance, rather than independence-based binomial intervals. '
        'Scalar tests used asymptotic normal inference and joint Wald tests used chi-squared inference. '
        'Benjamini–Hochberg adjustments were reported separately for the three family-reference contrasts, six family pairs and 29 WP25 contrasts. '
        'All confidence intervals are pointwise 95% intervals, not simultaneous intervals.',
        '', 'Sensitivity analyses retained the original individual-sample unit, restricted to records coded MS and excluded partly missing site-days. '
        'The MS restriction is based on the supplied purpose code; no unverified interpretation of other codes was imposed. '
        'An additional site fixed-effects Poisson fit was retained as a diagnostic only, excluding sites without outcome variation. '
        'In the supplied run it produced fitted means above one and an indefinite full two-way covariance matrix. '
        'It is not used in the publication sensitivity figure and must not be cited as validation of a site-adjusted probability model. '
        'Its positive family-effect covariance block does not resolve these full-model diagnostic failures.',
        '', '## Primary family results','',
        '| Family | Site-days | Exceedances | Adjusted probability | Ratio versus settled (95% CI) | Raw p | BH q |',
        '|---|---:|---:|---:|---|---:|---:|']
    for g in FAMILY_ORDER:
        r=rr.loc[g]; m=pr.loc[g]
        ratio='1.00 (reference)' if r.status=='reference' else f'{r.RR:.3f} ({r.rr_lo:.3f}, {r.rr_hi:.3f})'
        pv='—' if pd.isna(r.p) else f'{r.p:.4g}';q='—' if pd.isna(r.q_bh_vs_reference) else f'{r.q_bh_vs_reference:.4g}'
        lines.append(f'| {g} | {int(r.n):,} | {int(r.exceedances):,} | {m.p:.2%} ({m.lo:.2%}, {m.hi:.2%}) | {ratio} | {pv} | {q} |')
    w=p['wald'];lines+=['',f"Family global test: χ²({w['df']}) = {w['chi2']:.4g}; p = {w['p']:.4g}; status: {w['status']}.",
        '', '## Material limitations and verification boundaries','',
        '* These are retrospective associations in sampled site-days. They do not estimate prospective forecast skill, issued advisories, illness prevention, or contamination duration.',
        '* The main model adjusts for month and year, not rainfall, other meteorology or site baseline differences. Site clustering changes uncertainty but does not adjust for between-site confounding. The separate site fixed-effects diagnostic failed probability-bound and full-covariance checks and is not presented as confirming the main model. Claims must remain descriptive associations.',
        '* Site clustering allows within-site dependence and date clustering allows dependence across sites sampled on the same date. Dependence between different sites on different dates during prolonged weather episodes is not fully captured.',
        '* Monitoring is uneven across years, sites and purposes. Complete-case results concern measured samples; missingness and unsampled days cannot be resolved from these inputs.',
        '* The ANY rule makes the primary unit one site-day, but days with more sampling opportunities have more chances to record an exceedance. Multiple-sample days and sample-level sensitivity are exported.',
        '* Reported coordinates are checked against the inclusive 49–52°N, 6–2°W box. Designation histories, individual coordinate accuracy and upstream workbook selection are not independently re-audited here. The supplied workbook is preserved in full, including its exclusion and provenance sheets.',
        '* The fixed family mapping is an external, previously reviewed input here. This association code does not independently establish rainfall mechanisms or validate the synoptic descriptors.',
        '* The adopted threshold is a study definition here. This package does not independently verify its current operational or regulatory use.',
        '* The original study manuscript and updated prediction/storyline outputs are not supplied in this request. All downstream analyses and manuscript numbers affected by the cohort change must be updated separately.',
        '* Reproducibility of the supplied analysis does not establish correctness of the original laboratory measurements or of pre-selection of records.',
        '', '## Diagnostic flags','']
    for name,r in results.items():
        d=r['diagnostics']; lines.append(f"* {name}: n={d['n']:,}; converged={d['converged']}; covariance indefinite={d['covariance_indefinite']}; "
             f"fitted means >1: {d['fitted_probabilities_over_one']}; marginal interval upper bounds >1: {d['marginal_CI_upper_over_one']}; "
             f"invalid ratio variances: {d['invalid_RR_variances']}; global test: {d['global_test_status']}.")
    lines += ['', '## Sources checked for methods','',
        '* Zou (2004), A modified Poisson regression approach to prospective studies with binary data. https://doi.org/10.1093/aje/kwh090',
        '* statsmodels two-group covariance documentation (small-sample correction and covariance decomposition). https://www.statsmodels.org/v0.14.4/generated/statsmodels.stats.sandwich_covariance.cov_cluster_2groups.html',
        '* The installed statsmodels score/Hessian implementation is cross-checked numerically against this script on every model.',
        '', '## Files to use','',
        '* `tables/annual_cohort.csv` and `cohort_summary.json`: updated dataset counts.',
        '* `models/primary_family/`: primary four-family estimates, pairwise and joint tests.',
        '* `models/primary_weather_patterns/`: primary 30-pattern estimates and tests.',
        '* `models/sensitivity_*/`: explicitly secondary checks; do not substitute selectively for primary results.',
        '* `figures/`: 600 dpi PNG and vector PDF/SVG. Captions are in FIGURE_CAPTIONS.md.',
        '* `figure_data/`: exact data used to generate each figure.',
        '* `audit/` and `analysis_data/`: exclusions, provenance, merge checks and analysis rows.',
        '']
    (out/'RESULTS_AND_METHODS.md').write_text('\n'.join(lines),encoding='utf-8')


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bw',type=Path,default=ROOT/'data/input/bathing_water_records_2012_2024.xlsx')
    parser.add_argument('--regimes',type=Path,default=ROOT/'data/input/weather_patterns_30.csv')
    parser.add_argument('--families',type=Path,default=ROOT/'data/derived/weather_pattern_family_assignments.csv')
    parser.add_argument('--output',type=Path,default=ROOT/'results')
    parser.add_argument('--skip-site-diagnostic',action='store_true',help='Omit the slower site fixed-effects diagnostic, which is not a publication sensitivity result.')
    args=parser.parse_args(argv);out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
    for folder in ['audit','analysis_data','tables','models','figures','figure_data']:(out/folder).mkdir(exist_ok=True)
    days,samples,routine,counts=build_df(args.bw,args.regimes,args.families,out)
    results={}
    results['primary_family']=fit_model(days,'group_4','primary_family',out)
    results['primary_weather_patterns']=fit_model(days,'regime','primary_weather_patterns',out)
    results['observed_family']=fit_model(days,'group_4','observed_family',out,adjusted=False)
    results['observed_weather_patterns']=fit_model(days,'regime','observed_weather_patterns',out,adjusted=False)
    for frame,name in [(samples,'sample_level'),(routine,'routine_MS'),(days[~days.partially_missing],'complete_days')]:
        results['sensitivity_'+name]=fit_model(frame,'group_4','sensitivity_'+name,out)
    no_variation=days.groupby('site_id').exceedance.nunique().loc[lambda x:x<2].index
    save_csv(days[days.site_id.isin(no_variation)].groupby('site_id').agg(n=('Date','size'),exceedances=('exceedance','sum')).reset_index(),out/'audit/site_FE_excluded_no_variation.csv')
    if not args.skip_site_diagnostic:
        results['diagnostic_site_FE']=fit_model(days[~days.site_id.isin(no_variation)],'group_4','diagnostic_site_FE',out,site_fe=True)
    save_csv(pd.DataFrame([r['diagnostics'] for r in results.values()]),out/'tables/model_diagnostics.csv')
    plot_family_panels(results['observed_family']['margins'],results['primary_family']['margins'],out)
    plot_family_combined(results['primary_family']['margins'],results['primary_family']['rr'],out)
    plot_rr_forest(results['primary_family']['rr'],out/'figures/Figure_2_family_ratios')
    save_csv(results['primary_family']['rr'],out/'figure_data/Figure_2_family_ratios.csv')
    plot_rr_forest(results['primary_weather_patterns']['rr'],out/'figures/Figure_S1_weather_pattern_ratios',family=False)
    save_csv(results['primary_weather_patterns']['rr'],out/'figure_data/Figure_S1_weather_pattern_ratios.csv')
    plot_wp_probabilities(results['observed_weather_patterns']['margins'],results['primary_weather_patterns']['margins'],out,read_family_assignments(args.families))
    sens={'Primary site-day':results['primary_family'],'Individual samples':results['sensitivity_sample_level'],
          'MS site-days':results['sensitivity_routine_MS'],'Complete-result site-days':results['sensitivity_complete_days']}
    plot_sensitivity(sens,out)
    report(out,counts,results,pd.read_csv(out/'tables/annual_cohort.csv'))
    versions={p:importlib.metadata.version(p) for p in ['numpy','pandas','scipy','statsmodels','patsy','matplotlib','openpyxl']}
    hashes={str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [args.bw,args.regimes,args.families]}
    meta=dict(python=platform.python_version(),platform=platform.platform(),packages=versions,input_sha256=hashes,
              site_FE_diagnostic_run=not args.skip_site_diagnostic,deterministic=True,
              primary_unit='site-day; any evaluable sample >=63',source_script='archive/original_bathing_water_exceedance_associations.py')
    (out/'run_metadata.json').write_text(json.dumps(meta,indent=2))
    print(json.dumps(counts,indent=2));print('Completed:',out,flush=True)


if __name__=='__main__':main()
