"""Independent reconciliation of saved results against source workbook rows.

This does not refit models. It independently parses these source result strings,
checks the analytic unit, totals, labels, displayed plot inputs and inference
arithmetic, and records diagnostic-only failures separately from publication results.
"""
import json
from pathlib import Path
import hashlib
import math
import re
import argparse
from collections import defaultdict

import numpy as np
import pandas as pd
from openpyxl import load_workbook
from scipy.stats import chi2,norm
from statsmodels.stats.multitest import multipletests

ROOT=Path(__file__).resolve().parents[1]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=ROOT/'results')
    parser.add_argument('--bw',type=Path,default=ROOT/'data/input/bathing_water_records_2012_2024.xlsx')
    args=parser.parse_args()
    out=args.output;checks=[]
    def check(name,condition,detail=''):
        checks.append({'check':name,'passed':bool(condition),'detail':detail})
        if not condition:raise AssertionError(f'{name}: {detail}')
    source=args.bw
    book=load_workbook(source,read_only=True,data_only=True)
    sheet=book['Records'];it=sheet.iter_rows(values_only=True);headers=next(it)
    col={s:i for i,s in enumerate(headers)};group=defaultdict(list);n_in=0;n_valid=0;n_missing=0;positive=0
    for row in it:
        date=row[col['Date']]
        if not (2012<=date.year<=2024 and 5<=date.month<=9):continue
        n_in+=1;v=row[col['3723 IE Conf (CFU/0_1l)']]
        if v is None or str(v).strip()=='':
            y=None;n_missing+=1
        else:
            text=str(v).strip()
            if text.startswith('<'):
                limit=float(text[1:]);assert limit<=63
                y=0
            elif text.startswith('>'):
                limit=float(text[1:]);assert limit>=63
                y=1
            else:y=int(float(text)>=63)
            n_valid+=1;positive+=y
        group[(str(row[col['site_id']]),date)].append(y)
    expected={k:max(v for v in vals if v is not None) for k,vals in group.items() if any(v is not None for v in vals)}
    book.close()
    days=pd.read_csv(out/'analysis_data/site_day_analysis.csv',parse_dates=['Date'])
    samples=pd.read_csv(out/'analysis_data/sample_level_sensitivity.csv',parse_dates=['Date'],low_memory=False)
    counts=json.loads((out/'cohort_summary.json').read_text())
    check('source in-season record count',n_in==counts['in_season_records'])
    check('source missing IE count',n_missing==counts['missing_IE_records'])
    check('source valid sample count',n_valid==len(samples)==counts['evaluable_samples'])
    check('source sample exceedance count',positive==int(samples.exceedance.sum()))
    check('independent site-day count',len(expected)==len(days)==counts['evaluable_site_days'])
    actual={(r.site_id,r.Date.to_pydatetime()):int(r.exceedance) for r in days.itertuples()}
    check('every site-day outcome equals independent ANY rule',actual==expected)
    check('unique analytic site-days',not days.duplicated(['site_id','Date']).any())
    check('source site-day exceedance count',sum(expected.values())==counts['site_day_exceedances'])
    check('binary nonmissing primary outcome',days.exceedance.isin([0,1]).all())
    check('domain and date membership',days.lat.between(49,52).all() if 'lat' in days else counts['records_outside_domain']==0)
    check('all sample coordinates inside inclusive domain',samples.lat.between(49,52).all() and samples.lon.between(-6,-2).all())
    check('all model samples in season',days.Date.dt.month.isin(range(5,10)).all() and days.Date.dt.year.between(2012,2024).all())
    annual=pd.read_csv(out/'tables/annual_cohort.csv')
    check('annual site-day totals',annual.n_site_days.sum()==len(days))
    check('annual exceedance totals',annual.n_exceedances.sum()==days.exceedance.sum())
    check('annual sample totals',annual.n_evaluable_samples.sum()==len(samples))
    check('annual percentages',np.allclose(annual.exceedance_proportion,annual.n_exceedances/annual.n_site_days,rtol=1e-10))
    fam=pd.read_csv(out/'audit/family_mapping_used.csv')
    check('exactly 30 explicit family rows',len(fam)==30 and set(fam.regime)==set(range(1,31)) and not fam.regime.duplicated().any())
    check('family mapping agrees on every analysis row',days.group_4.equals(days.regime.map(fam.set_index('regime').group_4)))
    calendar=pd.read_csv(out/'audit/study_weather_calendar.csv',parse_dates=['Date'])
    dates=pd.date_range('2012-01-01','2024-12-31');dates=dates[dates.month.isin(range(5,10))]
    check('complete unique study calendar',not calendar.Date.duplicated().any() and set(calendar.Date)==set(dates))
    for stem in ['family','weather_pattern']:
        cover=pd.read_csv(out/f'tables/{stem}_sampling_coverage.csv')
        check(stem+' calendar coverage total',cover.n_calendar_days.sum()==len(dates))
        check(stem+' sampling coverage total',cover.n_site_days.sum()==len(days) and cover.n_exceedances.sum()==days.exceedance.sum())
        check(stem+' valid sample coverage total',cover.n_evaluable_samples.sum()==len(samples))
    obs=pd.read_csv(out/'models/observed_family/marginal_probabilities.csv').set_index('level')
    obs30=pd.read_csv(out/'models/observed_weather_patterns/marginal_probabilities.csv').set_index('level')
    check('observed family means equal raw proportions',np.allclose(obs.p,days.groupby('group_4').exceedance.mean().reindex(obs.index),rtol=1e-9))
    check('observed WP means equal raw proportions',np.allclose(obs30.p,days.groupby('regime').exceedance.mean().reindex(obs30.index),rtol=1e-9))
    diag=pd.read_csv(out/'tables/model_diagnostics.csv')
    accepted=diag[~diag.label.str.startswith('diagnostic_')]
    check('accepted models converge and are full rank',accepted.converged.all() and (accepted.n_parameters==accepted.design_rank).all())
    check('accepted fitted means within [0,1]',accepted.min_fitted_probability.ge(0).all() and accepted.max_fitted_probability.le(1).all())
    check('accepted covariance positive semidefinite',accepted.min_covariance_eigenvalue.ge(-1e-10).all())
    check('accepted contrast inference valid',accepted.invalid_RR_variances.eq(0).all() and accepted.global_test_status.eq('ok').all())
    check('accepted marginal intervals within [0,1]',accepted.marginal_CI_upper_over_one.eq(0).all())
    for name in ['primary_family','primary_weather_patterns','sensitivity_sample_level','sensitivity_routine_MS','sensitivity_complete_days']:
        folder=out/'models'/name
        rr=pd.read_csv(folder/'ratios_vs_reference.csv');beta=pd.read_csv(folder/'coefficients.csv').set_index('term').coefficient
        cov=pd.read_csv(folder/'covariance_two_way.csv',index_col='term')
        prefix='C(group_4' if name!='primary_weather_patterns' else 'C(regime'
        terms=[s for s in beta.index if s.startswith(prefix)]
        w=json.loads((folder/'global_wald.json').read_text())
        b=beta.loc[terms].to_numpy();V=cov.loc[terms,terms].to_numpy()
        statistic=float(b@np.linalg.solve(V,b))
        check(name+' joint test arithmetic',math.isclose(statistic,w['chi2'],rel_tol=1e-9) and math.isclose(chi2.sf(statistic,len(terms)),w['p'],rel_tol=1e-8))
        valid=rr.p.notna()
        check(name+' BH arithmetic',np.allclose(rr.loc[valid,'q_bh_vs_reference'],multipletests(rr.loc[valid,'p'],method='fdr_bh')[1],rtol=1e-9))
        for t in terms:
            lev=t.split('[T.',1)[1][:-1];sel=rr.level.astype(str).eq(lev)
            r=rr.loc[sel].iloc[0];se=np.sqrt(cov.loc[t,t]);estimate=beta.loc[t]
            check(name+' effect '+lev,math.isclose(r.RR,np.exp(estimate),rel_tol=1e-9)
                  and math.isclose(r.rr_lo,np.exp(estimate-norm.ppf(.975)*se),rel_tol=1e-9)
                  and math.isclose(r.rr_hi,np.exp(estimate+norm.ppf(.975)*se),rel_tol=1e-9)
                  and math.isclose(r.p,2*norm.sf(abs(estimate/se)),rel_tol=1e-8))
    # Check that failed optional diagnostics never enter the publication comparison.
    sensitivity=pd.read_csv(out/'figure_data/Figure_S3_sensitivity.csv')
    check('publication sensitivity figure excludes failed diagnostic',not sensitivity.analysis.str.contains('fixed|diagnostic',case=False).any())
    pairs=[('Figure_1a_observed.csv','observed_family/marginal_probabilities.csv'),
           ('Figure_1b_adjusted.csv','primary_family/marginal_probabilities.csv'),
           ('Figure_2_family_ratios.csv','primary_family/ratios_vs_reference.csv'),
           ('Figure_S1_weather_pattern_ratios.csv','primary_weather_patterns/ratios_vs_reference.csv'),
           ('Figure_S2a_observed.csv','observed_weather_patterns/marginal_probabilities.csv'),
           ('Figure_S2b_adjusted.csv','primary_weather_patterns/marginal_probabilities.csv')]
    for fig,table in pairs:
        a=pd.read_csv(out/'figure_data'/fig);b=pd.read_csv(out/'models'/table)
        check(fig+' matches model output',a.equals(b))
    combined=pd.read_csv(out/'figure_data/Figure_family_adjusted_combined.csv').set_index('level')
    primary_prob=pd.read_csv(out/'models/primary_family/marginal_probabilities.csv').set_index('level').reindex(combined.index)
    primary_ratio=pd.read_csv(out/'models/primary_family/ratios_vs_reference.csv').set_index('level').reindex(combined.index)
    check('combined figure probabilities and intervals match primary estimates',
          np.array_equal(combined.n,primary_prob.n) and np.allclose(combined[['adjusted_probability','probability_lo','probability_hi']],primary_prob[['p','lo','hi']],rtol=1e-10))
    check('combined figure ratios and intervals match primary estimates',
          np.array_equal(combined.n,primary_ratio.n) and np.allclose(combined[['RR','rr_lo','rr_hi']],primary_ratio[['RR','rr_lo','rr_hi']],rtol=1e-10,equal_nan=True))
    for stem in ['Figure_1_family_probabilities','Figure_2_family_ratios','Figure_S1_weather_pattern_ratios',
                 'Figure_S2_weather_pattern_probabilities','Figure_S3_family_sensitivity','Figure_family_adjusted_combined']:
        check(stem+' all formats',all((out/'figures'/f'{stem}.{ext}').is_file() for ext in ['png','pdf','svg']))
    # Frozen source identity anchors the delivered snapshot; future changed datasets
    # must be reviewed rather than automatically inheriting these expected counts.
    h=hashlib.sha256(source.read_bytes()).hexdigest()
    if h=='c4dea14f2223bde55297e0eb9085e50cafd08d36e8f9a435536c55e114e70f62':
        check('delivered source cohort regression check',(n_in,n_valid,len(expected),sum(expected.values()),len({k[0] for k in expected}))==(35621,35590,35518,3727,194))
    pd.DataFrame(checks).to_csv(out/'tables/validation_checks.csv',index=False)
    print(f'{len(checks)} independent reconciliation checks passed.')
    flagged=diag[diag.label.str.startswith('diagnostic_')]
    if len(flagged):
        print('Separate diagnostic-only fit (excluded from publication figures):')
        print(flagged[['label','fitted_probabilities_over_one','covariance_indefinite']].to_string(index=False))


if __name__=='__main__':main()
