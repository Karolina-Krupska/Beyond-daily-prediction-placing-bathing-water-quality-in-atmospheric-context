# Implemented equations and definitions

These equations document the revised code. The full current manuscript was not supplied in this request, so an equation-by-equation comparison with its current wording has not been established.

## Outcome and analysis unit

For evaluable sample j at supplied site s on date t:

$$y_{stj}=\mathbf{1}(\mathrm{IE}_{stj}\geq63\ \mathrm{CFU}\,(100\ \mathrm{mL})^{-1}).$$

Censored results are evaluable only where the reported bound establishes the binary outcome. A missing value is not assigned zero. For the primary site-day analysis, J_st denotes the set of evaluable samples:

$$Y_{st}=\max_{j\in J_{st}}y_{stj},\qquad |J_{st}|>0.$$

Site-days with no evaluable sample are excluded. Partly missing site-days use measured samples and are explicitly flagged. The complete-result sensitivity excludes those partly missing days. Implementation: `classify_ie`, `aggregate_site_days` and `build_df`.

## Main modified Poisson mean models

Two models are fitted separately, one with four-family predictor and one with 30-pattern predictor:

$$\log(\mu_{st})=\beta_0+\beta_{g(t)}+\gamma_{m(t)}+\delta_{a(t)}.$$

Here mu_st is the fitted mean of binary Y_st, g(t) is family or weather pattern, m(t) is month and a(t) is year. Treatment-coded reference coefficients are zero. The family reference is settled anticyclonic quiet; the pattern reference is WP25. The main models have no site fixed effects, rainfall covariate or other hydrometeorological covariates. Implementation: `fit_model`, using the Poisson family with its default log link.

For primary group contrasts, with all other model terms held fixed:

$$\mathrm{PR}_{a:b}=\exp(\beta_a-\beta_b).$$

The tables retain the familiar field name `RR`, but the reported quantity here is an exceedance probability ratio. It is not an illness ratio or a ratio of actual advisories. The individual-sample sensitivity substitutes y_stj for Y_st; it therefore has a different analysis unit and sampling weight.

## Two-way covariance

Let N be the number of analytic rows, K the number of model parameters, X the fitted design matrix and u_i the observation score. For the Poisson mean model with unit weights:

$$u_i=x_i(Y_i-\mu_i),\qquad B=(-H)^{-1}=(X^\top\operatorname{diag}(\mu_i)X)^{-1}.$$

For each clustering scheme h (site, date, or site-date intersection), with G_h distinct clusters:

$$S_{hc}=\sum_{i\in c}u_i,\qquad f_h=\frac{G_h}{G_h-1}\frac{N-1}{N-K},\qquad M_h=f_h\sum_{c=1}^{G_h}S_{hc}S_{hc}^{\top}.$$

$$V=B(M_{\mathrm{site}}+M_{\mathrm{date}}-M_{\mathrm{intersection}})B.$$

Implementation: `_cluster_meat` and `two_way_cluster_cov`. The score/Hessian calculation is cross-checked against `statsmodels.stats.sandwich_covariance.cov_cluster_2groups(..., use_correction=True)` on every fit. The main results use asymptotic inference, not a claim of exact small-sample coverage. The factor is a finite-cluster correction; it is not a correction for non-random sampling or confounding.

## Contrasts and joint tests

For coefficient contrast vector c:

$$\theta=c^\top\widehat\beta,\quad s_\theta=\sqrt{c^\top Vc},\quad \mathrm{CI}_{\mathrm{PR}}=\exp(\theta\pm1.959964s_\theta).$$

Two-sided scalar p values use the standard normal survival function. If the contrast variance is non-positive or non-finite, inference is withheld, not assigned a zero standard error. For the selected group coefficient vector b and its covariance block V_g:

$$W=b^\top V_g^{-1}b\ \dot\sim\ \chi^2_q.$$

The joint test is withheld if the block is singular or not positive definite. Its nominal degrees of freedom q equal the number of jointly tested coefficients only when that block is valid. Implementation: `contrast_stats` and `global_wald_test`. BH q values are calculated separately over the three family-reference contrasts, six family pairs and 29 pattern-reference contrasts. Pointwise intervals are not simultaneous multiplicity-adjusted intervals.

## Adjusted probabilities

For each group g, replace the group indicator in every analytic row while retaining observed month/year, constructing X_i(g) from the fitted design information:

$$\widehat p_g=\frac{1}{N}\sum_{i=1}^N\exp\{x_i(g)^\top\widehat\beta\},\qquad d_g=\frac{1}{N}\sum_i\widehat\mu_i(g)x_i(g).$$

$$s_{\log p_g}=\frac{\sqrt{d_g^\top Vd_g}}{\widehat p_g},\qquad \mathrm{CI}_{p_g}=\widehat p_g\exp(\pm1.959964s_{\log p_g}).$$

Implementation: `marginal_mean_and_ci` and the fitted `design_info` in `fit_model`. These are empirical standardised means over sampled site-days, not equal-weight means over sites or all calendar days. The Poisson link does not mathematically constrain fitted means or interval bounds to one. The script checks and reports such violations; intervals are not clipped to conceal them. All accepted primary and focused sensitivity fits in the delivered run have original-data fitted means and reported marginal intervals within [0,1]. The added site fixed-effects diagnostic does not, and is excluded from the publication figures.

Observed-proportion intervals use the same mean/gradient/covariance calculation from saturated unadjusted group models. Those point estimates are checked to equal the raw group proportions. They are not Wilson intervals assuming independent site-days.
