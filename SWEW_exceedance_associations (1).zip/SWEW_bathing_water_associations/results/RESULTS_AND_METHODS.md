# Bathing water exceedance associations

This package reruns the supplied association analysis on the supplied consolidated workbook. The primary unit is the site-day; the original individual-sample unit is retained as a sensitivity analysis.

## Cohort verified from the supplied files

The Records sheet contains 35,672 records. Restricting to May to September 2012 to 2024 excludes 51 records. The 35,621 retained records include 31 missing IE results and 0 indeterminate censored results. There are 35,590 evaluable samples and 35,518 evaluable site-days from 194 supplied site identities, with 3,727 site-day exceedances (10.5%).

Of the evaluable site-days, 19 contain both measured and missing results. The primary outcome uses the measured samples; a complete-result-day sensitivity excludes these days. No missing IE value is imputed as a negative result. The supplied site identities are used unchanged; their legal designation histories are not independently verified.

## Methods suitable for manuscript adaptation

Intestinal enterococci exceedance was defined as a reported concentration ≥63 CFU 100 mL⁻¹. Censored values were classified only where their reported bound established exceedance or non-exceedance. Within each supplied bathing-water identity and sampling date, the outcome was one if any evaluable sample exceeded the threshold and zero if all evaluable samples were below it. Dates without an evaluable result were excluded. The fixed rainfall-family mapping was recovered unchanged from the earlier audited rainfall-family package, independently of these microbiological outcomes.

Separate modified Poisson regressions with a log link related the binary outcome to the four rainfall families and the 30 weather patterns, adjusting for categorical month and year. The reference levels were settled anticyclonic conditions and WP25, respectively. WP25 is a retained coding reference within that family, rather than a demonstrated optimum or a uniquely representative anticyclonic pattern. Exponentiated coefficients describe exceedance probability ratios. Two-way sandwich covariance was calculated by site and sampling date with component-specific finite-cluster corrections. Joint Wald tests used the same covariance; invalid or singular test covariance was flagged rather than repaired silently. Marginal probabilities were standardised to the empirical month/year distribution of the analytic site-days. Confidence intervals were calculated by the delta method on the log mean scale, without clipping. Observed-proportion uncertainty used unadjusted saturated Poisson models with the same two-way covariance, rather than independence-based binomial intervals. Scalar tests used asymptotic normal inference and joint Wald tests used chi-squared inference. Benjamini–Hochberg adjustments were reported separately for the three family-reference contrasts, six family pairs and 29 WP25 contrasts. All confidence intervals are pointwise 95% intervals, not simultaneous intervals.

Sensitivity analyses retained the original individual-sample unit, restricted to records coded MS and excluded partly missing site-days. The MS restriction is based on the supplied purpose code; no unverified interpretation of other codes was imposed. An additional site fixed-effects Poisson fit was retained as a diagnostic only, excluding sites without outcome variation. In the supplied run it produced fitted means above one and an indefinite full two-way covariance matrix. It is not used in the publication sensitivity figure and must not be cited as validation of a site-adjusted probability model. Its positive family-effect covariance block does not resolve these full-model diagnostic failures.

## Primary family results

| Family | Site-days | Exceedances | Adjusted probability | Ratio versus settled (95% CI) | Raw p | BH q |
|---|---:|---:|---:|---|---:|---:|
| Cyclonic Atlantic (frontal) | 14,263 | 2,023 | 14.13% (12.50%, 15.96%) | 2.052 (1.649, 2.552) | 1.099e-10 | 3.298e-10 |
| Showery maritime / unsettled | 6,770 | 681 | 9.49% (8.03%, 11.20%) | 1.377 (1.114, 1.703) | 0.003149 | 0.004723 |
| Convective extremes | 11,769 | 852 | 7.38% (6.19%, 8.80%) | 1.072 (0.869, 1.322) | 0.5144 | 0.5144 |
| Settled anticyclonic quiet | 2,716 | 171 | 6.89% (5.40%, 8.78%) | 1.00 (reference) | — | — |

Family global test: χ²(3) = 94.78; p = 2.056e-20; status: ok.

## Material limitations and verification boundaries

* These are retrospective associations in sampled site-days. They do not estimate prospective forecast skill, issued advisories, illness prevention, or contamination duration.
* The main model adjusts for month and year, not rainfall, other meteorology or site baseline differences. Site clustering changes uncertainty but does not adjust for between-site confounding. The separate site fixed-effects diagnostic failed probability-bound and full-covariance checks and is not presented as confirming the main model. Claims must remain descriptive associations.
* Site clustering allows within-site dependence and date clustering allows dependence across sites sampled on the same date. Dependence between different sites on different dates during prolonged weather episodes is not fully captured.
* Monitoring is uneven across years, sites and purposes. Complete-case results concern measured samples; missingness and unsampled days cannot be resolved from these inputs.
* The ANY rule makes the primary unit one site-day, but days with more sampling opportunities have more chances to record an exceedance. Multiple-sample days and sample-level sensitivity are exported.
* Reported coordinates are checked against the inclusive 49–52°N, 6–2°W box. Designation histories, individual coordinate accuracy and upstream workbook selection are not independently re-audited here. The supplied workbook is preserved in full, including its exclusion and provenance sheets.
* The fixed family mapping is an external, previously reviewed input here. This association code does not independently establish rainfall mechanisms or validate the synoptic descriptors.
* The adopted threshold is a study definition here. This package does not independently verify its current operational or regulatory use.
* The original study manuscript and updated prediction/storyline outputs are not supplied in this request. All downstream analyses and manuscript numbers affected by the cohort change must be updated separately.
* Reproducibility of the supplied analysis does not establish correctness of the original laboratory measurements or of pre-selection of records.

## Diagnostic flags

* primary_family: n=35,518; converged=True; covariance indefinite=False; fitted means >1: 0; marginal interval upper bounds >1: 0; invalid ratio variances: 0; global test: ok.
* primary_weather_patterns: n=35,518; converged=True; covariance indefinite=False; fitted means >1: 0; marginal interval upper bounds >1: 0; invalid ratio variances: 0; global test: ok.
* observed_family: n=35,518; converged=True; covariance indefinite=False; fitted means >1: 0; marginal interval upper bounds >1: 0; invalid ratio variances: 0; global test: ok.
* observed_weather_patterns: n=35,518; converged=True; covariance indefinite=False; fitted means >1: 0; marginal interval upper bounds >1: 0; invalid ratio variances: 0; global test: ok.
* sensitivity_sample_level: n=35,590; converged=True; covariance indefinite=False; fitted means >1: 0; marginal interval upper bounds >1: 0; invalid ratio variances: 0; global test: ok.
* sensitivity_routine_MS: n=35,438; converged=True; covariance indefinite=False; fitted means >1: 0; marginal interval upper bounds >1: 0; invalid ratio variances: 0; global test: ok.
* sensitivity_complete_days: n=35,499; converged=True; covariance indefinite=False; fitted means >1: 0; marginal interval upper bounds >1: 0; invalid ratio variances: 0; global test: ok.
* diagnostic_site_FE: n=34,772; converged=True; covariance indefinite=True; fitted means >1: 39; marginal interval upper bounds >1: 0; invalid ratio variances: 0; global test: ok.

## Sources checked for methods

* Zou (2004), A modified Poisson regression approach to prospective studies with binary data. https://doi.org/10.1093/aje/kwh090
* statsmodels two-group covariance documentation (small-sample correction and covariance decomposition). https://www.statsmodels.org/v0.14.4/generated/statsmodels.stats.sandwich_covariance.cov_cluster_2groups.html
* The installed statsmodels score/Hessian implementation is cross-checked numerically against this script on every model.

## Files to use

* `tables/annual_cohort.csv` and `cohort_summary.json`: updated dataset counts.
* `models/primary_family/`: primary four-family estimates, pairwise and joint tests.
* `models/primary_weather_patterns/`: primary 30-pattern estimates and tests.
* `models/sensitivity_*/`: explicitly secondary checks; do not substitute selectively for primary results.
* `figures/`: 600 dpi PNG and vector PDF/SVG. Captions are in FIGURE_CAPTIONS.md.
* `figure_data/`: exact data used to generate each figure.
* `audit/` and `analysis_data/`: exclusions, provenance, merge checks and analysis rows.
