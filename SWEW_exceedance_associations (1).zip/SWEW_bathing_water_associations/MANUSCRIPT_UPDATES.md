# Manuscript updates for this analysis

The full manuscript was not supplied in this request. The following text and table describe this rerun and can replace the corresponding association-analysis reporting. Check section numbering and citations against the final paper. These updates do not validate or update predictive-model or storyline results.

## Microbiological observations

Microbiological observations were taken from the supplied consolidated bathing-water dataset for the 2012 to 2024 bathing seasons, restricted to May to September and the inclusive geographical domain 49–52°N, 6–2°W. The 35,621 retained sample records included 31 missing intestinal enterococci results, leaving 35,590 evaluable samples. After aggregation to one observation per supplied site identity and sampling date, the primary dataset comprised 35,518 site-day observations from 194 site identities, of which 3,727 (10.5%) contained an intestinal enterococci threshold exceedance (≥63 CFU 100 mL⁻¹). A site-day was classified as an exceedance when any evaluable sample reached this threshold; site-days without an evaluable result were excluded. Nineteen retained site-days contained both measured and missing results and were assessed separately in a complete-result sensitivity analysis. The number of site identities represents coverage across the study period, rather than the number sampled in every year.

## Updated dataset table

| Dataset characteristic | Value |
|---|---:|
| Study period | 2012 to 2024, May to September |
| Supplied site identities represented across the study | 194 |
| Retained in-season sample records | 35,621 |
| Sample records with missing IE | 31 |
| Evaluable individual samples | 35,590 |
| Evaluable site-day observations, primary unit | 35,518 |
| Site-day exceedances, IE ≥63 CFU 100 mL⁻¹ | 3,727 |
| Overall site-day exceedance proportion | 10.5% |
| Distinct calendar dates with evaluable samples | 1,616 |
| Median annual site-day observations | 2,630 |
| Annual site-day observations, range | 489 (2020) to 3,489 (2013) |
| Annual site-day exceedance proportion, range | 7.8% (2013) to 19.6% (2020) |
| Retained partly missing site-days | 19 |

IE denotes intestinal enterococci. All counts concern the supplied selected workbook and this association analysis. The mean or median number of observations per year is not the number of independent weather events. Site identity and designation histories have not been independently verified in this rerun. The low count in 2020 is established from the records; its cause has not been established here.

## Family results

Cyclonic Atlantic conditions had the highest adjusted exceedance probability among the four prescribed families, followed by showery maritime conditions. In the month/year-adjusted model, the corresponding probabilities were 14.1%, 9.5%, 7.4%, 6.9% for cyclonic Atlantic, showery maritime, convective extremes and settled anticyclonic conditions, respectively. Compared with settled conditions, the probability ratio was 2.05 (95% CI 1.65 to 2.55) for cyclonic atlantic (frontal); 1.38 (95% CI 1.11 to 1.70) for showery maritime / unsettled; 1.07 (95% CI 0.87 to 1.32) for convective extremes. Cyclonic and showery contrasts remained statistically significant after BH adjustment across the three reference comparisons; the convective contrast did not. The sample-level, MS-only and complete-result checks gave similar estimates. These comparisons establish associations in sampled site-days and do not demonstrate causal effects, forecast performance or actual warning decisions.

## Brief limitations

The primary association models adjusted for month and year, rather than rainfall, other meteorological drivers or site baseline differences. Site/date clustering addressed uncertainty from repeated sites and shared sampling dates but did not remove confounding, non-random sampling or dependence between different sites on different dates. Missing and unsampled outcomes were not reconstructed. A separate site fixed-effects Poisson diagnostic produced fitted means above one and an indefinite full covariance matrix; it was not accepted as validation of a site-adjusted probability model or included in publication figures.

## Mandatory consistency changes

1. Replace previous cohort counts throughout the abstract, methods, results, tables, captions and supplement. Keep individual samples, site-days and calendar days distinct.
2. Update family and weather-pattern estimates from the new result tables. Main-model adjustment is month/year only. Do not describe the association model as adjusted for rainfall or site differences.
3. Update the covariance and interval methods: finite-cluster corrections, clustered observed-proportion uncertainty, log-mean marginal intervals and separately defined BH comparisons are now explicit. These are substantive inferential changes.
4. Keep the previously audited family membership and its rainfall-diagnostic summaries separate from this cohort. The full weather calendar contains 1,989 May–September days; the earlier radar histogram grouping used 1,969 available dates. Neither equals 35,518 site-days. This package's `family_sampling_coverage.csv` explains the denominators.
5. Present WP25 as the retained reference category, rather than a proven stable or optimal baseline. It does not change the model's fitted values when only the reference coding changes.
6. Update and verify the downstream prediction, lag and storyline applications using the corrected cohort where they depend on microbiological model fitting. This package has not performed those analyses.
