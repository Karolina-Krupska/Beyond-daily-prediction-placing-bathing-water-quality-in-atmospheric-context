# SWEW bathing water exceedance associations

Revised analysis of intestinal enterococci exceedances in the supplied bathing-water workbook for May to September 2012 to 2024. The original modified Poisson approach, fixed family mapping, month/year adjustment and site/date clustering are retained. The primary unit is now explicitly one site-day, matching the manuscript's stated unit. This changes the estimand from an individual-sample association to an association in sampled site-days. The original sample-level analysis is provided as a secondary sensitivity check.

## Run

Use Python 3.12. From this folder:

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s code -v
python code/bathing_water_exceedance_associations.py
python code/verify_results.py
```

On Windows, `py -3.12` can replace `python`. No absolute Windows paths need editing. Data paths resolve relative to the code, so the script can also be launched from another working directory. Inputs and the output folder can be overridden with `--bw`, `--regimes`, `--families` and `--output`. Use a new output folder for a modified specification. The optional `--skip-site-diagnostic` omits the slower site fixed-effects diagnostic and is recorded in run metadata. The delivered results include that diagnostic separately from the accepted sensitivity results.

The pipeline has no random resampling. Floating-point precision and SVG metadata may differ slightly across platforms. CSV tables retain more precision than figures; round only for reporting.

## Contents

* `code/`: revised analysis, scientific boundary tests and result reconciliation.
* `data/input/`: the two supplied datasets, copied byte-for-byte. The Excel workbook includes its original site register, excluded records and selection notes.
* `data/derived/`: the previous audited family assignments recovered unchanged from the earlier rainfall-family package. Provenance and hashes are recorded. Family membership was not selected using the new microbiological outcomes.
* `archive/`: the supplied original Python script, unchanged, for comparison. It retains its old local paths and is not the runnable entry point.
* `results/analysis_data/`: primary site-day data and sample-level and MS-only secondary datasets.
* `results/audit/`: explicit exclusions, missing results, repeated records, source rows, family mapping and study calendar.
* `results/models/`: coefficients, cluster covariance, marginal probabilities, probability ratios, pairwise tests, global tests and diagnostics for each fitted model.
* `results/tables/`: annual and site summaries, model diagnostics and validation results.
* `results/figures/`: 600 dpi PNG plus vector PDF and SVG.
* `results/figure_data/`: exact numeric inputs to the figures.
* `results/RESULTS_AND_METHODS.md`: results, copy-ready methods and material limitations.
* `FIGURE_CAPTIONS.md`: captions and uncertainty definitions. Figure numbers are provisional and must match the final manuscript.
* `CHANGELOG.md`: every substantive departure from the supplied script.
* `MANIFEST_SHA256.csv`: package file integrity hashes.

All output tables are CSV files that can be opened in Excel. The source workbook is preserved rather than rewritten. No forecasting, lag, radar processing or storyline model has been run by this package.

## Combined family figure

`results/figures/Figure_family_adjusted_combined` provides the supplied reference layout with updated primary estimates: panel a shows adjusted IE exceedance probabilities and panel b shows adjusted probability ratios versus the whole settled family, with site-day counts and pointwise 95% intervals. It is an alternative combined presentation of the adjusted results in Figures 1 and 2, rather than additional independent evidence. Choose the appropriate layout for the manuscript and assign its final figure number.

The full analysis automatically generates this figure. To regenerate only the combined figure from the existing results, without refitting models, run:

```bash
python code/plot_family_combined.py
```

PNG (600 dpi), vector PDF and SVG are saved in `results/figures/`, with exact source values in `results/figure_data/Figure_family_adjusted_combined.csv`. The caption is in `FIGURE_CAPTIONS.md`.

## Interpretation

The outcome is an observed threshold exceedance in a sampled site-day, not an actual issued advisory or an observed illness. Ratios are conditional on the reported adjustment set. The main model adjusts for month and year; clustering changes uncertainty, not confounding control. Sensitivity results must be reported alongside the primary results where they materially change interpretation. The unchanged reference WP25 is a coding choice; it does not prove that WP25 is the most stable or representative settled pattern.

The added `models/diagnostic_site_FE/` Poisson fit produced 39 fitted means above one and an indefinite full covariance matrix in the delivered run. It is retained transparently as a diagnostic, not an accepted probability-model result, and is excluded from the publication figures. The main models and the three focused sensitivity analyses do not have these failures. The main estimates must still be described as month/year-adjusted associations, without asserting control for site baseline differences.

The coordinate bounds and supplied stable site IDs are checked, but site designation histories, coordinate accuracy, laboratory results and upstream selection cannot be independently established from the supplied files. The routine-only check uses the supplied `MS` code. Do not interpret the included archive or the curated input workbook as an independent verification of those upstream decisions.

## Publication and reuse

Source data and the supplied script are included for the author's requested reproducibility package. Third-party data redistribution permissions and the code licence have not been established here. Check the Environment Agency and Met Office source terms before public upload and add the author's chosen licence; this package does not invent a licence grant. No journal acceptance or compliance is guaranteed.

The revised cohort affects downstream analyses and manuscript numbers. This package updates only the supplied association analysis; it does not validate the remainder of the paper. Use the checked results, not numbers from earlier cohort versions.
