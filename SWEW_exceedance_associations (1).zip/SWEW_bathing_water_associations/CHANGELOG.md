# Changes from the supplied script

## Added combined figure layout

Added `plot_family_combined` and the standalone `code/plot_family_combined.py` entry point. The reference-style two-panel layout uses the existing primary family estimates, confidence intervals and site-day counts. It exports 600 dpi PNG, vector PDF/SVG and exact plotting data. The full analysis also calls this function automatically. The figure uses exceedance terminology and identifies the whole settled family as reference. Model fitting, source data and saved statistical results are unchanged by this plotting addition.

## Retained

* Binary intestinal enterococci threshold ≥63 CFU 100 mL⁻¹.
* Existing four-family mapping, separately defined from microbiological outcomes.
* Modified Poisson model with a log link and categorical month/year adjustment.
* Family reference settled anticyclonic quiet; individual pattern reference WP25.
* Score-based site/date two-way cluster sandwich, marginal standardisation, ratios, joint Wald tests and six family pairwise comparisons.
* Numeric estimates are recomputed using the supplied new workbook. No results from the old cohort are reused.

## Necessary correctness changes

1. Read the new consolidated workbook's `Records` sheet instead of four unavailable historical workbooks. Use its supplied stable `site_id`, not a replacement based on sample-point labels. Verify the inclusive coordinate domain, dates and required fields. No new sites are created.
2. Missing IE results are no longer converted to zero outcomes. Censored results are classified from their reported bounds, without half-limit substitution. Any threshold-crossing censor limit is labelled indeterminate and excluded; unrecognised/invalid values fail explicitly.
3. Primary analysis aggregates to one site-day, taking ANY exceedance among evaluable samples. This aligns the code with the manuscript's stated unit and changes the scientific estimand. Sample-level models are retained as sensitivity analyses. Days with no evaluable IE result are excluded; partially observed days and alternative complete-day results are exported.
4. Enforce unique calendar dates and explicit one-to-one WP-to-family membership. Validate merge cardinality and fail on unmatched dates instead of silently deleting records. The old implicit 30-row mapping fallback and silent duplicate-row removal are removed.
5. Use the fitted Patsy design information for counterfactual marginal standardisation. Validate full model matrix rank, convergence and exact sample retention.
6. Retain the original two-way sandwich decomposition and add explicit component-specific finite-cluster corrections. Use the inverse negative GLM Hessian as bread, cross-check against statsmodels on every fit, and export covariance matrices. These changes can alter confidence intervals and p-values, rather than only labels.
7. Do not turn negative variances into zero or use a pseudoinverse to present a full-df Wald test for an invalid covariance. Invalid scalar inference or singular/indefinite joint-test blocks are flagged and withheld. Full covariance eigenvalues are exported, including any nuisance-parameter indefiniteness.
8. Replace independence-based Wilson uncertainty for observed proportions with site/date-clustered saturated-model uncertainty. Point estimates remain observed proportions. Intervals can differ substantially because sites share weather on the same dates.
9. Use log-mean delta-method marginal intervals without clipping to [0,1]. Export fitted means and any interval bounds above one; do not conceal a Poisson probability-bound issue. All intervals are pointwise 95% intervals, not simultaneous intervals.
10. Add finite-p-value-safe BH correction and use survival functions for tail probabilities. Report raw p and BH q, with separately identified testing families. Remove stars that could imply uncorrected significance or simultaneous coverage.

## Focused robustness checks

* Original individual-sample unit, with missing outcomes corrected.
* Site-days based only on records with purpose code MS.
* Site-days without any missing/indeterminate IE record.

An additional site fixed-effects Poisson diagnostic is kept separately and flagged: it produced fitted values above one and an indefinite full covariance matrix. Sites with no within-site outcome variation are listed and excluded from this diagnostic. Its estimates are not used as an accepted robustness check or shown in publication figures. This does not repair or eliminate potential site-level confounding in the main month/year-adjusted models.

## Reporting and reproducibility

Use exceedance terminology instead of actual advice-against-bathing outcomes. Add explicit cohort reconciliation, annual/site coverage, source-row provenance, purposeful missing-data audits, complete coefficients/covariance, fixed environment versions, unit and result tests, figure source data, captions and high-resolution/vector exports. Preserve original script and input files byte-for-byte. All figure numbering is provisional.

No new rainfall, hydrometeorological, lag or storyline predictors are invented. No claimed prospective performance is inferred from these association models. Legal designation histories and upstream sampling selection remain author-verification matters.
