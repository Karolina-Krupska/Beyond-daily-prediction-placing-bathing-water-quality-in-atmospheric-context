SWEW May–Sep Storylines (NOQC) – Audit Trail

INPUT
  C:\Users\earth\OneDrive - University of Reading\Python codes objective 2\Beyond_rainfall_triggers\Rainfall fingerprints\SWEW histogram stats by regime - NOQC\SWEW_MaySep_by_regime_NOQC_stats.xlsx

FILTER
  region = SWEW
  months = [5, 6, 7, 8, 9]

PER-REGIME METRICS (from daily_metrics_filtered)
  depth_p50_mm         = median(daily_depth_mm)
  depth_p90_mm         = P90(daily_depth_mm)
  tail_q95_p90_mmph    = P90(q95_mmph)
  wf_p50               = median(wet_fraction)

THRESHOLDS (quantiles across the 30 regimes)
FINAL 4-GROUP STORYLINES (MANUSCRIPT)
  group_final4 is assigned directly from WP (1–30) using REGIME_TO_GROUP_4_FINAL.
  This reflects expert-reviewed adjustments (WP16 -> Convective extremes; WP28 -> Cyclonic Atlantic (frontal)).
  For transparency, rule-based outputs are also saved: group_rule6 and group_rule4.

  wf_high      = Q80(wf_p50)
  wf_low       = Q40(wf_p50)
  tail_high    = Q80(tail_q95_p90_mmph)
  tail_low     = Q40(tail_q95_p90_mmph)
  depth_high   = Q60(depth_p90_mm)
  depth_vhigh  = Q80(depth_p90_mm)
  depth_medlow = Q40(depth_p50_mm)

AUDIT WORKBOOK
  C:\Users\earth\OneDrive - University of Reading\Python codes objective 2\Beyond_rainfall_triggers\Rainfall fingerprints\SWEW histogram stats by regime - NOQC\storylines_swew_maysep_noqc_audit 1\AUDIT_storylines.xlsx

