# SWEW rainfall fingerprints and weather-pattern families

This package contains the supplied May–September 2012–2024 SWEW rainfall summaries,
the final 30-to-four weather-pattern family mapping, its diagnostic audit, and
portable code. The supplied result files are preserved. No bathing-water models
or seasonal storyline simulations were rerun or added.

## Start here

- `code/`: portable family-mapping script, plotting from stored summaries, and verification.
- `data_input/`: the supplied rainfall-statistics workbook and its prepared daily CSV.
- `results/family_mapping/`: the supplied CSV, JSON and Excel results, plus clearly labelled publication extracts.
- `results/figures/`: 30 rainfall-summary figures, each as a 600 dpi PNG, a vector PDF and a data CSV.
- `results/verification/`: arithmetic and consistency checks against supplied results.
- `docs/`: metric definitions, version selection, changes, captions and file provenance.
- `originals/`: all three supplied scripts and the original README, unchanged.

## Run

Use Python 3.10 or newer. From the unzipped package directory:

```bash
python -m pip install -r requirements.txt
python code/01_weather_pattern_family_mapping.py --csv-only
python code/02_plot_saved_rainfall_summaries.py
python code/04_export_publication_tables.py
python code/03_verify_results.py --package . --output results/verification/verification_report.json
```

The family script defaults to the included workbook and writes a separate
`results/reproduced_family_mapping/` directory, leaving the supplied results intact.
Omit `--csv-only` to also generate the original Excel audit exports. Input and
output paths can be overridden with `--input` and `--output`. Plotting uses only
the stored percentile tables; it does not reconstruct daily histograms.
Script 04 creates the three explicitly labelled publication CSV views from the
saved audit, preserving its classifications and numbers.
The environment actually used for the package checks is recorded in
`docs/environment_tested.json`; the unpinned requirements list names dependencies,
not a claim that every future release is compatible.

## Which version to use

Use `code/01_weather_pattern_family_mapping.py` for the publication workflow.
The supplied `weather_pattern_family_mapping_audit.py` and
`Rev_Audit_SWEW_MaySep_storyline_WP1_30_FINALmapping.py` have the same executable
logic. Their filenames do not establish a different scientific version or an
earlier/later execution date. The portable copy preserves their calculations
and final membership while clarifying paths, guards and documentation.

The manuscript family is **`group_final4`**. The legacy `group` column is a
six-group diagnostic classification. The legacy `reason` column explains that
diagnostic rule, not the final family. Final families differ from the collapsed
rule groups for **WP16, WP19 and WP28**. No new expert justification was invented.
`publication_family_mapping.csv` labels these fields explicitly.

## What is reproducible from this ZIP

The family summaries, seven quantile thresholds, diagnostic flags, final
membership and saved-percentile figures can be checked from the included
processed inputs. There are **1,969 available histogram dates**, not all 1,989
possible May–September calendar dates. The observed-date family totals are
777 cyclonic, 400 showery, 652 convective and 140 settled.

Rebuilding the upstream rainfall workbook from original observations requires
the **complete daily histogram archive and the original classification calendar**.
These inputs were not in this supplied batch. The upstream histogram script is
therefore retained under `originals/`, with that limitation stated explicitly;
this package is not an end-to-end raw-radar reconstruction.

`NOQC` means no additional study-specific coverage/outlier exclusions in these
summaries; it does not mean no Met Office producer processing. The name
`daily_metrics_filtered.csv` refers to SWEW/season selection, not extra rainfall QC.
Read `docs/METHODS_AND_LIMITS.md` before describing physical mechanisms, extremes,
or the origin of the final families. The package verifies internal agreement;
it does not independently validate rainfall magnitudes or source WP dates.
