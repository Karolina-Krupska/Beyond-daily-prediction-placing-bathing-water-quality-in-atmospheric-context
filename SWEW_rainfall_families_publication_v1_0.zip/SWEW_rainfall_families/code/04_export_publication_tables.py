#!/usr/bin/env python3
"""Export clearly labelled views of the supplied final family assignments.

No classifications are changed. The legacy reason field is labelled reason_rule6
to distinguish it from the final lookup. These are derived reporting tables.
"""
from pathlib import Path
import argparse
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / 'results' / 'family_mapping'

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-dir', type=Path, default=DEFAULT)
    parser.add_argument('--output', type=Path, default=DEFAULT)
    args = parser.parse_args()
    audit = args.input_dir / 'AUDIT_storylines.xlsx'
    if audit.is_file():
        src = pd.read_excel(audit, sheet_name='storyline_assignments')
    else:
        src = pd.read_csv(args.input_dir / 'storyline_assignments.csv')
    if len(src) != 30 or set(src.regime) != set(range(1,31)) or src.regime.duplicated().any():
        raise ValueError('Expected exactly one assignment for each WP1–30.')
    pub = src.rename(columns={'regime':'weather_pattern','reason':'reason_rule6'}).copy()
    pub['final_differs_from_rule4'] = pub.group_final4.ne(pub.group_rule4)
    pub = pub[['weather_pattern','n_days','group_final4','group_rule4','group_rule6','final_differs_from_rule4',
               'depth_p50_mm','depth_p90_mm','tail_q95_p90_mmph','wf_p50','synoptic_label','reason_rule6']]
    args.output.mkdir(parents=True, exist_ok=True)
    pub.to_csv(args.output/'publication_family_mapping.csv',index=False)
    pub[pub.final_differs_from_rule4].to_csv(args.output/'final_mapping_overrides.csv',index=False)
    summary = pub.groupby('group_final4',sort=False).agg(
        n_weather_patterns=('weather_pattern','size'), n_histogram_dates=('n_days','sum')).reset_index()
    summary.to_csv(args.output/'family_summary_observed_dates.csv',index=False)
    print(f'Publication tables written to {args.output}')

if __name__=='__main__':
    main()
