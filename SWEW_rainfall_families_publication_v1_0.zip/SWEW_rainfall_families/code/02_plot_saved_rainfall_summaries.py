#!/usr/bin/env python3
"""Redraw supplied SWEW histogram-count summaries without recalculating rainfall.

The percentile curves describe variation across days in each intensity-bin count.
They are not quantiles of rainfall intensity. Zero-valued summaries are masked on
the logarithmic count axis; no replacement count is introduced.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_INPUT = PACKAGE_ROOT / "data_input" / "SWEW_MaySep_by_regime_NOQC_stats.xlsx"
DEFAULT_OUTPUT = PACKAGE_ROOT / "results" / "figures"
BINS = np.array([0, 0.0625, 0.125, 0.25, 0.5, 1, 2, 4, 8, 16, 32, 64, 128, 256], dtype=float)
PERCENTILES = ["P10", "P25", "P50", "P75", "P90", "P95", "P99", "P100"]
SHEET = "MaySep_percentiles_wide"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_stored_summaries(path: Path) -> pd.DataFrame:
    frame = pd.read_excel(path, sheet_name=SHEET, engine="openpyxl")
    required = {"region", "regime", "n_days", "bin_lower_mmph", *PERCENTILES}
    missing = sorted(required.difference(frame.columns))
    if missing:
        raise ValueError(f"Missing columns in {SHEET}: {missing}")
    if len(frame) != 30 * len(BINS):
        raise ValueError(f"Expected 420 rows (30 weather patterns x 14 bins); found {len(frame)}")
    if frame[list(required)].isna().any().any():
        raise ValueError("Required stored-summary fields contain missing values")
    if not frame["region"].astype(str).eq("SWEW").all():
        raise ValueError("The supplied summary must contain SWEW only")
    for col in ["regime", "n_days", "bin_lower_mmph", *PERCENTILES]:
        numeric = pd.to_numeric(frame[col], errors="raise")
        if not np.isfinite(numeric.to_numpy(dtype=float)).all():
            raise ValueError(f"Non-finite values in {col}")
        frame[col] = numeric
    if not np.equal(frame["regime"] % 1, 0).all():
        raise ValueError("Weather-pattern identifiers must be integers")
    if set(frame["regime"]) != set(range(1, 31)):
        raise ValueError("Expected weather-pattern identifiers 1 through 30 exactly")
    if frame.duplicated(["region", "regime", "bin_lower_mmph"]).any():
        raise ValueError("Duplicate weather-pattern/bin rows in supplied summary")
    if (frame[PERCENTILES].to_numpy(dtype=float) < 0).any():
        raise ValueError("Stored count-percentiles must be non-negative")
    if (np.diff(frame[PERCENTILES].to_numpy(dtype=float), axis=1) < -1e-10).any():
        raise ValueError("Stored count-percentiles are not ordered from P10 to P100")
    for regime, group in frame.groupby("regime", sort=True):
        sorted_bins = group.sort_values("bin_lower_mmph")["bin_lower_mmph"].to_numpy(dtype=float)
        if len(group) != len(BINS) or not np.array_equal(sorted_bins, BINS):
            raise ValueError(f"WP {int(regime):02d} does not contain the 14 expected bins")
        n = group["n_days"]
        if n.nunique() != 1 or not np.equal(n % 1, 0).all() or not n.gt(0).all():
            raise ValueError(f"WP {int(regime):02d} has inconsistent or invalid n_days")
    return frame.sort_values(["regime", "bin_lower_mmph"]).reset_index(drop=True)


def positive_only(values: np.ndarray) -> np.ma.MaskedArray:
    return np.ma.masked_less_equal(np.asarray(values, dtype=float), 0)


def draw_one(group: pd.DataFrame, output: Path, dpi: int) -> dict:
    regime = int(group["regime"].iloc[0])
    n_days = int(group["n_days"].iloc[0])
    base = output / f"SWEW_WP{regime:02d}_MaySep_count_percentiles"
    x = np.arange(len(BINS))
    p = {name: positive_only(group[name].to_numpy(dtype=float)) for name in PERCENTILES}
    fig, ax = plt.subplots(figsize=(9.4, 5.3), layout="constrained")
    ax.fill_between(x, p["P10"], p["P90"], color="#DDE8EF", linewidth=0, label="P10–P90")
    ax.fill_between(x, p["P25"], p["P75"], color="#A8C3D3", linewidth=0, label="P25–P75")
    ax.plot(x, p["P50"], color="#183E52", linewidth=1.9, marker="o", markersize=2.8, label="Median (P50)")
    ax.plot(x, p["P95"], color="#B45F06", linewidth=1.3, linestyle="--", marker="o", markersize=2.8, label="P95")
    ax.plot(x, p["P99"], color="#297E7E", linewidth=1.3, linestyle=":", marker="o", markersize=2.8, label="P99")
    ax.plot(x, p["P100"], color="#555555", linewidth=1.2, linestyle="-.", marker="o", markersize=2.8, label="Maximum (P100)")
    ax.set_yscale("log")
    ax.set_xticks(x, [f"{b:g}" for b in BINS])
    ax.set_xlim(-0.2, len(BINS) - 0.8)
    ax.set_xlabel("Rainfall intensity bin lower edge (mm h⁻¹)", labelpad=8)
    ax.set_ylabel("Pixel-observation count\n(percentiles across days)", labelpad=8)
    ax.set_title(f"SWEW · weather pattern {regime:02d} · May–September", loc="left", pad=16, fontsize=12)
    ax.text(1, 1.015, f"n = {n_days} days", transform=ax.transAxes, ha="right", va="bottom", fontsize=9)
    ax.grid(axis="y", which="major", color="#DDDDDD", linewidth=0.6)
    ax.set_axisbelow(True)
    ax.spines[["top", "right"]].set_visible(False)
    ax.spines[["left", "bottom"]].set_color("#777777")
    ax.tick_params(axis="both", labelsize=9)
    ax.legend(frameon=False, ncol=2, fontsize=9, loc="upper right")
    fig.supxlabel("Zero-valued summaries omitted on the logarithmic axis; no values substituted.", fontsize=8, color="#444444")
    png = base.with_suffix(".png")
    pdf = base.with_suffix(".pdf")
    csv = base.with_suffix(".csv")
    fig.savefig(png, dpi=dpi, facecolor="white", metadata={"Description": "Redrawn from stored histogram-count summaries; not recalculated rainfall."})
    fig.savefig(pdf, facecolor="white", metadata={"Creator": Path(__file__).name, "CreationDate": None, "ModDate": None})
    plt.close(fig)
    # Preserve the workbook values. This is a sidecar of stored data, not a fit.
    group.to_csv(csv, index=False, float_format="%.17g")
    return {
        "weather_pattern": regime,
        "n_days": n_days,
        "files": [{"name": path.name, "sha256": sha256(path)} for path in [png, pdf, csv]],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT, help="Supplied SWEW statistics workbook")
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT, help="Directory for PNG, PDF and CSV outputs")
    parser.add_argument("--dpi", type=int, default=600, help="PNG resolution (default: 600 dpi)")
    args = parser.parse_args()
    if args.dpi <= 0:
        parser.error("--dpi must be positive")
    frame = load_stored_summaries(args.input)
    args.output.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 10,
        "pdf.fonttype": 42,
        "svg.fonttype": "none",
        "axes.linewidth": 0.7,
    })
    plots = [draw_one(group, args.output, args.dpi) for _, group in frame.groupby("regime", sort=True)]
    manifest = {
        "operation": "redrawn_from_stored_summaries",
        "source_workbook": args.input.name,
        "source_sha256": sha256(args.input),
        "source_sheet": SHEET,
        "rainfall_recalculated": False,
        "source_values_modified": False,
        "figure_count": len(plots),
        "png_dpi": args.dpi,
        "region": "SWEW",
        "months": "May–September",
        "days_counted_once_per_weather_pattern": int(frame.groupby("regime")["n_days"].first().sum()),
        "x_axis": "Categorical positions labelled with the 14 rainfall-intensity bin lower edges in mm/h",
        "y_axis": "Percentiles across daily pixel-observation counts within each intensity bin; logarithmic count axis",
        "not_intensity_percentiles": True,
        "zero_display": "Zero-valued summaries are masked, not replaced by one or another count",
        "interpretation_limit": "Pooled pixel observations do not identify unique locations, scan times, spatial coverage or continuous event duration. This redraw does not independently validate rainfall estimates.",
        "figures": plots,
    }
    manifest_path = args.output / "figure_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"Redrawn {len(plots)} weather-pattern summaries as PNG, vector PDF and CSV in {args.output}")
    print(f"Manifest: {manifest_path}")


if __name__ == "__main__":
    main()
