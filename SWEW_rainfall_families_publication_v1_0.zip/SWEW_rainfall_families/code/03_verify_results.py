#!/usr/bin/env python3
"""Read-only reconciliation of the supplied SWEW rainfall-family results.

This checks saved data and summaries, not radar accuracy or the source weather-
pattern calendar. It does not fit models, generate storylines, or edit inputs.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd


EXPECTED_FAMILIES = {
    'Cyclonic Atlantic (frontal)': [1, 5, 7, 8, 11, 19, 21, 22, 24, 28, 29, 30],
    'Showery maritime / unsettled': [2, 4, 14, 15, 20, 26],
    'Convective extremes': [3, 6, 9, 10, 12, 16, 17, 18, 27],
    'Settled anticyclonic quiet': [13, 23, 25],
}
EXPECTED_GROUP_DAYS = {
    'Cyclonic Atlantic (frontal)': 777,
    'Showery maritime / unsettled': 400,
    'Convective extremes': 652,
    'Settled anticyclonic quiet': 140,
}
THRESHOLD_RULES = {
    'wf_high': ('wf_p50', .8),
    'wf_low': ('wf_p50', .4),
    'tail_high': ('tail_q95_p90_mmph', .8),
    'tail_low': ('tail_q95_p90_mmph', .4),
    'depth_high': ('depth_p90_mm', .6),
    'depth_vhigh': ('depth_p90_mm', .8),
    'depth_medlow': ('depth_p50_mm', .4),
}
EXACT_COLUMNS = {'regime', 'n_days', 'month', 'total_samples'}


def canonical_frame(frame: pd.DataFrame, keys: list[str]) -> pd.DataFrame:
    frame = frame.copy()
    if 'date' in frame.columns:
        frame['date'] = pd.to_datetime(frame['date'], errors='raise')
    return frame.sort_values(keys, kind='stable').reset_index(drop=True)


def run_checks(package: Path) -> dict:
    checks: list[dict] = []
    summary: dict = {}

    def add(name: str, passed: bool, detail=None):
        entry = {'check': name, 'passed': bool(passed)}
        if detail is not None:
            entry['detail'] = detail
        checks.append(entry)

    def same(name: str, left: pd.DataFrame, right: pd.DataFrame, keys: list[str]):
        if set(left.columns) != set(right.columns):
            add(name, False, {'left_columns': list(left.columns),
                              'right_columns': list(right.columns)})
            return
        left = canonical_frame(left, keys)
        right = canonical_frame(right, keys)[left.columns]
        if left.shape != right.shape:
            add(name, False, {'left_shape': list(left.shape),
                              'right_shape': list(right.shape)})
            return
        different = []
        maxima = {}
        for col in left.columns:
            l, r = left[col], right[col]
            if pd.api.types.is_numeric_dtype(l) and not pd.api.types.is_bool_dtype(l):
                lv = l.to_numpy(dtype=float)
                rv = r.to_numpy(dtype=float)
                tol = 0.0 if col in EXACT_COLUMNS else 1e-8
                okay = np.allclose(lv, rv, rtol=0, atol=tol, equal_nan=True)
                delta = np.abs(lv - rv)
                maxima[col] = float(np.nanmax(delta)) if np.isfinite(delta).any() else None
            else:
                okay = bool(((l == r) | (l.isna() & r.isna())).all())
            if not okay:
                different.append(col)
        add(name, not different, {'rows': len(left), 'different_columns': different,
                                  'maximum_absolute_numeric_differences': maxima})

    results = package / 'results' / 'family_mapping'
    source = package / 'data_input' / 'SWEW_MaySep_by_regime_NOQC_stats.xlsx'
    prepared = package / 'data_input' / 'daily_metrics_SWEW_MaySep_NOQC.csv'
    required = [source, prepared] + [results / n for n in [
        'daily_metrics_filtered.csv', 'regime_metrics_by_regime.csv',
        'regime_metrics_by_regime.xlsx', 'rule_flags_by_regime.csv',
        'storyline_assignments.csv', 'storyline_assignments.xlsx',
        'storyline_thresholds.csv', 'storyline_thresholds.json',
        'AUDIT_storylines.xlsx',
    ]]
    missing = [str(p.relative_to(package)) for p in required if not p.is_file()]
    add('Required supplied files present', not missing, {'missing_files': missing})
    if missing:
        return finish(package, checks, summary)

    try:
        daily = pd.read_csv(results / 'daily_metrics_filtered.csv', parse_dates=['date'])
        prepared_daily = pd.read_csv(prepared, parse_dates=['date'])
        metrics = pd.read_csv(results / 'regime_metrics_by_regime.csv')
        flags = pd.read_csv(results / 'rule_flags_by_regime.csv')
        assignments = pd.read_csv(results / 'storyline_assignments.csv')
        thresholds = pd.read_csv(results / 'storyline_thresholds.csv')
        threshold_json = json.loads((results / 'storyline_thresholds.json').read_text())
        original_daily = pd.read_excel(source, sheet_name='daily_metrics')
        audit = pd.ExcelFile(results / 'AUDIT_storylines.xlsx')

        same('NOQC workbook daily metrics equal supplied daily CSV',
             original_daily, daily, ['date', 'region'])
        same('Prepared daily input equals supplied daily result',
             prepared_daily, daily, ['date', 'region'])

        add('Daily region and dates match study window',
            daily['region'].eq('SWEW').all()
            and daily['date'].dt.year.between(2012, 2024).all()
            and daily['date'].dt.month.between(5, 9).all()
            and daily['month'].eq(daily['date'].dt.month).all())
        add('Daily records have unique dates, positive counts and complete metrics',
            len(daily) == 1969 and daily['date'].nunique() == 1969
            and daily['total_samples'].gt(0).all()
            and not daily.isna().any().any()
            and np.isfinite(daily.select_dtypes(include='number')).all().all())
        add('Daily WP values span integer codes 1 to 30',
            set(daily['regime']) == set(range(1, 31)))
        add('Daily depth equals 24 times mean rate', np.allclose(
            daily['daily_depth_mm'], 24 * daily['mean_rate_mmph'],
            rtol=0, atol=1e-10))

        full_calendar = pd.date_range('2012-01-01', '2024-12-31', freq='D')
        full_calendar = full_calendar[full_calendar.month.isin([5, 6, 7, 8, 9])]
        gaps = full_calendar.difference(pd.DatetimeIndex(daily['date']))
        add('Calendar has 1989 possible dates and 20 absent dates',
            len(full_calendar) == 1989 and len(gaps) == 20)
        summary['daily_cohort'] = {
            'region': 'SWEW', 'available_dates': len(daily),
            'possible_dates': len(full_calendar), 'absent_dates': len(gaps),
            'absent_date_list': [d.strftime('%Y-%m-%d') for d in gaps],
            'available_dates_by_year': {
                str(k): int(v) for k, v in daily.groupby(daily['date'].dt.year).size().items()
            },
        }

        recalculated = daily.groupby('regime').agg(
            n_days=('date', 'size'),
            depth_p50_mm=('daily_depth_mm', 'median'),
            depth_p90_mm=('daily_depth_mm', lambda x: x.quantile(.9)),
            tail_q95_p90_mmph=('q95_mmph', lambda x: x.quantile(.9)),
            wf_p50=('wet_fraction', 'median'),
        ).reset_index()
        same('Per-WP summaries reproduce from daily metrics',
             metrics, recalculated, ['regime'])
        same('Assignment metrics equal per-WP summary metrics',
             assignments[metrics.columns], metrics, ['regime'])
        add('Threshold names match the seven documented rules',
            set(thresholds['threshold_name']) == set(THRESHOLD_RULES)
            and set(threshold_json) == set(THRESHOLD_RULES)
            and len(thresholds) == 7)
        for name, (metric, quantile) in THRESHOLD_RULES.items():
            row = thresholds.loc[thresholds['threshold_name'].eq(name)]
            calculated = float(metrics[metric].quantile(quantile))
            okay = len(row) == 1 and row.iloc[0]['metric'] == metric
            okay = okay and np.isclose(float(row.iloc[0]['quantile']), quantile)
            okay = okay and np.isclose(float(row.iloc[0]['value']), calculated,
                                       rtol=0, atol=1e-10)
            okay = okay and np.isclose(float(threshold_json[name]), calculated,
                                       rtol=0, atol=1e-10)
            add('Threshold reproduces: ' + name, okay,
                {'metric': metric, 'quantile_across_WPs': quantile,
                 'recalculated_value': calculated})

        t = threshold_json
        recalculated_flags = pd.DataFrame({
            'regime': metrics['regime'],
            'wf_ge_high': metrics['wf_p50'] >= t['wf_high'],
            'wf_le_low': metrics['wf_p50'] <= t['wf_low'],
            'tail_ge_high': metrics['tail_q95_p90_mmph'] >= t['tail_high'],
            'tail_le_low': metrics['tail_q95_p90_mmph'] <= t['tail_low'],
            'depth90_ge_high': metrics['depth_p90_mm'] >= t['depth_high'],
            'depth90_ge_vhigh': metrics['depth_p90_mm'] >= t['depth_vhigh'],
            'depth50_le_medlow': metrics['depth_p50_mm'] <= t['depth_medlow'],
        })
        same('All rule flags reproduce', flags, recalculated_flags, ['regime'])

        actual_mapping = assignments.groupby('group_final4')['regime'].apply(
            lambda x: sorted(int(v) for v in x)).to_dict()
        add('Final mapping has the documented 12/6/9/3 membership',
            actual_mapping == EXPECTED_FAMILIES
            and not assignments['regime'].duplicated().any())
        override_wps = sorted(int(v) for v in assignments.loc[
            assignments['group_rule4'].ne(assignments['group_final4']), 'regime'])
        add('Final mapping differs from four-rule grouping for WPs 16,19,28',
            override_wps == [16, 19, 28], {'WP_codes': override_wps})
        days = assignments.groupby('group_final4')['n_days'].sum().to_dict()
        days = {k: int(v) for k, v in days.items()}
        add('Available-date family counts reproduce 777/400/652/140',
            days == EXPECTED_GROUP_DAYS, days)
        summary['final_family_mapping'] = actual_mapping
        summary['available_dates_by_final_family'] = days

        same('Standalone regime-summary workbook equals CSV', metrics,
             pd.read_excel(results / 'regime_metrics_by_regime.xlsx'), ['regime'])
        same('Standalone assignment workbook equals CSV within rounding', assignments,
             pd.read_excel(results / 'storyline_assignments.xlsx'), ['regime'])
        for sheet, frame, keys in [
            ('daily_metrics_filtered', daily, ['date', 'region']),
            ('regime_metrics', metrics, ['regime']),
            ('thresholds', thresholds, ['threshold_name']),
            ('rule_flags', flags, ['regime']),
            ('storyline_assignments', assignments, ['regime']),
        ]:
            same('AUDIT workbook sheet equals standalone output: ' + sheet,
                 frame, pd.read_excel(audit, sheet_name=sheet), keys)

        n_days = pd.read_excel(source, sheet_name='MaySep_days_by_regime')
        same('Upstream per-WP date counts equal daily-derived counts',
             n_days[['regime', 'n_days']], recalculated[['regime', 'n_days']], ['regime'])
        long = pd.read_excel(source, sheet_name='MaySep_percentiles_long')
        wide = pd.read_excel(source, sheet_name='MaySep_percentiles_wide')
        index = ['region', 'regime', 'n_days', 'bin_lower_mmph']
        pivot = long.pivot(index=index, columns='stat', values='value').reset_index()
        pivot.columns.name = None
        same('Upstream long and wide bin-count percentile tables agree',
             wide, pivot, ['regime', 'bin_lower_mmph'])
    except Exception as exc:
        add('Verification completed without an unexpected input/schema error', False,
            {'error_type': type(exc).__name__, 'message': str(exc)})

    return finish(package, checks, summary)


def finish(package: Path, checks: list[dict], summary: dict) -> dict:
    passed = all(c['passed'] for c in checks)
    return {
        'status': 'passed' if passed else 'failed',
        'package': str(package),
        'numeric_tolerance': 'Absolute 1e-8 for CSV/XLSX float comparisons; integer counts exact',
        'scope': 'Internal reconciliation of supplied outputs using saved values and simple arithmetic.',
        'limits': [
            'This does not independently validate radar rainfall estimates or individual extremes.',
            'The source daily WP calendar is not checked; raw radar histograms are not regenerated.',
            'The final family lookup is checked against its declared mapping, not independently validated.',
            'No models are fitted, significance tests run or synthetic storyline seasons generated.',
        ],
        'summary': summary,
        'checks_passed': sum(c['passed'] for c in checks),
        'checks_total': len(checks),
        'checks': checks,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package', type=Path,
                        default=Path(__file__).resolve().parents[1],
                        help='Package root containing data_input/ and results/.')
    parser.add_argument('--output', type=Path,
                        help='Optional JSON output path; otherwise print JSON to stdout.')
    args = parser.parse_args()
    result = run_checks(args.package.resolve())
    output = json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False) + '\n'
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(output, encoding='utf-8')
    else:
        sys.stdout.write(output)
    return 0 if result['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
