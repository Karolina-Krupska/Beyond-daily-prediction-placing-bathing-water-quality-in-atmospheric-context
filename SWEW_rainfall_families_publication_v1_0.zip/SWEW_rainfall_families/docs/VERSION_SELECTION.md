# Version selection

The two supplied family scripts are equivalent in executable logic after removal
of module descriptions. Neither is established as a later scientific algorithm.
The more descriptive filename weather_pattern_family_mapping_audit.py was used
as the source for the portable publication copy. All three supplied scripts are
retained byte-for-byte in originals/. Source timestamps were not used to infer
execution history. The rainfall-statistics script is an upstream step, not a
competing family-mapping version.
