# Publication package changes

- Retained all supplied scientific results and the final WP membership.
- Replaced absolute Windows paths in the active family script with package-relative defaults and CLI options.
- Added input guards for dates, month consistency, duplicate region-date keys, metric validity and all 30 WPs.
- Added CSV-only reproduction; supplied Excel workbooks remain unchanged.
- Documented all three final overrides: WP16, WP19 and WP28.
- Clarified that legacy reason refers to the diagnostic rule and group_final4 is the manuscript family.
- Replaced misleading wet-day and objective/no-hand-tuning descriptions in the active code; calculations are unchanged.
- Documented the fixed wf < 0.08 diagnostic-rule cutoff and the distinction between seasonal families and simulated sequences.
- Added plots from the existing stored percentile summaries, with zeros omitted on log axes rather than represented as positive counts.
- Added transparent missing-input notes, verification results, source hashes and a file manifest.
