# Rainfall diagnostics and weather pattern families

This package describes regional rainfall diagnostics and the assignment of the 30 weather patterns to four families. It does not generate synthetic seasonal weather sequences, fit bathing-water models or evaluate operational forecasts. The supplied files use “storyline” in several filenames, but those files contain weather-pattern family assignments.

## Scope and observations

The prepared input covers SWEW and May–September 2012–2024. It contains 1,969 observed daily histogram records, compared with 1,989 calendar days in that study window. Twenty calendar dates are unrepresented; the prepared tables alone do not establish why. These counts concern regional rainfall days, not bathing-water samples or site-days. The name `daily_metrics_filtered.csv` refers to filtering by region and season in this workflow, not additional rainfall quality-control exclusions.

Daily histograms pool contributing grid-pixel observations across the available radar scans. Histogram counts are therefore pixel–scan observations, not numbers of independent pixels, independent storms or independent rainfall measurements. The summaries lose the location and scan time of individual values. In particular, wet fraction is a pooled pixel–scan proportion; it is not an independently measured, instantaneous physical rainfall footprint.

## Metric definitions

| Quantity | Definition and interpretation |
|---|---|
| Histogram bins | Lower edges are 0, 0.0625, 0.125, 0.25, 0.5, 1, 2, 4, 8, 16, 32, 64, 128 and 256 mm/h. The last, open-ended bin is assigned a **pseudo upper edge of 512 mm/h** for the calculations. This is an assumption, not an observed maximum. |
| Mean rate and daily depth | Positive bins use logarithmic-mean representatives, `(b − a)/(ln(b) − ln(a))`, weighted by histogram counts. The first bin is represented by zero. `daily_depth_mm` is 24 times the resulting mean rate. It is a histogram-derived regional depth estimate, not a local gauge accumulation. |
| `wet_fraction` | Counts in bins whose lower edge is greater than zero, divided by total contributing counts. Values in the first bin do not contribute to the numerator. |
| `q95_mmph` | A wet-observation intensity quantile estimated from grouped bins. The code locates the bin containing the 95th percentile of wet counts and interpolates within that bin on a logarithmic intensity scale. It is an estimate, not an exact observed intensity. |
| Per-pattern summaries | `depth_p50_mm` and `depth_p90_mm` are the median and P90 of daily depth across **all available May–September days** assigned to a pattern. There is no wet-day depth filter. `tail_q95_p90_mmph` is P90 across that pattern’s daily `q95_mmph` estimates; `wf_p50` is the median daily wet fraction. |
| Plotted percentiles | P10–P100 curves are percentiles **across days of the count in each intensity bin**, conditional on weather pattern. They are not rainfall-intensity quantile curves. P100 is the maximum daily bin count, not maximum rainfall intensity. |

Depth estimates depend on the bin representatives, treatment of the first bin and assumed upper edge of the highest bin. Multiplication of the pooled mean rate by 24 hours also requires caution where contributing scan or pixel coverage is incomplete or uneven. The diagnostics do not independently validate individual extreme rainfall magnitudes.

## Rules and final mapping

Thresholds are calculated across the 30 per-pattern summaries. The quantile probabilities are prescribed choices: wet-fraction Q80 and Q40; intensity-tail Q80 and Q40; depth-P90 Q60 and Q80; and median-depth Q40. The exploratory rule scheme additionally uses the fixed `wf_p50 < 0.08` cutoff. Consequently, the procedure is reproducible but should not be described as a wholly automatic, objectively discovered classification.

Rules are evaluated in order, with the first matching rule retained: high wet fraction; settled conditions; low-extent strong-tail cases; very high depth with wet fraction below 0.08; remaining high-depth cases; then the showery default. The six exploratory labels are collapsed into `group_rule4`.

The manuscript family column, **`group_final4`**, is assigned separately by a fixed lookup for WP1–30. Relative to `group_rule4`, the supplied final mapping changes **WP16, WP19 and WP28**. The supplied `reason` column explains the exploratory rule-based classification, not the expert basis for those final adjustments. The package does not invent meteorological justifications for the adjustments. Family labels summarise regional rainfall diagnostics and the supplied synoptic interpretation; they do not independently prove the rainfall-generation mechanism of every event.

## Reproducibility and verification limits

The two supplied family-audit scripts have equivalent executable logic; their differences are descriptive text and a comment. Their filenames do not establish a scientifically newer algorithm. Original source and result files are preserved as supplied. Publication copies make portability, documentation and input-validation changes only; they retain the supplied metric definitions, thresholds, rule ordering and final mapping.

The family audit can be reproduced from the included prepared statistics workbook. A complete upstream reconstruction from the radar archive additionally requires the full daily histogram collection and the daily weather-pattern classification calendar. Those complete upstream inputs were not supplied in this batch. The package therefore does not establish end-to-end archive provenance, independently verify individual radar extremes or validate subsequent bathing-water predictions.
