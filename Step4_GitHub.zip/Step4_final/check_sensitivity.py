r"""Run kNN sensitivity and internal conditional driver hold-out checks.

py check_sensitivity.py "C:\full\path\to\Step4_timestamp"
"""
from pathlib import Path
import argparse,json,sys
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'code'))
from step4_core import resolve_inputs
from continuity_sensitivity import run_sensitivity
from validate_continuity import run_holdout
from plot_continuity import plot_checks
from year_uncertainty import run_uncertainty
from support_sensitivity import run_support
from audit_donor_reuse import run_reuse
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('run_folder',type=Path)
    p.add_argument('--inputs',type=Path,default=ROOT/'Step4_available_inputs')
    p.add_argument('--n-sims',type=int,default=5000);p.add_argument('--holdout-sims',type=int,default=500)
    a=p.parse_args();meta=json.loads((a.run_folder/'run_metadata.json').read_text())
    inputs=resolve_inputs(a.inputs)
    run_sensitivity(a.run_folder,inputs,n=a.n_sims,seed=meta['seed'])
    run_holdout(a.run_folder,inputs,n=a.holdout_sims,seed=meta['seed'])
    run_uncertainty(a.run_folder,n_boot=10000,seed=meta['seed'])
    run_support(a.run_folder,inputs,n=min(1000,a.n_sims))
    run_reuse(a.run_folder)
    plot_checks(a.run_folder)
