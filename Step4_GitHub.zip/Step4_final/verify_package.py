"""Verify all packaged files against the final SHA-256 inventory (read only)."""
from pathlib import Path
import csv,hashlib

ROOT=Path(__file__).resolve().parent
failed=[]
with (ROOT/'FILE_INVENTORY.csv').open(newline='',encoding='utf-8') as handle:
    records=list(csv.DictReader(handle))
for item in records:
    path=ROOT/item['relative_path']
    if not path.is_file():
        failed.append(item['relative_path']+': missing')
        continue
    digest=hashlib.sha256(path.read_bytes()).hexdigest()
    if path.stat().st_size!=int(item['bytes']) or digest!=item['sha256']:
        failed.append(item['relative_path']+': changed')
if failed:
    print('\n'.join(failed))
    raise SystemExit(f'FAILED: {len(failed)} packaged files differ')
print(f'PASS: all {len(records)} inventoried files match their recorded sizes and hashes.')
