"""Validate April histogram files and preserve readable CSV bytes unchanged."""
import zipfile,csv,io,re,datetime,collections,math,hashlib,json,sys
from pathlib import Path
src=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
expected={datetime.date(y,4,d) for y in range(2012,2025) for d in range(1,31)}
header=['region','0','0.0625','0.125','0.25','0.5','1','2','4','8','16','32','64','128','256']
regions={'SEE','EE','SWEW','NWEW','WSNI','ES','Devon','Cornwall'}
seen={};kept={};audit=[];summary=collections.Counter()
with zipfile.ZipFile(src) as z:
 for item in z.infolist():
  if item.is_dir():continue
  name=Path(item.filename).name;m=re.fullmatch(r'rainfall_linear_all_regions_(\d{8})\.csv',name)
  if not m:raise ValueError('Unexpected file: '+item.filename)
  d=datetime.datetime.strptime(m[1],'%Y%m%d').date()
  if d not in expected or d in seen:raise ValueError('Unexpected/duplicate date: '+str(d))
  seen[d]=name;raw=z.read(item);reason=''
  try:
   if raw and all(b==255 for b in raw):raise ValueError('File consists entirely of 0xFF bytes; no CSV data')
   rows=list(csv.reader(io.StringIO(raw.decode('utf-8-sig'))))
   assert rows and rows[0]==header,'Unexpected header'
   assert len(rows)==9 and {r[0] for r in rows[1:]}==regions,'Missing, duplicate or unexpected region rows'
   for r in rows[1:]:
    assert len(r)==15,'Wrong field count'
    v=[float(x) for x in r[1:]]
    assert all(math.isfinite(x) and x>=0 and x==int(x) for x in v),'Invalid histogram counts'
    assert sum(v)>0,'Zero histogram total'
   kept[name]=raw;status='retained'
  except Exception as exc:status='excluded_unreadable_or_invalid';reason=str(exc)
  audit.append([d.isoformat(),name,status,reason,len(raw),hashlib.sha256(raw).hexdigest()]);summary[status]+=1
for d in sorted(expected-set(seen)):
 audit.append([d.isoformat(),'','absent_from_archive','No file supplied for this date','','']);summary['absent_from_archive']+=1
with (out/'April_histogram_date_audit.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['date','filename','status','reason','bytes','sha256']);w.writerows(sorted(audit))
with (out/'April_histogram_year_summary.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['year','expected','retained','excluded_unreadable_or_invalid','absent_from_archive'])
 for y in range(2012,2025):
  c=collections.Counter(r[2] for r in audit if r[0].startswith(str(y)));w.writerow([y,30,c['retained'],c['excluded_unreadable_or_invalid'],c['absent_from_archive']])
readme=f'''April rainfall histograms, 2012–2024: cleaned copy

Expected dates: 390 (30 April days × 13 years).
Supplied CSV files: {len(seen)}.
Retained readable/structurally valid files: {summary['retained']}.
Excluded unreadable/invalid files: {summary['excluded_unreadable_or_invalid']}.
Dates absent from supplied archive: {summary['absent_from_archive']}.

Checks: ZIP entry read/CRC; date coverage and uniqueness; UTF-8 CSV parsing;
expected histogram bin header; all eight unique region rows; finite,
non-negative integer counts; positive count total for every region.
All retained files are byte-for-byte unchanged. No rainfall values have been
imputed, reconstructed, filtered for magnitude or treated as zero.
These checks establish file readability and basic structure, not radar accuracy
or full spatial/temporal sampling completeness. Positive totals do not prove
that every expected pixel/time observation is present.

Absent dates: {", ".join(d.isoformat() for d in sorted(expected-set(seen)))}.
Every expected date is represented in April_histogram_date_audit.csv.
The original uploaded ZIP is unchanged; this is a separate cleaned copy.
No models or rainfall metric calculations were rerun.
'''
(out/'README.txt').write_text(readme)
with zipfile.ZipFile(out/'April_histograms_cleaned.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name,raw in sorted(kept.items()):z.writestr('histograms/'+name,raw)
 for name in ['README.txt','April_histogram_date_audit.csv','April_histogram_year_summary.csv','check_april.py']:z.write(out/name,name)
with zipfile.ZipFile(out/'April_histograms_cleaned.zip') as z:assert z.testzip() is None
print(json.dumps(dict(summary)));print((out/'April_histograms_cleaned.zip').resolve())
