"""Independent source/prepared-data verification. Never edits analysis inputs."""
from pathlib import Path
import argparse,csv,hashlib,io,json,re,sys,zipfile
import numpy as np,pandas as pd,xarray as xr

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main(base,inputs,run,out,code,uploads):
    sys.path.insert(0,str(code));from netcdf_drivers import _prepare,_support_signature
    out.mkdir(parents=True,exist_ok=True);rows=[];series={};checks=[]
    folders=['wind','Soil top layer','SSR','SSRD','UV','t2m']
    expected=pd.DatetimeIndex(np.concatenate([pd.date_range(f'{y}-04-01',f'{y}-09-30').values for y in range(2012,2025)]))
    replacement_names={'781d2d9ea2389e8edcb44f5ebfa2ffa2.nc','a72e547a7f88335132bb08584f044731.nc','2fffcc369760e74ab2335f89824b7997.nc','634180e81b5a3d55d96bdbb987513971.nc','db31564e1517a9a66f4c727e959b93fc.nc','1bcf688a4a4683b88537ebf8ba68f973.nc','1dcac1f522b2921202d75222a9a7a187.nc'}
    replacements=[]
    for folder in folders:
      for p in sorted((base/folder).glob('*.nc')):
       with xr.open_dataset(p) as ds:
        history=ds.attrs.get('history','');agg=re.findall(r'how\s*=\s*[\'\"]?(\w+)',history);agg=agg[-1] if agg else 'unknown'
        for key in ds.data_vars:
          original=ds[key];da,lat,lon,mode=_prepare(original)
          idx=pd.DatetimeIndex(pd.to_datetime(da.time.values));use=(idx.year>=2012)&(idx.year<=2024)&np.isin(idx.month,np.arange(4,10));da=da.isel(time=np.flatnonzero(use));idx=idx[use]
          support=da.notnull().any('time');w=np.cos(np.deg2rad(da[lat])).broadcast_like(support).where(support,0)
          # Independent direct weighted sum on fixed support; dynamic gaps stay missing.
          vals=(da.fillna(0)*w).sum([lat,lon])/w.sum([lat,lon]);bad=(support&da.isnull()).any([lat,lon]);vals=vals.where(~bad)
          s=pd.Series(vals.values.astype(float),index=idx)
          units=str(original.attrs.get('units',''));factor=1.
          if key in ['ssr','ssrd','uvb']:
            assert 'J' in units
            if agg=='sum':factor=86400.
            elif agg=='mean' and key=='ssr' and p.name=='514fc04cd13dd4cbc71cb1bd7eeabfbf.nc':factor=3600.
            else:raise ValueError('Unverified radiation aggregation '+p.name)
            s=s/factor
          elif key=='t2m':assert units=='K';s=s-273.15
          elif key=='swvl1':assert 'm**3' in units
          series.setdefault(key,[]).append(s)
          sig=_support_signature(da,lat,lon)
          record=dict(folder=folder,filename=p.name,variable=key,sha256=sha(p),units=units,aggregation=agg,conversion_divisor_seconds=factor,
              first_date=idx.min().strftime('%Y-%m-%d'),last_date=idx.max().strftime('%Y-%m-%d'),n_records=len(idx),n_unique_dates=idx.nunique(),
              raw_latitude_min=float(original[lat].min()),raw_latitude_max=float(original[lat].max()),
              raw_longitude_min=float(original[lon].min()),raw_longitude_max=float(original[lon].max()),
              domain_latitude_min=float(da[lat].min()),domain_latitude_max=float(da[lat].max()),domain_longitude_min=float(da[lon].min()),domain_longitude_max=float(da[lon].max()),
              latitude_spacing=float(np.abs(np.diff(da[lat].values)).mean()),longitude_spacing=float(np.abs(np.diff(da[lon].values)).mean()),
              fixed_valid_grid_cells=int(support.sum()),n_missing_region_values=int(s.isna().sum()),spatial_support_sha256=sig,source_history=history)
          rows.append(record)
          if p.name in replacement_names:
            record=record.copy();record['identical_to_uploaded_bytes']=sha(p)==sha(uploads/p.name);replacements.append(record)
    inv=pd.DataFrame(rows);inv.to_csv(out/'source_inventory.csv',index=False)
    rep=pd.DataFrame(replacements);rep.to_csv(out/'replacement_soil_audit.csv',index=False)
    soil=inv[inv.variable.eq('swvl1')];assert soil.spatial_support_sha256.nunique()==1
    assert len(rep)==7 and rep.identical_to_uploaded_bytes.all() and rep.n_records.sum()==214
    assert rep.spatial_support_sha256.eq(soil.spatial_support_sha256.iloc[0]).all()
    met=pd.read_csv(run/'prepared/meteorology_daily_AprSep.csv',parse_dates=['date']).set_index('date')
    assert len(met)==2379 and met.index.is_unique and met.index.equals(expected)
    duplicate_audits=[]
    for key,parts in series.items():
       joined=pd.concat(parts).sort_index();conflicts=0
       for dt,g in joined.groupby(level=0):
          finite=g.dropna().to_numpy()
          if len(finite)>1 and not np.allclose(finite,finite[0],rtol=1e-6,atol=1e-8):conflicts+=1
       assert conflicts==0
       clean=joined.groupby(level=0).first().reindex(expected)
       duplicate_audits.append(dict(variable=key,n_raw_records=len(joined),n_unique_dates=joined.index.nunique(),n_duplicate_records=len(joined)-joined.index.nunique(),n_conflicting_times=conflicts))
       if key in ['u10','v10']:continue # Dailyvector wind needs magnitude before spatial averaging; checked separately below.
       name={'swvl1':'swvl1','ssr':'ssr_Wm2','ssrd':'ssrd_Wm2','uvb':'uvb_Wm2','t2m':'t2m_C'}[key]
       np.testing.assert_allclose(clean,met[name],rtol=1e-11,atol=1e-11,equal_nan=True)
       checks.append(dict(variable=name,independent_weighted_extraction_matches=True,n_present=int(clean.notna().sum())))
    pd.DataFrame(duplicate_audits).to_csv(out/'duplicate_timestamp_audit.csv',index=False)
    # Wind percell magnitude before spatialmean, match using paired annual timestamps.
    ufiles=[];vfiles=[]
    for p in sorted((base/'wind').glob('*.nc')):
       with xr.open_dataset(p) as ds:
         key='u10' if 'u10' in ds else 'v10';da,lat,lon,_=_prepare(ds[key]);a=da.load();(ufiles if key=='u10' else vfiles).append((a,lat,lon))
    windparts=[]
    for u,lat,lon in ufiles:
       for v,_,_ in vfiles:
         times=np.intersect1d(u.time.values,v.time.values)
         if not len(times):continue
         a,b=xr.align(u.sel(time=times),v.sel(time=times),join='exact');speed=np.hypot(a,b);w=np.cos(np.deg2rad(speed[lat]));mean=(speed*w).sum([lat,lon])/w.broadcast_like(speed.isel(time=0)).sum([lat,lon]);windparts.append(pd.Series(mean.values,index=pd.to_datetime(times)))
    wind=pd.concat(windparts).groupby(level=0).first().reindex(expected)
    np.testing.assert_allclose(wind,met.wind_speed,rtol=1e-11,atol=1e-11)
    checks.append(dict(variable='wind_speed',independent_weighted_extraction_matches=True,n_present=int(wind.notna().sum())))
    pd.DataFrame(checks).to_csv(out/'independent_meteorology_checks.csv',index=False)
    # Histogram metrics independently reconstructed from all supplied readable raw counts.
    canonical=np.array([0,.0625,.125,.25,.5,1,2,4,8,16,32,64,128,256]);upper=np.r_[canonical[1:],512.];representative=np.r_[0.,(upper[1:]-canonical[1:])/np.log(upper[1:]/canonical[1:])]
    rawfiles=[]
    with zipfile.ZipFile(inputs/'03_rainfall_summer/readable_histograms_1940.zip') as z:
       assert z.testzip() is None
       for n in z.namelist():
         if n.endswith('.csv'):rawfiles.append((Path(n).name,z.read(n),'summer'))
    for p in sorted((inputs/'04_rainfall_April/histograms').glob('*.csv')):rawfiles.append((p.name,p.read_bytes(),'April'))
    rainrows=[]
    for name,raw,period in rawfiles:
       d=pd.read_csv(io.BytesIO(raw));assert np.array_equal(np.array(d.columns[1:],float),canonical)
       w=d.loc[d.region.eq('SWEW')].iloc[0,1:].to_numpy(float);assert np.isfinite(w).all() and (w>=0).all() and (w==np.floor(w)).all() and w.sum()>0
       total=w.sum();wet=w[1:];wt=wet.sum();quant=0.
       if wt:
         cumulative=np.cumsum(wet);i=int(np.searchsorted(cumulative,.95*wt,side='left'));f=(.95*wt-(cumulative[i]-wet[i]))/wet[i];quant=float(np.exp(np.log(canonical[i+1])+f*np.log(upper[i+1]/canonical[i+1])))
       date=pd.to_datetime(re.search(r'(\d{8})',name)[1],format='%Y%m%d')
       rainrows.append(dict(date=date,period=period,total_samples=total,wet_fraction=wt/total,depth_mm=float(np.dot(w,representative)/total*24),intensity_q95_mmph=quant,source_sha256=hashlib.sha256(raw).hexdigest()))
    rain=pd.DataFrame(rainrows).sort_values('date');assert len(rain)==2305 and rain.date.nunique()==2305
    actual=pd.read_csv(run/'prepared/rainfall_AprSep_calendar.csv',parse_dates=['date']).set_index('date');independent=rain.set_index('date')
    for c in ['total_samples','wet_fraction','depth_mm','intensity_q95_mmph']:np.testing.assert_allclose(independent[c],actual.loc[independent.index,c],rtol=1e-11,atol=1e-11)
    rain.to_csv(out/'independent_histogram_checks.csv',index=False)
    modal=rain.total_samples.mode().iloc[0];rain['count_ratio_to_mode']=rain.total_samples/modal;rain['descriptive_support_flag']=rain.count_ratio_to_mode.lt(.8)|rain.count_ratio_to_mode.gt(1.05)
    rain[['date','period','total_samples','count_ratio_to_mode','descriptive_support_flag']].to_csv(out/'histogram_count_support_audit.csv',index=False)
    lib=pd.read_csv(run/'prepared/historical_donor_library.csv',parse_dates=['date']);assert len(lib)==2305 and lib.date.nunique()==2305
    assert lib.date.isin(rain.date).all();assert met.notna().all().all()
    blocked=['volumetric_soil_water_layer_1_0_daily-mean (7).nc','aba611a15eea730bfc3ad405ee3e8927.nc'];assert not any((base/'Soil top layer'/x).exists() for x in blocked)
    counts=dict(active_NetCDF_files=len(list(base.glob('*/*.nc'))),source_variable_rows=len(inv),source_files_by_folder=inv.groupby('folder').filename.nunique().to_dict(),soil_support_grid_cells=int(soil.fixed_valid_grid_cells.iloc[0]),soil_grid_support_signatures=int(soil.spatial_support_sha256.nunique()),replacement_soil_files=len(rep),replacement_soil_dates=int(rep.n_records.sum()),historical_calendar_dates=len(expected),meteorology_present={c:int(met[c].notna().sum()) for c in met},rainfall_present=len(rain),April_rainfall_dates=int(rain.period.eq('April').sum()),summer_rainfall_dates=int(rain.period.eq('summer').sum()),rainfall_missing_calendar_dates=int(actual.depth_mm.isna().sum()),eligible_complete_donors=len(lib),histogram_modal_count=int(modal),histogram_below_0_8_mode=int(rain.count_ratio_to_mode.lt(.8).sum()),histogram_above_1_05_mode=int(rain.count_ratio_to_mode.gt(1.05).sum()),SSR2022_declared_mean_hourly_energy_divisor_seconds=3600,SSR_daily_sum_files=int(((inv.variable=='ssr')&(inv.aggregation=='sum')).sum()),SSR2022_mean_Wm2=float(met.loc[met.index.year==2022,'ssr_Wm2'].mean()),all_SSR_le_SSRD=bool((met.ssr_Wm2<=met.ssrd_Wm2+1e-8).all()),blocked_legacy_source_files_absent_from_active_sources=blocked)
    (out/'verified_counts.json').write_text(json.dumps(counts,indent=2))
    (out/'SOURCE_VERIFICATION.txt').write_text('''VERIFIED FROM SUPPLIED EVIDENCE
Active NetCDF file bytes, variable metadata, date coverage, grid support and the
seven soil replacements were inspected. All seven replacements match the uploaded
bytes and fill May2013 plus Apr–Sep2024 (214days) on the common0.1degree391landcell
support. Meteorology has2379available dates for every required field. Independent
weighted extraction agrees with the prepared values within1e-11.
All2305readable SWEW histograms were independently reconstructed; count totals,
wet fractions, grouped depth and wet-onlyq95 agree within1e-11. Missing rainfall
remains74explicit calendar gaps. Complete donor rows number2305.
SSR2022 records how=mean;12otherSSRannualfiles record how=sum. The configured
3600-second divisor for the declared ERA5 HRES hourly accumulations is recorded;
the sum files use86400seconds. No extra daily date shift is applied.
Identical overlapping source timestamps are deduplicated after agreement checks.
No conflicting duplicate regional values were found. Duplicate raw records are
listed in duplicate_timestamp_audit.csv and do not inflate the calendar.

INTERNALLY CONSISTENT BUT NOT INDEPENDENTLY VERIFIED
Supplied metadata and source processing history identify daily aggregation and
support the stated products/conventions. These files alone do not independently
establish the full original hourly completeness or original download request.
The wind definition is magnitude of dailymean vector components per grid cell,
then cosine-latitude area averaging; not mean instantaneous wind speed.

UNRESOLVED FROM SUPPLIED MATERIAL
Readable histogram counts do not establish complete temporal/spatial radar
coverage or measurement accuracy. There are33dates below0.8and10above1.05times
the modalcount. These are descriptive support flags, not proven erroneous days.
Original scan timestamps/processing completeness and gauge comparisons are not
provided. Missing rainfall dates are not replaced, and histogram-bin/top-bin
approximations remain as documented. These limits require reporting, not invented
corrections. Superseded partial-domain2013 and incompatible2024soil files remain
outside active inputs and should be retained only as provenance.
''')
    print(json.dumps(counts,indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--base',type=Path,required=True);p.add_argument('--inputs',type=Path,required=True);p.add_argument('--run',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--code',type=Path,required=True);p.add_argument('--uploads',type=Path,required=True);a=p.parse_args();main(a.base,a.inputs,a.run,a.out,a.code,a.uploads)
