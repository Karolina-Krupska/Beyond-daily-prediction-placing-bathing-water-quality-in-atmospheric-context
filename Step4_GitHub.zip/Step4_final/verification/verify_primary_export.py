"""Independent primary reconstruction and actual-data CSV exporter verification."""
from pathlib import Path
import sys,json,shutil,subprocess,tempfile
import numpy as np,pandas as pd
import argparse
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--package',type=Path,default=Path(__file__).resolve().parents[1])
parser.add_argument('--run',type=Path)
parser.add_argument('--out',type=Path)
args=parser.parse_args()
CODE=args.package.resolve()
RUN=(args.run or CODE/'completed_run').resolve()
OUT=(args.out or CODE/'verification_output/method').resolve()
OUT.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(CODE/'code'))
from step4_core import reconstruct_from_donors,load_sequences,season_metrics,SIM_DATES,SUMMER,GROUPS,STORIES

def main():
    meta=json.loads((RUN/'run_metadata.json').read_text())
    lib=pd.read_csv(RUN/'prepared/historical_donor_library.csv',parse_dates=['date'],float_precision='round_trip')
    saved=pd.read_csv(RUN/'results/seasonal_driver_metrics.csv',float_precision='round_trip')
    seq=load_sequences(CODE/'Step4_available_inputs')
    checks=[]
    for story in STORIES:
        with np.load(RUN/f'simulations/{story}_AprSep.npz') as z:
            donor=z['donor_row'];states=z['states'];status=z['conditioning_status']
            assert donor.shape==(5000,183) and donor.min()>=0 and donor.max()<len(lib)
            np.testing.assert_array_equal(states,seq[story])
            np.testing.assert_array_equal(lib.state.to_numpy()[donor],states)
            np.testing.assert_array_equal(lib.month.to_numpy()[donor],np.broadcast_to(SIM_DATES.month.to_numpy(),states.shape))
            arrays=reconstruct_from_donors(lib,donor,meta['driver_columns'],meta['api_alpha'])
            for key in meta['driver_columns']:np.testing.assert_array_equal(arrays[key],lib[key].to_numpy()[donor])
            metric=season_metrics(arrays,status)
            metric['matching_with_p7_fraction']=metric.pop('conditioning_applied_fraction')
            metric['matching_without_observed_p7_fraction']=metric.pop('conditioning_sparse_pool_fraction')
            g=saved[saved.storyline.eq(story)].sort_values('sim')
            maximum=0.
            for key,v in metric.items():
                np.testing.assert_allclose(v,g[key].to_numpy(),rtol=1e-10,atol=1e-10,equal_nan=True)
                maximum=max(maximum,float(np.max(np.abs(v-g[key].to_numpy()))))
            checks.append(dict(storyline=story,n_seasons=5000,n_calendar_days=183,exact_step3_states=True,
                family_month_match=True,whole_donor_row=True,all_season_metrics_match=True,
                maximum_absolute_season_metric_difference=maximum))
            print('Primary PASS',story,'maxabsolute season metric difference',maximum,flush=True)
    with tempfile.TemporaryDirectory(prefix='step4_export_check_') as tmp:
        fixture=Path(tmp);(fixture/'prepared').mkdir();(fixture/'simulations').mkdir()
        shutil.copyfile(RUN/'prepared/historical_donor_library.csv',fixture/'prepared/historical_donor_library.csv')
        shutil.copyfile(RUN/'run_metadata.json',fixture/'run_metadata.json')
        for story in STORIES:
            with np.load(RUN/f'simulations/{story}_AprSep.npz') as z:
                np.savez_compressed(fixture/f'simulations/{story}_AprSep.npz',
                    **{k:z[k][:2] for k in z.files})
        command=[sys.executable,str(CODE/'export_daily.py'),str(fixture)]
        completed=subprocess.run(command,check=True,capture_output=True,text=True)
        (OUT/'export_cli_log.txt').write_text(completed.stdout+completed.stderr)
        exports=[]
        for story in STORIES:
            d=pd.read_csv(fixture/f'simulations/{story}_daily_MaySep.csv.gz',float_precision='round_trip')
            with np.load(fixture/f'simulations/{story}_AprSep.npz') as z:
                donor=z['donor_row'];states=z['states'];status=z['conditioning_status']
                a=reconstruct_from_donors(lib,donor,meta['driver_columns'],meta['api_alpha'])
                assert len(d)==306 and d.groupby('sim').size().eq(153).all()
                assert np.array_equal(d.sim.to_numpy(),np.repeat([0,1],153))
                np.testing.assert_array_equal(d.day_of_season.to_numpy(),np.tile(np.arange(1,154),2))
                np.testing.assert_array_equal(d.date.to_numpy(),np.tile(SIM_DATES[SUMMER].strftime('%Y-%m-%d').to_numpy(),2))
                np.testing.assert_array_equal(d.state.to_numpy(),states[:,SUMMER].ravel())
                np.testing.assert_array_equal(d.donor_row.to_numpy(),donor[:,SUMMER].ravel())
                np.testing.assert_array_equal(d.conditioning_status.to_numpy(),status[:,SUMMER].ravel())
                for key,v in a.items():np.testing.assert_array_equal(d[key].to_numpy(),v[:,SUMMER].ravel())
                donor_dates=lib.date.dt.strftime('%Y-%m-%d').to_numpy()[donor[:,SUMMER]].ravel()
                np.testing.assert_array_equal(d.donor_date.to_numpy(),donor_dates)
                np.testing.assert_array_equal(d.donor_regime.to_numpy(),lib.regime.to_numpy()[donor[:,SUMMER]].ravel())
                np.testing.assert_array_equal(d.family.to_numpy(),np.array(GROUPS)[states[:,SUMMER]].ravel())
            exports.append(dict(storyline=story,fixture_seasons=2,rows=306,days_per_season=153,
                all_numeric_driver_columns_bitwise_equal_to_reconstruction=True,trace_columns_exact=True))
            print('Export PASS',story,'306 rows; all driver and trace columns exact',flush=True)
    report={'primary_run':str(RUN),'source_inputs':str(CODE/'Step4_available_inputs'),
            'library_rows':len(lib),'primary_reconstruction':checks,'actual_cli_export_checks':exports,
            'fixture_only':'CSV CLI test writes a temporary two-season-per-scenario fixture, never the primary run',
            'season_metric_tolerance':'rtol=1e-10,atol=1e-10; exact state/row/month and exported driver checks use array_equal'}
    (OUT/'primary_export_verification.json').write_text(json.dumps(report,indent=2))
    print('ALL RECONSTRUCTION AND EXPORT CHECKS PASSED',flush=True)

if __name__=='__main__':main()
