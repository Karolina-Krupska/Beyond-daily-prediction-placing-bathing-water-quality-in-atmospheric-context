The count-support threshold is a descriptive sensitivity only. Primary NOQC inputs and outputs are unchanged.
Flagged rainfall depths/intensities were set to missing solely in the sensitivity calendar. p7/API were recalculated before donor eligibility was rebuilt.
Other meteorological inputs remain unchanged. No replacement rainfall or clipping was used.
All six scenarios use the requested prefix of unchanged Step3 sequences and common uniforms. Contrasts and MonteCarloSEs use paired season-level summaries.
Read metadata and poolcomparison before interpreting differences. This is not independent validation of radar accuracy or a recommendation to exclude extremes.
