STEP 4
Historical daily weather and simulated weather under six circulation storylines

Read WHAT_CHANGED.txt for the API correction and its effect on the results.
Start with completed_run/. This folder contains the Step 4 output. The other
folders contain the code and inputs used to produce it.

WHERE TO LOOK

* completed_run/prepared/historical_daily_calendar.csv contains daily rainfall,
  meteorology and antecedent wetness for April to September 2012-2024. The
  columns api and api_before give the index at the end and start of each day.
* completed_run/prepared/historical_donor_library.csv contains the 2,305
  historical days with a complete set of same-day weather measurements.
* completed_run/results/ensemble_summary.csv summarises the six simulated
  storylines. scenario_minus_baseline.csv gives their differences from baseline.
* completed_run/results/support_sensitivity/ contains a separate check in which
  rainfall histograms with unusual observation counts were excluded. It includes
  its own historical calendar and donor library.
* completed_run/figures/ contains all six figures in PNG, PDF and SVG formats.
  FIGURE_CAPTIONS.txt describes what each figure shows.
* METHODS_AND_LIMITATIONS.txt explains the calculations and how to interpret the
  results. FILE_INVENTORY.csv records the sizes and hashes of the packaged files.

HOW API IS CALCULATED

The index starts from zero immediately before 1 April each year. Each day with
measured rainfall contributes its depth to the index and retains 85% of the
previous day's index. A day without a rainfall measurement has a missing
end-of-day API. The next measured depth starts a new sequence, including when
that depth is zero. Its starting (previous-day) API remains missing for that
day. The new sequence omits carry-over from before the gap.

The primary calendar contains 1,989 May-September dates. End-of-day API is
available on the 1,940 dates with rainfall measurements. A further 365 measured
April dates provide the seasonal lead-in. Simulated weather uses complete donor
days, selected by weather family, month, previous soil moisture and wind, and
seven-day rainfall when available. API is recomputed along each simulated
season from its sampled rainfall.

RUN THE ANALYSIS ON WINDOWS

1. Extract the complete ZIP into a local folder. Open PowerShell in the
   extracted Step4_final folder, alongside run_all.py and config.json.

2. Create the Python environment and install dependencies. Use Python 3.12
   for the pinned versions. A compatible dependency list is also provided
   in requirements.txt.

     py -3.12 -m venv .venv
     .\.venv\Scripts\python.exe -m pip install -r requirements-lock.txt

3. Restore the six meteorological source archives and start the workflow.
   The --base-dir . argument makes the scripts use the files in this folder.

     .\.venv\Scripts\python.exe extract_sources.py
     .\.venv\Scripts\python.exe run_all.py --base-dir .

   Each new run writes a timestamped folder under outputs/. Its primary
   calendar and donor library are in prepared/. Assessment settings and
   completion are recorded in results/assessment_completion.json.

4. Optional commands for the supplied run:

     .\.venv\Scripts\python.exe verify_package.py
     .\.venv\Scripts\python.exe verification\verify_primary_export.py
     .\.venv\Scripts\python.exe export_daily.py completed_run

   The first command checks the packaged file hashes. The second reconstructs
   the primary seasonal metrics from saved donor indices and checks the daily
   exporter on two seasons per storyline. The third writes six full daily
   May-September CSV.gz files to completed_run/simulations/. Each row
   identifies the season, synthetic date, source date and donor row. The year
   2001 is used as a calendar template for simulated dates.

Inputs
Step4_available_inputs/ contains the daily weather pattern classifications,
Step 3 circulation sequences and radar inputs. source_archives/ contains the
regional meteorological source files. extract_sources.py unpacks them locally.
The historical data and generated drivers in this package cover Step 4 only.

For the independent raw-source check, first run extract_sources.py, then run
this command from the Step4_final folder (one line):
  .\.venv\Scripts\python.exe verification\verify_latest_sources.py --base . --inputs Step4_available_inputs --run completed_run --out verification_output/sources --code code --uploads provenance/original_replacement_files
