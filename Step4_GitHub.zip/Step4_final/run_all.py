"""Run the complete preserved Step4 workflow and its prescribed checks.

Windows: py run_all.py
Portable: py extract_sources.py; py run_all.py --base-dir .
No downstream microbiological models or alert selections are run.
"""
from pathlib import Path
import argparse,json,sys,subprocess,contextlib,datetime
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'code'))
from run_step4 import run
from step4_core import resolve_inputs
from continuity_sensitivity import run_sensitivity
from validate_continuity import run_holdout
from year_uncertainty import run_uncertainty
from support_sensitivity import run_support
from plot_continuity import plot_checks
from audit_donor_reuse import run_reuse

class Tee:
    def __init__(self,*handles):self.handles=handles
    def write(self,value):
        for h in self.handles:h.write(value);h.flush()
        return len(value)
    def flush(self):
        for h in self.handles:h.flush()

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config',default=str(ROOT/'config.json'))
    p.add_argument('--base-dir');p.add_argument('--existing-run',type=Path)
    p.add_argument('--n-sims',type=int);p.add_argument('--holdout-sims',type=int,default=500)
    a=p.parse_args();config=json.loads(Path(a.config).read_text(encoding='utf-8-sig'))
    tests=subprocess.run([sys.executable,'-m','unittest','discover','-s',str(ROOT/'code'),'-p','test*.py','-v'],text=True,capture_output=True)
    if tests.returncode:print(tests.stdout+tests.stderr);raise SystemExit('Numerical tests failed; no analysis was started')
    if a.existing_run:
        out=a.existing_run;meta=json.loads((out/'run_metadata.json').read_text());n=int(a.n_sims or meta['n_sims_per_scenario'])
    else:
        out=run(SimpleNamespace(config=a.config,base_dir=a.base_dir,prepare_only=False,n_sims=a.n_sims));n=int(a.n_sims or config['n_sims'])
    (out/'NUMERICAL_TESTS.txt').write_text(tests.stdout+tests.stderr)
    base=Path(a.base_dir or config['base_dir']);proposed=base/config.get('inputs_folder','Step4_available_inputs')
    inputs=resolve_inputs(proposed if proposed.exists() else ROOT/'Step4_available_inputs')
    seed=int(json.loads((out/'run_metadata.json').read_text())['seed'])
    with (out/'assessment_execution.log').open('w',encoding='utf-8') as log,contextlib.redirect_stdout(Tee(sys.stdout,log)):
        run_sensitivity(out,inputs,n=n,seed=seed)
        run_holdout(out,inputs,n=a.holdout_sims,seed=seed)
        run_uncertainty(out,n_boot=10000,seed=seed)
        run_support(out,inputs,n=min(1000,n))
        run_reuse(out)
        plot_checks(out)
        (out/'results/assessment_completion.json').write_text(json.dumps({'status':'completed','finished_at':datetime.datetime.now().isoformat(),'sensitivity_seasons_per_scenario':n,'holdout_seasons_per_year_and_sampler':a.holdout_sims,'historical_mean_bootstrap_replicates':10000,'input_support_seasons_per_scenario':min(1000,n)},indent=2))
        metadata=json.loads((out/'run_metadata.json').read_text())
        metadata['assessment_status']='Completed; see results/assessment_completion.json and the diagnostic limitations'
        (out/'run_metadata.json').write_text(json.dumps(metadata,indent=2))
        print('All checks complete:',out,flush=True)
