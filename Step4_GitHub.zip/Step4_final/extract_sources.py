"""Restore curated, original-byte meteorological sources; never overwrite different bytes."""
from pathlib import Path
import zipfile
ROOT=Path(__file__).resolve().parent
for name in ['wind','Soil top layer','SSR','SSRD','t2m','UV']:
    with zipfile.ZipFile(ROOT/'source_archives'/(name+'.zip')) as z:
        for info in z.infolist():
            if info.is_dir():continue
            target=ROOT/info.filename
            if not target.resolve().is_relative_to(ROOT):raise ValueError('Unsafe archive path')
            raw=z.read(info)
            if target.exists():
                if target.read_bytes()!=raw:raise FileExistsError('Keeping existing different source: '+str(target))
                continue
            target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    print('Available:',name)
