"""Rainfall preparation and conditional whole-day donor resampling.

This module never refits circulation transitions. Soil and weather are sampled
jointly from observed days; dynamical continuity/water balance is not imposed.
"""
from pathlib import Path
import csv, io, re, zipfile, hashlib
import numpy as np
import pandas as pd

GROUPS = ['Cyclonic Atlantic (frontal)', 'Showery maritime / unsettled',
          'Convective extremes', 'Settled anticyclonic quiet']
STORIES = ['baseline','persistent_wet','persistent_dry','dry_with_bursts',
           'flip_wet_to_dry','flip_dry_to_wet']
BINS = np.array([0,.0625,.125,.25,.5,1,2,4,8,16,32,64,128,256], dtype=float)
DRIVERS = ['depth_mm','intensity_q95_mmph','wind_speed','uvb_Wm2',
           'ssrd_Wm2','t2m_C','swvl1']
SIM_DATES = pd.date_range('2001-04-01','2001-09-30')
SUMMER = SIM_DATES.month.to_numpy() >= 5

def calendar():
    return pd.DatetimeIndex(np.concatenate([pd.date_range(f'{y}-04-01',f'{y}-09-30').values
                                           for y in range(2012,2025)]), name='date')

def resolve_inputs(path):
    path=Path(path)
    for candidate in (path,path/'Step4_available_inputs'):
        if (candidate/'01_storylines/primary_sequences_AprSep.npz').exists(): return candidate
    raise FileNotFoundError(f'Extract Step4_available_inputs.zip first. Cannot find 01_storylines in {path}')

def verify_manifest(root):
    manifest=root/'FILE_MANIFEST.csv'
    if not manifest.exists(): raise FileNotFoundError('Missing input FILE_MANIFEST.csv')
    for r in csv.DictReader(manifest.open(newline='',encoding='utf-8')):
        p=root/r['relative_path']
        if not p.is_file() or p.stat().st_size!=int(r['bytes']) or hashlib.sha256(p.read_bytes()).hexdigest()!=r['sha256']:
            raise ValueError(f'Input differs from supplied manifest: {p}. Restore the package or explicitly disable manifest checking after documenting changes.')

def load_classifications(root):
    d=pd.read_csv(root/'02_classification/classifications.csv',comment='#')
    d['date']=pd.to_datetime(d[['year','month','day']])
    d=d[d.year.between(2012,2024)&d.month.between(4,9)].sort_values('date')
    if d.date.duplicated().any() or not np.array_equal(d.date.values,calendar().values):
        raise ValueError('Weather calendar is not the complete unique April–September calendar')
    m=pd.read_csv(root/'02_classification/weather_pattern_family_mapping.csv')
    if m.regime.duplicated().any() or set(m.regime)!=set(range(1,31)) or set(m.group)!=set(GROUPS):
        raise ValueError('Invalid 30-to-four mapping')
    d['family']=d.regime.map(dict(zip(m.regime,m.group)))
    d['state']=d.family.map(dict(zip(GROUPS,range(4))))
    return d[['date','year','month','regime','family','state']]

def histogram_metrics(raw):
    d=pd.read_csv(io.BytesIO(raw))
    if d.columns[0]!='region' or len(d.columns)!=15 or not np.array_equal(np.array(d.columns[1:],float),BINS):
        raise ValueError('Unexpected raw histogram bins/header')
    s=d[d.region.eq('SWEW')]
    if len(s)!=1: raise ValueError('Expected one SWEW histogram row')
    w=s.iloc[0,1:].to_numpy(dtype=float)
    if not np.isfinite(w).all() or (w<0).any() or (w!=np.floor(w)).any() or w.sum()<=0:
        raise ValueError('Invalid SWEW histogram counts')
    upper=np.r_[BINS[1:],BINS[-1]*2.0]
    rep=np.zeros_like(BINS);rep[1:]=(upper[1:]-BINS[1:])/np.log(upper[1:]/BINS[1:])
    rate=float(np.dot(w,rep)/w.sum())
    wet=w[1:];total=wet.sum()
    def quant(q):
        if total==0:return 0.0
        c=np.cumsum(wet);target=q*total;i=min(int(np.searchsorted(c,target,side='left')),len(wet)-1)
        fraction=(target-(c[i]-wet[i]))/wet[i]
        return float(np.exp(np.log(BINS[i+1])+fraction*np.log(upper[i+1]/BINS[i+1])))
    return dict(total_samples=int(w.sum()),wet_fraction=float(total/w.sum()),mean_rate_mmph=rate,
                daily_depth_mm=24*rate,q50_mmph=quant(.5),q90_mmph=quant(.9),q95_mmph=quant(.95))

def prepare_rainfall(root, weather, output):
    summer=pd.read_csv(root/'03_rainfall_summer/rainfall_MaySep_1940.csv',parse_dates=['date'])
    if len(summer)!=1940 or summer.date.duplicated().any() or not summer.date.dt.month.between(5,9).all():
        raise ValueError('Expected 1940 unique corrected summer rainfall dates')
    check=summer[['date','regime']].merge(weather[['date','regime']],on='date',validate='one_to_one',suffixes=('_rain','_weather'),how='left')
    if not check.regime_rain.eq(check.regime_weather).all(): raise ValueError('Summer rainfall/weather mismatch')
    apr=[]
    for p in sorted((root/'04_rainfall_April/histograms').glob('*.csv')):
        m=re.fullmatch(r'rainfall_linear_all_regions_(\d{8})\.csv',p.name)
        if not m:raise ValueError(f'Unexpected histogram filename: {p}')
        date=pd.to_datetime(m[1],format='%Y%m%d')
        if date.month!=4 or not 2012<=date.year<=2024:raise ValueError('Unexpected April date')
        apr.append(dict(date=date,**histogram_metrics(p.read_bytes())))
    april=pd.DataFrame(apr)
    if len(april)!=365 or april.date.duplicated().any():raise ValueError('Expected 365 readable unique April histograms')
    fields=['date','total_samples','wet_fraction','mean_rate_mmph','daily_depth_mm','q50_mmph','q90_mmph','q95_mmph']
    rain=pd.concat([april[fields],summer[fields]],ignore_index=True).sort_values('date')
    if rain.date.duplicated().any() or not np.isfinite(rain[fields[1:]].to_numpy(float)).all():raise ValueError('Invalid combined rainfall table')
    daily=weather.merge(rain,on='date',how='left',validate='one_to_one')
    daily['rainfall_available']=daily.daily_depth_mm.notna()
    daily=daily.rename(columns={'daily_depth_mm':'depth_mm','q95_mmph':'intensity_q95_mmph'})
    daily.to_csv(output/'rainfall_AprSep_calendar.csv',index=False)
    april.to_csv(output/'rainfall_April_metrics_365.csv',index=False)
    daily.loc[~daily.rainfall_available,['date','year','month','regime','family']].to_csv(output/'rainfall_missing_dates.csv',index=False)
    return daily

def antecedents(df, alpha=.85):
    """Complete daily windows. Historical API restarts on the first observed rainfall day after a gap.

    April 1 API is initialised at zero BEFORE that day's rain. No March inputs
    are implied. Seven-day totals require all seven actual daily values.
    """
    d=df.sort_values('date').copy()
    for col in ['p7_before_mm','p7_mm','api_before','api','swvl1_roll']:d[col]=np.nan
    for year,g in d.groupby(d.date.dt.year,sort=True):
        if not np.array_equal(g.date.values,pd.date_range(f'{year}-04-01',f'{year}-09-30').values):
            raise ValueError('Antecedents require full April–September calendar, including missing rows')
        p=g.depth_mm
        d.loc[g.index,'p7_before_mm']=p.shift(1).rolling(7,min_periods=7).sum().to_numpy()
        d.loc[g.index,'p7_mm']=p.rolling(7,min_periods=7).sum().to_numpy()
        before=[];after=[];a=0.0
        for depth in p.to_numpy():
            before.append(a)
            if not np.isfinite(depth):
                a = np.nan
            elif np.isfinite(a):
                a = alpha * a + depth
            else:
                # Earlier rainfall is unknown. Start a new series with today's depth.
                a = depth
            after.append(a)
        d.loc[g.index,'api_before']=before;d.loc[g.index,'api']=after
        if 'swvl1' in g:d.loc[g.index,'swvl1_roll']=g.swvl1.rolling(7,min_periods=7).mean().to_numpy()
    return d

def build_library(daily,met,output,alpha=.85,min_pool=20):
    met=met.copy();met['date']=pd.to_datetime(met.date)
    if met.date.duplicated().any():raise ValueError('Duplicate meteorological dates')
    if not set(met.date)<=set(calendar()):raise ValueError('Unexpected meteorological dates')
    overlap=set(daily.columns)&set(met.columns)-{'date'}
    if overlap:raise ValueError(f'Overlapping input fields: {overlap}')
    d=antecedents(daily.merge(met,on='date',how='left',validate='one_to_one'),alpha)
    need=list(DRIVERS)
    if 'ssr_Wm2' in d and d.ssr_Wm2.notna().any():need.append('ssr_Wm2')
    missing=[c for c in need if c not in d]
    if missing:raise ValueError(f'Missing required donor fields: {missing}')
    values=d[need].to_numpy(float)
    d['donor_eligible']=np.isfinite(values).all(axis=1)
    d['ineligible_reason']=[';'.join(c for c in need if not np.isfinite(row[c])) for _,row in d.iterrows()]
    d.to_csv(output/'historical_daily_calendar.csv',index=False)
    d.loc[~d.donor_eligible,['date','family','month','ineligible_reason']].to_csv(output/'excluded_donor_dates.csv',index=False)
    lib=d[d.donor_eligible].copy().reset_index(drop=True)
    if (lib.depth_mm<0).any() or (lib.intensity_q95_mmph<0).any() or (lib.wind_speed<0).any() or not lib.swvl1.between(0,1).all():
        raise ValueError('Physically invalid donor rainfall/wind/soil values; inspect inputs')
    pools={};rows=[]
    for state in range(4):
        for month in range(4,10):
            idx=lib.index[(lib.state==state)&(lib.month==month)].to_numpy()
            if not len(idx):raise ValueError(f'Empty complete donor pool: {GROUPS[state]}, month {month}; see excluded_donor_dates.csv')
            p7=lib.loc[idx,'p7_before_mm'];valid=idx[p7.notna().to_numpy()]
            q=np.quantile(lib.loc[valid,'p7_before_mm'],[1/3,2/3]) if len(valid) else np.array([np.nan,np.nan])
            bins=np.searchsorted(q,lib.loc[valid,'p7_before_mm'].to_numpy(),side='right') if len(valid) else np.array([],int)
            parts=[valid[bins==b] for b in range(3)]
            pools[state,month]=(idx,q,parts)
            for b in range(3):rows.append(dict(state=state,family=GROUPS[state],month=month,
                complete_donors=len(idx),donors_with_complete_pre_day_p7=len(valid),wetness_bin=b,
                wetness_bin_donors=len(parts[b]),p7_cut_low=q[0],p7_cut_high=q[1],
                conditioning_available=len(parts[b])>=min_pool,min_conditioning_donors=min_pool))
    lib.to_csv(output/'historical_donor_library.csv',index=False)
    pd.DataFrame(rows).to_csv(output/'donor_pool_audit.csv',index=False)
    return lib,pools,need

def load_sequences(root,n=None):
    with np.load(root/'01_storylines/primary_sequences_AprSep.npz') as data:
        if set(data.files)!=set(STORIES+['month']):raise ValueError('Unexpected scenario keys')
        if not np.array_equal(data['month'],SIM_DATES.month.to_numpy()):raise ValueError('Sequence month calendar mismatch')
        seq={s:data[s].copy() for s in STORIES}
    sizes={v.shape for v in seq.values()}
    if sizes!={(5000,183)}:raise ValueError('Expected six 5000 × 183 sequence arrays')
    for v in seq.values():
        if not np.isin(v,np.arange(4)).all():raise ValueError('Invalid state values')
    if n is not None:
        if not 1<=n<=5000:raise ValueError('n_sims must be between 1 and 5000')
        seq={s:v[:n].copy() for s,v in seq.items()}
    return seq

def sample_sequence(states,lib,pools,columns,uniforms,alpha=.85,conditioning=True,min_pool=20):
    """Vectorised daily selection, retaining the exact supplied circulation states."""
    n,L=states.shape
    if L!=183 or uniforms.shape!=(n,L):raise ValueError('Expected 183-day seasons and matching uniforms')
    source=lib[columns].to_numpy(float)
    donor=np.empty((n,L),np.int32);used=np.zeros((n,L),bool)
    # Codes:0 applied;1 disabled;2 incomplete simulated antecedent;3 sparse bin;4 absent observed antecedents.
    status=np.zeros((n,L),np.int8)
    arrays={c:np.empty((n,L),float) for c in columns}
    for c in ['p7_before_mm','p7_mm','api_before','api','swvl1_roll']:arrays[c]=np.full((n,L),np.nan)
    api=np.zeros(n)
    for t,month in enumerate(SIM_DATES.month):
        p7=np.sum(arrays['depth_mm'][:,t-7:t],axis=1) if t>=7 else np.full(n,np.nan)
        arrays['p7_before_mm'][:,t]=p7;arrays['api_before'][:,t]=api
        for state in range(4):
            sims=np.flatnonzero(states[:,t]==state)
            if not len(sims):continue
            base,q,parts=pools[state,int(month)]
            chosen=np.full(len(sims),-1,dtype=np.int32)
            flags=np.full(len(sims),1 if not conditioning else 2,dtype=np.int8)
            if conditioning and np.isfinite(q).all():
                valid=np.isfinite(p7[sims]);bins=np.searchsorted(q,p7[sims],side='right')
                for b in range(3):
                    loc=np.flatnonzero(valid&(bins==b))
                    if not len(loc):continue
                    if len(parts[b])>=min_pool:
                        chosen[loc]=parts[b][np.minimum((uniforms[sims[loc],t]*len(parts[b])).astype(int),len(parts[b])-1)]
                        flags[loc]=0
                    else:flags[loc]=3
            elif conditioning:flags[np.isfinite(p7[sims])]=4
            rest=np.flatnonzero(chosen<0)
            chosen[rest]=base[np.minimum((uniforms[sims[rest],t]*len(base)).astype(int),len(base)-1)]
            donor[sims,t]=chosen;status[sims,t]=flags;used[sims,t]=flags==0
        picked=source[donor[:,t]]
        for j,c in enumerate(columns):arrays[c][:,t]=picked[:,j]
        api=alpha*api+arrays['depth_mm'][:,t];arrays['api'][:,t]=api
        if t>=6:
            arrays['p7_mm'][:,t]=arrays['depth_mm'][:,t-6:t+1].sum(axis=1)
            arrays['swvl1_roll'][:,t]=arrays['swvl1'][:,t-6:t+1].mean(axis=1)
    return arrays,donor,used,status

def season_metrics(arrays,donor_status):
    m={}
    for c in ['depth_mm','intensity_q95_mmph','wind_speed','uvb_Wm2','ssrd_Wm2','t2m_C','swvl1','swvl1_roll','p7_mm','api']:
        a=arrays[c][:,SUMMER]
        m['mean_'+c]=a.mean(axis=1);m['p95_'+c]=np.quantile(a,.95,axis=1)
    m['total_rainfall_mm']=arrays['depth_mm'][:,SUMMER].sum(axis=1)
    m['conditioning_applied_fraction']=(donor_status[:,SUMMER]==0).mean(axis=1)
    m['conditioning_sparse_pool_fraction']=(donor_status[:,SUMMER]==3).mean(axis=1)
    return m


def reconstruct_from_donors(lib,donor,columns,alpha=.85):
    """Losslessly reconstruct all simulated drivers from compact donor indices."""
    arrays={c:lib[c].to_numpy(float)[donor] for c in columns}
    n,L=donor.shape
    for c in ['p7_before_mm','p7_mm','api_before','api','swvl1_roll']:arrays[c]=np.full((n,L),np.nan)
    api=np.zeros(n)
    for t in range(L):
        arrays['api_before'][:,t]=api
        api=alpha*api+arrays['depth_mm'][:,t];arrays['api'][:,t]=api
        if t>=7:arrays['p7_before_mm'][:,t]=arrays['depth_mm'][:,t-7:t].sum(axis=1)
        if t>=6:
            arrays['p7_mm'][:,t]=arrays['depth_mm'][:,t-6:t+1].sum(axis=1)
            arrays['swvl1_roll'][:,t]=arrays['swvl1'][:,t-6:t+1].mean(axis=1)
    return arrays
