"""Small numerical checks for sensitivity diagnostics; no environmental models."""
import unittest
import numpy as np
from step4_sensitivity import calendar_metrics, api_from_rain, _lag1, _max_wet_run


class SensitivityDiagnosticsTests(unittest.TestCase):
    def test_missing_date_breaks_pairs_and_run(self):
        v = np.array([1., 2., 3., np.nan, 4., 5.])
        _, n = _lag1(v)
        self.assertEqual(n, 3)
        self.assertEqual(_max_wet_run(v), 3.)

    def test_incomplete_season_has_no_total(self):
        rain = np.ones(153)
        rain[10] = np.nan
        soil = np.arange(153, dtype=float) / 1000.
        wind = np.full(153, 2.)
        m = calendar_metrics(rain, soil, wind)
        self.assertTrue(np.isnan(m['rainfall_season_total_mm']))
        self.assertEqual(m['n_valid_depth_mm'], 152)
        self.assertEqual(m['n_consecutive_pairs_depth_mm'], 150)
        self.assertEqual(m['wet_days_ge1mm_available'], 152)
        self.assertAlmostEqual(m['mean_absolute_soil_day_change'], .001)
        self.assertTrue(np.isnan(m['lag1_wind_speed']))

    def test_complete_season_total_and_threshold(self):
        rain = np.ones(153)
        m = calendar_metrics(rain, rain/10, rain*2)
        self.assertEqual(m['rainfall_season_total_mm'], 153.)
        self.assertEqual(m['max_valid_wet_run_ge1mm'], 153.)

    def test_api_recurrence_uses_entire_april_warmup(self):
        rain = np.zeros((2, 183))
        rain[:, 0] = [1., 2.]
        api = api_from_rain(rain, .8)
        self.assertTrue(np.allclose(api[:, 0], [1., 2.]))
        self.assertTrue(np.allclose(api[:, 30], np.array([1., 2.]) * .8**30))


if __name__ == '__main__':
    unittest.main()
