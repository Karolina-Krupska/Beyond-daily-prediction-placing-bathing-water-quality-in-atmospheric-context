"""Conditional Step 4 sensitivities and descriptive baseline adequacy checks.

This module does not fit or change the circulation model. All donor-selection
variants use the supplied Step 3 sequences and the same uniforms. Reported
2.5th–97.5th percentiles are conditional simulation ranges, not confidence
intervals. Monte Carlo standard errors quantify numerical precision only.
Historical summaries use available data on the intact daily calendar; missing
days break runs/pairs. An incomplete observed season has no total-rainfall
estimate. No hypothesis test, formal pass/fail criterion or validation guarantee
is provided.
"""
from pathlib import Path
import argparse
import json
import numpy as np
import pandas as pd

from step4_core import (GROUPS, STORIES, SUMMER, SIM_DATES, load_sequences,
                        resolve_inputs, sample_sequence, season_metrics)


def rebuild_pools(lib):
    """Reproduce primary family/month pools without altering donor eligibility."""
    pools = {}
    for state in range(4):
        for month in range(4, 10):
            idx = np.flatnonzero((lib.state.to_numpy() == state) &
                                 (lib.month.to_numpy() == month))
            if not len(idx):
                raise ValueError(f'Empty donor pool: {GROUPS[state]}, month {month}')
            vals = lib.loc[idx, 'p7_before_mm'].to_numpy(float)
            valid = idx[np.isfinite(vals)]
            q = (np.quantile(lib.loc[valid, 'p7_before_mm'], [1/3, 2/3])
                 if len(valid) else np.full(2, np.nan))
            bins = (np.searchsorted(q, lib.loc[valid, 'p7_before_mm'].to_numpy(),
                                   side='right') if len(valid) else np.array([], int))
            pools[state, month] = (idx, q, [valid[bins == b] for b in range(3)])
    return pools


def _mean_or_nan(v):
    finite = np.isfinite(v)
    return float(np.mean(v[finite])) if finite.any() else np.nan


def _lag1(values):
    """Pairwise Pearson correlation; missing dates never become adjacent."""
    v = np.asarray(values, float)
    valid = np.isfinite(v[:-1]) & np.isfinite(v[1:])
    a, b = v[:-1][valid], v[1:][valid]
    if len(a) < 3 or np.std(a) == 0 or np.std(b) == 0:
        return np.nan, int(len(a))
    return float(np.corrcoef(a, b)[0, 1]), int(len(a))


def _max_wet_run(values, threshold=1.):
    """Missing days break runs. With gaps this is an observed lower bound."""
    longest = current = 0
    for x in np.asarray(values, float):
        current = current + 1 if np.isfinite(x) and x >= threshold else 0
        longest = max(longest, current)
    return float(longest) if np.isfinite(values).any() else np.nan


def calendar_metrics(depth, soil, wind):
    """Descriptive metrics for one intact 153-day May–September calendar."""
    depth, soil, wind = [np.asarray(v, float) for v in (depth, soil, wind)]
    if any(v.shape != (153,) for v in (depth, soil, wind)):
        raise ValueError('Adequacy metrics require an intact 153-day calendar')
    result = {}
    for label, v in [('depth_mm', depth), ('swvl1', soil), ('wind_speed', wind)]:
        result['n_valid_' + label] = int(np.isfinite(v).sum())
        result['mean_' + label] = _mean_or_nan(v)
        corr, n = _lag1(v)
        result['lag1_' + label] = corr
        result['n_consecutive_pairs_' + label] = n
    pair = np.isfinite(soil[:-1]) & np.isfinite(soil[1:])
    result['mean_absolute_soil_day_change'] = (
        float(np.mean(np.abs(np.diff(soil)[pair]))) if pair.any() else np.nan)
    result['rainfall_season_total_mm'] = (float(depth.sum())
                                         if np.isfinite(depth).all() else np.nan)
    result['wet_days_ge1mm_available'] = (int(np.sum(depth >= 1.))
                                         if np.isfinite(depth).any() else np.nan)
    result['max_valid_wet_run_ge1mm'] = _max_wet_run(depth)
    return result


def api_from_rain(rain, alpha):
    """End-of-day API, zero immediately before April 1; no donor changes."""
    rain = np.asarray(rain, float)
    if rain.ndim != 2 or rain.shape[1] != 183 or not np.isfinite(rain).all():
        raise ValueError('API sensitivity requires complete n × 183 rainfall')
    out = np.empty_like(rain)
    current = np.zeros(len(rain))
    for t in range(183):
        current = alpha * current + rain[:, t]
        out[:, t] = current
    return out


def _summary_row(v):
    v = np.asarray(v, float)
    valid = v[np.isfinite(v)]
    return {'n_defined': len(valid),
            'mean': float(valid.mean()) if len(valid) else np.nan,
            'simulation_p025': float(np.quantile(valid, .025)) if len(valid) else np.nan,
            'simulation_p975': float(np.quantile(valid, .975)) if len(valid) else np.nan,
            'monte_carlo_se_mean': (float(np.std(valid, ddof=1)/np.sqrt(len(valid)))
                                    if len(valid) > 1 else np.nan)}


def run_sensitivity(primary_run, input_root, n=5000, seed=42):
    """Write sensitivity*.csv and baseline_adequacy*.csv beneath results/."""
    primary_run, input_root = Path(primary_run), resolve_inputs(input_root)
    metadata = json.loads((primary_run/'run_metadata.json').read_text(encoding='utf-8'))
    config = json.loads((primary_run/'config_used.json').read_text(encoding='utf-8'))
    if int(seed) != int(metadata['seed']):
        raise ValueError('Sensitivity seed must equal primary seed to retain pairing')
    if not 1 <= n <= min(5000, int(metadata['n_sims_per_scenario'])):
        raise ValueError('Sensitivity n must be positive and no larger than primary n')
    alpha = float(metadata['api_alpha'])
    minimum = int(config.get('min_conditioning_donors', 20))
    conditioned = bool(config.get('wetness_conditioning', True))
    out = primary_run/'results'
    out.mkdir(exist_ok=True)
    lib = pd.read_csv(primary_run/'prepared/historical_donor_library.csv', parse_dates=['date'],float_precision='round_trip')
    # Donor row numbers in primary NPZ/CSV refer to this exact library order.
    lib = lib.reset_index(drop=True)
    historical = pd.read_csv(primary_run/'prepared/historical_daily_calendar.csv', parse_dates=['date'],float_precision='round_trip')
    pools = rebuild_pools(lib)
    columns = list(metadata['driver_columns'])
    sequences = load_sequences(input_root, n)
    rng = np.random.default_rng(np.random.SeedSequence([int(seed), 4]))
    uniforms = rng.random((n, 183))
    configs = [('primary_reconstructed', conditioned, minimum),
               ('no_wetness_conditioning', False, minimum),
               ('minimum_donors_10', True, 10),
               ('minimum_donors_30', True, 30)]
    seasonal, fallbacks, api_rows = [], [], []
    primary_metrics = {}
    simulated_adequacy = None
    for label, use_conditioning, min_donors in configs:
        print(f'[Sensitivity] {label}: {n} seasons per scenario', flush=True)
        for story in STORIES:
            arrays, donor, used, status = sample_sequence(
                sequences[story], lib, pools, columns, uniforms, alpha=alpha,
                conditioning=use_conditioning, min_pool=min_donors)
            if not np.array_equal(lib.state.to_numpy()[donor], sequences[story]):
                raise AssertionError('Sensitivity donor-family mismatch')
            metrics = season_metrics(arrays, status)
            seasonal.append(pd.DataFrame({'configuration': label, 'storyline': story,
                                          'sim': np.arange(n), **metrics}))
            for month in range(4, 10):
                for state in range(4):
                    mask = (sequences[story] == state) & (SIM_DATES.month.to_numpy()[None, :] == month)
                    denom = int(mask.sum())
                    for code in range(5):
                        numerator = int(np.sum((status == code) & mask))
                        fallbacks.append(dict(configuration=label, storyline=story,
                            month=month, state=state, family=GROUPS[state], status=code,
                            days=numerator, total_days=denom,
                            fraction=numerator/denom if denom else np.nan))
            if label == 'primary_reconstructed':
                primary_metrics[story] = metrics
                # Compare against saved primary metrics where available. A small-n
                # smoke test uses the first n rows from the same fixed uniform stream.
                saved = primary_run/'results/seasonal_driver_metrics.csv'
                if saved.exists():
                    old = pd.read_csv(saved,float_precision='round_trip')
                    old = old[old.storyline.eq(story) & old.sim.lt(n)].sort_values('sim')
                    if len(old) != n:
                        raise ValueError('Saved primary metrics have different simulation count')
                    for key, vals in metrics.items():
                        if key in old and not np.allclose(old[key], vals, rtol=1e-10, atol=1e-10, equal_nan=True):
                            raise ValueError('Reconstructed primary differs from saved metrics: '+key)
                alpha_values = sorted(set([.8, .85, .9, alpha]))
                reference = arrays['api'][:, SUMMER]
                reference_mean = reference.mean(axis=1)
                for api_alpha in alpha_values:
                    api = api_from_rain(arrays['depth_mm'], api_alpha)[:, SUMMER]
                    values = {'mean_api': api.mean(axis=1), 'p95_api': np.quantile(api, .95, axis=1)}
                    for metric, v in values.items():
                        ref = reference_mean if metric == 'mean_api' else np.quantile(reference, .95, axis=1)
                        delta = v-ref
                        api_rows.append(dict(storyline=story, api_alpha=api_alpha,
                            primary_api_alpha=alpha, metric=metric, **_summary_row(v),
                            mean_difference_from_primary=float(delta.mean()),
                            monte_carlo_se_difference=(float(delta.std(ddof=1)/np.sqrt(n)) if n>1 else np.nan),
                            interpretation='Derived API only; identical rainfall and donors; not a model-output sensitivity'))
                if story == 'baseline':
                    simulated_adequacy = pd.DataFrame([
                        dict(sim=i, **calendar_metrics(arrays['depth_mm'][i, SUMMER],
                            arrays['swvl1'][i, SUMMER], arrays['wind_speed'][i, SUMMER]))
                        for i in range(n)])
    seasonal = pd.concat(seasonal, ignore_index=True)
    seasonal.to_csv(out/'sensitivity_seasonal_driver_metrics.csv', index=False)
    pd.DataFrame(fallbacks).to_csv(out/'sensitivity_conditioning_audit.csv', index=False)
    pd.DataFrame(api_rows).to_csv(out/'sensitivity_api_alpha.csv', index=False)
    summary, contrast, shift = [], [], []
    metrics = seasonal.columns.difference(['configuration', 'storyline', 'sim'])
    for label, _, _ in configs:
        table = seasonal[seasonal.configuration.eq(label)]
        baseline = table[table.storyline.eq('baseline')].sort_values('sim')
        for story in STORIES:
            g = table[table.storyline.eq(story)].sort_values('sim')
            for key in metrics:
                v = g[key].to_numpy(float)
                summary.append(dict(configuration=label, storyline=story, metric=key, **_summary_row(v)))
                delta = v-baseline[key].to_numpy(float)
                contrast.append(dict(configuration=label, storyline=story, metric=key,
                                     mean_difference_from_baseline=float(delta.mean()),
                                     monte_carlo_se_difference=(float(delta.std(ddof=1)/np.sqrt(n)) if n>1 else np.nan)))
                delta_primary = v-primary_metrics[story][key]
                shift.append(dict(configuration=label, storyline=story, metric=key,
                                  mean_change_from_primary=float(delta_primary.mean()),
                                  monte_carlo_se_change=(float(delta_primary.std(ddof=1)/np.sqrt(n)) if n>1 else np.nan)))
    pd.DataFrame(summary).to_csv(out/'sensitivity_ensemble_summary.csv', index=False)
    pd.DataFrame(contrast).to_csv(out/'sensitivity_scenario_minus_baseline.csv', index=False)
    pd.DataFrame(shift).to_csv(out/'sensitivity_change_from_primary.csv', index=False)
    observed = []
    for year in range(2012, 2025):
        g = historical[historical.date.dt.year.eq(year)].set_index('date').reindex(
            pd.date_range(f'{year}-05-01', f'{year}-09-30'))
        observed.append(dict(year=year, **calendar_metrics(g.depth_mm.to_numpy(),
                        g.swvl1.to_numpy(), g.wind_speed.to_numpy())))
    observed = pd.DataFrame(observed)
    observed.to_csv(out/'baseline_adequacy_observed_years.csv', index=False)
    simulated_adequacy.to_csv(out/'baseline_adequacy_simulated_seasons.csv', index=False)
    adequacy = []
    for key in observed.columns.difference(['year']):
        v = observed[key].to_numpy(float)
        finite = v[np.isfinite(v)]
        s = _summary_row(simulated_adequacy[key].to_numpy(float))
        adequacy.append(dict(metric=key, n_observed_defined=len(finite),
            observed_mean=float(finite.mean()) if len(finite) else np.nan,
            observed_min=float(finite.min()) if len(finite) else np.nan,
            observed_max=float(finite.max()) if len(finite) else np.nan,
            **{'baseline_'+k: value for k, value in s.items()}))
    pd.DataFrame(adequacy).to_csv(out/'baseline_adequacy_summary.csv', index=False)
    (out/'sensitivity_interpretation.txt').write_text(
        'All donor-selection variants retain the same supplied circulation sequences and uniforms.\n'
        'Primary uses the configured conditioning setting and donor minimum; variants disable conditioning or use 10/30 donors.\n'
        'Simulation percentiles are central 95% conditional ranges, not confidence intervals. Monte Carlo SEs describe numerical precision only.\n'
        'API-alpha checks recompute a derived indicator on unchanged rainfall; no predictive models or warning decisions were rerun.\n'
        'Baseline adequacy comparisons are descriptive, using 13 observed summers and simulated seasons. No formal pass/fail test is applied.\n'
        'Observed means use available dates, with n_valid fields. Observed seasonal rainfall totals are unavailable unless all 153 dates are finite.\n'
        'Lag-one correlations and soil jumps use only consecutive finite calendar pairs. Missing rainfall breaks wet runs, making observed maximum runs lower bounds when dates are missing.\n'
        'The wet-day threshold is explicitly >=1 mm of daily SWEW domain-mean depth; it is a diagnostic threshold, not proof of local rainfall or contamination.\n'
        'Comparisons do not establish dynamical soil-water continuity, operational forecast skill, causality or contamination duration.\n', encoding='utf-8')
    return out


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('primary_run', type=Path)
    parser.add_argument('input_root', type=Path)
    parser.add_argument('--n-sims', type=int, default=5000)
    parser.add_argument('--seed', type=int, default=42)
    args = parser.parse_args()
    run_sensitivity(args.primary_run, args.input_root, n=args.n_sims, seed=args.seed)
