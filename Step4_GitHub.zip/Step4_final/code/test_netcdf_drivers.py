"""Synthetic checks; these do not validate the user's unavailable NetCDF files."""
import tempfile
import unittest
from pathlib import Path
import numpy as np
import pandas as pd
import xarray as xr
from netcdf_drivers import (_radiation_daily,_daily_mean,_combine,_spatial_mean,
                           _prepare,extract_meteorology,_read_radiation)

class NetCDFTests(unittest.TestCase):
    def _write_radiation(self,path,dates,values,how=None):
        dims=('time','latitude','longitude')
        coords={'time':dates,'latitude':[49.,52.],'longitude':[-6.,-2.]}
        values=np.asarray(values,float)
        data=np.broadcast_to(values[:,None,None],(len(dates),2,2)).copy()
        history=(f'earthkit.transforms.aggregate.temporal.daily_reduce(ssr, how={how}, time_shift=-1hour)' if how else '')
        xr.Dataset({'ssr':(dims,data,{'units':'J m**-2'})},coords=coords,
                   attrs={'history':history}).to_netcdf(path,engine='scipy')

    def test_daily_mean_energy_requires_verified_per_file_mode(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'mean.nc';self._write_radiation(p,pd.date_range('2012-04-01',periods=2),[3600.,7200.],how='mean')
            errors=[]
            with self.assertRaisesRegex(ValueError,'how=mean'):
                _read_radiation([p],'ssr',[],errors)
            self.assertEqual(errors[0]['file'],str(p))

    def test_verified_hourly_energy_mean_conversion_and_audit(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'mean.nc';self._write_radiation(p,pd.date_range('2012-04-01',periods=2),[3600.,7200.],how='mean')
            audit=[]
            daily,_=_read_radiation([p],'ssr',audit,[],file_modes={'mean.nc':'mean_hourly_energy_3600'})
            np.testing.assert_allclose(daily.to_numpy(),[1.,2.])
            # The old daily-total interpretation was lower by exactly24.
            np.testing.assert_allclose(daily.to_numpy(),24*np.array([3600.,7200.])/86400.)
            self.assertEqual(audit[0]['conversion_divisor_seconds'],3600.)
            self.assertEqual(audit[0]['source_aggregation'],'mean')
            self.assertEqual(audit[0]['declared_source_accumulation_period_seconds'],3600)

    def test_mixed_year_daily_sum_and_mean_harmonised_before_combining(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'sum.nc';q=Path(tmp)/'mean.nc'
            self._write_radiation(p,pd.date_range('2012-04-01',periods=2),[86400.,172800.],how='sum')
            self._write_radiation(q,pd.date_range('2013-04-01',periods=2),[3600.,7200.],how='mean')
            audit=[]
            daily,_=_read_radiation([p,q],'ssr',audit,[],file_modes={'mean.nc':'mean_hourly_energy_3600'})
            np.testing.assert_allclose(daily.to_numpy(),[1.,2.,1.,2.])
            self.assertEqual([a['conversion_divisor_seconds'] for a in audit],[86400.,3600.])

    def test_daily_sum_rejects_contradictory_hourly_mean_override(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'sum.nc';self._write_radiation(p,pd.date_range('2012-04-01',periods=1),[86400.],how='sum')
            with self.assertRaisesRegex(ValueError,'contradicts'):
                _read_radiation([p],'ssr',[],[],file_modes={'sum.nc':'mean_hourly_energy_3600'})

    def test_hourly_end_intervals_preserved_across_source_file_boundary(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'part1.nc';q=Path(tmp)/'part2.nc';dates=pd.date_range('2012-04-01 01:00',periods=24,freq='h')
            self._write_radiation(p,dates[:12],np.full(12,3600.))
            self._write_radiation(q,dates[12:],np.full(12,3600.))
            daily,_=_read_radiation([p,q],'ssr',[],[],mode='incremental_end')
            self.assertEqual(daily.loc[pd.Timestamp('2012-04-01')],1.)

    def test_daily_energy(self):
        s=pd.Series([86400.,172800.],index=pd.date_range('2012-04-01',periods=2))
        np.testing.assert_allclose(_radiation_daily(s,'J m**-2','auto','ssrd'),[1.,2.])

    def test_hourly_energy_requires_convention(self):
        s=pd.Series(3600.,index=pd.date_range('2012-04-01',periods=24,freq='h'))
        with self.assertRaisesRegex(ValueError,'ambiguous'):_radiation_daily(s,'J m-2','auto','ssrd')
        self.assertEqual(_radiation_daily(s,'J m-2','incremental_start','ssrd').iloc[0],1.)

    def test_cumulative_ends_and_partial_day(self):
        idx=pd.date_range('2012-04-01 01:00',periods=24,freq='h')
        s=pd.Series(np.arange(1,25)*3600.,index=idx)
        self.assertEqual(_radiation_daily(s,'J/m2','cumulative_end','ssrd').iloc[0],1.)
        self.assertTrue(_radiation_daily(s.iloc[:-1],'J/m2','cumulative_end','ssrd').isna().all())

    def test_static_ocean_mask_and_dynamic_missing(self):
        d=xr.DataArray([[.2,np.nan,.4],[.2,np.nan,np.nan]],dims=['time','longitude'],coords={'time':pd.date_range('2012-04-01',periods=2),'longitude':[-6.,-4.,-2.]})
        d=d.expand_dims(latitude=[50.])
        result=_spatial_mean(d,'latitude','longitude')
        self.assertAlmostEqual(float(result.isel(time=0)),.3)
        self.assertTrue(np.isnan(float(result.isel(time=1))))

    def test_partial_domain_rejected(self):
        a=xr.DataArray(np.ones((2,2,2)),dims=['time','latitude','longitude'],coords={'time':pd.date_range('2012-04-01',periods=2),'latitude':[49.,52.],'longitude':[-6.,-2.9]})
        with self.assertRaisesRegex(ValueError,'complete SWEW domain'):_prepare(a)

    def test_coordinate_roundoff_at_boundary(self):
        a=xr.DataArray(np.ones((2,2,2)),dims=['time','latitude','longitude'],coords={'time':pd.date_range('2012-04-01',periods=2),'latitude':[49.-4e-14,52.],'longitude':[-6.,-2.]})
        b,lat,lon,_=_prepare(a)
        self.assertEqual(b.sizes[lat],2)

    def test_duplicate_conflict(self):
        idx=pd.date_range('2012-04-01',periods=1)
        with self.assertRaisesRegex(ValueError,'conflicting'):_combine([pd.Series([1.],idx),pd.Series([2.],idx)],'test')

    def test_missing_hour_daily_mean(self):
        s=pd.Series(1.,index=pd.date_range('2012-04-01',periods=23,freq='h'))
        self.assertTrue(_daily_mean(s,'test').isna().all())

    def test_irregular_hour_spacing_not_daily_mean(self):
        idx=list(pd.date_range('2012-04-01',periods=24,freq='h'))
        idx[10]=idx[10]+pd.Timedelta(minutes=10)
        self.assertTrue(_daily_mean(pd.Series(1.,index=idx),'test').isna().all())

    def test_complete_extraction_and_wind_before_spatial_mean(self):
        with tempfile.TemporaryDirectory() as tmp:
            base=Path(tmp);dates=pd.date_range('2012-04-01',periods=2)
            dims=('time','latitude','longitude');coords={'time':dates,'latitude':[49.,52.],'longitude':[-6.,-2.]}
            def write(folder,variables):
                p=base/folder;p.mkdir(exist_ok=True)
                xr.Dataset(variables,coords=coords).to_netcdf(p/'test.nc',engine='scipy')
            shape=(2,2,2)
            u=np.broadcast_to([[3.,-3.],[3.,-3.]],shape).copy();v=np.broadcast_to([[4.,-4.],[4.,-4.]],shape).copy()
            write('wind',{'u10':(dims,u,{'units':'m s**-1'}),'v10':(dims,v,{'units':'m s**-1'})})
            for folder,key in [('UV','uvb'),('SSRD','ssrd')]:write(folder,{key:(dims,np.ones(shape)*86400,{'units':'J m**-2'})})
            write('t2m',{'t2m':(dims,np.ones(shape)*283.15,{'units':'K'})})
            write('Soil top layer',{'swvl1':(dims,np.ones(shape)*.3,{'units':'m**3 m**-3'})})
            d=extract_meteorology(base,base/'out',{})
            self.assertEqual(len(d),2379)
            np.testing.assert_allclose(d.loc[:1,'wind_speed'],[5.,5.])
            np.testing.assert_allclose(d.loc[:1,'t2m_C'],[10.,10.])
            self.assertEqual(d['ssrd_Wm2'].notna().sum(),2)
            self.assertTrue(d['ssr_Wm2'].isna().all())

if __name__=='__main__':unittest.main()
