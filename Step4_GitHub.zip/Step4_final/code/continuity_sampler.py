"""Previous-state conditional whole-day donor resampling for Step 4.

A nearest-neighbour successor bootstrap adapted to prescribed four-family
circulation sequences. Every selected current-day driver comes from one observed
current-day donor. Neighbours match the donor's observed previous-calendar-day
soil and wind to the simulated previous state. Complete pre-day log(1+p7) may
also enter the distance. No March values are inferred, missing values are not
filled, and circulation states are never changed.

This is a statistical continuity adjustment, not a dynamical soil-water model.
The square-root candidate-count neighbourhood is prespecified; k_factor permits
sensitivity checks. It must not be described as independently validated merely
because in-sample temporal diagnostics improve.
"""
import numpy as np
import pandas as pd
from step4_core import GROUPS, SIM_DATES, reconstruct_from_donors

STATUS = {
    0: 'previous soil/wind and pre-day p7 used',
    1: 'previous soil/wind only: p7 disabled',
    2: 'April 1 empirical same-family/month initialisation',
    3: 'previous soil/wind only: no complete observed p7 candidates',
    4: 'previous soil/wind only: simulated p7 incomplete',
}


def prepare_predecessors(lib, history):
    """Exact t-1 lookup; no joining across gaps or between annual seasons."""
    lib = lib.reset_index(drop=True).copy()
    history = history.copy()
    for d in (lib, history):
        d['date'] = pd.to_datetime(d['date']).dt.normalize()
        if d.date.duplicated().any():
            raise ValueError('Duplicate historical dates in continuity inputs')
    if not {'swvl1', 'wind_speed'} <= set(history):
        raise ValueError('History requires swvl1 and wind_speed')
    dates = lib.date - pd.Timedelta(days=1)
    previous = history.set_index('date')[['swvl1', 'wind_speed']].reindex(dates)
    # April 1 has no observed pre-season context in this study.
    valid_date = (dates.dt.year == lib.date.dt.year) & dates.dt.month.between(4, 9)
    lib['previous_calendar_date'] = dates
    lib['previous_swvl1'] = previous.swvl1.to_numpy(float)
    lib['previous_wind_speed'] = previous.wind_speed.to_numpy(float)
    lib.loc[~valid_date, ['previous_swvl1', 'previous_wind_speed']] = np.nan
    lib['has_previous_state'] = np.isfinite(
        lib[['previous_swvl1', 'previous_wind_speed']].to_numpy(float)).all(axis=1)
    if 'p7_before_mm' not in lib:
        lib['p7_before_mm'] = np.nan
    if (lib.p7_before_mm.dropna() < 0).any():
        raise ValueError('Negative antecedent rainfall cannot enter log1p distance')
    return lib


def _pool_record(lib, idx, use_p7, k_factor):
    features = [lib.loc[idx, 'previous_swvl1'].to_numpy(float),
                lib.loc[idx, 'previous_wind_speed'].to_numpy(float)]
    names = ['previous_swvl1', 'previous_wind_speed']
    if use_p7:
        features.append(np.log1p(lib.loc[idx, 'p7_before_mm'].to_numpy(float)))
        names.append('log1p_p7_before_mm')
    x = np.column_stack(features)
    if not np.isfinite(x).all():
        raise ValueError('Non-finite continuity matching features')
    scales = np.std(x, axis=0, ddof=1) if len(x) > 1 else np.zeros(x.shape[1])
    active = np.isfinite(scales) & (scales > np.finfo(float).eps)
    scales = np.where(active, scales, 1.)
    # Ignoring truly constant dimensions avoids introducing arbitrary unit floors.
    scaled = x[:, active] / scales[active]
    k = max(1, min(len(idx), int(np.ceil(float(k_factor) * np.sqrt(len(idx))))))
    probs = 1. / np.arange(1, k + 1)
    probs /= probs.sum()
    cumulative = np.cumsum(probs); cumulative[-1] = 1.
    return {'indices': idx, 'names': names, 'scales': scales,
            'active': active, 'scaled': scaled, 'k': k, 'cdf': cumulative}


def prepare_pools(lib, k_factor=1.):
    if not np.isfinite(k_factor) or k_factor <= 0:
        raise ValueError('k_factor must be finite and positive')
    pools, audit = {}, []
    for state in range(4):
        for month in range(4, 10):
            base = np.flatnonzero((lib.state.to_numpy() == state) &
                                  (lib.month.to_numpy() == month))
            if not len(base):
                raise ValueError(f'Empty donor pool: {GROUPS[state]}, month {month}')
            # Stable chronological input ordering determines any exact distance ties.
            base = base[np.argsort(lib.loc[base, 'date'].to_numpy(), kind='stable')]
            previous = base[lib.loc[base, 'has_previous_state'].to_numpy(bool)]
            if not len(previous):
                raise ValueError(f'No valid previous-state donor pool: {GROUPS[state]}, month {month}')
            wet = previous[np.isfinite(lib.loc[previous, 'p7_before_mm'].to_numpy(float))]
            plain = _pool_record(lib, previous, False, k_factor)
            conditioned = _pool_record(lib, wet, True, k_factor) if len(wet) else None
            pools[state, month] = {'base': base, 'previous': plain, 'p7': conditioned}
            for label, record in [('previous_state', plain), ('previous_state_and_p7', conditioned)]:
                audit.append({'state': state, 'family': GROUPS[state], 'month': month,
                    'matching': label, 'base_donors': len(base),
                    'matching_candidates': len(record['indices']) if record else 0,
                    'k_factor': k_factor, 'k': record['k'] if record else 0,
                    'soil_scale': record['scales'][0] if record else np.nan,
                    'wind_scale': record['scales'][1] if record else np.nan,
                    'logp7_scale': (record['scales'][2] if record and len(record['scales']) > 2 else np.nan),
                    'ignored_constant_features': (';'.join(n for n, a in zip(record['names'], record['active']) if not a)
                                                    if record else '')})
    return pools, pd.DataFrame(audit)


def _select(record, targets, uniforms):
    """Ranks are stable for exact ties; selection weights are proportional to 1/j."""
    valid = targets[:, record['active']] / record['scales'][record['active']]
    delta = valid[:, None, :] - record['scaled'][None, :, :]
    distances = np.sum(delta * delta, axis=2)
    order = np.argsort(distances, axis=1, kind='stable')[:, :record['k']]
    ranks = np.searchsorted(record['cdf'], uniforms, side='right')
    selected_position = order[np.arange(len(uniforms)), ranks]
    selected_donor = record['indices'][selected_position]
    selected_distance = np.sqrt(distances[np.arange(len(uniforms)), selected_position])
    closest_distance = np.sqrt(np.min(distances, axis=1))
    return selected_donor, ranks + 1, selected_distance, closest_distance


def sample_continuity(states, lib, history, columns, uniforms, alpha=.85,
                      k_factor=1., include_p7=True):
    """Return arrays, donor_row, status, diagnostics.

    Diagnostics dict keys: donor_library, pool_audit, chosen_rank,
    selected_standardised_distance, nearest_standardised_distance, status_counts.
    Status codes are defined by STATUS above. Every t>0 donor has an observed
    immediately preceding calendar day with soil/wind available. No cross-family
    or cross-month fallback is allowed. Rank/distance are zero/NaN on April 1. candidate_count and k_used there
    equal the unconditioned initialisation pool size.
    """
    states, uniforms = np.asarray(states), np.asarray(uniforms, float)
    if states.ndim != 2 or states.shape[1] != 183 or uniforms.shape != states.shape:
        raise ValueError('Expected states and uniforms of matching n × 183 shape')
    if not np.isin(states, np.arange(4)).all():
        raise ValueError('State codes must be 0..3')
    if not np.isfinite(uniforms).all() or (uniforms < 0).any() or (uniforms >= 1).any():
        raise ValueError('Uniform values must lie in [0,1)')
    if not 0 < alpha < 1:
        raise ValueError('API alpha must lie strictly between 0 and 1')
    if not {'depth_mm', 'swvl1', 'wind_speed'} <= set(columns):
        raise ValueError('Output columns must include depth_mm, swvl1 and wind_speed')
    prepared = prepare_predecessors(lib, history)
    if not np.isfinite(prepared[columns].to_numpy(float)).all():
        raise ValueError('All donor package values must be finite')
    pools, audit = prepare_pools(prepared, k_factor)
    source = prepared[columns].to_numpy(float)
    col = {c: i for i, c in enumerate(columns)}
    n, L = states.shape
    donor = np.empty((n, L), np.int32)
    status = np.zeros((n, L), np.int8)
    chosen_rank = np.zeros((n, L), np.int16)
    selected_distance = np.full((n, L), np.nan)
    candidate_count = np.zeros((n, L), np.int16)
    k_used = np.zeros((n, L), np.int16)
    nearest_distance = np.full((n, L), np.nan)
    values = np.empty((n, L, len(columns)), float)
    for t, month in enumerate(SIM_DATES.month):
        p7 = values[:, t-7:t, col['depth_mm']].sum(axis=1) if t >= 7 else None
        for state in range(4):
            sims = np.flatnonzero(states[:, t] == state)
            if not len(sims):
                continue
            pool = pools[state, int(month)]
            if t == 0:
                idx = pool['base']
                donor[sims, t] = idx[np.minimum((uniforms[sims, t] * len(idx)).astype(int), len(idx)-1)]
                status[sims, t] = 2
                candidate_count[sims, t] = len(idx)
                k_used[sims, t] = len(idx)
                continue
            use_p7 = include_p7 and p7 is not None and pool['p7'] is not None
            rec = pool['p7'] if use_p7 else pool['previous']
            targets = np.column_stack([values[sims, t-1, col['swvl1']],
                                       values[sims, t-1, col['wind_speed']]])
            if use_p7:
                targets = np.column_stack([targets, np.log1p(p7[sims])])
            ix, rank, dist, closest = _select(rec, targets, uniforms[sims, t])
            donor[sims, t] = ix
            chosen_rank[sims, t] = rank
            selected_distance[sims, t] = dist
            nearest_distance[sims, t] = closest
            candidate_count[sims, t] = len(rec['indices'])
            k_used[sims, t] = rec['k']
            status[sims, t] = (0 if use_p7 else
                              (1 if not include_p7 else (4 if p7 is None else 3)))
        values[:, t, :] = source[donor[:, t]]
    arrays = reconstruct_from_donors(prepared, donor, columns, alpha)
    # Source rows, family and month are immutable: this is a successor resampler.
    if not np.array_equal(prepared.state.to_numpy()[donor], states):
        raise AssertionError('Continuity donor family mismatch')
    if not np.array_equal(prepared.month.to_numpy()[donor], np.broadcast_to(SIM_DATES.month.to_numpy(), donor.shape)):
        raise AssertionError('Continuity donor month mismatch')
    diagnostics = {'donor_library': prepared, 'pool_audit': audit,
        'chosen_rank': chosen_rank, 'selected_rank': chosen_rank,
        'candidate_count': candidate_count, 'k_used': k_used,
        'nearest_distance': nearest_distance,
        'selected_standardised_distance': selected_distance,
        'nearest_standardised_distance': nearest_distance,
        'status_counts': {STATUS[c]: int(np.sum(status == c)) for c in STATUS}}
    return arrays, donor, status, diagnostics
