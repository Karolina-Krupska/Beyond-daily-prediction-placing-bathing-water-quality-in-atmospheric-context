"""Ensure compact simulations reconstruct from saved decimal float64 libraries."""
import io,unittest
import numpy as np
import pandas as pd
from step4_core import reconstruct_from_donors

class SavedRoundTripTests(unittest.TestCase):
    def test_all_driver_values_and_derived_arrays_round_trip(self):
        rng=np.random.default_rng(192)
        lib=pd.DataFrame({'depth_mm':rng.random(100)*37.5,
                          'wind_speed':rng.random(100)*11,
                          'swvl1':rng.random(100)*.6})
        donor=rng.integers(0,100,size=(3,183))
        columns=['depth_mm','wind_speed','swvl1']
        expected=reconstruct_from_donors(lib,donor,columns)
        saved=io.StringIO();lib.to_csv(saved,index=False);saved.seek(0)
        recovered=pd.read_csv(saved,float_precision='round_trip')
        np.testing.assert_array_equal(recovered.to_numpy(),lib.to_numpy())
        actual=reconstruct_from_donors(recovered,donor,columns)
        for key in expected:
            np.testing.assert_array_equal(actual[key],expected[key])

if __name__=='__main__':unittest.main()
