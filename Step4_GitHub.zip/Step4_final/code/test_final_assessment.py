import unittest,numpy as np,pandas as pd
from validate_continuity import extended_metrics
from year_uncertainty import bootstrap_annual_means

class FinalAssessmentTests(unittest.TestCase):
    def test_tail_quantiles_keep_missing_values_out_of_denominator(self):
        rain=np.arange(153,dtype=float);rain[0]=np.nan
        intensity=np.full(153,16.);intensity[1]=np.nan
        r=extended_metrics(rain,np.full(153,.3),np.full(153,5.),intensity,np.full(153,12.))
        self.assertAlmostEqual(r['p95_depth_mm'],np.nanquantile(rain,.95))
        self.assertEqual(r['fraction_intensity_q95_ge16mmph'],1.)
        self.assertTrue(np.isnan(r['rainfall_season_total_mm']))
    def test_within_summer_calendar_boundaries(self):
        month=np.repeat(np.arange(5),[31,30,31,31,30]).astype(float)
        r=extended_metrics(np.ones(153),.2+.01*month,np.ones(153),np.ones(153),month)
        self.assertEqual(r['mean_absolute_t2m_month_boundary_change'],1.)
        self.assertAlmostEqual(r['mean_absolute_soil_month_boundary_change'],.01)
        self.assertAlmostEqual(r['mean_absolute_t2m_change'],4/152)
    def test_year_bootstrap_resamples_whole_rows_and_is_reproducible(self):
        a=pd.DataFrame({'year':range(2012,2025),'x':np.arange(13,dtype=float),'twice_x':2*np.arange(13,dtype=float),'constant':3.})
        r,w=bootstrap_annual_means(a,n_boot=1000);rr,ww=bootstrap_annual_means(a,n_boot=1000)
        pd.testing.assert_frame_equal(r,rr);pd.testing.assert_frame_equal(w,ww)
        self.assertTrue((w.sum(axis=1)==13).all())
        q=r.set_index('metric');self.assertEqual(q.loc['constant','year_bootstrap_ci025'],3.)
        self.assertAlmostEqual(q.loc['twice_x','year_bootstrap_ci975'],2*q.loc['x','year_bootstrap_ci975'])
if __name__=='__main__':unittest.main()
