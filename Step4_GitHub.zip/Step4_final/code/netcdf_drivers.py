"""Strict daily ERA extraction for Step 4; no missing-value imputation.

Domain: regular latitude/longitude grid-cell centres inside 49–52 N, 6–2 W.
Area means use cosine(latitude). Already spatially reduced time series are
accepted and flagged; their original domain cannot be verified here.
Daily radiation is converted according to each file's aggregation history.
A daily mean of hourly accumulated energy is NOT a daily energy total: it
requires a verified per-file mean_hourly_energy_3600 declaration. Subdaily
accumulations require an explicit convention. See module error messages.
"""
from pathlib import Path
import hashlib
import json
import re
import numpy as np
import pandas as pd
import xarray as xr

FOLDERS = {'wind':'wind','swvl1':'Soil top layer','ssr':'SSR','ssrd':'SSRD','t2m':'t2m','uvb':'UV'}
ALIASES = {'u10':['u10','10m_u_component_of_wind','u_component_of_wind'],
 'v10':['v10','10m_v_component_of_wind','v_component_of_wind'],
 'swvl1':['swvl1','volumetric_soil_water_layer_1'],
 't2m':['t2m','2m_temperature'],'ssr':['ssr'],'ssrd':['ssrd'],'uvb':['uvb']}


def _unit(s):
    return re.sub(r'[\s_{}^*·()]','',str(s).lower()).replace('−','-').replace('²','2').replace('³','3')


def _var(ds, key):
    names={n.lower():n for n in ds.data_vars}
    for alias in ALIASES[key]:
        if alias.lower() in names:return names[alias.lower()]
    return None


def _prepare(da):
    # Explicitly combine ERA expver versions only where their finite values agree.
    if 'expver' in da.dims:
        merged=da.isel(expver=0,drop=True)
        for j in range(1,da.sizes['expver']):
            other=da.isel(expver=j,drop=True)
            conflict=(merged.notnull()&other.notnull()&(~np.isclose(merged,other,rtol=1e-6,atol=1e-8)))
            if bool(conflict.any().item()):raise ValueError('Conflicting overlapping expver values')
            merged=merged.combine_first(other)
        da=merged
    time=next((n for n in ['time','valid_time','date'] if n in da.dims),None)
    if time is None:raise ValueError('No one-dimensional time/valid_time/date dimension')
    if time!='time':da=da.rename({time:'time'})
    for d in list(da.dims):
        if d not in ['time','latitude','longitude','lat','lon']:
            if da.sizes[d]==1:da=da.isel({d:0},drop=True)
            else:raise ValueError(f'Unresolved dimension {d!r}; select the correct level/member/forecast step explicitly')
    lat=next((n for n in ['latitude','lat'] if n in da.coords and n in da.dims),None)
    lon=next((n for n in ['longitude','lon'] if n in da.coords and n in da.dims),None)
    mode='already_spatially_reduced_domain_unverified'
    if lat or lon:
        if not(lat and lon) or da[lat].ndim!=1 or da[lon].ndim!=1:raise ValueError('Need both one-dimensional latitude/longitude coordinates')
        lv=da[lat].values.astype(float);ov=da[lon].values.astype(float)
        if not(np.isfinite(lv).all() and np.isfinite(ov).all()):raise ValueError('Non-finite geographic coordinates')
        if np.max(np.abs(lv))>90 or np.max(np.abs(ov))>360:raise ValueError('Coordinates are not geographic degrees')
        da=da.assign_coords({lon:((da[lon]+180)%360)-180})
        tolerance=1e-8
        if (float(da[lat].min())>49+tolerance or float(da[lat].max())<52-tolerance or
            float(da[lon].min())>-6+tolerance or float(da[lon].max())<-2-tolerance):
            raise ValueError('Source geographic grid does not span the complete SWEW domain 49–52 N, 6–2 W')
        da=da.where((da[lat]>=49-1e-8)&(da[lat]<=52+1e-8),drop=True).where((da[lon]>=-6-1e-8)&(da[lon]<=-2+1e-8),drop=True)
        if not da.sizes[lat] or not da.sizes[lon]:raise ValueError('No grid-cell centres inside SWEW domain')
        for name in [lat,lon]:
            v=np.sort(np.unique(da[name].values))
            if len(v)>2 and not np.allclose(np.diff(v),np.diff(v)[0],rtol=1e-4,atol=1e-6):
                raise ValueError('Irregular grid requires cell-area weights; cosine weighting is not sufficient')
        mode='SWEW_grid_centres_cosine_latitude_area_mean'
    return da,lat,lon,mode


def _support_signature(da,lat,lon):
    if lat is None:return 'already_reduced'
    support=da.notnull().any('time')
    payload=(np.round(np.asarray(da[lat].values,dtype=float),8).tobytes()+
             np.round(np.asarray(da[lon].values,dtype=float),8).tobytes()+
             np.asarray(support.values,dtype=bool).tobytes())
    return hashlib.sha256(payload).hexdigest()


def _spatial_mean(da,lat,lon):
    if lat is None:return da
    # ERA5-Land soil has a static ocean mask. Exclude only cells missing for the
    # entire source file; varying missingness within the remaining support makes
    # that timestamp missing, so daily means never silently use changing areas.
    support=da.notnull().any('time')
    weights=np.cos(np.deg2rad(da[lat])).broadcast_like(support).where(support,0.)
    if not bool(support.any().item()):return da.mean([lat,lon],skipna=False)
    value=da.weighted(weights).mean([lat,lon],skipna=True)
    dynamic_missing=(support&da.isnull()).any([lat,lon])
    return value.where(~dynamic_missing)


def _series(da):
    if da.dims!=('time',):da=da.transpose('time')
    idx=pd.DatetimeIndex(pd.to_datetime(da.time.values))
    if idx.tz is not None:idx=idx.tz_convert('UTC').tz_localize(None)
    return pd.Series(np.asarray(da.values,dtype=float),index=idx).sort_index()


def _combine(parts,label):
    if not parts:raise ValueError('No usable records for '+label)
    s=pd.concat(parts).sort_index()
    # Duplicate identical records may arise from overlapping downloads. Conflicts fail.
    if s.index.has_duplicates:
        for t,g in s.groupby(level=0):
            finite=g.dropna()
            if len(finite)>1 and not np.allclose(finite,finite.iloc[0],rtol=1e-6,atol=1e-8):
                raise ValueError(f'{label}: conflicting duplicate timestamp {t}')
        s=s.groupby(level=0).first()
    if np.isinf(s.to_numpy()).any():raise ValueError(label+': infinite values')
    return s


def _daily_mean(s,label):
    counts=s.groupby(s.index.normalize()).size()
    if counts.max()==1:return s.groupby(s.index.normalize()).first()
    delta=s.index.to_series().diff().dropna().dt.total_seconds()
    freq=float(delta.mode().iloc[0])
    if freq<=0 or freq>86400 or not np.isclose(86400/freq,round(86400/freq)):
        raise ValueError(label+': unsupported subdaily interval; expected equally spaced intervals dividing 24 hours')
    expected=int(round(86400/freq))
    # Equal intervals make an arithmetic mean equivalent to time weighting. Reject
    # incomplete days rather than treating a partial-day average as a daily mean.
    out=s.resample('D').mean();n=s.resample('D').count();size=s.resample('D').size()
    regular={}
    for day,g in s.groupby(s.index.normalize()):
        intervals=np.diff(g.index.asi8)/1e9
        regular[day]=len(g)==expected and np.all(np.isclose(intervals,freq,rtol=0,atol=1e-6))
    regular=pd.Series(regular).reindex(out.index,fill_value=False)
    return out.where((n==expected)&(size==expected)&regular)


def _radiation_daily(s,unit,mode,label):
    u=_unit(unit)
    flux=u in ['wm-2','w/m2','wm2']
    energy=u in ['jm-2','j/m2','jm2','mjm-2','mj/m2','mjm2']
    if not(flux or energy):raise ValueError(f'{label}: unsupported radiation units {unit!r}; supply a verified unit override')
    if (s.dropna() < -1e-7).any():raise ValueError(label+': negative radiation; inspect accumulation convention')
    if flux:return _daily_mean(s,label)
    if u.startswith('mj'):s=s*1e6
    perday=s.groupby(s.index.normalize()).size()
    if perday.max()==1:
        if mode not in ['auto','daily_total']:raise ValueError(label+': subdaily mode requested but only daily records supplied')
        return s.groupby(s.index.normalize()).first()/86400.
    if mode in ['auto','daily_total']:
        raise ValueError(f'{label}: subdaily J/m2 is ambiguous. Set radiation_modes["{label}"] to incremental_start, incremental_end or cumulative_end ONLY after checking source metadata.')
    if mode not in ['incremental_start','incremental_end','cumulative_end']:raise ValueError('Unknown radiation mode: '+mode)
    delta=s.index.to_series().diff().dropna().dt.total_seconds();freq=float(delta.mode().iloc[0])
    if freq!=3600:raise ValueError(label+': explicit subdaily energy modes currently require hourly data')
    if ((s.index.minute!=0)|(s.index.second!=0)|(s.index.microsecond!=0)|(s.index.nanosecond!=0)).any():
        raise ValueError(label+': hourly accumulated energy timestamps must fall exactly on the hour')
    if mode=='cumulative_end':
        # ERA5-Land daily accumulation: 01 UTC first hour, 00 UTC final hour.
        labels=(s.index-pd.Timedelta(seconds=1)).normalize();increments=[]
        for date,g in s.groupby(labels):
            target=pd.date_range(date+pd.Timedelta(hours=1),periods=24,freq='h')
            if not g.index.equals(target):
                increments.append(pd.Series(np.nan,index=g.index));continue
            vals=g.diff();vals.iloc[0]=g.iloc[0]
            if (vals.dropna()<-1e-7).any():raise ValueError(label+': cumulative_end values decrease within accumulation day')
            increments.append(vals)
        s=pd.concat(increments).sort_index()
    idx=s.index if mode=='incremental_start' else s.index-pd.Timedelta(seconds=1)
    s=pd.Series(s.values,index=idx)
    out=s.resample('D').sum(min_count=24)/86400.
    return out.where(s.resample('D').count()==24)


def _read_scalar(files,key,provenance,errors):
    parts=[];units=set();modes=set();supports=set()
    for path in files:
        try:
            with xr.open_dataset(path) as ds:
                var=_var(ds,key)
                if var is None:continue
                da,lat,lon,mode=_prepare(ds[var]);units.add(str(da.attrs.get('units','')));modes.add(mode)
                da=da.sel(time=slice('2012-04-01','2024-10-01'))
                if da.sizes['time']==0:continue
                supports.add(_support_signature(da,lat,lon))
                if len(supports)>1:raise ValueError(f'{key}: grid or static missing-cell mask differs between files; harmonise spatial support explicitly')
                s=_series(_spatial_mean(da,lat,lon));parts.append(s)
                provenance.append({'variable':key,'file':str(path),'source_variable':var,'source_history':ds.attrs.get('history',''),'source_cell_methods':da.attrs.get('cell_methods',''),'source_time_shift':str(ds[next((n for n in ['time','valid_time','date'] if n in ds.coords),'time')].attrs.get('time_shift','')),'units':str(da.attrs.get('units','')),'spatial_method':mode,'records':len(s),'first_time':str(s.index.min()),'last_time':str(s.index.max()),'spatial_support_signature':_support_signature(da,lat,lon),'mask_policy':'Static always-missing cells excluded; dynamic missingness makes the timestamp missing; fixed support checked across files'})
        except Exception as e:errors.append({'file':str(path),'variable':key,'error':str(e)});raise
    if len(units)>1:raise ValueError(f'{key}: inconsistent source units {units}; harmonise source files explicitly')
    return _combine(parts,key),next(iter(units)),modes


def _daily_aggregation(history):
    """Return the last daily_reduce aggregation recorded in source history."""
    found=re.findall(r'daily_reduce\([^\n]*?\bhow\s*=\s*[\'\"]?(sum|mean)\b',str(history))
    return found[-1] if found else 'unknown'


def _convert_daily_radiation(s,unit,source_how,file_mode,label,path):
    """Convert one already-daily source before combining it with other files.

    mean_hourly_energy_3600 is an explicit assertion about the source period,
    not an inference from its retained J/m2 units or GRIB_stepUnits metadata.
    """
    u=_unit(unit)
    flux=u in ['wm-2','w/m2','wm2']
    energy=u in ['jm-2','j/m2','jm2','mjm-2','mj/m2','mjm2']
    if not(flux or energy):
        raise ValueError(f'{label}: unsupported radiation units {unit!r}')
    if file_mode not in [None,'auto','daily_total','mean_hourly_energy_3600']:
        raise ValueError(f'{label}: file mode {file_mode!r} is not valid for already-daily records')
    if flux:
        if source_how=='sum':
            raise ValueError(f'{path.name}: daily sum of flux values in W/m2 needs its source sampling convention; do not treat it as a daily mean')
        if file_mode=='mean_hourly_energy_3600':
            raise ValueError(f'{path.name}: mean_hourly_energy_3600 requires energy units, not W/m2')
        return _radiation_daily(s,unit,'auto',label),1.,'flux_daily_mean',''
    if source_how=='mean' and file_mode!='mean_hourly_energy_3600':
        raise ValueError(f'{path.name}: source history records daily_reduce how=mean for accumulated energy in {unit}. '
            'It is not a complete daily energy total. Verify the original accumulation period and declare '
            'radiation_file_modes["'+path.name+'"]="mean_hourly_energy_3600" ONLY if it is the mean of ERA5 one-hour accumulations; '
            'otherwise supply correctly aggregated source data.')
    if file_mode=='mean_hourly_energy_3600':
        if source_how=='sum':
            raise ValueError(f'{path.name}: mean_hourly_energy_3600 contradicts daily_reduce how=sum')
        if (s.dropna() < -1e-7).any():
            raise ValueError(label+': negative radiation; inspect source values')
        scale=1e6 if u.startswith('mj') else 1.
        result=(s*scale).groupby(s.index.normalize()).first()/3600.
        note='Explicit per-file declaration: daily mean of one-hour accumulated energies; source period=3600s. Not inferred from units.'
        return result,3600.,'mean_hourly_energy_3600',note
    result=_radiation_daily(s,unit,'daily_total',label)
    note=('Source daily_reduce how=sum: complete daily accumulated energy.' if source_how=='sum' else
          'Aggregation history unavailable: daily energy total assumed from one daily record; verify source period.')
    return result,86400.,'daily_total',note


def _read_radiation(files,key,provenance,errors,mode='auto',unit_override=None,file_modes=None):
    """Harmonise file-specific radiation semantics before daily concatenation.

    Subdaily files with the same verified unit/mode are combined before daily
    reduction, preserving intervals that cross file boundaries at midnight.
    """
    file_modes=file_modes or {}
    daily_parts=[];subdaily={};modes=set();supports=set()
    for path in files:
        try:
            with xr.open_dataset(path) as ds:
                var=_var(ds,key)
                if var is None:continue
                da,lat,lon,spatial_mode=_prepare(ds[var])
                da=da.sel(time=slice('2012-04-01','2024-10-01'))
                if da.sizes['time']==0:continue
                signature=_support_signature(da,lat,lon);supports.add(signature)
                if len(supports)>1:
                    raise ValueError(f'{key}: grid or static missing-cell mask differs between files; harmonise spatial support explicitly')
                source_unit=str(da.attrs.get('units',''));unit=unit_override or source_unit
                history=ds.attrs.get('history','');how=_daily_aggregation(history)
                s=_combine([_series(_spatial_mean(da,lat,lon))],key)
                perday=s.groupby(s.index.normalize()).size()
                record_mode=file_modes.get(path.name)
                if perday.max()==1:
                    effective_mode=record_mode
                    if effective_mode is None and mode not in ['auto','daily_total']:
                        raise ValueError(f'{path.name}: subdaily mode {mode!r} requested for already-daily records')
                    result,divisor,effective_mode,note=_convert_daily_radiation(s,unit,how,effective_mode,key,path)
                    daily_parts.append(result)
                    source_period=3600 if effective_mode=='mean_hourly_energy_3600' else ''
                else:
                    effective_mode=record_mode or mode
                    if effective_mode=='mean_hourly_energy_3600':
                        raise ValueError(f'{path.name}: mean_hourly_energy_3600 is for already-daily means, not subdaily data')
                    subdaily.setdefault((_unit(unit),effective_mode,unit),[]).append(s)
                    divisor='see explicit subdaily mode';source_period='see explicit subdaily mode'
                    note='Subdaily files are combined by compatible unit/mode before daily reduction, preserving midnight intervals.'
                modes.add(spatial_mode)
                provenance.append({'variable':key,'file':str(path),'source_variable':var,
                    'source_history':history,'source_cell_methods':da.attrs.get('cell_methods',''),
                    'source_aggregation':how,'source_units':source_unit,'units':unit,'output_units':'W m-2',
                    'radiation_file_mode':effective_mode,'conversion_divisor_seconds':divisor,
                    'declared_source_accumulation_period_seconds':source_period,
                    'spatial_method':spatial_mode,'spatial_support_signature':signature,
                    'records':len(s),'first_time':str(s.index.min()),'last_time':str(s.index.max()),
                    'note':note+' Supplied daily_reduce time shift has already been applied; no additional date shift.'})
        except Exception as e:
            errors.append({'file':str(path),'variable':key,'error':str(e)});raise
    for (_,record_mode,unit),parts in subdaily.items():
        daily_parts.append(_radiation_daily(_combine(parts,key),unit,record_mode,key))
    return _combine(daily_parts,key),modes


def _read_wind(files,provenance,errors):
    infos=[]
    for p in files:
        try:
            with xr.open_dataset(p) as ds:
                u=_var(ds,'u10');v=_var(ds,'v10')
                if u or v:
                    da,_,_,_=_prepare(ds[u or v]);t=pd.DatetimeIndex(pd.to_datetime(da.time.values))
                    infos.append((p,u,v,t.min(),t.max()))
        except Exception as e:errors.append({'file':str(p),'variable':'wind','error':str(e)});raise
    parts=[];supports=set()
    for p,u,_,lo,hi in infos:
        if not u:continue
        for q,_,v,lo2,hi2 in infos:
            if not v or hi2<lo or lo2>hi:continue
            try:
                with xr.open_dataset(p) as ds1,xr.open_dataset(q) as ds2:
                    a,lat,lon,mode=_prepare(ds1[u]);b,lat2,lon2,mode2=_prepare(ds2[v])
                    for da in [a,b]:
                        if _unit(da.attrs.get('units','')) not in ['ms-1','m/s','ms1']:
                            raise ValueError('Wind components require m/s units')
                    common=np.intersect1d(a.time.values,b.time.values)
                    common=common[(common>=np.datetime64('2012-04-01'))&(common<np.datetime64('2024-10-01'))]
                    if not len(common):continue
                    if (lat,lon)!=(lat2,lon2):raise ValueError('Wind component coordinates differ')
                    a,b=xr.align(a.sel(time=common),b.sel(time=common),join='exact')
                    speed=np.hypot(a,b)
                    supports.add(_support_signature(speed,lat,lon))
                    if len(supports)>1:raise ValueError('wind_speed: grid or static missing-cell mask differs between files')
                    s=_series(_spatial_mean(speed,lat,lon));parts.append(s)
                    provenance.append({'variable':'wind_speed','file':str(p)+' | '+str(q),'source_variable':u+' | '+v,'source_history':ds1.attrs.get('history','')+' | '+ds2.attrs.get('history',''),'units':'m s-1','spatial_method':mode,'records':len(s),'first_time':str(s.index.min()),'last_time':str(s.index.max()),'note':('Magnitude calculated per grid cell from supplied components before area mean; daily-mean components give daily-vector magnitude, not daily mean instantaneous speed' if lat is not None else 'Magnitude of supplied spatial-mean wind components; not the spatial mean of wind-speed magnitude')})
            except Exception as e:errors.append({'file':str(p)+' | '+str(q),'variable':'wind','error':str(e)});raise
    return _daily_mean(_combine(parts,'wind_speed'),'wind_speed')


def extract_meteorology(base_dir,output_dir,radiation_modes=None,radiation_unit_overrides=None,excluded_source_files=None,radiation_file_modes=None):
    """Read local input folders, write audit CSVs and return Apr–Sep daily table.

    Required radiation_modes keys are uvb/ssrd/ssr when overriding 'auto'.
    Unit overrides affect only radiation and must be verified against the source.
    Source timestamps are treated as UTC. No missing driver values are filled.
    excluded_source_files lists exact basenames to exclude explicitly; exclusions
    are written to the error audit and their missing dates are not imputed.
    radiation_file_modes maps exact basenames to verified file-specific modes.
    mean_hourly_energy_3600 explicitly declares a daily mean of ERA5 one-hour
    accumulated energies; it is never inferred from J/m2 or GRIB_stepUnits.
    """
    base_dir=Path(base_dir);output_dir=Path(output_dir);output_dir.mkdir(parents=True,exist_ok=True)
    radiation_modes=radiation_modes or {};radiation_unit_overrides=radiation_unit_overrides or {}
    radiation_file_modes=radiation_file_modes or {}
    excluded_source_files=set(excluded_source_files or [])
    provenance=[];errors=[]
    calendar=pd.date_range('2012-04-01','2024-09-30',freq='D');calendar=calendar[calendar.month.isin([4,5,6,7,8,9])]
    out=pd.DataFrame(index=calendar);out.index.name='date'
    try:
        for key,folder in FOLDERS.items():
            files=sorted(p for p in (base_dir/folder).rglob('*') if p.is_file() and p.suffix.lower() in ['.nc','.nc4','.cdf']) if (base_dir/folder).exists() else []
            kept_files=[]
            for source_path in files:
                if source_path.name in excluded_source_files:
                    errors.append({'file':str(source_path),'variable':key,'error':'EXCLUDED_EXPLICITLY_BY_CONFIGURATION; data remain missing, not replaced'})
                else:kept_files.append(source_path)
            files=kept_files
            if not files:
                if key=='ssr':out['ssr_Wm2']=np.nan;continue
                raise FileNotFoundError(f'No NetCDF files in {base_dir/folder}')
            print(f'[ERA] {folder}: {len(files)} files',flush=True)
            if key=='wind':out['wind_speed']=_read_wind(files,provenance,errors);continue
            if key in ['uvb','ssrd','ssr']:
                out[key+'_Wm2'],_= _read_radiation(files,key,provenance,errors,
                    mode=radiation_modes.get(key,'auto'),unit_override=radiation_unit_overrides.get(key),file_modes=radiation_file_modes)
                continue
            s,unit,spatial_modes=_read_scalar(files,key,provenance,errors)
            if key=='t2m':
                u=_unit(unit)
                if u in ['k','kelvin']:s=s-273.15
                elif u not in ['c','degc','degreecelsius','degreescelsius','celsius','°c']:raise ValueError(f'Unsupported temperature units {unit!r}')
                out['t2m_C']=_daily_mean(s,key)
            elif key=='swvl1':
                if _unit(unit) not in ['m3m-3','m3/m3','m3m3','1','fraction']:raise ValueError(f'Unsupported soil-water units {unit!r}')
                if ((s.dropna()<0)|(s.dropna()>1)).any():raise ValueError('Soil moisture outside volumetric fraction range [0,1]')
                out['swvl1']=_daily_mean(s,key)
        cols=['wind_speed','uvb_Wm2','ssrd_Wm2','ssr_Wm2','t2m_C','swvl1']
        out=out.reindex(columns=cols)
        coverage=[]
        for (year,month),g in out.groupby([out.index.year,out.index.month]):
            for c in cols:coverage.append({'year':year,'month':month,'variable':c,'expected_days':len(g),'available_days':int(g[c].notna().sum()),'missing_days':int(g[c].isna().sum())})
        pd.DataFrame(coverage).to_csv(output_dir/'meteorology_coverage.csv',index=False)
        out.to_csv(output_dir/'meteorology_daily_AprSep.csv')
        if out[['wind_speed','uvb_Wm2','ssrd_Wm2','t2m_C','swvl1']].notna().sum().min()==0:
            raise ValueError('At least one required variable has no daily values in Apr–Sep2012–2024; inspect coverage and time conventions')
        return out.reset_index()
    finally:
        pd.DataFrame(provenance).to_csv(output_dir/'meteorology_provenance.csv',index=False)
        pd.DataFrame(errors,columns=['file','variable','error']).to_csv(output_dir/'meteorology_source_errors.csv',index=False)
