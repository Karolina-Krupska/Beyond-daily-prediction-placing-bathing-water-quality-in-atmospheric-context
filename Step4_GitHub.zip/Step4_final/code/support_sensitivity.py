"""Bounded input-support sensitivity; count flags are not validated QC limits.
Primary observations and donor library are never changed. Recalculate historical
p7/API after flagged rain is made missing and before constructing donor pools.
"""
from pathlib import Path
import sys,json,hashlib
import numpy as np,pandas as pd
from step4_core import antecedents,load_sequences,season_metrics,GROUPS
from continuity_sampler import sample_continuity,prepare_predecessors,prepare_pools
from continuity_sensitivity import temporal_metrics_batch

def metrics(arrays,status):
    values=season_metrics(arrays,status)
    values['matching_with_p7_fraction']=values.pop('conditioning_applied_fraction')
    values['matching_without_observed_p7_fraction']=values.pop('conditioning_sparse_pool_fraction')
    values.update(temporal_metrics_batch(arrays))
    return values

def run_support(run_root,input_root,n=1000):
    RUN=Path(run_root);OUT=RUN/'results/support_sensitivity';OUT.mkdir(parents=True,exist_ok=True)
    if not 1<=n<=5000:raise ValueError('n must be1..5000')
    hpath=RUN/'prepared/historical_daily_calendar.csv'
    before=hashlib.sha256(hpath.read_bytes()).hexdigest()
    history=pd.read_csv(hpath,parse_dates=['date'],float_precision='round_trip')
    meta=json.loads((RUN/'run_metadata.json').read_text())
    columns=meta['driver_columns'];alpha=float(meta['api_alpha'])
    modes=history.total_samples.dropna().mode()
    if len(modes)!=1:raise ValueError('Support-count mode is ambiguous')
    modal=float(modes.iloc[0]);ratio=history.total_samples/modal
    screen=ratio.lt(.8)|ratio.gt(1.05)
    flags=history[['date','year','month','regime','family','state','total_samples','depth_mm','intensity_q95_mmph','donor_eligible']].copy()
    flags['count_ratio_to_mode']=ratio
    flags['status']=np.select([ratio.isna(),ratio.lt(.8),ratio.gt(1.05)],['original_count_unavailable','screen_below_0.8','screen_above_1.05'],default='within_descriptive_band')
    flags['screened_in_sensitivity']=screen
    flags.to_csv(OUT/'rainfall_count_support_flags_all_dates.csv',index=False)
    screened=history.copy()
    screened.loc[screen,['depth_mm','intensity_q95_mmph']]=np.nan
    screened['rainfall_available']=screened.depth_mm.notna()
    screened=antecedents(screened,alpha)
    screened['donor_eligible']=np.isfinite(screened[columns].to_numpy(float)).all(axis=1)
    screened.to_csv(OUT/'sensitivity_only_historical_daily_calendar.csv',index=False)
    lib_primary=pd.read_csv(RUN/'prepared/historical_donor_library.csv',parse_dates=['date'],float_precision='round_trip').reset_index(drop=True)
    lib_screen=screened[screened.donor_eligible].copy().reset_index(drop=True)
    lib_screen.to_csv(OUT/'sensitivity_only_donor_library.csv',index=False)
    audit=[]
    for config,lib,hist in [('primary_noqc',lib_primary,history),('count_support_screen',lib_screen,screened)]:
        p=prepare_predecessors(lib,hist);_,pools=prepare_pools(p,1.)
        pools.insert(0,'configuration',config);audit.append(pools)
    pd.concat(audit,ignore_index=True).to_csv(OUT/'coverage_support_pool_comparison.csv',index=False)
    seq=load_sequences(Path(input_root),n)
    seed=int(meta['seed'])
    uniforms=np.random.default_rng(np.random.SeedSequence([seed,4])).random((n,183))
    seasons=[];means=[];contrasts=[];primary={}
    for config,lib,hist in [('primary_noqc',lib_primary,history),('count_support_screen',lib_screen,screened)]:
        for story,states in seq.items():
            print(config,story,flush=True)
            arrays,donor,status,diag=sample_continuity(states,lib,hist,columns,uniforms,alpha,k_factor=1.,include_p7=True)
            m=metrics(arrays,status)
            seasons.append(pd.DataFrame({'configuration':config,'storyline':story,'sim':np.arange(n),**m}))
            if config=='primary_noqc':primary[story]=m
            for name,v in m.items():
                v=np.asarray(v,float);valid=v[np.isfinite(v)]
                means.append(dict(configuration=config,storyline=story,metric=name,n_defined=len(valid),mean=np.mean(valid) if len(valid) else np.nan,
                    simulation_p025=np.quantile(valid,.025) if len(valid) else np.nan,simulation_p975=np.quantile(valid,.975) if len(valid) else np.nan,
                    monte_carlo_se_mean=np.std(valid,ddof=1)/np.sqrt(len(valid)) if len(valid)>1 else np.nan))
                if config=='count_support_screen':
                    delta=v-primary[story][name];finite=delta[np.isfinite(delta)]
                    contrasts.append(dict(storyline=story,metric=name,n_paired=len(finite),mean_change_from_primary=np.mean(finite) if len(finite) else np.nan,
                        monte_carlo_se_change=np.std(finite,ddof=1)/np.sqrt(len(finite)) if len(finite)>1 else np.nan))
    pd.concat(seasons,ignore_index=True).to_csv(OUT/'coverage_support_seasonal_metrics.csv',index=False)
    pd.DataFrame(means).to_csv(OUT/'coverage_support_ensemble_summary.csv',index=False)
    pd.DataFrame(contrasts).to_csv(OUT/'coverage_support_paired_changes.csv',index=False)
    metadata={'status':'completed','modal_histogram_count':modal,'descriptive_count_ratio_band':[.8,1.05],
        'n_calendar_dates':len(history),'originally_unavailable_counts':int(ratio.isna().sum()),'screen_flagged_dates':int(screen.sum()),
        'screen_below':int(ratio.lt(.8).sum()),'screen_above':int(ratio.gt(1.05).sum()),
        'flagged_original_complete_donors':int((screen&history.donor_eligible).sum()),
        'primary_complete_donors':len(lib_primary),'screened_complete_donors':len(lib_screen),
        'previously_complete_p7_before_lost':int((history.p7_before_mm.notna()&screened.p7_before_mm.isna()).sum()),
        'previously_complete_p7_endday_lost':int((history.p7_mm.notna()&screened.p7_mm.isna()).sum()),
        'n_sims_per_scenario':n,'seed_sequence':[seed,4],'same_circulation_states_and_uniforms':True,
        'rainfall_values_screened':['depth_mm','intensity_q95_mmph'],'antecedents_recomputed_before_donor_eligibility':True,
        'limitations':['This screen is descriptive support-count sensitivity, not independently verified temporal/spatial radar completeness.',
        'Primary NOQC data and outputs remain unchanged; no automatic extreme filtering is recommended.',
        'Count anomalies can reflect incomplete sampling or duplication; the raw scan metadata is needed to establish cause.',
        'Central95%simulationranges are conditional, not confidence intervals; MCSE based on independent paired seasonal summaries.',
        'No prediction/alert model was rerun; sensitivity concerns simulated drivers only.']}
    assert hashlib.sha256(hpath.read_bytes()).hexdigest()==before
    metadata['canonical_historical_calendar_unchanged']=True
    (OUT/'coverage_support_metadata.json').write_text(json.dumps(metadata,indent=2))
    (OUT/'README_support_sensitivity.txt').write_text('The count-support threshold is a descriptive sensitivity only. Primary NOQC inputs and outputs are unchanged.\nFlagged rainfall depths/intensities were set to missing solely in the sensitivity calendar. p7/API were recalculated before donor eligibility was rebuilt.\nOther meteorological inputs remain unchanged. No replacement rainfall or clipping was used.\nAll six scenarios use the requested prefix of unchanged Step3 sequences and common uniforms. Contrasts and MonteCarloSEs use paired season-level summaries.\nRead metadata and poolcomparison before interpreting differences. This is not independent validation of radar accuracy or a recommendation to exclude extremes.\n')
    print(json.dumps(metadata,indent=2))

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('run_root',type=Path);p.add_argument('input_root',type=Path);p.add_argument('--n-sims',type=int,default=1000);a=p.parse_args()
    run_support(a.run_root,a.input_root,a.n_sims)
