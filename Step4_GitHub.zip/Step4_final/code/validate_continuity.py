"""Internal leave-one-year-out comparison of two conditional driver samplers.

The observed held-out circulation sequence is prescribed, not predicted. Every
fold excludes the held-out year from both the complete donor library and the
historical feature calendar. The sampler must fit all neighbour scales and
candidate pools from those training inputs. Old p7 and successor matching use
identical forced sequences and uniforms. To compare like observation support,
each simulated variable is masked to the observed year's available dates before
calculating diagnostic metrics. Missing dates never become adjacent.

Outputs are descriptive internal assessment following method development, not
external validation, a test of the circulation generator, or forecast skill.
The family mapping is held fixed. Simulation intervals are conditional central
95% ranges; Monte Carlo SEs describe numerical precision, not sampling error.
"""
from pathlib import Path
import argparse
import json
import traceback
import numpy as np
import pandas as pd

from step4_core import (GROUPS, SUMMER, SIM_DATES, load_classifications, resolve_inputs,
                        sample_sequence)
from step4_sensitivity import rebuild_pools, calendar_metrics, _summary_row


KEY_METRICS = ['mean_depth_mm', 'mean_swvl1', 'mean_wind_speed',
               'lag1_depth_mm', 'lag1_swvl1', 'lag1_wind_speed',
               'mean_absolute_soil_day_change', 'max_valid_wet_run_ge1mm',
               'wet_days_ge1mm_available', 'rainfall_season_total_mm',
               'p95_depth_mm','p99_depth_mm','mean_intensity_q95_mmph','p95_intensity_q95_mmph','p99_intensity_q95_mmph',
               'fraction_depth_ge10mm','fraction_intensity_q95_ge16mmph','mean_t2m_C',
               'mean_absolute_t2m_change','mean_absolute_t2m_month_boundary_change',
               'mean_absolute_soil_month_boundary_change']


def extended_metrics(depth,soil,wind,intensity,temperature):
    """Amount/intensity tails and within-summer month-boundary diagnostics.

    q95 intensity is a daily wet-pixel/time histogram metric, not local storm
    duration. Physical diagnostic thresholds are specified, never fitted on the
    held-out year. Month-boundary pairs are June1 through September1.
    """
    r=calendar_metrics(depth,soil,wind)
    for name,vals in [('depth_mm',depth),('intensity_q95_mmph',intensity)]:
        v=np.asarray(vals,float);v=v[np.isfinite(v)]
        for q in [.95,.99]:r[f'p{int(q*100)}_'+name]=float(np.quantile(v,q)) if len(v) else np.nan
        if name.startswith('intensity'):r['mean_'+name]=float(v.mean()) if len(v) else np.nan
        key='fraction_depth_ge10mm' if name=='depth_mm' else 'fraction_intensity_q95_ge16mmph'
        r[key]=float(np.mean(v>=(10 if name=='depth_mm' else 16))) if len(v) else np.nan
    t=np.asarray(temperature,float);r['mean_t2m_C']=float(np.nanmean(t)) if np.isfinite(t).any() else np.nan
    valid=np.isfinite(t[:-1])&np.isfinite(t[1:]);delta=np.abs(np.diff(t))
    boundary=SIM_DATES[SUMMER].day.to_numpy()[1:]==1
    r['mean_absolute_t2m_change']=float(delta[valid].mean()) if valid.any() else np.nan
    r['mean_absolute_t2m_month_boundary_change']=float(delta[valid&boundary].mean()) if (valid&boundary).any() else np.nan
    soil=np.asarray(soil,float);valid=np.isfinite(soil[:-1])&np.isfinite(soil[1:])&boundary
    r['mean_absolute_soil_month_boundary_change']=float(np.abs(np.diff(soil))[valid].mean()) if valid.any() else np.nan
    return r


def _observed_summer(history, year):
    idx = pd.date_range(f'{year}-05-01', f'{year}-09-30')
    rows = history[history.date.dt.year.eq(year)].set_index('date').reindex(idx)
    return {key: rows[key].to_numpy(float) for key in
            ['depth_mm', 'swvl1', 'wind_speed','intensity_q95_mmph','t2m_C']}


def _masked_metrics(arrays, observed):
    """Keep the same date support in observations and each simulation."""
    vals = {}
    for key in ['depth_mm', 'swvl1', 'wind_speed','intensity_q95_mmph','t2m_C']:
        a = arrays[key][:, SUMMER]
        if not np.isfinite(a).all():
            raise ValueError('Sampled driver contains missing values')
        vals[key] = np.where(np.isfinite(observed[key])[None, :], a, np.nan)
    return pd.DataFrame([extended_metrics(vals['depth_mm'][i], vals['swvl1'][i],
                                         vals['wind_speed'][i],vals['intensity_q95_mmph'][i],vals['t2m_C'][i])
                         for i in range(len(vals['depth_mm']))])


def run_holdout(run_root, input_root, n=500, seed=42):
    """Compare old p7 and successor samplers, with n seasons per held-out year."""
    from continuity_sampler import sample_continuity
    run_root, input_root = Path(run_root), resolve_inputs(input_root)
    if not 1 <= int(n) <= 5000:
        raise ValueError('n must be between 1 and 5000')
    n = int(n)
    metadata = json.loads((run_root/'run_metadata.json').read_text(encoding='utf-8'))
    config = json.loads((run_root/'config_used.json').read_text(encoding='utf-8'))
    alpha = float(metadata.get('api_alpha', .85))
    columns = list(metadata['driver_columns'])
    k_factor = float(config.get('knn_k_factor', config.get('continuity_k_factor', 1.)))
    include_p7 = bool(config.get('knn_include_p7', config.get('continuity_include_p7', True)))
    minimum = int(config.get('min_conditioning_donors', 20))
    lib = pd.read_csv(run_root/'prepared/historical_donor_library.csv', parse_dates=['date'],float_precision='round_trip')
    history = pd.read_csv(run_root/'prepared/historical_daily_calendar.csv', parse_dates=['date'],float_precision='round_trip')
    if lib.date.duplicated().any() or history.date.duplicated().any():
        raise ValueError('Historical inputs contain duplicate dates')
    weather = load_classifications(input_root)
    # This independent source fixes the observed sequence in each fold.
    expected = weather[['date', 'state']].merge(history[['date', 'state']],
        on='date', how='left', validate='one_to_one', suffixes=('_weather', '_history'))
    if not expected.state_weather.eq(expected.state_history).all():
        raise ValueError('Prepared historical calendar differs from supplied weather states')
    out = run_root/'results'
    out.mkdir(exist_ok=True)
    fold_rows, observed_rows, all_simulation_metrics, coverage_rows, errors = [], [], [], [], []
    method_names = ['old_p7', 'successor_matching']
    for year in range(2012, 2025):
        print(f'[LOYO] Hold out {year}: {n} simulations per sampler', flush=True)
        train_lib = lib[lib.date.dt.year.ne(year)].copy().reset_index(drop=True)
        train_history = history[history.date.dt.year.ne(year)].copy().sort_values('date')
        if train_lib.date.dt.year.eq(year).any() or train_history.date.dt.year.eq(year).any():
            raise AssertionError('Held-out data leaked into training inputs')
        observed = _observed_summer(history, year)
        obsmetrics = extended_metrics(observed['depth_mm'],observed['swvl1'],observed['wind_speed'],observed['intensity_q95_mmph'],observed['t2m_C'])
        observed_rows.append(dict(year=year, **obsmetrics))
        state = weather[weather.year.eq(year)].sort_values('date').state.to_numpy(dtype=np.int8)
        if state.shape != (183,):
            raise ValueError('Incomplete held-out circulation calendar')
        states = np.broadcast_to(state, (n, 183)).copy()
        rng = np.random.default_rng(np.random.SeedSequence([int(seed), 45, year]))
        uniforms = rng.random((n, 183))
        for st in range(4):
            for month in range(4, 10):
                count = int(((train_lib.state == st) & (train_lib.month == month)).sum())
                coverage_rows.append(dict(year_held_out=year, state=st, family=GROUPS[st],
                                          month=month, train_complete_donors=count))
        for method in method_names:
            try:
                if method == 'old_p7':
                    pools = rebuild_pools(train_lib)
                    arrays, donor, used, status = sample_sequence(
                        states, train_lib, pools, columns, uniforms, alpha=alpha,
                        conditioning=True, min_pool=minimum)
                else:
                    arrays, donor, status, diagnostics = sample_continuity(
                        states, train_lib, train_history, columns, uniforms, alpha=alpha,
                        k_factor=k_factor, include_p7=include_p7)
                if not np.array_equal(train_lib.state.to_numpy()[donor], states):
                    raise AssertionError('Held-out sampler selected wrong donor family')
                if not np.array_equal(train_lib.month.to_numpy()[donor],
                                      np.broadcast_to(SIM_DATES.month.to_numpy(), donor.shape)):
                    raise AssertionError('Held-out sampler selected wrong donor month')
                if np.any(train_lib.date.dt.year.to_numpy()[donor] == year):
                    raise AssertionError('Held-out-year donor selected')
                for col in columns:
                    if not np.array_equal(train_lib[col].to_numpy()[donor], arrays[col]):
                        raise AssertionError('Sampled drivers do not preserve a whole donor row')
                sim = _masked_metrics(arrays, observed)
                all_simulation_metrics.append(sim.assign(year_held_out=year,
                    method=method, sim=np.arange(n)))
                for key in sim.columns:
                    summary = _summary_row(sim[key].to_numpy(float))
                    obsval = obsmetrics[key]
                    error = summary['mean'] - obsval
                    fold_rows.append(dict(year_held_out=year, method=method,
                        metric=key, observed_value=obsval, **summary,
                        signed_error=error, absolute_error=abs(error),
                        squared_error=error**2, n_simulations=n,
                        train_complete_donors=len(train_lib),
                        status='completed', support='matched observed finite dates'))
            except Exception as exc:
                # No borrowing from the held-out year or another family/month.
                errors.append(dict(year_held_out=year, method=method,
                                   error_type=type(exc).__name__, error=str(exc)))
                fold_rows.append(dict(year_held_out=year, method=method,
                    metric='', observed_value=np.nan, n_defined=0,
                    n_simulations=n, train_complete_donors=len(train_lib),
                    status='failed', error=str(exc)))
                print(f'  {method} FAILED: {exc}', flush=True)
    folds = pd.DataFrame(fold_rows)
    for col in ['signed_error', 'absolute_error', 'squared_error']:
        if col not in folds:
            folds[col] = np.nan
    folds.to_csv(out/'loyo_driver_fold_summary.csv', index=False)
    pd.DataFrame(observed_rows).to_csv(out/'loyo_driver_observed_years.csv', index=False)
    pd.DataFrame(coverage_rows).to_csv(out/'loyo_driver_donor_coverage.csv', index=False)
    pd.DataFrame(errors, columns=['year_held_out','method','error_type','error']).to_csv(
        out/'loyo_driver_errors.csv', index=False)
    if all_simulation_metrics:
        pd.concat(all_simulation_metrics, ignore_index=True).to_csv(
            out/'loyo_driver_simulation_metrics.csv', index=False)
    aggregates, comparison = [], []
    for method in method_names:
        for key in KEY_METRICS:
            g = folds[(folds.method == method) & (folds.metric == key) &
                      (folds.status == 'completed')]
            valid = g[np.isfinite(g.signed_error)]
            e = valid.signed_error.to_numpy(float)
            aggregates.append(dict(method=method, metric=key,
                n_defined_years=len(e),
                mean_signed_error=float(e.mean()) if len(e) else np.nan,
                mae=float(np.abs(e).mean()) if len(e) else np.nan,
                rmse=float(np.sqrt(np.mean(e**2))) if len(e) else np.nan,
                year_weighting='equal weight per defined observed year',
                n_simulations_per_fold=n))
    aggregate = pd.DataFrame(aggregates)
    aggregate.to_csv(out/'loyo_driver_aggregate_errors.csv', index=False)
    for key in KEY_METRICS:
        a = folds[(folds.method == 'old_p7') & (folds.metric == key) &
                  (folds.status == 'completed')][['year_held_out','absolute_error','squared_error']]
        b = folds[(folds.method == 'successor_matching') & (folds.metric == key) &
                  (folds.status == 'completed')][['year_held_out','absolute_error','squared_error']]
        joined = a.merge(b, on='year_held_out', suffixes=('_old','_successor')).dropna()
        comparison.append(dict(metric=key, n_paired_years=len(joined),
            old_mae=float(joined.absolute_error_old.mean()) if len(joined) else np.nan,
            successor_mae=float(joined.absolute_error_successor.mean()) if len(joined) else np.nan,
            successor_minus_old_mae=(float((joined.absolute_error_successor-joined.absolute_error_old).mean())
                                     if len(joined) else np.nan),
            old_rmse=float(np.sqrt(joined.squared_error_old.mean())) if len(joined) else np.nan,
            successor_rmse=float(np.sqrt(joined.squared_error_successor.mean())) if len(joined) else np.nan))
    pd.DataFrame(comparison).to_csv(out/'loyo_driver_sampler_comparison.csv', index=False)
    notes = {
        'purpose': 'Internal LOYO driver assessment conditional on observed held-out circulation',
        'n_simulations_per_fold': n,
        'seed_sequence': [int(seed), 45, 'held-out year'],
        'api_alpha': alpha,
        'old_p7_minimum_donors': minimum,
        'successor_k_factor': k_factor,
        'successor_include_p7': include_p7,
        'n_failed_method_folds': len(errors),
        'limitations': [
            'Sampler design followed inspection of the full-study baseline; this is not untouched external validation.',
            'Observed circulation is imposed; no circulation forecasts or operational forecast skills are evaluated.',
            'All donor pools and successor feature scaling must be fitted from training-year inputs only.',
            'The study family mapping is held fixed, not reconstructed inside folds.',
            'Simulated metrics use the same variable-specific finite-date mask as held-out observations.',
            'Missing dates break runs and pairs. Wet-run maxima are lower bounds where rainfall dates are missing.',
            'Observed and matched simulated seasonal rainfall totals are undefined unless all 153 rainfall dates exist.',
            'Simulation ranges are central 95% conditional ranges, not confidence intervals.',
            'Monte Carlo SEs quantify numerical simulation precision, not sampling uncertainty across environmental years.',
            'Error summaries weight each defined year equally and contain no hypothesis tests or hidden acceptance thresholds.',
            'Empirical continuity does not demonstrate a soil-water balance, causality, contamination duration or health benefit.'
        ]}
    (out/'loyo_driver_metadata.json').write_text(json.dumps(notes, indent=2), encoding='utf-8')
    print(f'LOYO complete: {len(errors)} failed method-folds. Results: {out}', flush=True)
    return out


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run_root', type=Path)
    parser.add_argument('input_root', type=Path)
    parser.add_argument('--n-sims', type=int, default=500)
    parser.add_argument('--seed', type=int, default=42)
    args = parser.parse_args()
    run_holdout(args.run_root, args.input_root, n=args.n_sims, seed=args.seed)
