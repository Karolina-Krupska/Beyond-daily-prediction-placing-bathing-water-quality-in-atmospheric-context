"""Publication diagnostics from saved results; simulation ranges are not CIs.

This module only reads result tables and writes figures/captions. It does not
change source data, donor pools, circulation sequences or simulation settings.
"""
from pathlib import Path
import numpy as np
import pandas as pd


def plot_checks(run):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    run = Path(run)
    out = run / 'figures'
    out.mkdir(exist_ok=True)
    plt.rcParams.update({
        'font.size': 9, 'axes.titlesize': 9, 'axes.labelsize': 9,
        'axes.spines.top': False, 'axes.spines.right': False,
        'axes.linewidth': .7, 'xtick.labelsize': 8, 'ytick.labelsize': 8,
        'pdf.fonttype': 42, 'svg.fonttype': 'none',
    })
    grey, blue = '#737373', '#0072B2'
    comp = pd.read_csv(run / 'results/loyo_driver_sampler_comparison.csv').set_index('metric')

    def save(fig, name):
        for ext in ('png', 'pdf', 'svg'):
            fig.savefig(out / f'{name}.{ext}', dpi=600, bbox_inches='tight')
        plt.close(fig)

    def panel(ax, letter):
        ax.text(-.13, 1.06, letter, transform=ax.transAxes,
                fontweight='bold', va='bottom', ha='left')
        ax.set_axisbelow(True)
        ax.grid(axis='y', color='#e8e8e8', lw=.6)

    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.65), layout='constrained')
    for i, (ax, (key, title, unit)) in enumerate(zip(axes, [
        ('lag1_swvl1', 'Soil-moisture continuity', 'MAE in lag-one correlation'),
        ('lag1_wind_speed', 'Vector-wind continuity', 'MAE in lag-one correlation'),
        ('mean_absolute_soil_day_change', 'Daily soil-moisture change', 'MAE (m³ m⁻³)'),
    ])):
        r = comp.loc[key]
        ax.bar([0, 1], [r.old_mae, r.successor_mae], color=[grey, blue], width=.56)
        ax.set_xticks([0, 1], ['Previous', 'Adjusted'])
        ax.set_title(title, pad=9)
        ax.set_ylabel(unit)
        panel(ax, chr(97 + i))
    save(fig, 'Figure_Step4_heldout_continuity')

    folds = pd.read_csv(run / 'results/loyo_driver_fold_summary.csv')
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.65), sharey=True, layout='constrained')
    for i, (ax, (key, title)) in enumerate(zip(axes, [
        ('lag1_swvl1', 'Soil moisture'),
        ('lag1_wind_speed', 'Vector-wind magnitude'),
        ('lag1_depth_mm', 'Rainfall depth'),
    ])):
        d = folds[(folds.metric == key) & folds.method.eq('successor_matching')].sort_values('year_held_out')
        ax.plot(d.year_held_out, d.observed_value, 'o-', color=grey, ms=2.6, lw=1, label='Observed')
        ax.plot(d.year_held_out, d['mean'], 'o-', color=blue, ms=2.6, lw=1, label='Simulation mean')
        ax.fill_between(d.year_held_out, d.simulation_p025, d.simulation_p975, color=blue, alpha=.13, lw=0)
        ax.set_title(title, pad=9)
        ax.set_ylim(-.2, 1.01)
        ax.set_xticks([2012, 2016, 2020, 2024])
        ax.set_xlabel('Held-out year')
        panel(ax, chr(97 + i))
    axes[0].set_ylabel('Lag-one correlation')
    axes[-1].legend(frameon=False, fontsize=7, loc='upper right', handlelength=1.5)
    save(fig, 'Figure_Step4_heldout_correlations')

    fig, axes = plt.subplots(2, 2, figsize=(6.2, 4.6), layout='constrained')
    for i, (ax, (key, title, unit)) in enumerate(zip(axes.flat, [
        ('p95_depth_mm', 'Daily rainfall depth: P95', 'MAE (mm)'),
        ('p99_depth_mm', 'Daily rainfall depth: P99', 'MAE (mm)'),
        ('p95_intensity_q95_mmph', 'Daily intensity metric: P95', 'MAE (mm h⁻¹)'),
        ('p99_intensity_q95_mmph', 'Daily intensity metric: P99', 'MAE (mm h⁻¹)'),
    ])):
        r = comp.loc[key]
        ax.bar([0, 1], [r.old_mae, r.successor_mae], color=[grey, blue], width=.56)
        ax.set_xticks([0, 1], ['Previous', 'Adjusted'])
        ax.set_title(title, pad=9)
        ax.set_ylabel(unit)
        panel(ax, chr(97 + i))
    save(fig, 'Figure_Step4_heldout_rainfall_tails')

    c = pd.read_csv(run / 'results/sensitivity_scenario_minus_baseline.csv')
    c = c[c.metric.eq('mean_depth_mm') & ~c.storyline.eq('baseline')]
    stories = ['persistent_wet', 'persistent_dry', 'dry_with_bursts', 'flip_wet_to_dry', 'flip_dry_to_wet']
    labels = ['Cyclonic/showery persistence', 'Settled favouring', 'Convective interruptions', 'Cyclonic/showery to settled', 'Settled to cyclonic/showery']
    fig, ax = plt.subplots(figsize=(7.2, 3.05), layout='constrained')
    for j, (cfg, label, col, marker) in enumerate([
        ('primary_reconstructed', 'Primary', blue, 'o'),
        ('k_half', 'Half neighbourhood', '#D55E00', 's'),
        ('k_double', 'Double neighbourhood', '#009E73', '^'),
        ('no_p7', 'Without rainfall matching', '#CC79A7', 'D'),
    ]):
        g = c[c.configuration.eq(cfg)].set_index('storyline').reindex(stories)
        if g.mean_difference_from_baseline.isna().any():
            raise ValueError(f'Missing sensitivity results for configuration {cfg}')
        ax.scatter(g.mean_difference_from_baseline, np.arange(5) + (j - 1.5) * .12,
                   label=label, color=col, marker=marker, s=22)
    ax.axvline(0, color=grey, ls='--', lw=.8)
    ax.set_yticks(range(5), labels)
    ax.invert_yaxis()
    ax.set_xlabel('Scenario − baseline mean rainfall (mm day⁻¹)')
    ax.set_axisbelow(True)
    ax.grid(axis='x', color='#e8e8e8', lw=.6)
    ax.legend(frameon=False, fontsize=7, loc='lower right', handletextpad=.4, labelspacing=.5)
    save(fig, 'Figure_Step4_rainfall_sensitivity')

    counts = ', '.join(f'{title}: {int(comp.loc[key, "n_paired_years"])} years' for key, title in [
        ('lag1_swvl1', 'soil'), ('lag1_wind_speed', 'wind'), ('lag1_depth_mm', 'rainfall')])
    captions = (
        'Held-out continuity. Mean absolute errors (MAE) across held-out years for the previous rainfall-only sampler and adjusted previous-state matching. Both use the observed circulation sequence; each held-out year is excluded from donor pools and scale estimates. ' + counts + '.\n\n'
        'Held-out correlations. Observed annual lag-one correlations and simulation means under held-out observed circulation. Shading spans the central 95% conditional simulation range, not a confidence interval. Simulations are masked to observed date availability; only consecutive calendar-day pairs contribute. There are 500 simulations per year.\n\n'
        'Held-out rainfall tails. Equal-year mean absolute errors in annual P95 and P99 daily rainfall depth and the daily wet-only P95 intensity metric, comparing the previous and adjusted samplers. Quantiles are calculated from available dates; simulations use the same date-availability mask. These are regional histogram-derived diagnostics, not local storm maxima.\n\n'
        'Rainfall sensitivity. Scenario-minus-baseline differences in May–September mean rainfall under four donor-matching settings, using the same 5,000 supplied circulation sequences and common random uniforms. Half and double refer to the primary neighbourhood-size factor; the final setting retains soil and wind matching while omitting antecedent rainfall. Points are ensemble means, not significance tests or uncertainty intervals.\n\n'
        'Assessment scope. These are internal assessments following sampler development, conditional on observed or supplied circulation sequences. They do not establish operational forecasting skill or physical water-balance consistency.\n'
    )
    (out / 'continuity_captions.txt').write_text(captions, encoding='utf-8')


if __name__ == '__main__':
    import argparse
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('run', type=Path)
    plot_checks(p.parse_args().run)
