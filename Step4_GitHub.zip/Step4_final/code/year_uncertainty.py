"""Year-block reference uncertainty; no fabricated confidence intervals for simulators.

Resamples whole historical summers (13 rows) to estimate pointwise percentile
intervals for means of the observed annual diagnostics. Missing diagnostic years
remain missing. This does NOT refit the donor sampler, circulation model or family
mapping and is NOT an interval for forecast skill or a scenario effect.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd


def bootstrap_annual_means(annual,n_boot=10000,seed=42):
    if len(annual)!=13 or set(annual.year)!=set(range(2012,2025)):
        raise ValueError('Expected one row for each of13historical summers')
    annual=annual.sort_values('year').reset_index(drop=True)
    keys=[c for c in annual if c!='year' and not c.startswith('n_')]
    vals=annual[keys].to_numpy(float);finite=np.isfinite(vals)
    rng=np.random.default_rng(np.random.SeedSequence([seed,60]))
    indices=rng.integers(0,13,size=(n_boot,13));weights=np.zeros((n_boot,13),int)
    for j in range(13):weights[:,j]=(indices==j).sum(axis=1)
    num=weights@np.where(finite,vals,0);den=weights@finite.astype(int)
    means=np.divide(num,den,out=np.full_like(num,np.nan),where=den>0)
    rows=[]
    for j,key in enumerate(keys):
        v=vals[:,j];v=v[np.isfinite(v)];b=means[:,j];b=b[np.isfinite(b)]
        rows.append(dict(metric=key,n_defined_years=len(v),observed_annual_mean=float(v.mean()) if len(v) else np.nan,
          year_bootstrap_ci025=float(np.quantile(b,.025)) if len(b) else np.nan,
          year_bootstrap_ci975=float(np.quantile(b,.975)) if len(b) else np.nan,
          n_bootstrap_defined=len(b),n_bootstrap=n_boot,
          interval_scope='Approximate pointwise year-block percentile interval for observed annual mean'))
    return pd.DataFrame(rows),pd.DataFrame(weights,columns=[str(y) for y in annual.year])


def run_uncertainty(run,n_boot=10000,seed=42):
    run=Path(run);out=run/'results'
    annual=pd.read_csv(out/'loyo_driver_observed_years.csv')
    summary,weights=bootstrap_annual_means(annual,n_boot,seed)
    summary.to_csv(out/'observed_annual_mean_confidence_intervals.csv',index=False)
    weights.to_csv(out/'observed_year_bootstrap_weights.csv',index=False)
    folds=pd.read_csv(out/'loyo_driver_fold_summary.csv');counts=[]
    for key,g in folds[folds.status.eq('completed')].groupby('metric'):
        q=g.pivot(index='year_held_out',columns='method',values='absolute_error').dropna()
        if not {'old_p7','successor_matching'}<=set(q):continue
        d=q.successor_matching-q.old_p7
        counts.append(dict(metric=key,n_paired_years=len(d),years_adjusted_error_lower=int((d<0).sum()),
                           years_adjusted_error_higher=int((d>0).sum()),years_equal=int((d==0).sum()),
                           mean_adjusted_minus_previous_absolute_error=float(d.mean()),
                           interpretation='Descriptive paired years; no independence-based p-value or full training-uncertainty CI'))
    pd.DataFrame(counts).to_csv(out/'holdout_direction_by_year.csv',index=False)
    # Exact sensitivity to an unspecified API initial offset; no invented March wetness.
    decay=[]
    for alpha in [.8,.85,.9]:
        decay.append(dict(api_alpha=alpha,initial_offset_remaining_before_May1=alpha**30,
          initial_offset_remaining_end_May1=alpha**31,
          mean_MaySep_offset_multiplier=float(np.mean(alpha**np.arange(31,184))),
          interpretation='Multiply by any assumed April1 pre-day API offset; API does not control donor selection'))
    pd.DataFrame(decay).to_csv(out/'API_initialisation_exact_decay.csv',index=False)
    (out/'uncertainty_scope.json').write_text(json.dumps({
      'observed_intervals':'10000whole-year percentile bootstrap reference intervals; pointwise and approximate',
      'assumptions':['Historical summers treated as approximately exchangeable; trends/interannual dependence not modelled.',
        'Only13years; some diagnostics such as complete-season rain totals have fewer defined years.',
        'No donor-pool, measurement, fitted-model, family-mapping or generator uncertainty propagated.',
        'Bootstrap references are not a formal test of agreement with simulations.',
        'Held-out comparisons follow methoddevelopment and use knowncirculation; they are internal driver assessment.'],
      'simulations':'Central95%conditional simulation ranges; season-level MonteCarloSEs describe numerical precision only',
      'n_bootstrap':n_boot,'seed_sequence':[seed,60]},indent=2))
    return out
