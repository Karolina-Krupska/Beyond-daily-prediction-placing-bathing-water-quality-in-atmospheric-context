"""Describe finite donor support and reuse; no inference from simulated-day counts."""
from pathlib import Path
import argparse
import numpy as np
import pandas as pd


def run_reuse(out):
    out = Path(out)
    lib = pd.read_csv(out/'prepared/historical_donor_library.csv', parse_dates=['date'], float_precision='round_trip')
    support = lib.groupby(['state', 'family', 'month']).agg(
        historical_donor_dates=('date', 'size'), historical_source_years=('year', 'nunique'))
    support.reset_index().to_csv(out/'results/donor_support_by_family_month.csv', index=False)
    records = []
    for file in sorted((out/'simulations').glob('*_AprSep.npz')):
        story = file.name.removesuffix('_AprSep.npz')
        with np.load(file) as data:
            donor = data['donor_row']
            counts = np.bincount(donor.ravel(), minlength=len(lib))
        for (state, family, month), group in lib.groupby(['state', 'family', 'month']):
            selected = counts[group.index.to_numpy()]
            total = int(selected.sum())
            used = selected > 0
            weights = selected / total if total else selected.astype(float)
            records.append(dict(storyline=story, state=state, family=family, month=month,
                historical_donor_dates=len(group), historical_source_years=group.year.nunique(),
                simulated_days=total, distinct_donor_dates_selected=int(used.sum()),
                distinct_source_years_selected=group.loc[used, 'year'].nunique(),
                largest_donor_share=float(weights.max()) if total else np.nan,
                inverse_concentration_of_date_weights=float(1/np.sum(weights**2)) if total else np.nan))
    pd.DataFrame(records).to_csv(out/'results/donor_reuse_by_scenario_family_month.csv', index=False)
    (out/'results/donor_reuse_scope.txt').write_text(
        'Counts cover April–September. Simulated days are repeated draws, not independent historical observations. '
        'Inverse concentration is 1/sum(p_date^2), a descriptive concentration measure, not a sampling effective size. '
        'Smaller p7-eligible matching pools are listed separately in prepared/continuity_pool_audit.csv.\n', encoding='utf-8')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run_folder', type=Path)
    run_reuse(parser.parse_args().run_folder)
