"""Sensitivity and descriptive adequacy for previous-state conditional sampling.

Prescribed circulation sequences and uniform draws stay fixed. These are
conditional simulation comparisons, not formal confidence intervals or proof
of physical soil-water dynamics. No parameters are tuned to adequacy results.
"""
from pathlib import Path
import argparse,json
import numpy as np
import pandas as pd
from continuity_sampler import sample_continuity,STATUS
from step4_core import STORIES,GROUPS,SUMMER,SIM_DATES,load_sequences,resolve_inputs,season_metrics
from step4_sensitivity import calendar_metrics,api_from_rain,_summary_row


def temporal_metrics_batch(arrays):
    """Finite simulated summer metrics; constant-series correlations are NaN."""
    out={}
    for key in ['depth_mm','swvl1','wind_speed']:
        x=np.asarray(arrays[key][:,SUMMER],float)
        if not np.isfinite(x).all():raise ValueError('Simulated temporal metrics require finite data')
        a=x[:,:-1]-x[:,:-1].mean(axis=1,keepdims=True)
        b=x[:,1:]-x[:,1:].mean(axis=1,keepdims=True)
        denom=np.sqrt(np.sum(a*a,axis=1)*np.sum(b*b,axis=1))
        out['lag1_'+key]=np.divide(np.sum(a*b,axis=1),denom,out=np.full(len(x),np.nan),where=denom>0)
    rain=arrays['depth_mm'][:,SUMMER];soil=arrays['swvl1'][:,SUMMER]
    out['mean_absolute_soil_day_change']=np.mean(np.abs(np.diff(soil,axis=1)),axis=1)
    out['wet_fraction_ge1mm']=np.mean(rain>=1.,axis=1)
    current=np.zeros(len(rain),int);longest=np.zeros(len(rain),int)
    for t in range(153):
        current=np.where(rain[:,t]>=1.,current+1,0);longest=np.maximum(longest,current)
    out['max_valid_wet_run_ge1mm']=longest.astype(float)
    return out


def _mean(v):
    v=np.asarray(v,float);v=v[np.isfinite(v)]
    return float(v.mean()) if len(v) else np.nan


def _mcse(v):
    v=np.asarray(v,float);v=v[np.isfinite(v)]
    return float(np.std(v,ddof=1)/np.sqrt(len(v))) if len(v)>1 else np.nan


def daily_diagnostic_summary(values):
    """Pooled daily distribution only; no false independent-day MCSE."""
    values=np.asarray(values,float)
    if values.ndim!=2:raise ValueError('Expected season-by-day diagnostic array')
    finite=values[np.isfinite(values)]
    return {'n_days':len(finite),'n_simulated_seasons':values.shape[0],
            'mean':float(finite.mean()) if len(finite) else np.nan,
            'pooled_day_p025':float(np.quantile(finite,.025)) if len(finite) else np.nan,
            'pooled_day_p975':float(np.quantile(finite,.975)) if len(finite) else np.nan,
            'summary_scope':'Pooled simulated days; no independent-day Monte Carlo SE'}


def run_sensitivity(run_root,inputroot,n=5000,seed=42):
    run_root=Path(run_root);inputroot=resolve_inputs(inputroot)
    meta=json.loads((run_root/'run_metadata.json').read_text())
    if meta.get('sampling_method')!='continuity_knn':raise ValueError('This sensitivity requires a continuity_knn primary run')
    if int(seed)!=int(meta['seed']):raise ValueError('Seed must match primary seed')
    if not 1<=n<=min(5000,int(meta['n_sims_per_scenario'])):raise ValueError('Invalid sensitivity simulation count')
    alpha=float(meta['api_alpha']);primary_k=float(meta.get('knn_k_factor',1.));primary_p7=bool(meta.get('knn_include_p7',True))
    lib=pd.read_csv(run_root/'prepared/historical_donor_library.csv',parse_dates=['date'],float_precision='round_trip').reset_index(drop=True)
    history=pd.read_csv(run_root/'prepared/historical_daily_calendar.csv',parse_dates=['date'],float_precision='round_trip')
    columns=list(meta['driver_columns']);seq=load_sequences(inputroot,n)
    uniforms=np.random.default_rng(np.random.SeedSequence([int(seed),4])).random((n,183))
    configs=[('primary_reconstructed',primary_k,primary_p7),('k_half',.5*primary_k,primary_p7),('k_double',2.*primary_k,primary_p7),('no_p7',primary_k,False)]
    out=run_root/'results';out.mkdir(exist_ok=True)
    saved=pd.read_csv(out/'seasonal_driver_metrics.csv',float_precision='round_trip')
    rows=[];audits=[];distances=[];pool_audits=[];api_rows=[];sim_adequacy=None;primary={}
    for label,kfactor,p7 in configs:
        print(f'[Continuity sensitivity] {label}: {n} seasons per scenario',flush=True)
        for story in STORIES:
            arrays,donor,status,diag=sample_continuity(seq[story],lib,history,columns,uniforms,alpha,kfactor,p7)
            metrics=season_metrics(arrays,status)
            metrics['matching_with_p7_fraction']=metrics.pop('conditioning_applied_fraction')
            metrics['matching_without_observed_p7_fraction']=metrics.pop('conditioning_sparse_pool_fraction')
            metrics.update(temporal_metrics_batch(arrays))
            rows.append(pd.DataFrame({'configuration':label,'storyline':story,'sim':np.arange(n),**metrics}))
            if story=='baseline':
                pa=diag['pool_audit'].copy();pa.insert(0,'configuration',label);pool_audits.append(pa)
            for month in range(4,10):
                for state in range(4):
                    mask=(seq[story]==state)&(SIM_DATES.month.to_numpy()[None,:]==month)
                    total=int(mask.sum())
                    for code in range(5):
                        count=int(((status==code)&mask).sum())
                        audits.append(dict(configuration=label,storyline=story,month=month,state=state,family=GROUPS[state],
                            status=code,status_description=STATUS[code],days=count,total_days=total,fraction=count/total if total else np.nan))
            for key in ['nearest_distance','selected_standardised_distance','selected_rank','candidate_count','k_used']:
                values=diag[key][:,SUMMER]
                distances.append(dict(configuration=label,storyline=story,metric=key,**daily_diagnostic_summary(values)))
            if label=='primary_reconstructed':
                primary[story]=metrics
                old=saved[saved.storyline.eq(story)&saved.sim.lt(n)].sort_values('sim')
                if len(old)!=n:raise ValueError('Primary seasonal CSV does not contain requested seasons')
                for key,v in metrics.items():
                    if key in old and not np.allclose(old[key],v,rtol=1e-10,atol=1e-10,equal_nan=True):
                        raise ValueError('Primary reconstruction mismatch: '+story+' '+key)
                reference=arrays['api'][:,SUMMER]
                for aa in sorted(set([.8,.85,.9,alpha])):
                    values=api_from_rain(arrays['depth_mm'],aa)[:,SUMMER]
                    for key,v,ref in [('mean_api',values.mean(axis=1),reference.mean(axis=1)),
                                      ('p95_api',np.quantile(values,.95,axis=1),np.quantile(reference,.95,axis=1))]:
                        delta=v-ref;api_rows.append(dict(storyline=story,api_alpha=aa,primary_api_alpha=alpha,metric=key,
                            **_summary_row(v),mean_difference_from_primary=_mean(delta),monte_carlo_se_difference=_mcse(delta),
                            interpretation='Derived API on unchanged rainfall/donors; not predictive-model sensitivity'))
                if story=='baseline':
                    sim_adequacy=pd.DataFrame([dict(sim=i,**calendar_metrics(arrays['depth_mm'][i,SUMMER],
                        arrays['swvl1'][i,SUMMER],arrays['wind_speed'][i,SUMMER])) for i in range(n)])
        # Save progress at configuration boundaries without pretending incomplete runs are final.
        pd.concat(rows,ignore_index=True).to_csv(out/'sensitivity_seasonal_driver_metrics.csv',index=False)
    table=pd.concat(rows,ignore_index=True)
    pd.DataFrame(audits).to_csv(out/'sensitivity_conditioning_audit.csv',index=False)
    pd.DataFrame(distances).to_csv(out/'sensitivity_matching_distances.csv',index=False)
    pd.concat(pool_audits,ignore_index=True).to_csv(out/'sensitivity_pool_audit.csv',index=False)
    pd.DataFrame(api_rows).to_csv(out/'sensitivity_api_alpha.csv',index=False)
    pd.DataFrame([dict(configuration=l,k_factor=k,include_p7=p) for l,k,p in configs]).to_csv(out/'sensitivity_design.csv',index=False)
    summary=[];contrast=[];shift=[]
    keys=table.columns.difference(['configuration','storyline','sim'])
    for label,_,_ in configs:
        q=table[table.configuration.eq(label)];base=q[q.storyline.eq('baseline')].sort_values('sim')
        for story in STORIES:
            g=q[q.storyline.eq(story)].sort_values('sim')
            for key in keys:
                v=g[key].to_numpy(float);delta=v-base[key].to_numpy(float);change=v-primary[story][key]
                summary.append(dict(configuration=label,storyline=story,metric=key,**_summary_row(v)))
                contrast.append(dict(configuration=label,storyline=story,metric=key,
                    mean_difference_from_baseline=_mean(delta),monte_carlo_se_difference=_mcse(delta)))
                shift.append(dict(configuration=label,storyline=story,metric=key,
                    mean_change_from_primary=_mean(change),monte_carlo_se_change=_mcse(change)))
    pd.DataFrame(summary).to_csv(out/'sensitivity_ensemble_summary.csv',index=False)
    pd.DataFrame(contrast).to_csv(out/'sensitivity_scenario_minus_baseline.csv',index=False)
    pd.DataFrame(shift).to_csv(out/'sensitivity_change_from_primary.csv',index=False)
    observed=[]
    for year in range(2012,2025):
        g=history[history.date.dt.year.eq(year)].set_index('date').reindex(pd.date_range(f'{year}-05-01',f'{year}-09-30'))
        observed.append(dict(year=year,**calendar_metrics(g.depth_mm.to_numpy(),g.swvl1.to_numpy(),g.wind_speed.to_numpy())))
    observed=pd.DataFrame(observed);observed.to_csv(out/'baseline_adequacy_observed_years.csv',index=False)
    sim_adequacy.to_csv(out/'baseline_adequacy_simulated_seasons.csv',index=False)
    adequacy=[]
    for key in observed.columns.difference(['year']):
        vals=observed[key].to_numpy(float);valid=vals[np.isfinite(vals)];s=_summary_row(sim_adequacy[key])
        adequacy.append(dict(metric=key,n_observed_defined=len(valid),observed_mean=_mean(vals),
            observed_min=float(valid.min()) if len(valid) else np.nan,observed_max=float(valid.max()) if len(valid) else np.nan,
            **{'baseline_'+k:v for k,v in s.items()}))
    pd.DataFrame(adequacy).to_csv(out/'baseline_adequacy_summary.csv',index=False)
    (out/'sensitivity_interpretation.txt').write_text(
        'Circulation sequences, donor eligibility and random uniforms are fixed across settings.\n'
        'Primary K=ceil(sqrt(N)); variants multiply sqrt(N) by0.5 or2 or omit rainfall from the previous-state distance.\n'
        'No settings were chosen to optimise these adequacy summaries. Rank weights are proportional to1/j.\n'
        'Previous soil and wind remain in the distance when p7 is omitted. Thus no_p7 is NOT independent daily sampling.\n'
        'Percentiles are central95% conditional simulation ranges, not confidence intervals. Monte Carlo SE concerns numerical precision only.\n'
        'API checks alter a derived memory indicator on identical primary rain; no predictive/alert models are rerun.\n'
        'Historical means use available calendar dates; lag-one metrics use consecutive finite pairs, not compressed records.\n'
        'Rainfall totals are undefined for incomplete seasons, and observed wet-run maxima are lower bounds where rain is missing.\n'
        'These are in-sample adequacy/sensitivity comparisons. Held-out validation is required to assess generalisation.\n'
        'Better empirical continuity does not establish a dynamical soil-water balance, causal effects, contamination duration or forecast utility.\n',encoding='utf-8')
    return out

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('run_root',type=Path);p.add_argument('input_root',type=Path)
    p.add_argument('--n-sims',type=int,default=5000);p.add_argument('--seed',type=int,default=42);a=p.parse_args()
    run_sensitivity(a.run_root,a.input_root,a.n_sims,a.seed)
