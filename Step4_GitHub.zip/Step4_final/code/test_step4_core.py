import unittest, numpy as np, pandas as pd
from step4_core import (histogram_metrics,antecedents,build_library,sample_sequence,
                       GROUPS,SIM_DATES,SUMMER,season_metrics,reconstruct_from_donors)
from tempfile import TemporaryDirectory
from pathlib import Path

class CoreTests(unittest.TestCase):
    def test_histogram_log_mean_and_wet_quantile(self):
        header='region,0,0.0625,0.125,0.25,0.5,1,2,4,8,16,32,64,128,256\n'
        r=histogram_metrics((header+'SWEW,9,0,0,0,0,1,0,0,0,0,0,0,0,0\n').encode())
        self.assertAlmostEqual(r['daily_depth_mm'],24/(10*np.log(2)))
        self.assertAlmostEqual(r['q95_mmph'],2**.95)
        self.assertAlmostEqual(r['wet_fraction'],.1)
        with self.assertRaises(Exception):histogram_metrics(b'\xff'*100)
    def test_historical_antecedents_missing_and_boundary(self):
        dates=pd.date_range('2012-04-01','2012-09-30')
        d=pd.DataFrame({'date':dates,'depth_mm':np.arange(1,184,dtype=float),'swvl1':.3})
        r=antecedents(d)
        self.assertTrue(np.isnan(r.p7_before_mm.iloc[6]))
        self.assertEqual(r.p7_before_mm.iloc[7],28)
        self.assertEqual(r.p7_mm.iloc[6],28)
        self.assertEqual(r.p7_before_mm.iloc[30],sum(range(24,31)))
        d.loc[29,'depth_mm']=np.nan;r=antecedents(d)
        self.assertTrue(np.isnan(r.p7_mm.iloc[30]))
        self.assertTrue(np.isnan(r.api.iloc[29]))
        self.assertTrue(np.isnan(r.api_before.iloc[30]))
        self.assertEqual(r.api.iloc[30], 31)
        self.assertEqual(r.api.iloc[31], .85 * 31 + 32)
        self.assertTrue(np.isnan(r.p7_before_mm.iloc[36]));self.assertTrue(np.isfinite(r.p7_before_mm.iloc[37]))
        d.loc[[0, 1, 29, 30], 'depth_mm'] = np.nan
        r = antecedents(d)
        self.assertTrue(r.api.iloc[[0, 1, 29, 30]].isna().all())
        self.assertEqual(r.api.iloc[2], 3)
        self.assertEqual(r.api.iloc[31], 32)
        r = antecedents(d.assign(depth_mm=d.depth_mm.mask(d.index == 2, 0.0)))
        self.assertEqual(r.api.iloc[2], 0)
    def donor(self):
        rows=[];pools={}
        for month in range(4,10):
            for state in range(4):
                ix=[]
                for j in range(6):
                    ix.append(len(rows));rows.append({'month':month,'state':state,'depth_mm':float(j),
                        'wind_speed':100+10*state+j,'swvl1':.1+j*.01,'marker':1000*month+state*10+j})
                idx=np.array(ix);pools[state,month]=(idx,np.array([1.,3.]),[idx[:2],idx[2:4],idx[4:]])
        return pd.DataFrame(rows),pools
    def test_joint_donors_sequence_reproducibility_and_antecedents(self):
        lib,pools=self.donor();states=np.tile(np.arange(183)%4,(3,1));u=np.random.default_rng(9).random(states.shape)
        cols=['depth_mm','wind_speed','swvl1','marker']
        a,d,used,status=sample_sequence(states,lib,pools,cols,u,min_pool=2)
        aa,dd,_,_=sample_sequence(states,lib,pools,cols,u,min_pool=2)
        np.testing.assert_array_equal(d,dd)
        rebuilt=reconstruct_from_donors(lib,d,cols)
        for key in a:np.testing.assert_allclose(rebuilt[key],a[key],equal_nan=True)
        np.testing.assert_array_equal(lib.state.to_numpy()[d],states)
        for c in cols:np.testing.assert_array_equal(a[c],lib[c].to_numpy()[d])
        np.testing.assert_allclose(a['p7_before_mm'][:,30],a['depth_mm'][:,23:30].sum(axis=1))
        np.testing.assert_allclose(a['p7_mm'][:,30],a['depth_mm'][:,24:31].sum(axis=1))
        np.testing.assert_allclose(a['api'][:,1],.85*a['depth_mm'][:,0]+a['depth_mm'][:,1])
        self.assertEqual(SUMMER.sum(),153)
        self.assertTrue((status[:,:7]==2).all())
        for t in range(7,183):
            for i in range(3):
                _,q,parts=pools[states[i,t],SIM_DATES[t].month]
                b=np.searchsorted(q,a['p7_before_mm'][i,t],side='right')
                self.assertIn(d[i,t],parts[b])
    def test_sparse_conditioning_is_logged_not_cross_family(self):
        lib,pools=self.donor();states=np.zeros((2,183),int);u=np.full(states.shape,.7)
        a,d,used,status=sample_sequence(states,lib,pools,['depth_mm','swvl1'],u,min_pool=20)
        self.assertTrue((status[:,7:]==3).all());self.assertFalse(used.any())
        self.assertTrue((lib.state.to_numpy()[d]==0).all())
        _,_,_,off=sample_sequence(states,lib,pools,['depth_mm','swvl1'],u,conditioning=False)
        self.assertTrue((off==1).all())
    def test_empty_base_pool_fails(self):
        dates=pd.date_range('2012-04-01','2012-09-30')
        daily=pd.DataFrame({'date':dates,'month':dates.month,'year':dates.year,'regime':1,'state':0,'family':GROUPS[0],
                            'depth_mm':1.,'intensity_q95_mmph':2.})
        met=pd.DataFrame({'date':dates,'wind_speed':1.,'uvb_Wm2':1.,'ssrd_Wm2':1.,'t2m_C':10.,'swvl1':.3})
        with TemporaryDirectory() as td:
            with self.assertRaisesRegex(ValueError,'Empty complete donor pool'):build_library(daily,met,Path(td))

if __name__=='__main__':unittest.main()
