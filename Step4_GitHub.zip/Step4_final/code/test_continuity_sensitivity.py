import unittest,numpy as np
from continuity_sensitivity import temporal_metrics_batch
from step4_core import SUMMER
class ContinuitySensitivityTests(unittest.TestCase):
    def test_complete_metrics_and_correlations(self):
        x=np.tile(np.arange(183,dtype=float),(2,1));a={'depth_mm':x,'swvl1':x*.001,'wind_speed':x*.02}
        m=temporal_metrics_batch(a)
        np.testing.assert_allclose(m['lag1_swvl1'],1)
        np.testing.assert_allclose(m['mean_absolute_soil_day_change'],.001)
        np.testing.assert_allclose(m['max_valid_wet_run_ge1mm'],153)
        np.testing.assert_allclose(m['wet_fraction_ge1mm'],1)
    def test_constant_series_correlation_is_undefined(self):
        x=np.zeros((2,183));m=temporal_metrics_batch({'depth_mm':x,'swvl1':x,'wind_speed':x})
        self.assertTrue(np.isnan(m['lag1_swvl1']).all());self.assertTrue((m['max_valid_wet_run_ge1mm']==0).all())
    def test_missing_simulated_values_fail(self):
        x=np.zeros((2,183));x[0,40]=np.nan
        with self.assertRaises(ValueError):temporal_metrics_batch({'depth_mm':x,'swvl1':x,'wind_speed':x})
if __name__=='__main__':unittest.main()
