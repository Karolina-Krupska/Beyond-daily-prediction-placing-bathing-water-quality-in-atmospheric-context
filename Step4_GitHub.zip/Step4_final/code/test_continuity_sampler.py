import unittest
import numpy as np
import pandas as pd
from continuity_sampler import prepare_predecessors,prepare_pools,sample_continuity,_select
from step4_core import SIM_DATES

class ContinuityTests(unittest.TestCase):
    def data(self):
        frames=[]
        for year in [2012,2013]:
            dates=pd.date_range(f'{year}-04-01',f'{year}-09-30')
            t=np.arange(183)
            frames.append(pd.DataFrame({'date':dates,'state':t%4,'month':dates.month,
                'depth_mm':(t%9)/3.,'swvl1':.2+.001*t+.01*(year-2012),
                'wind_speed':2+np.sin(t/3), 'p7_before_mm':np.where(t>=7,5.+t%10,np.nan),
                'marker':year*1000+t}))
        h=pd.concat(frames,ignore_index=True)
        return h.copy(),h
    def test_exact_predecessor_no_season_bridge(self):
        lib,h=self.data();p=prepare_predecessors(lib,h)
        self.assertFalse(p.has_previous_state.iloc[0]);self.assertFalse(p.has_previous_state.iloc[183])
        self.assertEqual(p.previous_swvl1.iloc[184],h.swvl1.iloc[183])
        h.loc[9,'swvl1']=np.nan;p=prepare_predecessors(lib,h)
        self.assertFalse(p.has_previous_state.iloc[10])
        self.assertEqual(p.previous_calendar_date.iloc[30],pd.Timestamp('2012-04-30'))
    def test_current_package_kept_and_reproducible(self):
        lib,h=self.data();states=np.tile(np.arange(183)%4,(4,1));u=np.random.default_rng(9).random(states.shape)
        cols=['depth_mm','swvl1','wind_speed','marker']
        a,d,s,diag=sample_continuity(states,lib,h,cols,u)
        aa,dd,ss,_=sample_continuity(states,lib,h,cols,u)
        np.testing.assert_array_equal(d,dd);np.testing.assert_array_equal(s,ss)
        np.testing.assert_array_equal(lib.state.to_numpy()[d],states)
        for c in cols:np.testing.assert_allclose(a[c],lib[c].to_numpy()[d])
        np.testing.assert_allclose(a['p7_before_mm'][:,30],a['depth_mm'][:,23:30].sum(axis=1))
        self.assertTrue((s[:,0]==2).all());self.assertTrue((s[:,1:7]==4).all());self.assertTrue((s[:,7:]==0).all())
        self.assertTrue(diag['donor_library'].has_previous_state.to_numpy()[d[:,1:]].all())
    def test_rank_weights_nearest_and_stable_tie(self):
        rec={'active':np.array([True]),'scales':np.array([1.]),'scaled':np.array([[0.],[0.],[2.]]),
             'indices':np.array([7,8,9]),'k':3,'cdf':np.cumsum(np.array([1,1/2,1/3])/sum([1,1/2,1/3]))}
        rec['cdf'][-1]=1.
        donor,rank,dist,near=_select(rec,np.zeros((3,1)),np.array([0.,.6,.99]))
        np.testing.assert_array_equal(donor,[7,8,9]);np.testing.assert_array_equal(rank,[1,2,3])
        np.testing.assert_array_equal(near,[0,0,0]);np.testing.assert_array_equal(dist,[0,0,2])
    def test_missing_prev_pool_fails(self):
        lib,h=self.data();h['swvl1']=np.nan
        with self.assertRaisesRegex(ValueError,'No valid previous-state'):
            prepare_pools(prepare_predecessors(lib,h))
    def test_no_p7_uses_previous_soil_and_wind(self):
        lib,h=self.data();states=np.zeros((2,183),int);u=np.full(states.shape,.5)
        a,d,s,diag=sample_continuity(states,lib,h,['depth_mm','swvl1','wind_speed'],u,include_p7=False)
        self.assertTrue((s[:,1:]==1).all());self.assertTrue((diag['chosen_rank'][:,1:]>=1).all())

if __name__=='__main__':unittest.main()
