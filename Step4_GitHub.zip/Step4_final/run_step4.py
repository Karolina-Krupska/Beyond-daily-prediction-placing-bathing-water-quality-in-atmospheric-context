"""Run from Windows with Python 3.10+: python run_step4.py

Local source files are never edited. New outputs get a timestamped directory.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,sys,traceback,gzip,platform,importlib.metadata
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'code'))
from step4_core import (resolve_inputs,verify_manifest,load_classifications,prepare_rainfall,
                       build_library,load_sequences,sample_sequence,season_metrics,
                       SIM_DATES,SUMMER,GROUPS,STORIES)
from netcdf_drivers import extract_meteorology


def write_simulation(story,states,arrays,donor,status,lib,out,write_daily):
    # Compact, lossless: drivers can be reconstructed from the donor library.
    np.savez_compressed(out/'simulations'/f'{story}_AprSep.npz',states=states,
                        donor_row=donor,conditioning_status=status)
    if write_daily: write_daily_csv(story,states,arrays,donor,status,lib,out)

def write_daily_csv(story,states,arrays,donor,status,lib,out):
    path=out/'simulations'/f'{story}_daily_MaySep.csv.gz'
    donor_dates=lib.date.dt.strftime('%Y-%m-%d').to_numpy()
    donor_regime=lib.regime.to_numpy()
    with gzip.open(path,'wt',encoding='utf-8',newline='') as handle:
        for start in range(0,len(states),250):
            stop=min(start+250,len(states));n=stop-start;ix=donor[start:stop][:,SUMMER]
            frame=pd.DataFrame({'storyline':story,'sim':np.repeat(np.arange(start,stop),153),
                'date':np.tile(SIM_DATES[SUMMER].strftime('%Y-%m-%d'),n),
                'day_of_season':np.tile(np.arange(1,154),n),
                'state':states[start:stop][:,SUMMER].ravel(),
                'family':np.asarray(GROUPS)[states[start:stop][:,SUMMER]].ravel(),
                'donor_row':ix.ravel(),'donor_date':donor_dates[ix].ravel(),
                'donor_regime':donor_regime[ix].ravel(),
                'conditioning_status':status[start:stop][:,SUMMER].ravel()})
            for key,value in arrays.items():frame[key]=value[start:stop][:,SUMMER].ravel()
            frame.to_csv(handle,index=False,header=start==0)


def make_figures(out,season,daily):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,
                         'pdf.fonttype':42,'svg.fonttype':'none'})
    fig,ax=plt.subplots(figsize=(7.2,3.3))
    table=daily.assign(year=daily.date.dt.year,month=daily.date.dt.month).pivot_table(
        index='year',columns='month',values='donor_eligible',aggfunc='sum').reindex(columns=range(4,10))
    im=ax.imshow(table.to_numpy(),vmin=0,vmax=31,cmap='cividis',aspect='auto')
    for i in range(len(table)):
        for j in range(6):ax.text(j,i,str(int(table.iloc[i,j])),ha='center',va='center',fontsize=7,color='white' if table.iloc[i,j]<15 else 'black')
    ax.set_xticks(range(6),['Apr','May','Jun','Jul','Aug','Sep']);ax.set_yticks(range(len(table)),table.index)
    ax.set_xlabel('Month');ax.set_ylabel('Year');fig.colorbar(im,ax=ax,label='Eligible historical donor days')
    fig.tight_layout()
    for ext in ['png','pdf','svg']:fig.savefig(out/'figures'/f'Figure_Step4_donor_coverage.{ext}',dpi=600,bbox_inches='tight')
    plt.close(fig)
    labels=['Baseline','Cyclonic/showery\npersistence','Settled\nfavouring','Settled with\nconvective interruptions','Cyclonic/showery\nto settled','Settled to\ncyclonic/showery']
    colours=['#666666','#0072B2','#E69F00','#009E73','#CC79A7','#56B4E9']
    fig,axes=plt.subplots(2,2,figsize=(10,6.4))
    for ax,(metric,ylabel) in zip(axes.ravel(),[
        ('mean_depth_mm','Mean rainfall depth (mm day⁻¹)'),('mean_p7_mm','Mean seven-day rainfall total (mm)'),
        ('mean_wind_speed','Daily vector-wind magnitude (m s⁻¹)'),('mean_swvl1','Mean top-layer soil moisture (m³ m⁻³)')]):
        for i,s in enumerate(STORIES):
            v=season.loc[season.storyline.eq(s),metric].to_numpy();q=np.quantile(v,[.025,.975]);mean=v.mean()
            ax.vlines(i,q[0],q[1],color=colours[i],lw=1.6);ax.plot(i,mean,'o',color=colours[i],ms=5)
        ax.set_xticks(range(6),labels,rotation=35,ha='right',fontsize=7);ax.set_ylabel(ylabel);ax.grid(axis='y',alpha=.15)
    fig.tight_layout()
    for ext in ['png','pdf','svg']:fig.savefig(out/'figures'/f'Figure_Step4_driver_summaries.{ext}',dpi=600,bbox_inches='tight')
    plt.close(fig)
    (out/'figures/captions.txt').write_text(
        'Donor coverage. Number of historical days with all required daily drivers available; no missing values were filled.\n\n'
        'Driver summaries. Points show ensemble mean seasonal summaries; lines span the 2.5th–97.5th percentiles of seasonal summaries across simulations. '
        'These are conditional simulation ranges, not confidence intervals. April provides warm-up; summaries cover May–September. '
        'Soil moisture is resampled from historical donor days, without a dynamical water-balance model.\n',encoding='utf-8')


def run(args):
    config=json.loads(Path(args.config).read_text(encoding='utf-8-sig'))
    base=Path(args.base_dir or config['base_dir'])
    proposed=base/config.get('inputs_folder','Step4_available_inputs')
    inputs=resolve_inputs(proposed if proposed.exists() else ROOT/'Step4_available_inputs')
    stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    out=base/'outputs'/f'Step4_{stamp}';out.mkdir(parents=True)
    for folder in ['prepared','simulations','results','figures']:(out/folder).mkdir()
    print(f'OUTPUT: {out}',flush=True)
    (out/'config_used.json').write_text(json.dumps(config|{'resolved_base_dir':str(base),'prepare_only':args.prepare_only,'n_sims_override':args.n_sims},indent=2))
    try:
        if config.get('verify_input_manifest',True):
            print('[1/6] Checking supplied inputs',flush=True);verify_manifest(inputs)
        weather=load_classifications(inputs)
        print('[2/6] Preparing April and summer rainfall',flush=True)
        rainfall=prepare_rainfall(inputs,weather,out/'prepared')
        print('[3/6] Reading ERA5 / ERA5-Land files',flush=True)
        met=extract_meteorology(base,out/'prepared',config.get('radiation_modes'),config.get('radiation_unit_overrides'),config.get('excluded_source_files',[]),config.get('radiation_file_modes',{}))
        alpha=float(config.get('api_alpha',.85))
        if not 0<alpha<1:raise ValueError('api_alpha must lie strictly between 0 and 1')
        minimum=int(config.get('min_conditioning_donors',20))
        if minimum<1:raise ValueError('min_conditioning_donors must be positive')
        print('[4/6] Recalculating historical antecedents and auditing donor pools',flush=True)
        lib,pools,columns=build_library(rainfall,met,out/'prepared',alpha,minimum)
        n=int(args.n_sims if args.n_sims is not None else config.get('n_sims',5000));seq=load_sequences(inputs,n)
        method=config.get('sampling_method','continuity_knn')
        if method not in ['continuity_knn','p7_only']:raise ValueError('Unknown sampling_method')
        metadata={'sampling_method':method,'knn_k_factor':config.get('knn_k_factor',1.0),'knn_include_p7':config.get('knn_include_p7',True),'status':'prepared_only' if args.prepare_only else 'running','source_exclusions':config.get('excluded_source_files',[]),
                  'assessment_status':'Required meteorology complete; internal conditional-driver assessment required' if met[['wind_speed','uvb_Wm2','ssrd_Wm2','t2m_C','swvl1']].notna().all().all() else 'Incomplete required meteorology; inspect coverage', 'meteorology_missing_days':{c:int(met[c].isna().sum()) for c in met.columns if c!='date'},'n_sims_per_scenario':n,
                  'seed':int(config.get('seed',42)),'rng_seed_sequence':[int(config.get('seed',42)),4],
                  'api_alpha':alpha,'initial_api_before_April1':0,'simulated_calendar':'2001 template; not actual event dates',
                  'n_historical_calendar_dates':len(rainfall),'available_rainfall_days':int(rainfall.rainfall_available.sum()),
                  'complete_donor_days':len(lib),'driver_columns':columns,'group_order':GROUPS,
                  'summer_days':153,'warmup_days':30,'conditioning_status':({0:'previous soil/wind + pre-day p7',1:'previous soil/wind, p7 disabled',2:'April1 empirical initialisation',3:'no observed p7 candidates',4:'early incomplete simulated p7'} if method=='continuity_knn' else {0:'applied',1:'disabled',2:'incomplete simulated p7',3:'sparse wetness bin',4:'no observed p7'}),
                  'simulation_storage':'Compact donor rows + states + conditioning flags; all driver values reconstructible from saved library',
                  'wind_definition':'wind_speed is a daily-vector-wind magnitude proxy when source u/v are daily means; not a true daily mean instantaneous wind speed',
                  'intervals':'Central 95% conditional simulation ranges; NOT confidence intervals',
                  'software':{'python':platform.python_version(),**{p:importlib.metadata.version(p) for p in ['numpy','pandas','xarray','netCDF4','matplotlib']}},
                  'limits':['Statistical previous-state matching is used; no dynamical soil-water balance is imposed.',
                    'Whole-row successor resampling preserves donor-day associations and aims to improve empirical continuity; held-out assessment is required.',
                    'No modelled contamination, alerts, forecast skill or health outcome is calculated here.',
                    'No uncertainty in historical donor pools, radar measurement or circulation classification is propagated.',
                    'API starts at zero on April 1. Historical API is missing on days without rainfall data and restarts at the first subsequent observed daily depth.',
                    'Missing original rainfall and meteorology remain missing, never zero or median-filled.']}
        (out/'run_metadata.json').write_text(json.dumps(metadata,indent=2),encoding='utf-8')
        if args.prepare_only:
            print('Prepared inputs and donor audits complete. No simulations requested.',flush=True);return out
        # Independent stream from Step 3 weather RNG. Uniforms shared across scenarios.
        rng=np.random.default_rng(np.random.SeedSequence([int(config.get('seed',42)),4]))
        uniforms=rng.random((n,183));season_rows=[];fallback=[]
        for story in STORIES:
            print(f'[5/6] Sampling {story}: {n} seasons',flush=True)
            if method=='continuity_knn':
                from continuity_sampler import sample_continuity
                historical=pd.read_csv(out/'prepared/historical_daily_calendar.csv',parse_dates=['date'])
                arrays,donor,status,diagnostics=sample_continuity(seq[story],lib,historical,columns,uniforms,alpha,
                    k_factor=float(config.get('knn_k_factor',1.)),include_p7=bool(config.get('knn_include_p7',True)))
                diagnostics['pool_audit'].to_csv(out/'prepared/continuity_pool_audit.csv',index=False)
                diagnostics['donor_library'].to_csv(out/'prepared/continuity_donor_predecessors.csv',index=False)
                np.savez_compressed(out/'simulations'/f'{story}_matching.npz',
                    selected_rank=diagnostics['selected_rank'],candidate_count=diagnostics['candidate_count'],
                    k_used=diagnostics['k_used'],nearest_distance=diagnostics['nearest_distance'].astype(np.float32),
                    selected_distance=diagnostics['selected_standardised_distance'].astype(np.float32))
            else:
                arrays,donor,used,status=sample_sequence(seq[story],lib,pools,columns,uniforms,alpha,
                    conditioning=bool(config.get('wetness_conditioning',True)),min_pool=minimum)
            # Runtime checks: exact requested family/month and same donor row for all fields.
            if not np.array_equal(lib.state.to_numpy()[donor],seq[story]):raise AssertionError('Donor family mismatch')
            if not np.array_equal(lib.month.to_numpy()[donor],np.broadcast_to(SIM_DATES.month.to_numpy(),donor.shape)):raise AssertionError('Donor month mismatch')
            for col in columns:
                if not np.array_equal(lib[col].to_numpy()[donor],arrays[col]):raise AssertionError('Whole-row donor mismatch')
            write_simulation(story,seq[story],arrays,donor,status,lib,out,bool(config.get('write_daily_csv',True)))
            vals=season_metrics(arrays,status)
            if method=='continuity_knn':
                vals['matching_with_p7_fraction']=vals.pop('conditioning_applied_fraction')
                vals['matching_without_observed_p7_fraction']=vals.pop('conditioning_sparse_pool_fraction')
            season_rows.append(pd.DataFrame({'storyline':story,'sim':np.arange(n),**vals}))
            for month in range(4,10):
                for state in range(4):
                    mask=(seq[story]==state)&(SIM_DATES.month.to_numpy()[None,:]==month)
                    for code in range(5):fallback.append(dict(storyline=story,month=month,state=state,family=GROUPS[state],status=code,
                        days=int(((status==code)&mask).sum()),total_days=int(mask.sum())))
        season=pd.concat(season_rows,ignore_index=True);season.to_csv(out/'results/seasonal_driver_metrics.csv',index=False)
        pd.DataFrame(fallback).to_csv(out/'results/conditioning_audit.csv',index=False)
        summary=[]
        for s,g in season.groupby('storyline',sort=False):
            for col in g.columns.difference(['storyline','sim']):
                v=g[col].to_numpy(float);summary.append(dict(storyline=s,metric=col,n_seasons=len(v),mean=v.mean(),
                    simulation_p025=np.quantile(v,.025),simulation_p975=np.quantile(v,.975),
                    monte_carlo_se_mean=np.std(v,ddof=1)/np.sqrt(len(v)) if len(v)>1 else np.nan))
        pd.DataFrame(summary).to_csv(out/'results/ensemble_summary.csv',index=False)
        # Paired differences describe these conditional ensembles, not causal effects.
        contrasts=[];b=season[season.storyline.eq('baseline')].sort_values('sim')
        for story in STORIES[1:]:
            g=season[season.storyline.eq(story)].sort_values('sim')
            for col in g.columns.difference(['storyline','sim']):
                v=g[col].to_numpy()-b[col].to_numpy();contrasts.append(dict(storyline=story,metric=col,mean_difference=v.mean(),
                    monte_carlo_se_mean_difference=np.std(v,ddof=1)/np.sqrt(len(v)) if len(v)>1 else np.nan))
        pd.DataFrame(contrasts).to_csv(out/'results/scenario_minus_baseline.csv',index=False)
        print('[6/6] Making figures',flush=True)
        daily=pd.read_csv(out/'prepared/historical_daily_calendar.csv',parse_dates=['date'])
        make_figures(out,season,daily)
        metadata['status']='completed';(out/'run_metadata.json').write_text(json.dumps(metadata,indent=2),encoding='utf-8')
        (out/'SUCCESS.txt').write_text('Completed. Inspect README, coverage, excluded donors and conditioning audits before interpreting results.\n')
        print(f'COMPLETE: {out}',flush=True);return out
    except Exception:
        (out/'FAILED.txt').write_text(traceback.format_exc(),encoding='utf-8');print(f'FAILED: see {out / "FAILED.txt"}',flush=True);raise

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',default=str(ROOT/'config.json'))
    parser.add_argument('--base-dir',help='Override the Step 4 folder')
    parser.add_argument('--prepare-only',action='store_true',help='Prepare and audit historical inputs without simulations')
    parser.add_argument('--n-sims',type=int,help='Use first N supplied sequences (1..5000); small values are smoke tests only')
    run(parser.parse_args())
