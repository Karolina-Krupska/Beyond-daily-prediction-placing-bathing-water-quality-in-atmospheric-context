r"""Export May–September daily CSVs from a compact Step 4 result folder.

Usage: python export_daily.py "C:\path\to\Step4_2026..."
"""
import argparse,json,sys
from pathlib import Path
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'code'))
from step4_core import reconstruct_from_donors,STORIES
from run_step4 import write_daily_csv

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('run_folder',type=Path);a=p.parse_args()
    meta=json.loads((a.run_folder/'run_metadata.json').read_text())
    lib=pd.read_csv(a.run_folder/'prepared/historical_donor_library.csv',parse_dates=['date'],float_precision='round_trip')
    for story in STORIES:
        target=a.run_folder/f'simulations/{story}_daily_MaySep.csv.gz'
        if target.exists():print('Already exists; keeping:',target);continue
        with np.load(a.run_folder/f'simulations/{story}_AprSep.npz') as z:
            donor=z['donor_row'];states=z['states'];status=z['conditioning_status']
            arrays=reconstruct_from_donors(lib,donor,meta['driver_columns'],meta['api_alpha'])
            write_daily_csv(story,states,arrays,donor,status,lib,a.run_folder)
        print('Exported:',target)
if __name__=='__main__':main()
