"""Read-only checks of additional Step 6 percentage figures; no analysis rerun."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import xml.etree.ElementTree as ET

import numpy as np
import pandas as pd
from PIL import Image
from pypdf import PdfReader


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def check_all(root, snapshot=None):
    root=Path(root);folder=root/'figures/All_percentages'
    source=pd.read_csv(root/'results/seasonal_summary.csv',float_precision='round_trip')
    figures=pd.read_csv(folder/'FIGURE_DATA.csv',float_precision='round_trip')
    rules=['topk_01','topk_05','topk_10','topk_25','topk_50']
    models=['G','K'];metrics=['selected_days','clusters','max_run_days']
    stories=['baseline','persistent_wet','persistent_dry','dry_with_bursts','flip_wet_to_dry','flip_dry_to_wet']
    key=['model','rule','storyline','metric'];checks=[]
    def checked(name,condition,detail):
        if not bool(condition):raise AssertionError(name+': '+detail)
        checks.append(dict(check=name,passed=True,detail=detail))
    expected={(m,r,s,k) for m in models for r in rules for s in stories for k in metrics}
    actual=set(map(tuple,figures[key].to_numpy()))
    checked('complete_180_record_coverage',len(figures)==180 and not figures.duplicated(key).any() and actual==expected,
            'Two models, five selection fractions, six scenarios and three outcomes.')
    joined=figures.merge(source,on=key,validate='one_to_one',suffixes=('_figure','_source'))
    checked('all_plotted_values_match_source',len(joined)==180 and all(np.allclose(joined[c+'_figure'],joined[c+'_source'],
            rtol=1e-12,atol=1e-12,equal_nan=False) for c in ['mean','p05','p95']),
            'All 180 means and 360 interval endpoints agree with existing result tables.')
    export_details=[]
    for percentage in [1,5,10,25,50]:
        stem=f'Figure_Step6_Top{percentage:02d}'
        paths=[folder/(stem+'.'+extension) for extension in ['png','pdf','svg']]
        checked(stem+'_exports',all(p.exists() and p.stat().st_size>1000 for p in paths),
                'Non-empty PNG, PDF and SVG exports are present.')
        with Image.open(paths[0]) as im:
            expected_pixels=np.array([183,110])/25.4*600
            checked(stem+'_png_dimensions',np.all(np.abs(np.array(im.size)-expected_pixels)<=1),
                    '183 × 110 mm at 600 dpi, allowing pixel rounding.')
            checked(stem+'_png_dpi',np.all(np.abs(np.array(im.info.get('dpi',[0,0]))-600)<.1),
                    'PNG resolution metadata is 600 dpi.')
            pixels=list(im.size)
        svg=ET.parse(paths[2]);texts=svg.findall('.//{http://www.w3.org/2000/svg}text')
        checked(stem+'_editable_svg',len(texts)>10,'SVG retains editable text.')
        reader=PdfReader(paths[1]);text=' '.join(page.extract_text() or '' for page in reader.pages)
        checked(stem+'_pdf_percentage_label',len(reader.pages)==1 and f'Top{percentage}%' in re.sub(r'\s+','',text),
                'Single-page PDF explicitly identifies the intended selected fraction.')
        checked(stem+'_pdf_fonts',b'/Subtype /Type3' not in paths[1].read_bytes(),
                'No Type 3 font exports.')
        export_details.append(dict(percentage=percentage,stem=stem,pixels=pixels,
                                   file_sha256={p.suffix:digest(p) for p in paths}))
    combined=root/'figures/Figure_Step6_All_percentages.pdf'
    pdf=PdfReader(combined)
    checked('combined_pdf_five_pages',len(pdf.pages)==5,'One page for each of 1%, 5%, 10%, 25% and 50%.')
    for page,percentage in zip(pdf.pages,[1,5,10,25,50]):
        text=page.extract_text() or ''
        if f'Top{percentage}%' not in re.sub(r'\s+','',text):raise AssertionError('Combined PDF page order/label mismatch')
    checked('combined_pdf_page_order',True,'Pages follow ascending selected fraction and carry explicit labels.')
    snapshot=Path(snapshot) if snapshot is not None else root/'reports/PERCENTAGE_RESULT_BASELINE.json'
    baseline={}
    if snapshot.exists():
        baseline=json.loads(snapshot.read_text());missing=[];changed=[]
        for relative,expected_hash in baseline.items():
            p=root/'results'/relative
            if not p.exists():missing.append(relative)
            elif digest(p)!=expected_hash:changed.append(relative)
        checked('all_original_numerical_results_unchanged',not missing and not changed,
                f'All {len(baseline)} existing result files retain their original bytes; no statistical rerun.')
    return dict(status='passed',checks_passed=len(checks),checks=checks,
                original_result_files_verified=len(baseline),plotted_records=180,
                exports=export_details,scope='Additional figure-source/export checks only; no new model validation.')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent.parent)
    p.add_argument('--snapshot',type=Path,default=Path(__file__).resolve().parent.parent/'reports/PERCENTAGE_RESULT_BASELINE.json')
    p.add_argument('--report',type=Path,default=Path(__file__).resolve().parent.parent/'figures/All_percentages/VERIFICATION.json')
    args=p.parse_args();report=check_all(args.root,args.snapshot)
    args.report.write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({'status':report['status'],'checks_passed':report['checks_passed'],
                      'original_results_unchanged':report['original_result_files_verified'],
                      'plotted_records':report['plotted_records'],'report':str(args.report)},indent=2))
