"""Boundary/known-answer controls for the new inference implementation."""
import unittest
import numpy as np
from storyline_inference import holm_log,normal_inference,probability_display,numeric_probability


class StorylineControls(unittest.TestCase):
    def test_holm_known_answer(self):
        p=np.array([.01,.04,.03])
        np.testing.assert_allclose(np.exp(holm_log(np.log(p),3)),[.03,.06,.06])

    def test_missing_hypothesis_retains_family_slot(self):
        a=holm_log([np.log(.01),np.nan,np.log(.04)],3)
        self.assertTrue(np.isnan(a[1]))
        np.testing.assert_allclose(np.exp(a[[0,2]]),[.03,.08])

    def test_incomplete_family_rejected(self):
        with self.assertRaises(ValueError):holm_log([np.log(.01)],190)

    def test_zero_se_not_manufactured_significance(self):
        for point in [0.,1.]:
            r=normal_inference(point,0.)
            self.assertFalse(r['estimable'])
            self.assertTrue(np.isnan(r['log_p_raw']))

    def test_underflow_remains_logarithmic(self):
        r=normal_inference(100.,1.)
        self.assertTrue(np.isfinite(r['log_p_raw']))
        self.assertTrue(np.isnan(numeric_probability(r['log_p_raw'])))
        self.assertEqual(probability_display(r['log_p_raw']),'<1e-300')

    def test_interval_uses_supplied_standard_error(self):
        r=normal_inference(1.,.2)
        self.assertAlmostEqual(r['ci95_lower'],.608)
        self.assertAlmostEqual(r['ci95_upper'],1.392)


if __name__=='__main__':unittest.main()
