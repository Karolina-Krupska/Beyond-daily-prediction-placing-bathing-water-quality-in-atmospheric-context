"""Conditional whole-season bootstrap inference; pooled Top-k reselected each time.

No microbiological fitting, calibration fitting or weather simulation occurs.
"""
from pathlib import Path
import json,sys,time,contextlib,datetime,hashlib
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
import pandas as pd
from scipy.stats import norm,skew

ROOT=Path(__file__).resolve().parent.parent
MODELS=list('ABCDEFGHIJK')
PAIRS=[('E','C'),('F','J'),('G','K')]
STORIES=['baseline','persistent_wet','persistent_dry','dry_with_bursts','flip_wet_to_dry','flip_dry_to_wet']
METRICS=['selected_days','clusters','max_run_days']
BUDGETS=[.01,.05,.10,.25,.50]
REPLICATES=4000
SEED=[42,6,910]

def holm(p):
    p=np.asarray(p,float)
    if not np.isfinite(p).all():raise ValueError('All p-values must be finite')
    order=np.argsort(p);adjust=np.minimum(1,np.maximum.accumulate(p[order]*(len(p)-np.arange(len(p)))))
    out=np.empty(len(p));out[order]=adjust
    return out

def stars(p):
    return '***' if p<.001 else '**' if p<.01 else '*' if p<.05 else 'ns'

def add_safe_pvalues_and_diagnostics(frame):
    """Retain log-tail probabilities; never print numerical underflow as p=0."""
    frame=frame.copy();tiny=np.nextafter(0.,1.)
    for secol,suffix in [('bootstrap_se',''),('se_B1000','_B1000')]:
        z=np.divide(frame.mean_difference.to_numpy(),frame[secol].to_numpy(),
            out=np.zeros(len(frame)),where=frame[secol].to_numpy()>0)
        logp=np.log(2.)+norm.logsf(np.abs(z))
        order=np.argsort(logp)
        logadjust=np.minimum(0.,np.maximum.accumulate(logp[order]+np.log(len(frame)-np.arange(len(frame)))))
        adjusted=np.empty(len(frame));adjusted[order]=logadjust
        frame['log_p_raw'+suffix]=logp
        frame['log_p_holm'+suffix]=adjusted
        frame['p_raw'+suffix]=np.exp(np.maximum(logp,np.log(tiny)))
        frame['p_holm'+suffix]=np.exp(np.maximum(adjusted,np.log(tiny)))
    frame['stars']=frame.p_holm.map(stars);frame['stars_B1000']=frame.p_holm_B1000.map(stars)
    frame['significance_stable_B1000_B4000']=(frame.p_holm<.05)==(frame.p_holm_B1000<.05)
    frame['normal_approximation_flag']=(frame.bias_over_se.abs()>.25)|(frame.bootstrap_skewness.abs()>.5)
    frame['p_raw_display']=['<1e-300' if x<np.log(1e-300) else f'{np.exp(x):.4g}' for x in frame.log_p_raw]
    frame['p_holm_display']=['<1e-300' if x<np.log(1e-300) else f'{np.exp(x):.4g}' for x in frame.log_p_holm]
    return frame

def worker(root_string,letter):
    root=Path(root_string)
    from weighted_topk_bootstrap import TopkBootstrap
    tmp=root/'temporary_inference'
    exact=np.load(tmp/'exact_calibrated_probabilities.npy',mmap_mode='r')
    weights=np.load(tmp/'weights.npy',mmap_mode='r')
    flat=np.asarray(exact[MODELS.index(letter)]).ravel()
    tie=np.random.default_rng(np.random.SeedSequence([42,5,700])).random(len(flat))
    order=np.lexsort((tie,-flat))
    engine=TopkBootstrap(order,(6,5000,153),BUDGETS)
    source=pd.read_csv(root/'results/seasonal_summary.csv',float_precision='round_trip')
    # Reconcile all original means before resampling.
    point=np.asarray(engine.baseline_metrics).mean(axis=2)
    for b,f in enumerate(BUDGETS):
        for s,story in enumerate(STORIES):
            for j,metric in enumerate(METRICS):
                reference=source[(source.model==letter)&(source.rule==f'topk_{round(f*100):02d}')&(source.storyline==story)&(source.metric==metric)]['mean'].iloc[0]
                np.testing.assert_allclose(point[b,s,j],reference,rtol=0,atol=1e-12)
    draws=np.empty((len(weights),5,6,3),dtype=np.float64)
    t=time.time()
    for i,w in enumerate(weights):
        draws[i]=engine.bootstrap_means(w)
        if (i+1)%500==0:print(f'Bootstrap {letter}: {i+1}/{len(weights)} ({time.time()-t:.1f}s)',flush=True)
    np.save(tmp/f'bootstrap_{letter}.npy',draws)
    return letter,time.time()-t

def interval(v,point):
    se=float(np.std(v,ddof=1))
    return dict(bootstrap_se=se,ci95_lower=float(point-1.959963984540054*se),
        ci95_upper=float(point+1.959963984540054*se),
        percentile95_lower=float(np.quantile(v,.025)),percentile95_upper=float(np.quantile(v,.975)),
        bootstrap_mean=float(np.mean(v)),bias_over_se=float((np.mean(v)-point)/se) if se else 0.,
        bootstrap_skewness=float(skew(v,bias=False)) if se else 0.)

def run(root=ROOT,workers=3):
    root=Path(root);out=root/'results/inference';out.mkdir(parents=True,exist_ok=True)
    tmp=root/'temporary_inference';tmp.mkdir(exist_ok=True)
    if not (tmp/'exact_calibrated_probabilities.npy').exists():
        # Reuse the tested Step 5 prediction-only reconstruction, then move its temporary array.
        from analysis_step6 import reconstruct_exact
        exact=reconstruct_exact(root,root/'inputs/step5',{})
        del exact
        (root/'temporary/exact_calibrated_probabilities.npy').replace(tmp/'exact_calibrated_probabilities.npy')
        (root/'temporary').rmdir()
    rng=np.random.default_rng(np.random.SeedSequence(SEED))
    # Sampling 5000 complete simulation-index bundles with replacement.
    w=np.array([np.bincount(rng.integers(0,5000,5000),minlength=5000) for _ in range(REPLICATES)],dtype=np.uint8)
    assert np.all(w.sum(1)==5000)
    np.save(tmp/'weights.npy',w)
    weight_hash=hashlib.sha256(w.tobytes()).hexdigest()
    with ProcessPoolExecutor(max_workers=workers) as pool:
        jobs=[pool.submit(worker,str(root),m) for m in MODELS]
        timing={}
        for job in as_completed(jobs):
            m,elapsed=job.result();timing[m]=elapsed;print('Completed bootstrap model',m,flush=True)
    source=pd.read_csv(root/'results/seasonal_summary.csv',float_precision='round_trip')
    means=[];tests=[];replicates={}
    for m in MODELS:
        a=np.load(tmp/f'bootstrap_{m}.npy')
        for b,f in enumerate(BUDGETS):
            rule=f'topk_{round(100*f):02d}'
            for s,story in enumerate(STORIES):
                for j,metric in enumerate(METRICS):
                    p=float(source[(source.model==m)&(source.rule==rule)&(source.storyline==story)&(source.metric==metric)]['mean'].iloc[0])
                    means.append(dict(model=m,rule=rule,storyline=story,metric=metric,mean=p,**interval(a[:,b,s,j],p)))
    for high,low in PAIRS:
        delta=np.load(tmp/f'bootstrap_{high}.npy')-np.load(tmp/f'bootstrap_{low}.npy')
        replicates[f'{high}_{low}']=delta
        for b,f in enumerate(BUDGETS):
            rule=f'topk_{round(f*100):02d}'
            for s,story in enumerate(STORIES):
                for j,metric in enumerate(METRICS):
                    p1=source[(source.model==high)&(source.rule==rule)&(source.storyline==story)&(source.metric==metric)]['mean'].iloc[0]
                    p0=source[(source.model==low)&(source.rule==rule)&(source.storyline==story)&(source.metric==metric)]['mean'].iloc[0]
                    p=float(p1-p0);v=delta[:,b,s,j];iv=interval(v,p);se=iv['bootstrap_se']
                    if se==0 and p!=0:raise ValueError('Nonzero paired effect has zero bootstrap SE')
                    pv=float(2*norm.sf(abs(p/se))) if se else 1.
                    se1000=float(v[:1000].std(ddof=1));pv1000=float(2*norm.sf(abs(p/se1000))) if se1000 else 1.
                    tests.append(dict(comparison=f'{high}-{low}',rule=rule,storyline=story,metric=metric,
                        mean_difference=p,p_raw=pv,p_raw_B1000=pv1000,se_B1000=se1000,**iv))
    meanframe=pd.DataFrame(means);testframe=pd.DataFrame(tests)
    assert len(meanframe)==990 and len(testframe)==270
    testframe['p_holm']=holm(testframe.p_raw)
    testframe['p_holm_B1000']=holm(testframe.p_raw_B1000)
    testframe['stars']=testframe.p_holm.map(stars)
    testframe['stars_B1000']=testframe.p_holm_B1000.map(stars)
    testframe['significance_stable_B1000_B4000']=(testframe.p_holm<.05)==(testframe.p_holm_B1000<.05)
    testframe['ci_scope']='Pointwise 95% normal CI using whole-season pooled-reselection bootstrap SE; fixed fitted models/generator'
    testframe['test_scope']='Approximate two-sided Wald p-value using bootstrap SE; Holm across 270 unique comparisons'
    testframe=add_safe_pvalues_and_diagnostics(testframe)
    meanframe.to_csv(out/'mean_confidence_intervals.csv',index=False,float_format='%.17g')
    testframe.to_csv(out/'paired_tests.csv',index=False,float_format='%.17g')
    # Keep the complete paired table, including stable log/display p-values,
    # normal-approximation flags and both B1000/B4000 sensitivity results.
    testframe.to_csv(out/'bootstrap_sensitivity.csv',index=False,float_format='%.17g')
    np.savez_compressed(out/'paired_bootstrap_replicates.npz',**replicates,
        budgets=np.array(BUDGETS),scenarios=np.array(STORIES),metrics=np.array(METRICS))
    np.savez_compressed(out/'model_mean_bootstrap_replicates.npz',models=np.array(MODELS),
        means=np.stack([np.load(tmp/f'bootstrap_{m}.npy') for m in MODELS]),budgets=np.array(BUDGETS),scenarios=np.array(STORIES),metrics=np.array(METRICS))
    metadata=dict(completed=True,UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        replicates=REPLICATES,seed_sequence=SEED,weights_sha256=weight_hash,
        unit='One simulation index containing six complete April-initialised May-September scenario sequences',
        n_units=5000,resampling='Multinomial whole-bundle paired bootstrap; exact pooled quota reapplied separately for every model/budget/replicate',
        ties='Original shared full-precision rank priorities retained; replicated identical days ordered by copy ordinal',
        test='Normal-approximation two-sided Wald using bootstrap SE; not empirical bootstrap-tail p-values',
        multiplicity='Holm adjustment over all 270 unique paired contrasts',
        uncertainty='Conditional Monte Carlo only; fixed models, calibration, historical inputs, donor library and generator',
        excluded_uncertainty=['Microbiological parameter fitting','Calibration fitting','Weather generator fitting','Historical sampling uncertainty','Prospective warning performance'],
        significance_count=int((testframe.p_holm<.05).sum()),
        decisions_changed_B1000_B4000=int((~testframe.significance_stable_B1000_B4000).sum()),
        max_abs_bias_over_se=float(testframe.bias_over_se.abs().max()),
        max_abs_bootstrap_skewness=float(testframe.bootstrap_skewness.abs().max()),
        normal_approximation_flagged_contrasts=int(testframe.normal_approximation_flag.sum()),
        tail_underflow_handling='Raw and adjusted log p-values retained; numeric p floored only at smallest positive float; human-readable values below1e-300 shown as bounds, never as zero.',
        model_elapsed_seconds=timing,no_model_refitting=True,no_weather_regeneration=True)
    (out/'INFERENCE_METADATA.json').write_text(json.dumps(metadata,indent=2))
    print('Inference completed:',metadata['significance_count'],'/270 Holm-adjusted comparisons below .05',flush=True)
    # Predictions and per-model raw temporary draws are reconstructible and not duplicated in delivery.
    import shutil
    shutil.rmtree(tmp)
    return metadata

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=ROOT);p.add_argument('--workers',type=int,default=3)
    a=p.parse_args();run(a.root,a.workers)
