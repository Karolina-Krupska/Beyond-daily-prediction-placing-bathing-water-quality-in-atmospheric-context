"""Independent arithmetic/export verification of conditional bootstrap inference."""
from pathlib import Path
import argparse,json,math,hashlib
import numpy as np
import pandas as pd
from PIL import Image
from scipy.stats import skew
from scipy.special import log_ndtr

ROOT=Path(__file__).resolve().parent.parent
MODELS=list('ABCDEFGHIJK');RULES=['topk_01','topk_05','topk_10','topk_25','topk_50']
STORIES=['baseline','persistent_wet','persistent_dry','dry_with_bursts','flip_wet_to_dry','flip_dry_to_wet'];METRICS=['selected_days','clusters','max_run_days']
PAIRS=['E-C','F-J','G-K'];Z=1.959963984540054

def holm_independent(p):
 p=np.asarray(p,float);order=sorted(range(len(p)),key=lambda i:p[i]);result=np.empty(len(p));last=0
 for rank,i in enumerate(order):
  last=max(last,min(1.,(len(p)-rank)*p[i]));result[i]=last
 return result

def symbols(p):return '***' if p<.001 else '**' if p<.01 else '*' if p<.05 else 'ns'
def equal(a,b):return np.allclose(a,b,rtol=1e-11,atol=1e-12,equal_nan=True)

def verify(root=ROOT,require_figures=True):
 root=Path(root);folder=root/'results/inference';checks=[]
 def check(name,ok,detail):
  if not bool(ok):raise AssertionError(name+': '+detail)
  checks.append(dict(name=name,passed=True,detail=detail))
 means=pd.read_csv(folder/'mean_confidence_intervals.csv',float_precision='round_trip');tests=pd.read_csv(folder/'paired_tests.csv',float_precision='round_trip')
 source=pd.read_csv(root/'results/seasonal_summary.csv',float_precision='round_trip')
 key=['model','rule','storyline','metric'];tkey=['comparison','rule','storyline','metric']
 check('coverage',len(means)==990 and not means.duplicated(key).any() and len(tests)==270 and not tests.duplicated(tkey).any(),'990 mean intervals and 270 unique paired tests.')
 merged=means.merge(source,on=key,validate='one_to_one',suffixes=('_new','_source'))
 check('point_estimates_unchanged',len(merged)==990 and equal(merged.mean_new,merged.mean_source),'All point estimates match saved Step6 summary exactly.')
 mrep=np.load(folder/'model_mean_bootstrap_replicates.npz');rep=mrep['means'];letters=mrep['models'].tolist()
 check('bootstrap_draw_coverage',rep.shape==(11,4000,5,6,3) and letters==MODELS and np.isfinite(rep).all(),'All model/scenario/outcome bootstrap draws are finite with recorded ordering.')
 check('bootstrap_quotas',all(equal(rep[:, :, b, :,0].sum(axis=-1),np.full((11,4000),5000*153*6*f/5000)) for b,f in enumerate([.01,.05,.1,.25,.5])),'Every bootstrap draw retains the exact pooled selected-day count after re-selection.')
 for row in means.itertuples():
  v=rep[MODELS.index(row.model),:,RULES.index(row.rule),STORIES.index(row.storyline),METRICS.index(row.metric)]
  se=v.std(ddof=1)
  if not equal([se,row.mean-Z*se,row.mean+Z*se,*np.quantile(v,[.025,.975])],[row.bootstrap_se,row.ci95_lower,row.ci95_upper,row.percentile95_lower,row.percentile95_upper]):raise AssertionError('Mean bootstrap interval mismatch')
 check('mean_intervals_from_draws',True,'All 990 SEs, normal-approximation 95% CIs and percentile intervals independently recalculated.')
 prep=np.load(folder/'paired_bootstrap_replicates.npz');pvalues=[]
 for row in tests.itertuples():
  high,low=row.comparison.split('-');bi=RULES.index(row.rule);si=STORIES.index(row.storyline);mi=METRICS.index(row.metric)
  v=prep[high+'_'+low][:,bi,si,mi]
  if not equal(v,rep[MODELS.index(high),:,bi,si,mi]-rep[MODELS.index(low),:,bi,si,mi]):raise AssertionError('Paired bootstrap is not matched-draw subtraction')
  def point(letter):return float(source[(source.model==letter)&(source.rule==row.rule)&(source.storyline==row.storyline)&(source.metric==row.metric)]['mean'].iloc[0])
  effect=point(high)-point(low);se=v.std(ddof=1)
  p=math.erfc(abs(effect/se)/math.sqrt(2)) if se else 1.
  if not equal([effect,se,effect-Z*se,effect+Z*se,p,*np.quantile(v,[.025,.975])],[row.mean_difference,row.bootstrap_se,row.ci95_lower,row.ci95_upper,row.p_raw,row.percentile95_lower,row.percentile95_upper]):raise AssertionError('Paired inference mismatch')
  if hasattr(row,'log_p_raw'):
   expected_log=float(math.log(2)+log_ndtr(-abs(effect/se))) if se else 0.
   if not equal(expected_log,row.log_p_raw):raise AssertionError('Stable log p-value mismatch')
  pvalues.append(p)
 check('paired_inference_from_draws',True,'All 270 paired draw distributions, mean effects, SEs, 95% CIs, percentile intervals and Wald p-values independently verified.')
 adjusted=holm_independent(pvalues)
 check('holm_known_example',equal(holm_independent([.01,.04,.03]),[.03,.06,.06]),'Independent Holm implementation matches hand-calculated example.')
 check('holm270',equal(adjusted,tests.p_holm.to_numpy()),'Multiplicity correction spans all 270 unique comparisons.')
 if 'log_p_holm' in tests:
  order=np.argsort(tests.log_p_raw.to_numpy());expected=np.empty(len(tests));last=-np.inf
  for rank,i in enumerate(order):
   last=max(last,min(0.,float(tests.log_p_raw.iloc[i])+math.log(len(tests)-rank)));expected[i]=last
  check('holm_log_domain',equal(expected,tests.log_p_holm),'Stable Holm adjustment independently recomputed in log domain, including underflow-scale tails.')
 check('positive_log_safe_pvalues',bool((tests.p_raw>0).all() and (tests.p_holm>0).all()),'Numerically tiny p-values are stored with stable log values and positive numeric bounds, never as exact zero.')
 check('stars_match_adjusted_tests',all(symbols(p)==s for p,s in zip(adjusted,tests.stars)),'All significance symbols derive from adjusted p-values, not CI overlap or colours.')
 check('conditional_labels',tests.ci_scope.str.contains('fixed fitted models/generator').all() and tests.test_scope.str.contains('Wald').all(),'Inference is explicitly labelled approximate and conditional.')
 meta=json.loads((folder/'INFERENCE_METADATA.json').read_text())
 check('scope_and_counts',meta['replicates']==4000 and meta['no_model_refitting'] and meta['no_weather_regeneration'] and meta['significance_count']==int((tests.p_holm<.05).sum()),'Recorded execution scope and significant-comparison count agree.')
 full=root/'results/inference/FULL_SIZE_BOOTSTRAP_VALIDATION.json'
 if full.exists():
  f=json.loads(full.read_text());check('full_size_expansion_validation',f['status']=='passed' and f['cases']==15 and all(v['max_absolute_mean_difference']<=1e-12 for v in f['rows']),'15 literal expanded full-size bootstrap cases agree with efficient calculation.')
 baseline=root/'results/inference/BASELINE_INPUT_HASHES.json'
 if not baseline.exists():baseline=root.parent/'inference_work/point_estimate_baseline_hashes.json'
 if baseline.exists():
  b=json.loads(baseline.read_text())
  check('immutable_sources_and_point_tables',all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in b.items()),f'All {len(b)} source inputs/point-estimate tables retain original bytes.')
 if require_figures:
  figdir=root/'figures/Inference';fm=json.loads((figdir/'figure_metadata.json').read_text());fd=pd.read_csv(figdir/'FIGURE_DATA.csv',float_precision='round_trip')
  check('figure_count',fm['figure_count']==42 and len(fm['figures'])==42,'All requested 42 CI/range/heatmap displays generated.')
  for item in fm['figures']:
   for name in item['files']:
    path=Path(name)
    if path.is_absolute() and 'figures' in path.parts:path=root/Path(*path.parts[path.parts.index('figures'):])
    elif not path.is_absolute():path=root/path
    if not path.exists() or path.stat().st_size<1000:raise AssertionError('Missing figure export')
    if path.suffix=='.png':
     with Image.open(path) as im:
      dpi=600 if path.stem.endswith('_600dpi') else item['png_dpi']
      if not np.allclose(im.info.get('dpi',[0,0]),[dpi,dpi],atol=.1):raise AssertionError('Figure resolution mismatch')
  check('figure_exports',True,'All declared 42 PNG/PDF/SVG sets exist and PNG resolution metadata is correct.')
  model_rows=fd[fd.model.notna()].copy()
  mm=model_rows.merge(means,on=key,validate='many_to_one',suffixes=('_plot','_source'))
  check('mean_plot_source_values',len(mm)==2160 and all(equal(mm[c+'_plot'],mm[c+'_source']) for c in ['mean','ci95_lower','ci95_upper']),
        'All 2160 mean-based plot records match current means and confidence intervals.')
  ranged=model_rows[model_rows.interval_type.eq('90% seasonal range')]
  cirows=model_rows[model_rows.interval_type.eq('95% pointwise conditional mean CI') & model_rows.interval_lower.notna()]
  check('range_and_ci_not_conflated',equal(ranged.interval_lower,ranged.p05) and equal(ranged.interval_upper,ranged.p95) and
        equal(cirows.interval_lower,cirows.ci95_lower) and equal(cirows.interval_upper,cirows.ci95_upper),
        'Seasonal-range versions and confidence-interval versions use their distinct correct endpoints.')
  if 'comparison' in fd:
   pairs=fd[fd.comparison.notna()].copy();mm=pairs.merge(tests,on=tkey,validate='many_to_one',suffixes=('_plot','_source'))
   if len(mm)!=len(pairs) or not equal(mm.mean_difference_plot,mm.mean_difference_source):raise AssertionError('Paired plot source effects mismatch')
   expected_display=mm.stars_source.astype(str)
   if 'normal_approximation_flag_source' in mm:expected_display=expected_display+np.where(mm.normal_approximation_flag_source,'†','')
   elif 'normal_approximation_flag' in mm:expected_display=expected_display+np.where(mm.normal_approximation_flag,'†','')
   if not (mm.display_stars==expected_display).all():raise AssertionError('Paired figure significance/caution symbols mismatch')
  check('paired_plot_annotations',True,'Every paired heatmap/forest effect and symbol agrees with the 270-test table.')
 report={'status':'passed','checks_passed':len(checks),'checks':checks,'scope':'Arithmetic, implementation, source/export consistency only; no guaranteed coverage or operational validation.'}
 (folder/'VERIFICATION.json').write_text(json.dumps(report,indent=2))
 print(json.dumps({'status':'passed','checks_passed':len(checks)},indent=2));return report

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=ROOT);p.add_argument('--without-figures',action='store_true');a=p.parse_args();verify(a.root,not a.without_figures)
