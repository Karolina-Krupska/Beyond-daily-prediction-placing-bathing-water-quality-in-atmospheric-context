"""Publish current annotated plots under familiar folders without new analysis."""
from pathlib import Path
import json, shutil
from pypdf import PdfWriter

def publish(root):
    root=Path(root);fig=root/'figures';source=fig/'Inference'
    metadata=json.loads((source/'figure_metadata.json').read_text())
    # Preserve previous unannotated presentations once, outside the current folders.
    archive=fig/'Previous_versions_UNANNOTATED'
    names=['Main_publication','Legacy_style_updated','All_percentages','Heatmaps_by_percentage','Supplementary']
    for name in names:
        old=fig/name
        if old.exists() and not (old/'CURRENT_INFERENCE.txt').exists():
            archive.mkdir(exist_ok=True)
            if not (archive/name).exists():shutil.move(str(old),str(archive/name))
        old.mkdir(exist_ok=True)
        (old/'CURRENT_INFERENCE.txt').write_text('Current plots: 4,000 whole-season bundle bootstrap replicates.\n95% confidence intervals are conditional Monte Carlo intervals.\nSignificance is Holm-adjusted over 270 prespecified comparisons.\nCanonical plots, source values and metadata are in figures/Inference.\n',encoding='utf-8')
    aliases=[]
    def copies(src,dest):
        dest.parent.mkdir(exist_ok=True,parents=True)
        for ext in ['png','pdf','svg']:
            shutil.copy2(src.with_suffix('.'+ext),dest.with_suffix('.'+ext))
            aliases.append({'source':str(src.with_suffix('.'+ext).relative_to(root)),
                            'alias':str(dest.with_suffix('.'+ext).relative_to(root))})
    def bundle(paths,path):
        writer=PdfWriter()
        for p in paths:writer.append(p)
        with path.open('wb') as handle:writer.write(handle)
    barpdf=[];abspdf=[];heatpdf=[]
    for pct in [1,5,10,25,50]:
        tag=f'Top{pct:02d}'
        for stem in ['Selected_days','Clusters','Maximum_run']:
            src=source/'Grouped_bars_95CI'/tag/f'{stem}_{tag}_95CI'
            dst=fig/'Legacy_style_updated'/tag/f'{stem}_Bars_{tag}'
            copies(src,dst);barpdf.append(dst.with_suffix('.pdf'))
        src=(source/'Main_Top10'/'Figure_Main_Top10_95CI_significance' if pct==10 else source/f'Absolute_{tag}'/f'Figure_{tag}_95CI_significance')
        dst=fig/'All_percentages'/f'Figure_Step6_{tag}'
        copies(src,dst);abspdf.append(dst.with_suffix('.pdf'))
        if pct==10:
            copies(src,fig/'Main_publication/Figure_Main_Top10')
            shutil.copy2(src.with_name(src.name+'_600dpi').with_suffix('.png'),fig/'Main_publication/Figure_Main_Top10_600dpi.png')
        else:copies(src,fig/'Supplementary'/tag/f'Figure_Step6_{tag}')
        hsrc=source/'Heatmaps'/tag/f'Heatmaps_{tag}_significance'
        hdst=fig/'Heatmaps_by_percentage'/f'Heatmaps_{tag}_significance'
        copies(hsrc,hdst);heatpdf.append(hdst.with_suffix('.pdf'))
    copies(source/'Heatmaps/Figure_Paired_budget_sensitivity_significance',fig/'Supplementary/Figure_Step6_Paired_budget_sensitivity')
    copies(source/'Paired_differences/Figure_Paired_G_minus_K_Top10_95CI',fig/'Main_publication/Figure_Paired_G_minus_K_Top10_95CI')
    bundle(barpdf,fig/'Legacy_style_updated/Legacy_style_All_models_All_percentages.pdf')
    bundle(abspdf,fig/'Figure_Step6_All_percentages.pdf')
    bundle(heatpdf,fig/'Heatmaps_by_percentage/Heatmaps_All_percentages_significance.pdf')
    (fig/'INFERENCE_ALIASES.json').write_text(json.dumps(aliases,indent=2),encoding='utf-8')
    captions=(source/'CAPTIONS_AND_INTERVAL_DEFINITIONS.txt').read_text(encoding='utf-8')
    (fig/'captions.txt').write_text(captions,encoding='utf-8')
    for name in names:
        (fig/name/'captions.txt').write_text(captions,encoding='utf-8')
    (fig/'Main_publication/caption.txt').write_text('Figure. Temporal organisation of model-selected days under six atmospheric scenarios at a pooled Top-10% selection fraction. Panels show mean selected days, clusters and maximum run length for models with WP (G) and without WP (K). Lines show 95% pointwise conditional Monte Carlo confidence intervals from 4,000 whole-season bundle bootstrap replicates, with pooled selection repeated in each draw. Symbols denote paired G−K normal/Wald tests adjusted by Holm across 270 comparisons (* p<0.05, ** p<0.01, *** p<0.001; ns, not significant). Inference is conditional on the fitted models and weather generator.\n',encoding='utf-8')
    guide='''CURRENT FIGURES — START HERE

MAIN PAPER (TOP 10%): Main_publication/Figure_Main_Top10.png
Paired-effect confidence intervals: Main_publication/Figure_Paired_G_minus_K_Top10_95CI.pdf

OLD-STYLE ALL-MODEL GRAPHS WITH 95% CONFIDENCE INTERVALS AND SIGNIFICANCE:
Legacy_style_updated/Top01, Top05, Top10, Top25, Top50.
Three outcomes in every folder. One 15-page PDF is in Legacy_style_updated.

SAME OLD-STYLE GRAPHS WITH ORIGINAL 5th–95th SEASONAL RANGES AND SIGNIFICANCE:
Inference/Grouped_bars_90ranges/Top01, Top05, Top10, Top25, Top50.
These ranges show variability between seasons; they are not confidence intervals.

HEATMAPS WITH SIGNIFICANCE:
Inference/Heatmaps/Figure_Paired_budget_sensitivity_significance.pdf (all budgets).
Heatmaps_by_percentage/ (individual 1%, 5%, 10%, 25%, 50% and a five-page PDF).

G/K THREE-PANEL FIGURES: All_percentages/ and Figure_Step6_All_percentages.pdf.
Canonical files/source values/metadata/captions: Inference/.

Stars compare E−C, F−J and G−K only: * adjusted p<0.05; **<0.01; ***<0.001;
ns means not significant after Holm correction across 270 unique contrasts.
† flags bootstrap bias/skew diagnostics; see results/inference/bootstrap_sensitivity.csv.
95% intervals are pointwise conditional Monte Carlo intervals. Pointwise CIs may
exclude zero while a multiplicity-adjusted test is ns. Use paired tests, not overlap
between model-specific bars. No model fitting or weather generation was rerun.

Previous_versions_UNANNOTATED and Original_reference_NOT_FOR_PUBLICATION are inactive.
The two Figure_Step6_* compatibility plots at this folder's root and their old source
metadata are retained for original arithmetic verification only. Use the current
annotated files above for publication. Statistical inference is approximate and
conditional on the fitted simulation system, not operational warning validation.
'''
    (fig/'00_START_HERE.txt').write_text(guide,encoding='utf-8')
    rows=['<!doctype html><html lang="en"><meta charset="utf-8"><title>Step 6 figure index</title>',
          '<style>body{font:16px Arial;max-width:1100px;margin:40px auto}li{margin:12px 0}</style>',
          '<h1>Step 6: current annotated figures</h1><p>All five selection fractions, three outcomes and eleven models. Confidence intervals and tests are conditional on the fitted simulation system.</p>',
          '<p>Stars: Holm-adjusted across 270 comparisons. †: bootstrap diagnostic flag. See <a href="Inference/CAPTIONS_AND_INTERVAL_DEFINITIONS.txt">captions and interval definitions</a>.</p><ul>']
    for item in metadata['figures']:
        files={Path(p).suffix:p.removeprefix('figures/') for p in item['files'] if not p.endswith('_600dpi.png')}
        rows.append('<li>'+item['stem']+': '+ ' | '.join(f'<a href="{files[e]}">{e[1:].upper()}</a>' for e in ['.png','.pdf','.svg'])+'</li>')
    rows.append('</ul></html>');(fig/'INDEX.html').write_text('\n'.join(rows),encoding='utf-8')
    return {'current_figure_sets':len(metadata['figures']),'alias_files':len(aliases)}

if __name__=='__main__':
    print(json.dumps(publish(Path(__file__).resolve().parent.parent),indent=2))
