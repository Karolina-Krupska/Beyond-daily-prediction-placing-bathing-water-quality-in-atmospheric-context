"""Read-only audit and plot-source export for the saved equal-count sensitivity.

No probabilities, model parameters, simulations, selections, confidence intervals
or p-values are generated here. Existing interval arithmetic is independently
checked against the complete saved per-season metric records.
"""
from pathlib import Path
import argparse, datetime, hashlib, json
import numpy as np
import pandas as pd

STORIES=['baseline','persistent_wet','persistent_dry','dry_with_bursts','flip_wet_to_dry','flip_dry_to_wet']
MODELS=['C','E','F','G','J','K']
RULES={'matched_05':8,'matched_10':16}
METRICS=['selected_days','clusters','max_run_days']

def run(root):
    root=Path(root);out=root/'results/publication_revision';out.mkdir(exist_ok=True,parents=True)
    paths=[root/'results'/name for name in ['matched_count_seasonal_metrics.csv.gz','matched_count_summary.csv','matched_count_paired_differences.csv']]
    hashes={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    data=pd.read_csv(paths[0],float_precision='round_trip')
    summary=pd.read_csv(paths[1],float_precision='round_trip')
    paired=pd.read_csv(paths[2],float_precision='round_trip')
    checks=[]
    def check(name,condition,detail):
        if not bool(condition):raise AssertionError(name+': '+detail)
        checks.append(dict(name=name,passed=True,detail=detail))
    def close(a,b):return np.allclose(a,b,rtol=1e-12,atol=1e-12,equal_nan=True)
    keys=['model','rule','storyline','sim']
    expected={(m,r,s) for m in MODELS for r in RULES for s in STORIES}
    grouped={k:g.sort_values('sim') for k,g in data.groupby(['model','rule','storyline'],sort=False)}
    check('coverage',len(data)==360000 and set(grouped)==expected and not data.duplicated(keys).any(),
          '360,000 unique saved records cover six comparison models, two fixed counts and all six scenarios.')
    check('season_identifiers',all(len(g)==5000 and np.array_equal(g.sim.to_numpy(),np.arange(5000)) for g in grouped.values()),
          'Every model/count/scenario contains the same complete 5,000 simulation identifiers.')
    check('exact_equal_counts',all(np.all(g.selected_days==RULES[k[1]]) for k,g in grouped.items()),
          'Every season has exactly eight or sixteen selected days; counts match across every compared model.')
    check('metric_bounds_and_zero_handling',bool(np.isfinite(data[METRICS]).all().all() and
          (data[METRICS]>=0).all().all() and (data.clusters<=data.selected_days).all() and
          (data.max_run_days<=data.selected_days).all() and (data.clusters>=1).all() and
          (data.max_run_days>=1).all()),
          'Fixed positive counts imply no zero-selection seasons. Cluster counts and maximum runs are positive and bounded by the fixed selected-day count.')
    check('summary_coverage',len(summary)==216 and not summary.duplicated(['model','rule','storyline','metric']).any(),
          '216 summaries cover all models, fixed counts, scenarios and three metrics.')
    for row in summary.itertuples():
        a=grouped[row.model,row.rule,row.storyline][row.metric].to_numpy()
        observed=[a.mean(),np.median(a),*np.quantile(a,[.05,.95,.025,.975]),np.mean(a==0)]
        if row.n_seasons!=5000 or not close(observed,[row.mean,row.median,row.p05,row.p95,row.p025,row.p975,row.fraction_zero]):
            raise AssertionError('Saved matched-count summary disagrees with complete seasonal data')
    check('all_summary_values',True,'All 216 saved summary rows independently match per-season means, medians, quantiles and zero fractions.')
    check('paired_coverage',len(paired)==108 and set(paired.comparison)=={'E-C','F-J','G-K'} and
          not paired.duplicated(['comparison','rule','storyline','metric']).any(),
          '108 saved paired rows cover all three model pairs, two counts, six scenarios and three metrics.')
    for row in paired.itertuples():
        high,low=row.comparison.split('-')
        delta=grouped[high,row.rule,row.storyline][row.metric].to_numpy()-grouped[low,row.rule,row.storyline][row.metric].to_numpy()
        se=delta.std(ddof=1)/np.sqrt(len(delta))
        observed=[delta.mean(),*np.quantile(delta,[.05,.95]),se,delta.mean()-1.96*se,delta.mean()+1.96*se]
        if row.n_paired!=5000 or not close(observed,[row.mean_difference,row.difference_p05,row.difference_p95,row.mc_se,row.mc95_lower,row.mc95_upper]):
            raise AssertionError('Saved paired mean/interval arithmetic disagrees with matched per-season differences')
    check('all_paired_intervals',True,'All 108 paired means, difference quantiles, standard errors and mean +/- 1.96 SE endpoints independently match saved per-season subtraction.')
    check('count_difference_zero',bool((paired.loc[paired.metric=='selected_days',['mean_difference','mc_se','mc95_lower','mc95_upper']]==0).all().all()),
          'Every selected-day mean difference and interval is exactly zero by construction.')
    plot=paired[(paired.comparison=='G-K')&paired.metric.isin(['clusters','max_run_days'])].copy()
    plot['selected_days_per_season']=plot.rule.map(RULES)
    plot['actual_fraction_percent']=100*plot.selected_days_per_season/153
    plot['interval_type']='Pointwise 95% conditional Monte Carlo interval; mean +/- 1.96 SE; no multiplicity adjustment'
    plot['significance_annotations']='None; no new p-values or adjusted significance tests were generated'
    check('plot_source_coverage',len(plot)==24 and not plot.duplicated(['rule','storyline','metric']).any(),
          'The plot source contains 24 G-K rows: two fixed counts, six scenarios and two temporal-organisation metrics.')
    plot.to_csv(out/'matched_GK_plot_source.csv',index=False,float_format='%.17g')
    check('immutable_source_tables',all(hashlib.sha256(p.read_bytes()).hexdigest()==hashes[str(p.relative_to(root))] for p in paths),
          'All three matched-count scientific source tables retain their exact original bytes.')
    ranges={metric:{'minimum':float(g.mean_difference.min()),'maximum':float(g.mean_difference.max()),
                    'intervals_excluding_zero':int(((g.mc95_lower>0)|(g.mc95_upper<0)).sum()),'rows':len(g)}
            for metric,g in plot.groupby('metric',sort=False)}
    report=dict(status='passed',UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),checks_passed=len(checks),checks=checks,
                input_hashes=hashes,plot_source_rows=24,selected_counts=list(RULES.values()),
                actual_fractions_percent=[100*k/153 for k in RULES.values()],G_K_effect_ranges=ranges,
                uncertainty_scope='Pointwise conditional Monte Carlo precision of fixed-count paired means; excludes fitted-model, calibration, donor-library and weather-generator parameter uncertainty.',
                new_pvalues=False,new_resampling=False,models_refitted=False,weather_regenerated=False)
    (out/'MATCHED_COUNT_VERIFICATION.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    cr=ranges['clusters'];mr=ranges['max_run_days']
    fewer_clusters = int((plot.loc[plot.metric.eq('clusters'), 'mean_difference'] < 0).sum())
    longer_runs = int((plot.loc[plot.metric.eq('max_run_days'), 'mean_difference'] > 0).sum())
    wording=f'''MATCHED-COUNT SENSITIVITY — INDEPENDENT REVIEW

The complete saved sensitivity contains 360,000 unique model/count/scenario/season records. All six comparison models have exactly eight or sixteen selected days in every 153-day season and all 5,000 identifiers in each of the six scenarios. All 216 absolute summaries and 108 paired summaries, including the existing standard errors and interval endpoints, match independent arithmetic from the saved season records.

The two counts correspond to {100*8/153:.4f}% and {100*16/153:.4f}% within each season. They must not be labelled as exact pooled Top-5% or Top-10% selections. Their selected-day differences are identically zero by construction. There are no zero-selection seasons in this sensitivity: all seasons contain a fixed positive count.

Across the twelve G-K count/scenario comparisons, mean cluster differences range from {cr['minimum']:.4f} to {cr['maximum']:.4f} clusters, and maximum-run differences from {mr['minimum']:.4f} to {mr['maximum']:.4f} days. G has fewer clusters in {fewer_clusters} of twelve comparisons and longer maximum runs in {longer_runs} of twelve. The pointwise Monte Carlo intervals exclude zero in {cr['intervals_excluding_zero']} of twelve cluster comparisons and {mr['intervals_excluding_zero']} of twelve maximum-run comparisons. This is an interval diagnostic, not a newly adjusted significance result.

These small differences remain when selected-day count is controlled. They support a small change in simulated temporal organisation, conditional on the fixed fitted system. This sensitivity changes the selection rule and therefore the estimand; it does not make every pooled-budget result count-independent or establish an operational benefit. The existing intervals use mean +/- 1.96 times the standard error of the 5,000 paired season differences. They are pointwise and do not propagate fitting or generator uncertainty. No p-values, new significance stars, model refitting, recalibration, weather regeneration or resampling were performed in this audit.

Use results/publication_revision/matched_GK_plot_source.csv for the supplementary figure and MATCHED_COUNT_VERIFICATION.json for the completed checks.
'''
    (root/'reports/MATCHED_COUNT_REVIEW.txt').write_text(wording,encoding='utf-8')
    print(json.dumps({'status':'passed','checks_passed':len(checks),'plot_rows':len(plot),'ranges':ranges},indent=2))
    return report

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent.parent)
    run(parser.parse_args().root)
