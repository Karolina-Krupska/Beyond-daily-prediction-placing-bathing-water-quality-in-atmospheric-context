"""Compatibility entry point for current publication reporting."""
from publication_reporting import write_reports
from pathlib import Path
if __name__=='__main__':write_reports(Path(__file__).resolve().parent.parent)
