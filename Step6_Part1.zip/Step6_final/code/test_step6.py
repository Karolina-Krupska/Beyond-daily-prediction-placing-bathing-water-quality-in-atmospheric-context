"""Numerical tests for seasonal definitions and equal-count tie handling."""
import unittest
import numpy as np
from analysis_step6 import seasonal_metrics, per_season_order, select_equal_count, differences


class SeasonalMetricTests(unittest.TestCase):
    def test_known_disjoint_runs(self):
        x=np.array([[1,1,0,1,0,1,1,1],[0,1,0,0,1,1,0,0]],bool)
        np.testing.assert_array_equal(seasonal_metrics(x),[[6,3,3],[3,2,2]])

    def test_zero_and_fully_selected_seasons(self):
        np.testing.assert_array_equal(seasonal_metrics([[0]*5,[1]*5]),[[0,0,0],[5,1,5]])

    def test_isolated_edge_days(self):
        np.testing.assert_array_equal(seasonal_metrics([[1,0,0,0,1]]),[[2,2,1]])

    def test_season_boundary_is_not_a_run(self):
        np.testing.assert_array_equal(seasonal_metrics([[0,1],[1,0]]),[[1,1,1],[1,1,1]])

    def test_invalid_dimensions_rejected(self):
        with self.assertRaises(ValueError):seasonal_metrics([1,0,1])
        with self.assertRaises(ValueError):seasonal_metrics(np.empty((3,0)))

    def test_probability_priority_then_shared_tie_priority(self):
        p=np.array([[[.8,.8,.1,.8],[.9,.2,.9,.1]]])
        u=np.array([[[.7,.2,.0,.4],[.8,.1,.3,.0]]])
        order=per_season_order(p,u)
        np.testing.assert_array_equal(order,[[[1,3,0,2],[2,0,1,3]]])
        mask=select_equal_count(order,2)
        np.testing.assert_array_equal(mask.sum(-1),[[2,2]])
        np.testing.assert_array_equal(mask,select_equal_count(per_season_order(p,u),2))
        self.assertTrue(np.all(~select_equal_count(order,1)|mask))

    def test_equal_count_differences_and_interval_scope(self):
        a=np.array([[8,2,5],[8,3,4],[8,4,3]])
        b=np.array([[8,3,4],[8,4,3],[8,5,2]])
        rows=differences(a,b,matched_count=True)
        self.assertEqual(rows[0]['mean_difference'],0)
        self.assertEqual(rows[0]['mc95_lower'],0)
        self.assertEqual(rows[1]['mean_difference'],-1)
        self.assertEqual(rows[2]['mean_difference'],1)
        pooled=differences(a,b,matched_count=False)
        self.assertTrue(np.isnan(pooled[0]['mc95_lower']))


if __name__=='__main__':unittest.main()
