"""Publication figures from the authoritative Step 6 result tables only.

This module never fits models, changes predictions or reselects days.
"""
from __future__ import annotations

from pathlib import Path
import json
import math

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator
from matplotlib.colors import TwoSlopeNorm
from matplotlib.backends.backend_pdf import PdfPages

ROOT = Path(__file__).resolve().parent.parent
STORIES = ["baseline", "persistent_wet", "flip_wet_to_dry", "dry_with_bursts",
           "persistent_dry", "flip_dry_to_wet"]
STORY_LABELS = ["Baseline", "Persistent wet", "Wet to dry", "Dry with storm\noutbreaks",
                "Persistent dry", "Dry to wet"]
METRICS = ["selected_days", "clusters", "max_run_days"]
TITLES = {"selected_days": "Selected days", "clusters": "Clusters",
          "max_run_days": "Maximum run"}
UNITS = {"selected_days": "Days per season", "clusters": "Clusters per season",
         "max_run_days": "Days"}
PAIRS = ["E-C", "F-J", "G-K"]
RULES = ["topk_01", "topk_05", "topk_10", "topk_25", "topk_50"]
BUDGET_LABELS = ["1", "5", "10", "25", "50"]
COLOURS = {"G": "#0072B2", "K": "#D55E00"}
LABELS = {"G": "G: full model + WP", "K": "K: full model without WP"}
MM = 1 / 25.4


def _configure():
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 7.5,
        "axes.labelsize": 7.5, "axes.titlesize": 8.5,
        "xtick.labelsize": 7, "ytick.labelsize": 7.5,
        "legend.fontsize": 7.5, "axes.linewidth": 0.65,
        "xtick.major.width": 0.6, "ytick.major.width": 0.6,
        "xtick.major.size": 3, "ytick.major.size": 0,
        "pdf.fonttype": 42, "ps.fonttype": 42,
        "svg.fonttype": "none", "savefig.facecolor": "white",
        "figure.facecolor": "white", "axes.facecolor": "white",
    })


def _unique(frame, columns, description):
    if frame.duplicated(columns).any():
        raise ValueError(f"Duplicate figure records in {description}: {columns}")


def _save(fig, folder, stem, width_mm, height_mm, pdf_pages=None):
    paths = []
    for extension in ["png", "pdf", "svg"]:
        target = folder / f"{stem}.{extension}"
        fig.savefig(target, dpi=600, metadata=None)
        paths.append(str(target.relative_to(folder.parent)))
    if pdf_pages is not None:
        pdf_pages.savefig(fig)
    plt.close(fig)
    return {"stem": stem, "files": paths, "width_mm": width_mm,
            "height_mm": height_mm, "png_dpi": 600,
            "vector_text_editable": True}


def _main(summary, folder, rule="topk_01", stem="Figure_Step6_Storyline_behaviour", pdf_pages=None):
    percentage = int(rule.rsplit("_", 1)[1])
    subset = summary[(summary.rule == rule) & summary.model.isin(["G", "K"])
                     & summary.metric.isin(METRICS)].copy()
    _unique(subset, ["model", "storyline", "metric"], "primary figure")
    if len(subset) != 36:
        raise ValueError(f"Main figure requires 36 records; found {len(subset)}")
    if not set(subset.storyline) == set(STORIES):
        raise ValueError("Main figure scenario coverage is incomplete")
    fig, axes = plt.subplots(1, 3, figsize=(183 * MM, 110 * MM), sharey=True)
    fig.subplots_adjust(left=0.225, right=0.985, top=0.86, bottom=0.22, wspace=0.38)
    y = np.arange(6)
    for j, (ax, metric) in enumerate(zip(axes, METRICS)):
        for letter, offset in [("G", -0.12), ("K", 0.12)]:
            values = subset[(subset.model == letter) & (subset.metric == metric)]
            values = values.set_index("storyline").loc[STORIES]
            ax.hlines(y + offset, values.p05, values.p95,
                      color=COLOURS[letter], linewidth=1.05, alpha=0.85, zorder=2)
            ax.plot(values["mean"], y + offset, "o", color=COLOURS[letter],
                    markersize=3.8, markeredgecolor="white", markeredgewidth=0.4, zorder=3)
            for endpoint in [values.p05, values.p95]:
                ax.vlines(endpoint, y + offset - 0.045, y + offset + 0.045,
                          color=COLOURS[letter], linewidth=0.7, zorder=2)
        ax.set_yticks(y, STORY_LABELS)
        ax.set_ylim(5.6, -0.6)
        maximum = float(subset[subset.metric == metric][["p95", "mean"]].max().max())
        ax.set_xlim(0, max(1.0, maximum * 1.10))
        ax.xaxis.set_major_locator(MaxNLocator(nbins=4, integer=True))
        ax.set_xlabel(UNITS[metric], labelpad=6)
        ax.set_title(TITLES[metric], loc="left", pad=11, fontweight="normal")
        ax.text(-0.025, 1.12, chr(97 + j), transform=ax.transAxes,
                fontsize=9, fontweight="bold", va="bottom")
        ax.grid(axis="x", color="#E4E7E9", linewidth=0.5, zorder=0)
        ax.set_axisbelow(True)
        for spine in ["top", "right", "left"]:
            ax.spines[spine].set_visible(False)
        ax.tick_params(axis="y", pad=8)
    handles = [Line2D([], [], color=COLOURS[k], marker="o", markersize=4,
                      linewidth=1, label=LABELS[k]) for k in ["G", "K"]]
    fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(0.59, 0.08),
               frameon=False, ncol=2, columnspacing=1.8, handlelength=1.8)
    fig.text(0.59, 0.025, f"Top {percentage}% pooled selection · points: means · lines: 5th–95th percentiles",
             ha="center", va="bottom", fontsize=7)
    data = subset.copy()
    data.insert(0, "figure", stem)
    return _save(fig, folder, stem, 183, 110, pdf_pages=pdf_pages), data


def make_percentage_figures(root=ROOT):
    """Render all existing pooled budgets without recalculating any analysis."""
    root=Path(root)
    _configure()
    summary=pd.read_csv(root/'results/seasonal_summary.csv',float_precision='round_trip')
    folder=root/'figures/All_percentages'
    folder.mkdir(parents=True,exist_ok=True)
    metadata=[];data=[];captions=[]
    combined=root/'figures/Figure_Step6_All_percentages.pdf'
    with PdfPages(combined) as pages:
        for rule in RULES:
            pct=int(rule.rsplit('_',1)[1]);stem=f'Figure_Step6_Top{pct:02d}'
            meta,values=_main(summary,folder,rule=rule,stem=stem,pdf_pages=pages)
            meta['rule']=rule;meta['percentage']=pct
            meta['files']=[str((folder/Path(p).name).relative_to(root)) for p in meta['files']]
            metadata.append(meta);data.append(values)
            captions.append(f'Top {pct}% selection. Mean selected days, clusters and maximum run length per simulated May-September season for G (with WP) and K (without WP), across six scenarios. Points are means; lines show the 5th-95th percentiles of 5,000 seasons per scenario. Selection is applied separately to each model across all six scenarios pooled. Seasonal totals may differ; ranges describe conditional simulated variability, not confidence intervals. Axis limits adapt to each selection fraction.')
    pd.concat(data,ignore_index=True).to_csv(folder/'FIGURE_DATA.csv',index=False)
    report={'figures':metadata,'combined_pdf':str(combined.relative_to(root)),
        'page_order_percentages':[1,5,10,25,50],'plotted_records':sum(len(d) for d in data),
        'source':'results/seasonal_summary.csv','models':['G','K'],
        'analysis_rerun':False,'interval':'Central 90% conditional simulation range; not a confidence interval',
        'axes':'Same layout, colours and physical dimensions; axis limits adapt to each fraction'}
    (folder/'figure_metadata.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    (folder/'captions.txt').write_text('\n\n'.join(captions)+'\n',encoding='utf-8')
    from check_all_percentage_figures import check_all
    verification=check_all(root)
    (folder/'VERIFICATION.json').write_text(json.dumps(verification,indent=2),encoding='utf-8')
    return report


def _supplement(paired, folder):
    subset = paired[paired.comparison.isin(PAIRS) & paired.rule.isin(RULES)
                    & paired.metric.isin(METRICS)].copy()
    _unique(subset, ["comparison", "rule", "storyline", "metric"], "paired sensitivity figure")
    if len(subset) != 270:
        raise ValueError(f"Supplement requires 270 records; found {len(subset)}")
    fig, axes = plt.subplots(3, 3, figsize=(183 * MM, 200 * MM))
    fig.subplots_adjust(left=0.235, right=0.985, top=0.92, bottom=0.15,
                        wspace=0.23, hspace=0.38)
    norms = {}
    images = {}
    for metric in METRICS:
        bound = float(subset.loc[subset.metric == metric, "mean_difference"].abs().max())
        bound = max(0.01, bound)
        norms[metric] = TwoSlopeNorm(vmin=-bound, vcenter=0, vmax=bound)
    for r, pair in enumerate(PAIRS):
        for c, metric in enumerate(METRICS):
            ax = axes[r, c]
            values = subset[(subset.comparison == pair) & (subset.metric == metric)]
            matrix = values.pivot(index="storyline", columns="rule", values="mean_difference")
            matrix = matrix.loc[STORIES, RULES].to_numpy()
            image = ax.imshow(matrix, cmap="RdBu_r", norm=norms[metric],
                              interpolation="nearest", aspect="auto")
            images[metric] = image
            for iy in range(6):
                for ix in range(5):
                    value = matrix[iy, ix]
                    colour = "white" if abs(value) > norms[metric].vmax * 0.57 else "#111111"
                    label = f"{value:+.2f}" if abs(value) >= 0.005 else "0.00"
                    ax.text(ix, iy, label, ha="center", va="center", color=colour,
                            fontsize=6.8)
            ax.set_xticks(np.arange(5), BUDGET_LABELS)
            ax.tick_params(axis="x", length=0, pad=4)
            ax.set_yticks(np.arange(6), STORY_LABELS if c == 0 else [""] * 6)
            ax.tick_params(axis="y", pad=7)
            if r == 0:
                ax.set_title(TITLES[metric], fontsize=8.5, pad=15)
            ax.text(-0.015, 1.055, chr(97 + 3 * r + c), transform=ax.transAxes,
                    fontsize=8.5, fontweight="bold", va="bottom")
            if r == 2:
                ax.set_xlabel("Selected fraction (%)", labelpad=5, fontsize=7)
            ax.set_xticks(np.arange(-0.5, 5, 1), minor=True)
            ax.set_yticks(np.arange(-0.5, 6, 1), minor=True)
            ax.grid(which="minor", color="white", linewidth=0.5)
            ax.tick_params(which="minor", bottom=False, left=False)
            for spine in ax.spines.values():
                spine.set_visible(False)
        position = axes[r, 0].get_position()
        fig.text(0.025, (position.y0 + position.y1) / 2,
                 pair.replace("-", " − "), rotation=90, fontsize=9,
                 fontweight="bold", ha="center", va="center")
    for c, metric in enumerate(METRICS):
        position = axes[2, c].get_position()
        cbax = fig.add_axes([position.x0, 0.065, position.width, 0.012])
        cb = fig.colorbar(images[metric], cax=cbax, orientation="horizontal")
        cb.ax.tick_params(labelsize=6.5, length=2, pad=2)
        cb.locator = MaxNLocator(nbins=3)
        cb.update_ticks()
        cb.outline.set_linewidth(0.5)
        unit = "clusters" if metric == "clusters" else "days"
        cb.set_label(f"Mean difference ({unit})", fontsize=7, labelpad=3)
    data = subset.copy()
    data.insert(0, "figure", "Figure_Step6_Paired_budget_sensitivity")
    return _save(fig, folder, "Figure_Step6_Paired_budget_sensitivity", 183, 200), data


def make_figures(root=ROOT):
    """Create the agreed main figure and one supplementary sensitivity figure."""
    root = Path(root)
    folder = root / "figures"
    folder.mkdir(parents=True, exist_ok=True)
    _configure()
    summary = pd.read_csv(root / "results/seasonal_summary.csv", float_precision="round_trip")
    paired = pd.read_csv(root / "results/paired_model_differences.csv", float_precision="round_trip")
    main_meta, main_data = _main(summary, folder)
    supp_meta, supp_data = _supplement(paired, folder)
    pd.concat([main_data, supp_data], ignore_index=True).to_csv(folder / "FIGURE_DATA.csv", index=False)
    metadata = {
        "figures": [main_meta, supp_meta],
        "source_tables": ["results/seasonal_summary.csv", "results/paired_model_differences.csv"],
        "main_interval": "5th–95th percentiles across 5,000 simulated seasons: central 90% conditional simulation range, not a confidence interval",
        "supplement_colour": "Mean within-season paired model difference; with WP minus without WP",
        "main_rule": "Earlier Top-1% compatibility figure; publication main is Main_publication/Figure_Main_Top10",
        "models": {"G": "Full hydrometeorological model with WP", "K": "Same numerical predictors without WP"},
        "main_plotted_rows": len(main_data), "supplement_plotted_rows": len(supp_data),
    }
    (folder / "figure_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    captions = """Earlier Top-1% figure, now supplementary. Temporal organisation of model-selected days across six atmospheric storylines. Panels show (a) selected days, (b) clusters and (c) maximum run length per May–September season for full hydrometeorological models with WP (G) and without WP (K). Points are means and lines are 5th–95th percentiles across 5,000 simulated seasons per scenario. The highest 1% of calibrated daily probabilities are selected separately for each model across all six scenarios pooled; seasonal counts may differ. All metrics are zero in seasons with no selected days. Ranges describe conditional simulated variability, not confidence intervals or observed contamination duration.

Supplementary Step 6 figure. Sensitivity of paired WP-model differences to the pooled selection fraction. Rows compare E−C, F−J and G−K; columns show differences in selected days, clusters and maximum run length. Cells give mean within-season differences across 5,000 simulations per scenario, with WP minus without WP. Selection fractions are applied separately to each model across all six scenarios pooled. Colours are scaled consistently within each metric; no significance testing is implied. Differences in clusters and maximum runs can also reflect differences in selected-day totals. These are conditional simulation results, not operational warning validation.
"""
    (folder / "captions.txt").write_text(captions, encoding="utf-8")
    make_percentage_figures(root)
    from publication_figures_step6 import make_publication_set
    make_publication_set(root)
    from verify_publication_figures import check_publication
    check_publication(root)
    return metadata


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--all-percentages-only", action="store_true",help="Add absolute G/K figures for all five saved budgets without analysis")
    args = parser.parse_args()
    print(json.dumps(make_percentage_figures(args.root) if args.all_percentages_only else make_figures(args.root), indent=2))
