"""Exact whole-season weighted Top-k bootstrap without expanding copied days.

Ranking is supplied by the caller, normally exact calibrated probability followed
by the saved shared random tie priority. Bootstrap copies retain that priority;
copy ordinal is the final tie breaker. Every weight represents an entire season
index jointly across all scenarios. No model fitting occurs in this module.
"""
from __future__ import annotations
import numpy as np
from analysis_step6 import seasonal_metrics


def _one_season_metrics(mask):
    """Equivalent single-row calculation for the partial-copy boundary case."""
    x=np.asarray(mask,dtype=bool)
    edges=np.flatnonzero(np.diff(np.r_[False,x,False]))
    lengths=edges[1::2]-edges[::2]
    return np.array([int(x.sum()),len(lengths),int(lengths.max()) if len(lengths) else 0],dtype=np.int64)


class TopkBootstrap:
    """Precompute one model's ranking for exact whole-season re-selection.

    Parameters
    ----------
    order : array of flat original day indices in descending priority order
    shape : (scenarios, seasons, consecutive_days)
    budgets : iterable of fractions in [0, 1]

    Attributes
    ----------
    baseline_metrics : (budgets, scenarios, seasons, 3), original seasonal metrics
    counts : (budgets,), exact pooled selected-day quotas
    """
    def __init__(self, order, shape, budgets):
        self.shape=tuple(int(v) for v in shape)
        if len(self.shape)!=3 or min(self.shape)<=0:raise ValueError('Expected positive (S,N,L) shape')
        self.S,self.N,self.L=self.shape
        self.M=int(np.prod(self.shape))
        self.order=np.asarray(order,dtype=np.int64)
        if self.order.ndim!=1 or len(self.order)!=self.M:raise ValueError('Order size does not match shape')
        if self.order.min()!=0 or self.order.max()!=self.M-1 or np.unique(self.order).size!=self.M:
            raise ValueError('Order must be a permutation of every original day')
        self.budgets=np.asarray(list(budgets),dtype=float)
        if self.budgets.ndim!=1 or not np.isfinite(self.budgets).all() or np.any((self.budgets<0)|(self.budgets>1)):
            raise ValueError('Invalid selection fractions')
        self.counts=np.ceil(self.budgets*self.M).astype(np.int64)
        dtype=np.int32 if self.M<np.iinfo(np.int32).max else np.int64
        self.inverse=np.empty(self.M,dtype=dtype)
        self.inverse[self.order]=np.arange(self.M,dtype=dtype)
        self.rank_rows=self.inverse.reshape(self.S*self.N,self.L)
        self.order_unit=((self.order//self.L)%self.N).astype(np.int32)
        base=[]
        for k in self.counts:
            base.append(seasonal_metrics(self.rank_rows<k).reshape(self.S,self.N,3))
        self.baseline_metrics=np.stack(base)
        self._base_flat=self.baseline_metrics.reshape(len(self.counts),self.S*self.N,3)

    def _boundary(self, weights, k, original_weighted_count):
        """Return boundary original rank and selected copies of its day.

        A zero-copy boundary is allowed, and is handled explicitly downstream.
        Searching starts at the original quota and touches only the changed tail.
        """
        if k==0:return -1,0
        need=int(k-original_weighted_count)
        if need==0:
            rank=k-1
            return rank,int(weights[self.order_unit[rank]])
        chunk=max(1024,2*abs(need))
        accumulated=0
        if need>0:
            cursor=k
            while cursor<self.M:
                end=min(self.M,cursor+chunk)
                values=weights[self.order_unit[cursor:end]]
                cumulative=np.cumsum(values,dtype=np.int64)
                if accumulated+int(cumulative[-1])>=need:
                    j=int(np.searchsorted(cumulative,need-accumulated,side='left'))
                    before=int(cumulative[j-1]) if j else 0
                    return cursor+j,need-accumulated-before
                accumulated+=int(cumulative[-1]);cursor=end
            raise AssertionError('Positive-boundary quota not reached')
        trim=-need;cursor=k
        while cursor>0:
            start=max(0,cursor-chunk)
            values=weights[self.order_unit[start:cursor]][::-1]
            cumulative=np.cumsum(values,dtype=np.int64)
            if accumulated+int(cumulative[-1])>=trim:
                j=int(np.searchsorted(cumulative,trim-accumulated,side='left'))
                before=int(cumulative[j-1]) if j else 0
                rank=cursor-1-j
                removed_here=trim-accumulated-before
                return rank,int(weights[self.order_unit[rank]])-removed_here
            accumulated+=int(cumulative[-1]);cursor=start
        raise AssertionError('Negative-boundary quota not reached')

    def bootstrap_means(self, weights, return_diagnostics=False):
        """Return exact re-budgeted seasonal means for all configured fractions.

        ``weights`` are non-negative integer whole-season multiplicities of length
        N summing to N, shared across all S scenarios. The selected quota is exact
        even when it splits the identical day of a repeated season copy.
        """
        raw=np.asarray(weights)
        if raw.shape!=(self.N,) or not np.isfinite(raw).all() or np.any(raw<0) or np.any(raw!=np.floor(raw)):
            raise ValueError('Weights must be non-negative whole-season integers')
        w=raw.astype(np.int64)
        if int(w.sum())!=self.N:raise ValueError('Bootstrap weights must sum to N')
        outputs=[];diagnostics=[]
        for bi,k0 in enumerate(self.counts):
            k=int(k0);base=self.baseline_metrics[bi]
            totals=np.einsum('snm,n->sm',base.astype(np.int64),w,optimize=True)
            original_weighted_count=int(totals[:,0].sum())
            boundary,boundary_copies=self._boundary(w,k,original_weighted_count)
            lo=min(k,boundary+1);hi=max(k,boundary+1)
            changed=self.order[lo:hi]
            rows=np.unique(changed//self.L)
            rows=rows[w[rows%self.N]>0]
            boundary_row=-1;boundary_weight=0
            if boundary>=0:
                boundary_day=int(self.order[boundary]);boundary_row=boundary_day//self.L
                boundary_weight=int(w[boundary_row%self.N])
                if boundary_copies<0 or boundary_copies>boundary_weight:raise AssertionError('Invalid boundary multiplicity')
                if boundary_copies<boundary_weight:
                    rows=np.union1d(rows,np.array([boundary_row],dtype=np.int64))
            if len(rows):
                masks=self.rank_rows[rows]<=boundary
                revised=seasonal_metrics(masks).astype(np.int64)
                delta=revised-self._base_flat[bi,rows]
                weighted_delta=delta*w[rows%self.N,None]
                np.add.at(totals,rows//self.N,weighted_delta)
                if boundary>=0 and boundary_copies<boundary_weight:
                    at=int(np.searchsorted(rows,boundary_row))
                    off=masks[at].copy();off[boundary_day%self.L]=False
                    off_metric=_one_season_metrics(off)
                    on_metric=revised[at]
                    totals[boundary_row//self.N]-=(boundary_weight-boundary_copies)*(on_metric-off_metric)
            if int(totals[:,0].sum())!=k:raise AssertionError('Re-selected pooled quota not exact')
            outputs.append(totals/self.N)
            diagnostics.append({'k':k,'boundary_rank':boundary,'boundary_selected_copies':int(boundary_copies),
                'boundary_total_copies':boundary_weight,'changed_original_seasons':int(len(rows)),
                'pooled_selected_days':int(totals[:,0].sum())})
        result=np.stack(outputs)
        return (result,diagnostics) if return_diagnostics else result


def prepare(order, shape, budgets):
    """Convenience alias returning :class:`TopkBootstrap`."""
    return TopkBootstrap(order,shape,budgets)
