"""Independent verification of the retrospective Step 6 storyline amendment.

Reads saved seasonal records and matching saved bootstrap means only. No
model fitting, calibration fitting, weather generation or resampling occurs.
This implementation deliberately does not import the amendment analysis code.
"""
from pathlib import Path
import argparse
import datetime as dt
import hashlib
import json
import platform
import sys
import traceback

import numpy as np
import pandas as pd
from scipy.stats import norm

MODELS = ['G', 'K']
METRICS = ['selected_days', 'clusters', 'max_run_days']
STORIES = ['baseline', 'persistent_wet', 'persistent_dry', 'dry_with_bursts',
           'flip_wet_to_dry', 'flip_dry_to_wet']
BUDGETS = [.01, .05, .10, .25, .50]
KEYS = ['analysis', 'model', 'rule', 'storyline', 'metric']


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(2**20), b''):
            h.update(block)
    return h.hexdigest()


def log_holm(values):
    """Independent step-down calculation, retaining arbitrarily small tails."""
    values = np.asarray(values, float)
    if np.isnan(values).any() or (values > 0).any():
        raise ValueError('Invalid log probabilities')
    order = sorted(range(len(values)), key=lambda i: (values[i], i))
    result = np.empty(len(values), float)
    running = -np.inf
    for rank, i in enumerate(order):
        candidate = min(0., float(values[i]) + np.log(len(values)-rank))
        running = max(running, candidate)
        result[i] = running
    return result


def star_from_log(logp):
    if logp < np.log(.001): return '***'
    if logp < np.log(.01): return '**'
    if logp < np.log(.05): return '*'
    return 'ns'


def unbiased_skew(x):
    x = np.asarray(x, float)
    n = len(x)
    d = x - x.mean()
    m2 = np.mean(d*d)
    if n < 3 or m2 <= 0: return np.nan
    return float(np.sqrt(n*(n-1))/(n-2) * np.mean(d*d*d)/m2**1.5)


def as_bool(value):
    if isinstance(value, str): return value.lower() == 'true'
    return bool(value)


def check_close(actual, expected, message, atol=1e-11, rtol=1e-10):
    if not np.allclose(actual, expected, atol=atol, rtol=rtol, equal_nan=True):
        raise AssertionError(f'{message}: actual={actual!r}; expected={expected!r}')


def boundary_checks():
    """Known-answer tests independent of the scientific result patterns."""
    check_close(np.exp(log_holm(np.log([.01, .04, .03]))), [.03, .06, .06],
                'Known Holm example')
    check_close(log_holm(np.zeros(5)), np.zeros(5), 'All-one p-values')
    extreme = log_holm([-10000., -900., -2.])
    assert np.isfinite(extreme).all()
    check_close(extreme, [-10000.+np.log(3), -900.+np.log(2), -2.],
                'Extreme tails retained')
    assert star_from_log(np.log(.05)) == 'ns'
    assert star_from_log(np.log(.01)) == '*'
    assert star_from_log(np.log(.001)) == '**'
    same = np.array([1., 2., 4., 7.])
    assert np.std(same-same, ddof=1) == 0
    assert np.std(same, ddof=1) > 0
    # Variance of paired differences must retain the covariance term.
    other = 2*same + np.array([0., 1., 0., -1.])
    check_close(np.var(same-other, ddof=1),
                np.var(same, ddof=1)+np.var(other, ddof=1)
                -2*np.cov(same, other, ddof=1)[0, 1],
                'Paired covariance identity')
    return 8


def source_hash_check(root):
    """Compare original files against the amendment's pre-edit hash inventory."""
    path = root/'inputs/provenance/STORYLINE_AMENDMENT_INPUTS.json'
    if not path.exists():
        raise AssertionError('Missing original input hash snapshot')
    snapshot = json.loads(path.read_text())
    entries = []
    def visit(obj):
        if isinstance(obj, dict):
            if 'sha256' in obj:
                rel = obj.get('path', obj.get('relative_path'))
                if rel: entries.append((rel, obj['sha256']))
            for key, value in obj.items():
                if isinstance(value, str) and len(value)==64 and '/' in key:
                    entries.append((key, value))
                elif isinstance(value, (list, dict)):
                    visit(value)
        elif isinstance(obj, list):
            for value in obj: visit(value)
    visit(snapshot)
    checked = []
    protected = ('inputs/step5/', 'results/inference/',
                 'results/seasonal_', 'results/matched_count_',
                 'results/scenario_baseline_differences.csv',
                 'results/paired_model_differences.csv',
                 'code/inference_step6.py', 'code/weighted_topk_bootstrap.py')
    for rel, expected in entries:
        rel = str(rel).replace('\\', '/')
        if rel.startswith('Step6_final/'): rel = rel[len('Step6_final/'):]
        if rel.startswith(protected):
            target = root/rel
            if not target.is_file(): raise AssertionError('Missing protected file '+rel)
            if sha256(target) != expected: raise AssertionError('Changed protected file '+rel)
            checked.append(rel)
    if 'results/inference/paired_tests.csv' not in checked:
        raise AssertionError('Old 270-test table absent from protected hash inventory')
    return sorted(set(checked))


def saved_state_diagnostics(root):
    """Describe realised sequences; do not infer an absent generator algorithm."""
    folder = root/'inputs/step5/inputs/step4/completed_run/simulations'
    rows = []
    for story in STORIES:
        with np.load(folder/f'{story}_AprSep.npz', allow_pickle=False) as z:
            states = z['states']
            assert states.shape == (5000, 183)
            assert z['donor_row'].shape == states.shape
            v = states[:, 30:]
            assert set(np.unique(v)) == {0, 1, 2, 3}
            for state in range(4):
                den = int((v[:, :-1] == state).sum())
                num = int(((v[:, :-1] == state)&(v[:, 1:] == state)).sum())
                rows.append(dict(storyline=story, state=state,
                    realised_fraction=float((v==state).mean()),
                    realised_self_transition=float(num/den),
                    transition_denominator=den))
    return rows


def verify(root):
    root = Path(root).resolve()
    out = root/'results/storyline_inference'
    frame = pd.read_csv(out/'all_contrasts.csv', float_precision='round_trip')
    assert len(frame)==190
    assert not frame.duplicated(KEYS).any()
    assert frame.groupby('analysis').size().to_dict()=={'matched':40, 'pooled':150}
    assert set(frame.model)==set(MODELS)
    n_boundary = boundary_checks()
    protected = source_hash_check(root)
    source = pd.read_csv(root/'results/seasonal_summary.csv', float_precision='round_trip')
    assert len(source)==990
    source = source.set_index(['model','rule','storyline','metric'])
    baseline = pd.read_csv(root/'results/scenario_baseline_differences.csv',
                           float_precision='round_trip').set_index(['model','rule','storyline','metric'])

    records = pd.read_csv(root/'results/seasonal_metrics.csv.gz')
    assert len(records)==1650000
    assert not records.duplicated(['model','rule','storyline','sim']).any()
    subset = records[records.model.isin(MODELS)]
    sizes = subset.groupby(['model','rule','storyline']).size()
    assert len(sizes)==60 and (sizes==5000).all()
    summary_checks=0
    for key, group in subset.groupby(['model','rule','storyline']):
        assert group.sim.nunique()==5000
        for metric in METRICS:
            original = float(source.loc[key+(metric,), 'mean'])
            check_close(float(group[metric].mean()), original,
                        f'Seasonal mean {key} {metric}')
            summary_checks += 1
    del records, subset

    match = pd.read_csv(root/'results/matched_count_seasonal_metrics.csv.gz')
    assert len(match)==360000
    assert not match.duplicated(['model','rule','storyline','sim']).any()
    sizes=match.groupby(['model','rule','storyline']).size()
    assert len(sizes)==72 and (sizes==5000).all()
    expected_count=match.rule.map({'matched_05':8,'matched_10':16})
    assert expected_count.notna().all()
    assert (match.selected_days.to_numpy()==expected_count.to_numpy()).all()
    for key, group in match.groupby(['model','rule','storyline']):
        assert group.sim.nunique()==5000

    expected={}
    covariance_checks=0
    with np.load(root/'results/inference/model_mean_bootstrap_replicates.npz',
                 allow_pickle=False) as z:
        model_labels=list(z['models']); budgets=list(z['budgets'])
        scenario_labels=list(z['scenarios']); metric_labels=list(z['metrics'])
        draw=z['means']
        assert draw.shape==(11,4000,5,6,3)
        assert len(set(model_labels))==11 and set(MODELS)<=set(model_labels)
        assert set(scenario_labels)==set(STORIES)
        check_close(sorted(budgets), BUDGETS, 'Saved budgets')
        assert set(metric_labels)==set(METRICS)
        assert np.isfinite(draw).all()
        with np.load(root/'results/inference/paired_bootstrap_replicates.npz',
                     allow_pickle=False) as paired:
            assert list(paired['scenarios'])==scenario_labels
            assert list(paired['metrics'])==metric_labels
            check_close(paired['budgets'],budgets,'Paired saved budget alignment')
            for high,low in [('E','C'),('F','J'),('G','K')]:
                check_close(paired[f'{high}_{low}'],
                            draw[model_labels.index(high)]-draw[model_labels.index(low)],
                            'Stored paired bootstrap replicate alignment',atol=1e-12)
        for model in MODELS:
            mi=model_labels.index(model)
            for budget in BUDGETS:
                bi=next(i for i,b in enumerate(budgets) if abs(b-budget)<1e-12)
                rule=f'topk_{round(100*budget):02d}'
                for story in STORIES[1:]:
                    si=scenario_labels.index(story); zi=scenario_labels.index('baseline')
                    for metric in METRICS:
                        ti=metric_labels.index(metric)
                        point=float(source.loc[(model,rule,story,metric),'mean']-
                                    source.loc[(model,rule,'baseline',metric),'mean'])
                        check_close(point,float(baseline.loc[(model,rule,story,metric),'mean_difference']),
                                    'Original scenario point difference')
                        a=draw[mi,:,bi,si,ti]; b=draw[mi,:,bi,zi,ti]; v=a-b
                        variance=float(np.var(a,ddof=1)+np.var(b,ddof=1)
                                       -2*np.cov(a,b,ddof=1)[0,1])
                        check_close(np.var(v,ddof=1),variance,'Saved-draw covariance identity',atol=1e-9)
                        covariance_checks+=1
                        se=float(np.std(v,ddof=1))
                        bias=float(v.mean()-point)
                        sk=unbiased_skew(v)
                        expected[('pooled',model,rule,story,metric)]=dict(
                            scenario_mean=float(source.loc[(model,rule,story,metric),'mean']),
                            baseline_mean=float(source.loc[(model,rule,'baseline',metric),'mean']),
                            mean_difference=point,standard_error=se,
                            ci95_lower=point-1.96*se,ci95_upper=point+1.96*se,
                            percentile95_lower=float(np.quantile(v,.025)),
                            percentile95_upper=float(np.quantile(v,.975)),
                            bootstrap_mean=float(v.mean()),bias_over_se=bias/se if se>0 else np.nan,
                            bootstrap_skewness=sk,
                            normal_approximation_flag=bool(abs(bias/se)>.25 or abs(sk)>.5) if se>0 else True,
                            percentile_zero_disagreement=bool(
                                (point-1.96*se<=0<=point+1.96*se) !=
                                (float(np.quantile(v,.025))<=0<=float(np.quantile(v,.975)))),
                            log_p_raw=float(np.log(2)+norm.logsf(abs(point/se))) if se>0 else np.nan)

    for model in MODELS:
        for rule in ['matched_05','matched_10']:
            base=match[(match.model==model)&(match.rule==rule)&(match.storyline=='baseline')].set_index('sim')
            for story in STORIES[1:]:
                altered=match[(match.model==model)&(match.rule==rule)&(match.storyline==story)].set_index('sim')
                assert len(base)==len(altered)==5000
                assert set(base.index)==set(altered.index)
                altered=altered.reindex(base.index)
                assert (altered.selected_days.to_numpy()==base.selected_days.to_numpy()).all()
                for metric in METRICS[1:]:
                    v=altered[metric].to_numpy(float)-base[metric].to_numpy(float)
                    point=float(v.mean()); se=float(v.std(ddof=1)/np.sqrt(len(v)))
                    expected[('matched',model,rule,story,metric)]=dict(
                        scenario_mean=float(altered[metric].mean()),
                        baseline_mean=float(base[metric].mean()),
                        mean_difference=point,standard_error=se,
                        ci95_lower=point-1.96*se,ci95_upper=point+1.96*se,
                        paired_difference_skewness=unbiased_skew(v),
                        paired_difference_zero_fraction=float((v==0).mean()),
                        paired_difference_min=float(v.min()),paired_difference_max=float(v.max()),
                        paired_difference_distinct_values=int(len(np.unique(v))),
                        log_p_raw=float(np.log(2)+norm.logsf(abs(point/se))) if se>0 else np.nan)
    assert len(expected)==190
    frame=frame.set_index(KEYS)
    assert set(frame.index)==set(expected)
    key_order=list(expected)
    lograw=np.array([expected[k]['log_p_raw'] for k in key_order])
    estimable=np.isfinite(lograw)
    # Non-estimable rows remain in the planned family; placeholder p=1 is
    # used solely inside adjustment, never published as an estimated p-value.
    adj=log_holm(np.where(estimable,lograw,0.))
    fields_checked=0
    for i,key in enumerate(key_order):
        actual=frame.loc[key]
        for field,value in expected[key].items():
            if field in ['normal_approximation_flag','percentile_zero_disagreement']:
                assert as_bool(actual[field])==value, f'Diagnostic flag {key}'
            else:
                check_close(float(actual[field]),value,f'{key} {field}',atol=2e-10)
            fields_checked+=1
        assert int(actual.n_pairs)==5000
        assert int(actual.family_size)==190 and actual.family_id=='storyline_190'
        assert int(actual.n_bootstrap_replicates)==(4000 if key[0]=='pooled' else 0)
        if estimable[i]:
            check_close(float(actual.log_p_holm),adj[i],f'{key} adjusted p',atol=2e-9)
            assert str(actual.stars)==star_from_log(adj[i]), f'Adjusted stars {key}'
            assert as_bool(actual.holm_reject_05)==bool(adj[i]<np.log(.05))
            for field,logvalue in [('p_raw',lograw[i]),('p_holm',adj[i])]:
                value=float(actual[field])
                # Underflow may be missing or conservatively floored positive,
                # but never represented as a numerically exact zero.
                assert np.isnan(value) or (0<value<=1), f'Invalid probability {key} {field}'
                if logvalue>=np.log(np.nextafter(0.,1.)):
                    check_close(value,np.exp(logvalue),f'{key} {field}',atol=1e-15)
            for field,logvalue in [('p_raw_display',lograw[i]),('p_holm_display',adj[i])]:
                shown=str(actual[field]).strip()
                assert shown not in ['0','0.0','0.0000','0.000e+00']
                if logvalue<np.log(1e-300): assert shown.startswith('<'), (key,field,shown)
        else:
            assert str(actual.stars)=='NE'

    metadata=json.loads((root/'results/inference/INFERENCE_METADATA.json').read_text())
    assert metadata['replicates']==4000 and metadata['n_units']==5000
    assert 'exact pooled quota reapplied' in metadata['resampling']
    inference_code=(root/'code/inference_step6.py').read_text()
    assert 'draws[i]=engine.bootstrap_means(w)' in inference_code
    assert 'np.save(tmp/\'weights.npy\',w)' in inference_code
    assert 'replicates' in metadata and metadata['no_model_refitting'] and metadata['no_weather_regeneration']
    state_diagnostics=saved_state_diagnostics(root)
    report=dict(status='passed',UTC=dt.datetime.now(dt.timezone.utc).isoformat(),
        verifier='Independent implementation; amendment analysis module not imported',
        contrasts_verified=190,pooled_verified=150,matched_verified=40,
        independent_numerical_fields_checked=fields_checked,
        known_answer_boundary_checks=n_boundary,
        original_G_K_seasonal_summaries_reproduced=summary_checks,
        original_seasonal_records_read=1650000,matched_records_read=360000,
        complete_unique_matched_count_records=True,
        matched_counts_exactly_8_or_16=True,
        covariance_identities_checked=covariance_checks,
        existing_protected_files_hash_verified=protected,
        existing_270_WP_tests_hash_preserved=True,
        saved_bootstrap_alignment_and_labels_verified=True,
        original_paired_draw_alignment_checked_for=['E-C','F-J','G-K'],
        whole_bundle_reselection_source_and_metadata_verified=True,
        conditional_common_random_number_coupling='Numerical coupling, not causal observational pairing',
        saved_state_sequence_diagnostics=state_diagnostics,
        scenario_scope='Saved sequences change occurrence frequencies and persistence together; original Step 3 generation algorithm is not included in this Step 6 package.',
        scientific_refitting_or_simulation_performed=False,new_bootstrap_draws_generated=False,
        versions=dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__))
    out.mkdir(exist_ok=True)
    (out/'INDEPENDENT_VERIFICATION.json').write_text(json.dumps(report,indent=2)+'\n')
    logs=root/'logs';logs.mkdir(exist_ok=True)
    (logs/'independent_storyline_verification.log').write_text(
        'Independent verification completed '+report['UTC']+'\n'
        '150 pooled contrasts and 40 matched-count contrasts verified.\n'
        '190-test log-space Holm adjustment and annotations verified.\n'
        '180 original G/K seasonal summaries reproduced from saved records.\n'
        '360,000 matched records complete, unique and count-correct.\n'
        'Original protected source-file hashes verified.\n'
        'No model fitting, calibration fitting, simulation or bootstrap generation.\n')
    print('Independent verification passed: 150 pooled + 40 matched contrasts; Holm190; original summaries and source hashes.')
    return report


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent.parent)
    args=parser.parse_args()
    try:
        verify(args.root)
    except Exception:
        traceback.print_exc()
        sys.exit(1)
