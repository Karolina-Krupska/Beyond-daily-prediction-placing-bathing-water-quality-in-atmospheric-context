"""Literal expanded-season comparisons for the exact weighted Top-k engine."""
import unittest
import numpy as np
from analysis_step6 import seasonal_metrics
from weighted_topk_bootstrap import TopkBootstrap


def literal(order,shape,weights,budgets):
    S,N,L=shape;M=S*N*L
    rank=np.empty(M,int);rank[order]=np.arange(M)
    # Materialise complete copied seasons. Copy ordinal is the third tie key.
    indices=[];copies=[];scenario=[];season=[];day=[]
    cursor=0
    for s in range(S):
        within=0
        for i,w in enumerate(weights):
            for copy in range(int(w)):
                for t in range(L):
                    indices.append((s*N+i)*L+t);copies.append(copy)
                    scenario.append(s);season.append(within);day.append(t)
                within+=1
        if within!=N:raise AssertionError('Literal season count wrong')
    indices=np.array(indices);copies=np.array(copies)
    expanded_order=np.lexsort((copies,rank[indices]));outputs=[]
    for fraction in budgets:
        k=int(np.ceil(fraction*M));selected=np.zeros(M,bool);selected[expanded_order[:k]]=True
        x=selected.reshape(S,N,L)
        outputs.append(np.stack([seasonal_metrics(a).mean(0) for a in x]))
    return np.stack(outputs)


class WeightedTopkTests(unittest.TestCase):
    def test_identity_weights_preserve_original_metrics(self):
        rng=np.random.default_rng(34);shape=(3,7,9);order=rng.permutation(np.prod(shape))
        engine=TopkBootstrap(order,shape,[.01,.1,.5,.9])
        np.testing.assert_array_equal(engine.bootstrap_means(np.ones(7,int)),engine.baseline_metrics.mean(2))

    def test_random_expanded_samples_all_three_metrics(self):
        rng=np.random.default_rng(708)
        for shape in [(1,5,8),(3,7,9),(2,4,5)]:
            budgets=[0,.01,.1,.25,.5,.9,1]
            for trial in range(12):
                # Rounded probabilities deliberately create many exact ties.
                p=rng.integers(0,3,size=np.prod(shape));ties=rng.random(len(p));order=np.lexsort((ties,-p))
                engine=TopkBootstrap(order,shape,budgets)
                for rep in range(8):
                    w=rng.multinomial(shape[1],np.repeat(1/shape[1],shape[1]))
                    actual,diagnostics=engine.bootstrap_means(w,True)
                    np.testing.assert_allclose(actual,literal(order,shape,w,budgets),rtol=0,atol=1e-14)
                    self.assertEqual([v['pooled_selected_days'] for v in diagnostics],engine.counts.tolist())

    def test_single_duplicated_unit_and_partial_boundary(self):
        shape=(2,3,4);order=np.arange(24);weights=np.array([0,3,0]);budgets=[1/24,5/24,.5,23/24]
        engine=TopkBootstrap(order,shape,budgets)
        actual,diag=engine.bootstrap_means(weights,True)
        np.testing.assert_allclose(actual,literal(order,shape,weights,budgets),rtol=0,atol=1e-14)
        self.assertTrue(any(v['boundary_selected_copies']<v['boundary_total_copies'] for v in diag))

    def test_invalid_input_rejected(self):
        with self.assertRaises(ValueError):TopkBootstrap([0,0],(1,1,2),[.5])
        engine=TopkBootstrap(np.arange(12),(2,3,2),[.5])
        for w in [[1,1,0],[.5,.5,2],[-1,2,2]]:
            with self.assertRaises(ValueError):engine.bootstrap_means(w)


if __name__=='__main__':unittest.main()
