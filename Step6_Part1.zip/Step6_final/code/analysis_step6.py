"""Step 6: verify existing selections; analyse seasonal organisation without fitting."""
from pathlib import Path
import sys, json, hashlib, gzip, platform, time
import numpy as np
import pandas as pd
import joblib

STORIES = ['baseline','persistent_wet','persistent_dry','dry_with_bursts',
           'flip_wet_to_dry','flip_dry_to_wet']
BUDGETS = [.01,.05,.10,.25,.50]
MODELS = list('ABCDEFGHIJK')
PAIRS = [('E','C'),('F','J'),('G','K')]
METRICS = ['selected_days','clusters','max_run_days']
DATES = pd.date_range('2001-04-01','2001-09-30')
SUMMER = DATES.month >= 5
SHAPE = (6,5000,153)

def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(2**20),b''):h.update(block)
    return h.hexdigest()

def seasonal_metrics(x):
    """Independent vectorised implementation; rows must be consecutive seasons."""
    x=np.asarray(x,dtype=bool)
    if x.ndim!=2 or not x.shape[1]:raise ValueError('Expected non-empty seasons by days')
    n,L=x.shape
    count=x.sum(1).astype(np.int16)
    clusters=(x & ~np.concatenate([np.zeros((n,1),bool),x[:,:-1]],axis=1)).sum(1).astype(np.int16)
    current=np.zeros(n,np.int16);maximum=current.copy()
    for day in range(L):
        current=np.where(x[:,day],current+1,0)
        maximum=np.maximum(maximum,current)
    result=np.column_stack([count,clusters,maximum])
    if not np.all((count==0)==(clusters==0)) or not np.all((count==0)==(maximum==0)):
        raise AssertionError('Zero-season inconsistency')
    if not np.all((clusters<=count)&(maximum<=count)):raise AssertionError('Invalid run metrics')
    return result

def unpack(path):
    with np.load(path,allow_pickle=False) as z:
        if tuple(z['shape'])!=SHAPE or str(z['bitorder'])!='little':raise ValueError('Mask metadata changed')
        return np.unpackbits(z['packed'],count=int(np.prod(SHAPE)),bitorder='little').reshape(SHAPE).astype(bool)

def summarise(values,**labels):
    a=np.asarray(values)
    if not np.isfinite(a).all():raise ValueError('Non-finite seasonal metrics')
    out=[]
    for j,metric in enumerate(METRICS):
        v=a[:,j]
        out.append(dict(**labels,metric=metric,n_seasons=len(v),mean=float(v.mean()),
            median=float(np.median(v)),p05=float(np.quantile(v,.05)),p95=float(np.quantile(v,.95)),
            p025=float(np.quantile(v,.025)),p975=float(np.quantile(v,.975)),
            fraction_zero=float(np.mean(v==0))))
    return out

def differences(a,b,matched_count=False,**labels):
    delta=np.asarray(a,dtype=float)-np.asarray(b,dtype=float)
    rows=[]
    for j,metric in enumerate(METRICS):
        v=delta[:,j];se=float(v.std(ddof=1)/np.sqrt(len(v)))
        rows.append(dict(**labels,metric=metric,n_paired=len(v),mean_difference=float(v.mean()),
            difference_p05=float(np.quantile(v,.05)),difference_p95=float(np.quantile(v,.95)),
            mc_se_fixed_cutoff_approx=se if not matched_count else np.nan,
            mc_se=se if matched_count else np.nan,
            mc95_lower=float(v.mean()-1.96*se) if matched_count else np.nan,
            mc95_upper=float(v.mean()+1.96*se) if matched_count else np.nan,
            uncertainty_scope=('Normal-approximation Monte Carlo interval conditional on fitted models, generator and per-season selection; no refitting'
               if matched_count else 'Seasonal difference quantiles; MCSE approximate conditional on fixed pooled cut-offs; not an inferential confidence interval')))
    return rows

def per_season_order(probabilities,uniform):
    if probabilities.shape!=uniform.shape:raise ValueError('Tie priorities do not align')
    return np.lexsort((uniform,-probabilities),axis=-1)

def select_equal_count(order,k):
    out=np.zeros(order.shape,bool)
    np.put_along_axis(out,order[...,:k],True,axis=-1)
    return out

def validate_inputs(root,checks):
    src=root/'inputs/step5'
    for item in json.loads((root/'inputs/provenance/REQUIRED_INPUTS.json').read_text()):
        p=root/item['path']
        if not p.exists() or sha256(p)!=item['sha256']:raise ValueError('Changed or absent input: '+str(p))
    checks['immutable_required_inputs']=True
    config=json.loads((src/'config.json').read_text());registry=json.loads((src/'model_registry.json').read_text())
    assert config['scenarios']==STORIES and config['seasons_per_scenario']==5000
    assert list(registry)==MODELS and config['topk_budgets']==BUDGETS
    assert registry['G']['numerical']==registry['K']['numerical']
    assert registry['G']['categorical']==['family'] and registry['K']['categorical']==[]
    checks['registry_G_K_same_numerical_predictors']=True
    for high,low in PAIRS:
        assert registry[high]['numerical']==registry[low]['numerical']
        assert registry[high]['categorical']==['family'] and registry[low]['categorical']==[]
    checks['all_prespecified_model_pairs_differ_only_by_WP']=True
    assert SUMMER.sum()==153 and len(DATES)==183
    assert np.all(np.diff(DATES[SUMMER].to_numpy()).astype('timedelta64[D]')==np.timedelta64(1,'D'))
    checks['consecutive_synthetic_evaluation_dates']=True
    return src,registry

def reconstruct_exact(root,src,checks):
    """Prediction only from supplied fitted models; never .fit or .fit_transform."""
    sys.path.insert(0,str(src/'code'))
    from storylines import daily_frame
    lib=pd.read_csv(src/'inputs/step4/completed_run/prepared/historical_donor_library.csv',parse_dates=['date'],float_precision='round_trip')
    meta=json.loads((src/'inputs/step4/completed_run/run_metadata.json').read_text())
    scratch=root/'temporary';scratch.mkdir(exist_ok=True)
    exact=np.lib.format.open_memmap(scratch/'exact_calibrated_probabilities.npy',mode='w+',dtype='float64',shape=(11,)+SHAPE)
    coverage=[];model_audit=[]
    for s,story in enumerate(STORIES):
        print('Reconstructing existing calibrated probabilities:',story,flush=True)
        with np.load(src/f'inputs/step4/completed_run/simulations/{story}_AprSep.npz') as z:
            donor=z['donor_row'];states=z['states']
            assert donor.shape==states.shape==(5000,183)
            assert donor.min()>=0 and donor.max()<len(lib)
            assert np.array_equal(lib.state.to_numpy()[donor],states)
            assert np.array_equal(lib.month.to_numpy()[donor],np.broadcast_to(DATES.month.to_numpy(),donor.shape))
        frame=daily_frame(lib,donor,states,meta['api_alpha'])
        assert len(frame)==5000*153
        for i,letter in enumerate(MODELS):
            m=joblib.load(src/f'fitted_models/{letter}.joblib')
            if s==0:
                classifier=m['base'].named_steps['logistic']
                model_audit.append(dict(model=letter,features=m['features'],class_weight=classifier.class_weight,
                    C=classifier.C,base_iterations=classifier.n_iter_.tolist(),
                    calibration_coefficient=m['calibrator'].coef_.ravel().tolist(),
                    calibration_intercept=m['calibrator'].intercept_.ravel().tolist(),
                    fitted_model_sha256=sha256(src/f'fitted_models/{letter}.joblib'),action='predict only; no fitting'))
            score=m['base'].decision_function(frame[m['features']])
            p=m['calibrator'].predict_proba(score.reshape(-1,1))[:,1]
            assert np.isfinite(p).all() and np.all((p>=0)&(p<=1))
            exact[i,s]=p.reshape(5000,153)
        coverage.append(dict(storyline=story,n_seasons=5000,initialisation_days=30,evaluation_days=153,
            models=11,donor_state_month_checks_passed=True,all_probabilities_finite_and_bounded=True))
    exact.flush()
    pd.DataFrame(coverage).to_csv(root/'results/coverage.csv',index=False)
    (root/'results/fitted_model_prediction_audit.json').write_text(json.dumps(model_audit,indent=2))
    checks['all_scenario_donor_family_month_alignment']=True
    checks['all_reconstructed_probabilities_finite_bounded']=True
    return exact

def run(root):
    started=time.time();checks={};src,registry=validate_inputs(root,checks)
    out=root/'results';out.mkdir(exist_ok=True)
    exact=reconstruct_exact(root,src,checks)
    audits=pd.read_csv(src/'results/pooled_topk_budget_audit.csv',float_precision='round_trip')
    reference=pd.read_csv(src/'results/selected_day_metrics_by_season.csv.gz',float_precision='round_trip')
    reference=reference[reference.rule.str.startswith('topk_')].copy()
    reference=reference.set_index(['model','rule','storyline','sim']).sort_index()
    assert len(reference)==11*5*6*5000 and reference.index.is_unique
    summaries=[];paired=[];baseline=[];zeros=[];budgetaudit=[];tieaudit=[];stored={};matched={};stability=[]
    primary_ties=np.random.default_rng(np.random.SeedSequence([42,5,700])).random(int(np.prod(SHAPE)))
    alt_ties={seed:np.random.default_rng(np.random.SeedSequence([42,5,seed])).random(int(np.prod(SHAPE))) for seed in [701,702]}
    matched_uniform=np.random.default_rng(np.random.SeedSequence([42,6,800])).random(SHAPE)
    matched_alt={seed:np.random.default_rng(np.random.SeedSequence([42,6,seed])).random(SHAPE) for seed in [801,802]}
    matchletters=set(sum(([a,b] for a,b in PAIRS),[]))
    first=True;first_matched=True;match_tie=[]
    with gzip.open(out/'seasonal_metrics.csv.gz','wt',encoding='utf-8',newline='') as seasonal_handle, gzip.open(out/'matched_count_seasonal_metrics.csv.gz','wt',encoding='utf-8',newline='') as matched_handle:
      for i,letter in enumerate(MODELS):
        print('Verifying saved selections and summaries:',letter,flush=True)
        p=np.asarray(exact[i]);flat=p.ravel();order=np.lexsort((primary_ties,-flat))
        previous=np.zeros(SHAPE,bool)
        for budget in BUDGETS:
            rule=f'topk_{round(100*budget):02d}';k=int(np.ceil(budget*flat.size))
            selected=unpack(src/f'simulation_probabilities/selection_masks/{letter}_{rule}.npz')
            rebuilt=np.zeros(flat.size,bool);rebuilt[order[:k]]=True
            assert np.array_equal(selected.ravel(),rebuilt),f'Exact full-precision selection mismatch: {letter} {rule}'
            assert selected.sum()==k and not np.any(previous&~selected)
            previous=selected.copy()
            row=audits[(audits.model==letter)&(audits.rule==rule)].iloc[0]
            boundary=float(flat[order[k-1]])
            assert boundary==row.boundary_probability
            ntied=int(np.sum(flat==boundary));assert ntied==row.n_days_tied_at_boundary
            budgetaudit.append(dict(model=letter,rule=rule,pool_days=flat.size,k=k,selected_days=int(selected.sum()),
                boundary_probability=boundary,n_tied_at_boundary=ntied,ties_relative_to_k=ntied/k,
                exact_mask_reproduced=True,primary_tie_seed='42,5,700'))
            for s,story in enumerate(STORIES):
                m=seasonal_metrics(selected[s]);stored[letter,rule,story]=m
                ref=reference.loc[(letter,rule,story)].sort_index()[METRICS].to_numpy()
                assert np.array_equal(m,ref),f'Step 5 metric mismatch: {letter}/{rule}/{story}'
                summaries.extend(summarise(m,model=letter,rule=rule,storyline=story))
                frame=pd.DataFrame(m,columns=METRICS);frame.insert(0,'sim',np.arange(5000));frame.insert(0,'storyline',story)
                frame.insert(0,'rule',rule);frame.insert(0,'model',letter)
                frame.to_csv(seasonal_handle,index=False,header=first);first=False
                positive=m[:,0]>0
                zeros.append(dict(model=letter,rule=rule,storyline=story,n_seasons=5000,
                    n_zero=int((~positive).sum()),fraction_zero=float((~positive).mean()),
                    mean_max_run_all=float(m[:,2].mean()),
                    mean_max_run_if_selected=float(m[positive,2].mean()) if positive.any() else np.nan))
            # Target only boundary ties substantial relative to selected count; full numerical pairs usually have none.
            if ntied/k>=.01:
                for seed,uniform in alt_ties.items():
                    gt=flat>boundary;eq=np.flatnonzero(flat==boundary);need=k-int(gt.sum())
                    add=eq[np.argsort(uniform[eq],kind='stable')[:need]];alt=gt.copy();alt[add]=True
                    assert alt.sum()==k
                    for s,story in enumerate(STORIES):
                        am=seasonal_metrics(alt.reshape(SHAPE)[s]);pm=stored[letter,rule,story]
                        for j,name in enumerate(METRICS):
                            tieaudit.append(dict(model=letter,rule=rule,storyline=story,metric=name,tie_seed_component=seed,
                                primary_mean=float(pm[:,j].mean()),alternative_mean=float(am[:,j].mean()),
                                change_from_primary=float((am[:,j]-pm[:,j]).mean()),n_tied_at_boundary=ntied))
        if letter in matchletters:
            mo=per_season_order(p,matched_uniform)
            for budget in [.05,.10]:
                rule=f'matched_{round(100*budget):02d}';k=int(np.ceil(budget*153));mask=select_equal_count(mo,k)
                assert np.all(mask.sum(-1)==k)
                for s,story in enumerate(STORIES):
                    m=seasonal_metrics(mask[s]);matched[letter,rule,story]=m
                    frame=pd.DataFrame(m,columns=METRICS);frame.insert(0,'sim',np.arange(5000));frame.insert(0,'storyline',story)
                    frame.insert(0,'rule',rule);frame.insert(0,'model',letter)
                    frame.to_csv(matched_handle,index=False,header=first_matched);first_matched=False
                for seed,uniform in matched_alt.items():
                    alt=select_equal_count(per_season_order(p,uniform),k)
                    assert np.all(alt.sum(-1)==k)
                    for s,story in enumerate(STORIES):
                        am=seasonal_metrics(alt[s]);pm=matched[letter,rule,story]
                        for j,name in enumerate(METRICS):
                            match_tie.append(dict(model=letter,rule=rule,storyline=story,metric=name,tie_seed_component=seed,
                                mean_change=float((am[:,j]-pm[:,j]).mean()),
                                n_seasons_changed=int(np.any(am!=pm,axis=1).sum())))
    checks['all_55_full_precision_masks_reproduced_exactly']=True
    checks['all_55_pooled_budgets_exact_and_masks_nested']=True
    checks['all_1650000_primary_season_records_match_step5']=True
    checks['all_matched_count_seasons_equal_8_or_16_days']=True
    checks['all_targeted_tie_sensitivities_preserve_counts']=True
    matched_summary=[];matched_pairs=[]
    for (letter,rule,story),m in matched.items():matched_summary.extend(summarise(m,model=letter,rule=rule,storyline=story))
    for high,low in PAIRS:
        for budget in BUDGETS:
            rule=f'topk_{round(100*budget):02d}'
            for story in STORIES:
                a=stored[high,rule,story];b=stored[low,rule,story]
                paired.extend(differences(a,b,comparison=f'{high}-{low}',rule=rule,storyline=story))
                # Disjoint 250-season batches are a stability diagnostic, not confidence intervals.
                d=(a-b).reshape(20,250,3).mean(1)
                for j,metric in enumerate(METRICS):
                    stability.append(dict(comparison=f'{high}-{low}',rule=rule,storyline=story,metric=metric,
                        n_batches=20,seasons_per_batch=250,minimum_batch_mean=float(d[:,j].min()),
                        maximum_batch_mean=float(d[:,j].max()),mean_of_batch_means=float(d[:,j].mean()),
                        scope='Disjoint simulation-batch variability at fixed original selections; not a confidence interval'))
        for rule in ['matched_05','matched_10']:
            for story in STORIES:
                matched_pairs.extend(differences(matched[high,rule,story],matched[low,rule,story],True,
                    comparison=f'{high}-{low}',rule=rule,storyline=story))
    for letter in MODELS:
        for budget in BUDGETS:
            rule=f'topk_{round(100*budget):02d}'
            for story in STORIES[1:]:
                baseline.extend(differences(stored[letter,rule,story],stored[letter,rule,'baseline'],
                    comparison=f'{story}-baseline',model=letter,rule=rule,storyline=story,
                    pairing='Shared Step 4 donor uniforms by simulation index; conditional common-random-number coupling, not causal pairing'))
    # Aggregate selected-day differences must vanish: all compared models share one pooled budget.
    for high,low in PAIRS:
        for budget in BUDGETS:
            rule=f'topk_{round(100*budget):02d}'
            assert sum(int((stored[high,rule,s][:,0]-stored[low,rule,s][:,0]).sum()) for s in STORIES)==0
    checks['paired_selected_day_differences_sum_to_zero_across_pool']=True
    tables={'seasonal_summary':summaries,'paired_model_differences':paired,'scenario_baseline_differences':baseline,
        'zero_selection_seasons':zeros,'budget_and_precision_audit':budgetaudit,'tie_seed_sensitivity':tieaudit,
        'matched_count_summary':matched_summary,'matched_count_paired_differences':matched_pairs,
        'matched_count_tie_sensitivity':match_tie,'simulation_batch_stability':stability}
    for name,rows in tables.items():pd.DataFrame(rows).to_csv(out/f'{name}.csv',index=False,float_format='%.17g')
    # Upstream validation evidence remains historical, not Step 6 simulation uncertainty.
    perf=pd.read_csv(src/'results/performance_pooled.csv');perf=perf[perf.setting.eq('primary') & perf.model.isin(['G','K'])]
    perf.to_csv(out/'upstream_G_K_observed_validation.csv',index=False)
    ci=pd.read_csv(src/'results/paired_bootstrap_intervals.csv');ci[ci.setting.eq('primary')].to_csv(out/'upstream_observed_comparison_intervals.csv',index=False)
    checks['no_models_refitted_or_recalibrated']=True
    checks['all_figures_use_current_result_tables']=True
    import sklearn,scipy,matplotlib
    (out/'EXECUTION_METADATA.json').write_text(json.dumps(dict(status='analysis_completed',elapsed_seconds=time.time()-started,
        python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,sklearn=sklearn.__version__,
        scipy=scipy.__version__,matplotlib=matplotlib.__version__,n_scenarios=6,n_seasons_per_scenario=5000,
        n_evaluation_days=153,n_models=11,primary_season_records=1650000,matched_count_season_records=len(matchletters)*2*6*5000,
        primary_budget=json.loads((root/'config.json').read_text())['primary_budget'],primary_tie_seed=[42,5,700],matched_tie_seed=[42,6,800],
        no_model_fitting=True,no_weather_regeneration=True,checks=checks),indent=2))
    del exact
    (root/'temporary/exact_calibrated_probabilities.npy').unlink()
    (root/'temporary').rmdir()
    print('Step 6 analysis complete; original selections retained exactly.',flush=True)
    return checks
