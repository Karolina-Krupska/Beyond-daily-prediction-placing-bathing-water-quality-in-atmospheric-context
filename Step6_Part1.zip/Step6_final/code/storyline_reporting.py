"""Write reporting for the retrospective Step 6 storyline-inference amendment.

Reads existing outcomes and newly calculated contrasts. No model, calibration,
simulation or bootstrap sampling is performed by this module.
"""
from pathlib import Path
import argparse
import json
import math

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
SCENARIOS = [
    'baseline', 'persistent_wet', 'persistent_dry', 'dry_with_bursts',
    'flip_wet_to_dry', 'flip_dry_to_wet',
]
LABELS = {
    'baseline': 'Baseline', 'persistent_wet': 'Persistent wet',
    'persistent_dry': 'Persistent dry', 'dry_with_bursts': 'Dry with storm outbreaks',
    'flip_wet_to_dry': 'Wet to dry', 'flip_dry_to_wet': 'Dry to wet',
    'selected_days': 'Model-selected days', 'clusters': 'Selected-day clusters',
    'max_run_days': 'Maximum run length',
}


def _boolean(series):
    if series.dtype == bool:
        return series
    return series.astype(str).str.lower().eq('true')


def _row(frame, **filters):
    use = pd.Series(True, index=frame.index)
    for key, value in filters.items():
        use &= frame[key].eq(value)
    matches = frame.loc[use]
    if len(matches) != 1:
        raise ValueError(f'Expected one row for {filters}, found {len(matches)}')
    return matches.iloc[0]


def _number(value, places=2):
    value = float(value)
    if not math.isfinite(value):
        return 'not estimable'
    return f'{value:.{places}f}'


def _effect(row, places=3):
    # Readable publication wording; exact log/display values remain in sources.
    logp = float(row.log_p_holm)
    paper_p = '<0.001' if logp < math.log(.001) else f'{math.exp(logp):.3f}'
    return (f"{float(row.mean_difference):+.{places}f} "
            f"(pointwise 95% CI {float(row.ci95_lower):+.{places}f} to "
            f"{float(row.ci95_upper):+.{places}f}; Holm-adjusted p "
            f"{paper_p})")


def _source_table(frame, path):
    cols = [c for c in [
        'analysis', 'model', 'rule', 'selected_days_per_season', 'storyline',
        'metric', 'mean_difference', 'standard_error', 'ci95_lower',
        'ci95_upper', 'percentile95_lower', 'percentile95_upper',
        'p_holm_display', 'stars', 'normal_approximation_flag',
        'diagnostic_caution',
    ] if c in frame.columns]
    frame[cols].to_csv(path, index=False, float_format='%.17g')


def run(root=ROOT):
    root = Path(root)
    out = root / 'reports/storyline_amendment'
    out.mkdir(parents=True, exist_ok=True)
    result_dir = root / 'results/storyline_inference'
    contrasts = pd.read_csv(result_dir / 'all_contrasts.csv', float_precision='round_trip')
    summary = pd.read_csv(root / 'results/seasonal_summary.csv', float_precision='round_trip')
    matched = pd.read_csv(root / 'results/matched_count_summary.csv', float_precision='round_trip')
    original_tests = pd.read_csv(root / 'results/inference/paired_tests.csv', float_precision='round_trip')
    metadata_path = result_dir / 'METADATA.json'
    metadata = json.loads(metadata_path.read_text()) if metadata_path.exists() else {}
    if len(contrasts) != 190:
        raise ValueError('The new storyline family must contain exactly 190 planned contrasts')
    pooled = contrasts[contrasts.analysis.eq('pooled')]
    count = contrasts[contrasts.analysis.eq('matched')]
    if len(pooled) != 150 or len(count) != 40:
        raise ValueError('Expected 150 pooled and 40 matched-count contrasts')

    def gmean(story, metric):
        return _row(summary, model='G', rule='topk_10', storyline=story, metric=metric)['mean']

    def mmean(story, metric, model='G', rule='matched_10'):
        return _row(matched, model=model, rule=rule, storyline=story, metric=metric)['mean']

    def gcontrast(story, metric):
        return _row(pooled, model='G', rule='topk_10', storyline=story, metric=metric)

    def mcontrast(story, metric):
        return _row(count, model='G', rule='matched_10', storyline=story, metric=metric)

    gp = pooled[pooled.model.eq('G') & pooled.rule.eq('topk_10')]
    gm = count[count.model.eq('G') & count.rule.eq('matched_10')]
    flagged = pooled[_boolean(pooled.normal_approximation_flag)]
    disagree_col = 'percentile_zero_disagreement'
    disagreed = pooled[_boolean(pooled[disagree_col])] if disagree_col in pooled else pooled.iloc[:0]
    caution = pooled[_boolean(pooled.diagnostic_caution)] if 'diagnostic_caution' in pooled else flagged
    sig_col = 'stars'
    def nsig(frame):
        return int(frame[sig_col].isin(['*', '**', '***']).sum())

    # Copy-ready results use values read directly from the authoritative tables.
    wet_days = gcontrast('persistent_wet', 'selected_days')
    drywet_days = gcontrast('flip_dry_to_wet', 'selected_days')
    wet_run = gcontrast('persistent_wet', 'max_run_days')
    drywet_run = gcontrast('flip_dry_to_wet', 'max_run_days')
    m_wet_run = mcontrast('persistent_wet', 'max_run_days')
    m_bursts_run = mcontrast('dry_with_bursts', 'max_run_days')
    old_gk = original_tests[original_tests.comparison.eq('G-K') & original_tests.rule.eq('topk_10')]
    old_gk_clusters = old_gk[old_gk.metric.eq('clusters')]
    old_gk_runs = old_gk[old_gk.metric.eq('max_run_days')]
    old_flag = _boolean(original_tests.normal_approximation_flag)
    text = f'''STEP 6: COPY-READY RESULTS — STORYLINE INFERENCE AMENDMENT

Atmospheric storyline comparisons

At pooled Top 10% selection, the six equally sized scenario ensembles shared exactly 459,000 model-selected days per model across 4,590,000 evaluated days. The selection budget was pooled across scenarios rather than imposed within each season. For model G, mean selected-day counts were {gmean('persistent_wet','selected_days'):.2f} under persistent-wet conditions and {gmean('flip_dry_to_wet','selected_days'):.2f} under dry-to-wet conditions, compared with {gmean('baseline','selected_days'):.2f} at baseline. Mean maximum run lengths were {gmean('persistent_wet','max_run_days'):.2f}, {gmean('flip_dry_to_wet','max_run_days'):.2f} and {gmean('baseline','max_run_days'):.2f} days, respectively. Persistent-dry, storm-outbreak and wet-to-dry seasons contained {gmean('persistent_dry','selected_days'):.2f}, {gmean('dry_with_bursts','selected_days'):.2f} and {gmean('flip_wet_to_dry','selected_days'):.2f} selected days, with maximum runs of {gmean('persistent_dry','max_run_days'):.2f}, {gmean('dry_with_bursts','max_run_days'):.2f} and {gmean('flip_wet_to_dry','max_run_days'):.2f} days.

Within G, the persistent-wet minus baseline difference was {_effect(wet_days)} model-selected days and {_effect(wet_run)} maximum-run days. The corresponding dry-to-wet differences were {_effect(drywet_days)} model-selected days and {_effect(drywet_run)} maximum-run days. The complete table includes all five altered storylines, all three outcomes and both G and K; {nsig(gp)} of the 15 G/Top-10% contrasts met the 0.05 Holm-adjusted threshold within the full family of 190 new storyline comparisons. These are comparisons between specified simulated storylines, rather than tests of an isolated causal persistence effect.

Controlling selected-day counts

The matched-count sensitivity fixed the selection at eight or sixteen days in every season, corresponding to 5.23% or 10.46% of 153 days. At sixteen selected days, G's mean maximum run was {mmean('baseline','max_run_days'):.4f} days at baseline and {mmean('persistent_wet','max_run_days'):.4f} days under persistent-wet conditions. The within-model persistent-wet minus baseline contrast was {_effect(m_wet_run,4)} days. Persistent-wet seasons had more selected-day clusters than baseline, a difference of {_effect(mcontrast('persistent_wet','clusters'),4)} clusters per season. Under storm-outbreak conditions, mean maximum run length was {mmean('dry_with_bursts','max_run_days'):.4f} days, a baseline difference of {_effect(m_bursts_run,4)} days. With counts fixed, persistent-dry, storm-outbreak and dry-to-wet seasons all had fewer clusters and longer maximum runs than baseline. The corresponding maximum-run differences were {mcontrast('persistent_dry','max_run_days').mean_difference:+.4f}, {m_bursts_run.mean_difference:+.4f} and {mcontrast('flip_dry_to_wet','max_run_days').mean_difference:+.4f} days, respectively. Persistent-wet seasons showed no clear difference in maximum run length at equal counts. This sensitivity changes the selection estimand and does not provide a causal decomposition of the pooled result. {nsig(gm)} of the ten G/sixteen-day organisation contrasts met the 0.05 Holm-adjusted threshold within the 190-comparison family.

Incremental WP information

The recalculated with-WP versus without-WP tests answer a separate question. At pooled Top 10%, G−K mean cluster differences ranged from {old_gk_clusters.mean_difference.min():.4f} to {old_gk_clusters.mean_difference.max():.4f} clusters per season, with {nsig(old_gk_clusters)} of six tests below the 0.05 Holm-adjusted threshold in the original 270-comparison family. G−K maximum-run differences ranged from {old_gk_runs.mean_difference.min():.4f} to {old_gk_runs.mean_difference.max():.4f} days. Their stars must not be interpreted as significance tests of storyline-minus-baseline differences. The existing equal-count G−K analysis also remains separate: its pointwise intervals do not constitute new multiplicity-adjusted tests of WP inclusion.

Uncertainty and diagnostics

All confidence intervals and tests quantify conditional Monte Carlo precision with fitted microbiological models, calibrators, historical inputs, donor library, generator and saved tie scheme held fixed. The new storyline analyses are a retrospective methodological amendment. Across the {len(pooled)} pooled storyline contrasts, {len(flagged)} were flagged by the specified bootstrap-bias/skewness diagnostics and {len(disagreed)} differed between normal and percentile intervals in inclusion of zero. Diagnostic cautions remain attached to the relevant table entries and figures; interval-method agreement does not establish nominal coverage. The 270 weather pattern comparisons contain {int(old_flag.sum())} diagnostic flags ({', '.join(k + ': ' + str(v) for k,v in original_tests.loc[old_flag,'comparison'].value_counts().items())}). These results concern model-selected days and their organisation; they do not validate observed contamination durations or operational warning performance.
'''
    (out / 'RESULTS.txt').write_text(text, encoding='utf-8')

    methods = '''METHODS — RETROSPECTIVE STORYLINE INFERENCE AMENDMENT

Analysis scope and estimands

The storyline comparison uses Step 6 outcomes, seasonal records and bootstrap estimates regenerated with the corrected Step 5 models. At this comparison stage the saved bootstrap estimates are paired by replicate. Step 6 uses the supplied fitted models, calibration and simulated weather throughout. April provides initialisation and is not scored. Evaluation covers the 153 consecutive days from 1 May to 30 September; 2001 is a synthetic calendar label. There are 5,000 seasons in each of six storylines.

Three questions are distinguished: (i) altered storyline minus baseline within the same fitted model; (ii) with-WP minus without-WP within a storyline; and (iii) altered storyline minus baseline at fixed selected-day count. G includes the four-family WP predictor; K has the same numerical predictors without that predictor. This amendment adds (i) and (iii); it preserves the existing E−C, F−J and G−K results for (ii). It was motivated by inspection of existing results and is not described as prospectively prespecified.

Pooled selection and shared saved draws

For each model separately, calibrated scores are ranked across 6 × 5,000 × 153 = 4,590,000 days. Top 10% selects exactly 459,000 days from the complete pool; 1%, 5%, 25% and 50% are selection-fraction sensitivities. Scenario and seasonal totals can differ under this fixed pooled budget. This is neither a fixed probability threshold nor a target rate of issued warnings. The inherited full-precision rankings use shared pseudorandom tie priorities with SeedSequence [42,5,700]; repeated identical days retain those priorities, with copy ordinal resolving partial boundary allocation.

The supplied 4,000 bootstrap draws resample 5,000 whole simulation-index bundles with replacement. Each bundle retains all six complete scenario seasons, with common weights across models and repeated exact pooled selection for each model, budget and draw. The new contrast in each replicate is the altered-storyline mean minus the baseline mean from the same replicate. This retains covariance instead of treating scenario means as independent. The original point estimate comes from the original seasonal outcomes. Bootstrap SE is the sample standard deviation of the 4,000 saved contrast estimates; it is not divided by √4,000. The normal pointwise 95% interval is the original difference ±1.96 SE. The 2.5th and 97.5th percentiles of the saved contrast estimates provide a diagnostic sensitivity. Approximate two-sided Wald tests use the absolute original difference divided by SE, with normal-tail probabilities retained in log space. Ordinary bootstrap sign proportions are not substituted for hypothesis-test p-values.

Fixed-count analysis

Existing records select exactly eight or sixteen days within every 153-day season using shared within-season tie priorities with SeedSequence [42,6,800]. These counts are approximately 5.23% and 10.46%, and do not reproduce the pooled Top-5% or Top-10% estimands. Complete, unique simulation identifiers are paired between each altered storyline and baseline within G or K. This coupling represents common random numbers, not causal observational matching. Only clusters and maximum run length are tested: selected-day differences equal zero by construction. SE is the sample SD of the 5,000 paired seasonal differences divided by √5,000; intervals are the mean difference ±1.96 SE. Approximate two-sided normal/Wald p-values are calculated consistently. These are analytic conditional Monte Carlo intervals, not bootstrap intervals. Raw seasonal-difference skewness is descriptive and is not equated to skewness of a bootstrap distribution of mean differences.

Multiplicity, diagnostics and boundary cases

The single new test family comprises 150 pooled contrasts (two models × five budgets × five altered storylines × three outcomes) and 40 fixed-count contrasts (two models × two counts × five altered storylines × two organisation outcomes). Holm adjustment is applied across all 190 planned tests. G/Top-10% and G/sixteen-day displays receive presentation priority without becoming smaller adjustment families. The original 270 WP-inclusion tests remain a distinct family addressing a different scientific question. A zero baseline reference is not an additional test. Pointwise intervals are not simultaneous, and their inclusion of zero need not agree with Holm-adjusted significance. 'ns' does not establish equivalence.

Pooled diagnostics flag |bootstrap bias|/SE >0.25 or |bootstrap skewness| >0.5. Bias is the average saved contrast estimate minus the original contrast. Normal and percentile intervals are compared for inclusion of zero. Flagging, non-finite values, incomplete pairs, zero SE and degenerate distributions are recorded rather than converted into apparently certain significance; the planned multiplicity family is not silently reduced. Small probabilities are represented using retained log tails and readable bounds, never printed as p=0. A diagnostic sensitivity is not chosen because it gives a preferred finding. Weather pattern model comparisons have their own diagnostic flags in the 270-test table.

Uncertainty and study interpretation

The sampling unit is an entire simulation-index bundle, not an individual simulated day or site-day. These intervals and tests measure conditional Monte Carlo precision under the fixed fitted system. They exclude historical sampling uncertainty, model and calibration fitting uncertainty, generator parameter uncertainty and structural error. Seasonal 5th–95th percentiles are central 90% variability ranges across individual simulated seasons, not 95% intervals for estimated means. The new inference concerns specified atmospheric storylines; their occurrence frequencies, persistence, sequencing and resulting drivers must not be assumed to form an isolated persistence-only intervention. Step 5 observational predictive performance remains distinct from Step 6 simulation outcomes.
'''
    (out / 'METHODS.txt').write_text(methods, encoding='utf-8')

    limitations = '''LIMITATIONS — STORYLINE INFERENCE AMENDMENT

These additions complete conditional numerical comparisons; they do not remove the underlying modelling limitations. Intervals and approximate normal/Wald tests condition on fixed microbiological models, calibrators, historical records, donor library, weather generator and saved tie priorities. More simulated seasons can make these intervals narrow while historical, parameter and structural uncertainty remains unresolved. Common-random-number coupling supports efficient numerical comparison; it does not turn scenario differences into causal observational estimates.

The storyline design can change occurrence frequencies, sequencing, persistence and simulated environmental drivers together. Without a verified persistence-only contrast, the results should be described as effects of specified atmospheric storylines, rather than an isolated causal atmospheric-persistence effect. Pooled Top-k redistributes a fixed selection budget between scenarios. Changes in count can accompany changes in clusters and maximum runs. Fixing eight or sixteen selected days controls count but changes the selection rule and estimand; it is not a formal causal mediation or decomposition analysis. In particular, nearly identical fixed-count baseline and persistent-wet maximum runs must be retained alongside the larger pooled wet-storyline runs. Storm-outbreak scenarios can have longer fixed-count runs.

The new 190-test family is a retrospective amendment motivated by review of existing outputs. Holm adjustment controls multiplicity only to the extent that the marginal approximate tests are valid; it does not correct the retrospective motivation, bias, poor interval coverage or model misspecification. Pointwise confidence intervals are not Holm-compatible simultaneous intervals. Normal/percentile diagnostic agreement is not proof of coverage, and a diagnostic flag is not repaired merely by reporting a second interval. Numerical degeneracy or unavailable inference must be disclosed. Statistical detectability is interpreted with the effect in days or clusters per season, rather than treated as practical benefit.

The Step 4 limitations include underestimated rainfall persistence, 74 missing historical rainfall dates across April-September 2012-2024, rare donor pools and soil/rainfall-memory indicators without a dynamical water balance. Regional predictors and retrospective full-day information limit operational interpretation. Step 6 does not validate issued advice against bathing, actual warnings, observed contamination duration, prospective lead time, public-health benefit or improved operational forecasting. Observational predictive evidence belongs to Step 5. Passing code checks establishes consistency of the calculation and export, not physical validity, nominal inferential coverage or publication acceptance.
'''
    (out / 'LIMITATIONS.txt').write_text(limitations, encoding='utf-8')

    # A compact reported-value source makes every copy-ready number traceable.
    _source_table(pd.concat([gp, gm], ignore_index=True), out / 'RESULTS_CONTRAST_SOURCE.csv')
    abs_rows = summary[summary.model.eq('G') & summary.rule.eq('topk_10')].copy()
    abs_rows.to_csv(out / 'RESULTS_SEASONAL_SOURCE.csv', index=False, float_format='%.17g')
    matched[matched.model.eq('G')].to_csv(out / 'RESULTS_MATCHED_SOURCE.csv', index=False, float_format='%.17g')

    verification_path = result_dir / 'INDEPENDENT_VERIFICATION.json'
    if not verification_path.exists():
        verification_path = result_dir / 'VERIFICATION.json'
    verification = json.loads(verification_path.read_text()) if verification_path.exists() else None
    if verification and verification.get('status') == 'passed':
        verdict = (
            'The new independent verification report records status passed. '
            f"It checked {verification.get('contrasts_verified', 'unreported')} contrasts "
            f"and {verification.get('independent_numerical_fields_checked', 'unreported')} numerical fields; "
            f"{verification.get('known_answer_boundary_checks', 'unreported')} known-answer/boundary checks; "
            f"{verification.get('original_G_K_seasonal_summaries_reproduced', 'unreported')} original G/K seasonal summaries; "
            f"and {verification.get('covariance_identities_checked', 'unreported')} covariance identities. "
            'The detailed JSON and actual logs govern which checks were performed. '
            'No upstream model fitting or weather generation is implied by that status.'
        )
    elif verification:
        verdict = ('An independent verification report is present, but its status is not passed. '
                   'Do not release before resolving its recorded failures or exceptions.')
    else:
        verdict = ('Final independent verification has not yet been recorded when this report was generated. '
                   'This report must be regenerated after verification before release.')
    review = f'''REVIEW REPORT — RETROSPECTIVE STORYLINE INFERENCE AMENDMENT

Completed by this reporting module

Read all {len(contrasts)} planned new contrasts, split into {len(pooled)} pooled and {len(count)} fixed-count contrasts, from the current tables. Generated Results, Methods, limitations and traceable reported-value tables. G/Top-10% contains {len(gp)} rows; G/sixteen-day contains {len(gm)} organisation rows. Existing WP-inclusion table has {len(original_tests)} rows and is treated as a separate scientific family. The reporting module performs no refitting, probability replacement, weather simulation or bootstrap sampling.

Current numerical findings

New Holm-adjusted comparisons below 0.05: {nsig(contrasts)} / 190. Pooled: {nsig(pooled)} / 150. Fixed count: {nsig(count)} / 40. G/Top-10%: {nsig(gp)} / 15. G/sixteen-day: {nsig(gm)} / 10. Pooled bias/skewness flags: {len(flagged)}. Normal-versus-percentile zero-inclusion disagreements: {len(disagreed)}. Pooled diagnostic-caution entries: {len(caution)}. These summaries do not establish nominal coverage. The full row-level table and diagnostics govern interpretation.

An important retained qualification is G's fixed-sixteen-day maximum run: baseline {mmean('baseline','max_run_days'):.4f}, persistent wet {mmean('persistent_wet','max_run_days'):.4f}, storm outbreaks {mmean('dry_with_bursts','max_run_days'):.4f} days. No uniform count-independent persistent-wet increase is asserted.

Verification status

{verdict}
For the API-corrected release, the Step 6 bootstrap means were regenerated using the corrected Step 5 predictions and original resampling settings before this amendment was run. The amendment calculated storyline comparisons from those updated mean draws. Weather generation and model fitting belong to the upstream steps. The verification reports and logs identify the checks performed at each stage.

Unresolved limitations

The simulation system remains fixed and conditional; historical/model/generator fitting uncertainty is excluded. Approximate tests and pointwise intervals remain subject to diagnostics. The storyline design does not by itself identify an isolated causal persistence effect. A fixed-count selection changes the estimand. Rainfall persistence bias, missing historical rainfall, limited donors, no dynamical water balance and retrospective predictors remain. No operational warning benefit or observed contamination duration is established.
'''
    (out / 'REVIEW_REPORT.txt').write_text(review, encoding='utf-8')

    guide = '''PUBLICATION FIGURE SELECTION — THREE DISTINCT QUESTIONS

For Aim 3, prioritise the new G/Top-10% storyline-minus-baseline display: three outcomes, five altered storylines, pointwise conditional 95% intervals and adjusted symbols from the new family of 190 tests. Pair it with seasonal absolute outcomes or their separate 5th–95th percentile variability display. The zero line is baseline, not model K.

The new G/sixteen-day storyline-minus-baseline display is the count-controlled companion. Its clusters and maximum runs hold selected-day count fixed within every season. The eight-day and model-K equivalents are supplementary sensitivities. Eight and sixteen days equal approximately 5.23% and 10.46%, not exact pooled Top-5% and Top-10% selection.

Retain the user-selected three WP-comparison figure (E−C, F−J and G−K) separately. It addresses incremental WP inclusion within each storyline, with adjusted symbols from the original family of 270 tests. The existing matched-count G−K and all-pair figures answer WP inclusion at fixed counts, not storyline-minus-baseline effects. They must not be relabelled or given stars from the new family.

Keep all remaining pooled fractions (1%, 5%, 25%, 50%), annotated budget heatmaps, seasonal-range displays and flagged model-comparison interval checks in the supplement. The selected figures use the recalculated effects and the corresponding adjusted tests. Do not overcrowd a single graphic with both inferential families or with long limitations text; put assumptions in separate captions and Methods.

New figure files and plotted source tables are under figures/Storyline_comparisons. The current figure manifest/index, rather than historical filenames or archived publication choices, identifies the release's main and supplementary views. Confidence intervals show mean precision; seasonal ranges show between-season variation. New plot daggers identify current diagnostic cautions. All lettering and stars must agree with the current source tables.
'''
    (out / 'FIGURE_SELECTION.txt').write_text(guide, encoding='utf-8')
    (out / 'REPORTING_METADATA.json').write_text(json.dumps({
        'new_contrasts':len(contrasts), 'pooled':len(pooled), 'matched':len(count),
        'original_wp_tests':len(original_tests), 'new_significant':nsig(contrasts),
        'pooled_diagnostic_flags':len(flagged), 'percentile_zero_disagreements':len(disagreed),
        'verification_report_present':verification is not None,
        'metadata_present':bool(metadata), 'no_models_or_simulations_executed_by_reporting':True,
        'copy_ready_source_tables':['RESULTS_CONTRAST_SOURCE.csv','RESULTS_SEASONAL_SOURCE.csv','RESULTS_MATCHED_SOURCE.csv'],
    }, indent=2), encoding='utf-8')
    print(f'Generated storyline reporting from {len(contrasts)} new contrasts; no modelling or resampling.')
    return {'reports':str(out), 'new_contrasts':len(contrasts), 'new_significant':nsig(contrasts)}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    args = parser.parse_args()
    run(args.root)
