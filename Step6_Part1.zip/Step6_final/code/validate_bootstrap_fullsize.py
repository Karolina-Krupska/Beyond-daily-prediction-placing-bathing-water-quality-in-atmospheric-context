"""Check weighted Top-k bootstrap against literal full-size copied seasons.

The default performs 15 cases: D, E and G at all five fractions. If temporary
inference arrays have been removed, predictions are reconstructed from included
fitted models and Step 4 inputs only; no model or calibrator is fitted. A quick
partial check can use --max-cases 1. Partial reports use a separate filename so
that they do not overwrite the completed 15-case delivery evidence.
"""
from pathlib import Path
import argparse,json,sys,time,math
import numpy as np

ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'code'))
from weighted_topk_bootstrap import TopkBootstrap
from analysis_step6 import seasonal_metrics

MODELS=['D','E','G'];BUDGETS=[.01,.05,.10,.25,.50]
STORIES=['baseline','persistent_wet','persistent_dry','dry_with_bursts','flip_wet_to_dry','flip_dry_to_wet']
ALL_MODELS=list('ABCDEFGHIJK')


def predictions_and_weights(root,models):
    temporary=root/'temporary_inference'
    if (temporary/'exact_calibrated_probabilities.npy').exists() and (temporary/'weights.npy').exists():
        exact=np.load(temporary/'exact_calibrated_probabilities.npy',mmap_mode='r')
        values=np.asarray(exact[[ALL_MODELS.index(m) for m in models]])
        weights=np.array(np.load(temporary/'weights.npy',mmap_mode='r')[0])
        return values,weights,'Existing temporary full-precision predictions and first shared bootstrap draw'
    import pandas as pd
    import joblib
    source=root/'inputs/step5'
    sys.path.insert(0,str(source/'code'))
    from storylines import daily_frame
    driver_root=source/'inputs/step4/completed_run'
    library=pd.read_csv(driver_root/'prepared/historical_donor_library.csv',parse_dates=['date'],float_precision='round_trip')
    meta=json.loads((driver_root/'run_metadata.json').read_text())
    values=np.empty((len(models),6,5000,153),dtype=np.float64)
    fitted={model:joblib.load(source/f'fitted_models/{model}.joblib') for model in models}
    for si,story in enumerate(STORIES):
        with np.load(driver_root/f'simulations/{story}_AprSep.npz') as z:
            donor=z['donor_row'];states=z['states']
        if donor.shape!=(5000,183) or states.shape!=(5000,183):raise ValueError('Unexpected supplied season dimensions')
        frame=daily_frame(library,donor,states,meta['api_alpha'])
        for mi,model in enumerate(models):
            saved=fitted[model]
            scores=saved['base'].decision_function(frame[saved['features']])
            predicted=saved['calibrator'].predict_proba(scores.reshape(-1,1))[:,1]
            if not np.isfinite(predicted).all():raise AssertionError('Non-finite reconstructed probabilities')
            values[mi,si]=predicted.reshape(5000,153)
        print('Prediction-only reconstruction:',story,flush=True)
    rng=np.random.default_rng(np.random.SeedSequence([42,6,910]))
    weights=np.bincount(rng.integers(0,5000,5000),minlength=5000)
    return values,weights,'Prediction-only reconstruction from included fitted models and Step 4 drivers; recorded first bootstrap seed'


def validate(root=ROOT,max_cases=None,report_path=None):
    root=Path(root);start=time.time()
    if max_cases is not None and not 1<=max_cases<=15:raise ValueError('--max-cases must be between 1 and 15')
    models=MODELS[:math.ceil(max_cases/5)] if max_cases else MODELS
    predictions,weights,route=predictions_and_weights(root,models)
    shape=(6,5000,153);M=int(np.prod(shape))
    tie=np.random.default_rng(np.random.SeedSequence([42,5,700])).random(M)
    indices=np.repeat(np.arange(5000),weights.astype(int))
    if len(indices)!=5000:raise AssertionError('Shared bootstrap draw must contain 5000 whole seasons')
    rows=[]
    for probabilities,model in zip(predictions,models):
        order=np.lexsort((tie,-probabilities.ravel()))
        engine=TopkBootstrap(order,shape,BUDGETS);fast=engine.bootstrap_means(weights)
        inverse=np.empty(M,np.int32);inverse[order]=np.arange(M,dtype=np.int32)
        expanded=inverse.reshape(shape)[:,indices,:].ravel()
        expanded_order=np.argsort(expanded,kind='stable')
        for bi,budget in enumerate(BUDGETS):
            k=int(np.ceil(budget*M));selected=np.zeros(M,bool);selected[expanded_order[:k]]=True
            literal=seasonal_metrics(selected.reshape(6*5000,153)).reshape(6,5000,3).mean(axis=1)
            difference=float(np.max(np.abs(literal-fast[bi])))
            if difference>1e-12 or int(selected.sum())!=k:raise AssertionError((model,budget,difference))
            rows.append({'model':model,'budget':budget,'quota':k,'max_absolute_mean_difference':difference,'passed':True})
            if max_cases is not None and len(rows)>=max_cases:break
        print('Full-size literal validation passed:',model,flush=True)
        if max_cases is not None and len(rows)>=max_cases:break
    target=Path(report_path) if report_path else root/'results/inference'/('FULL_SIZE_BOOTSTRAP_VALIDATION_PARTIAL.json' if max_cases else 'FULL_SIZE_BOOTSTRAP_VALIDATION.json')
    target.parent.mkdir(parents=True,exist_ok=True)
    report={'status':'passed','cases':len(rows),'rows':rows,'prediction_route':route,
            'scope':'Independent literal expansion of a complete 5000-season resample for all six scenarios; full-precision rankings and exact quotas',
            'model_fitting':False,'elapsed_seconds':time.time()-start}
    target.write_text(json.dumps(report,indent=2));print('Saved',target,flush=True)
    return report


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=ROOT)
    parser.add_argument('--max-cases',type=int)
    parser.add_argument('--report',type=Path)
    args=parser.parse_args();validate(args.root,args.max_cases,args.report)
