"""Runner control-flow checks; no bootstrap or figures executed by these tests."""
from pathlib import Path
import sys,tempfile,types,unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from run_inference import run_pipeline


class InferencePipelineTests(unittest.TestCase):
    def modules(self,calls):
        return {
            'inference_step6':types.SimpleNamespace(run=lambda root,workers:calls.append(('run',workers))),
            'inference_figures_step6':types.SimpleNamespace(make_inference_figures=lambda root:calls.append(('figures',))),
            'publish_inference_figures':types.SimpleNamespace(publish=lambda root:calls.append(('publish',))),
            'write_inference_reports':types.SimpleNamespace(write_reports=lambda root:calls.append(('reports',))),
            'verify_inference_step6':types.SimpleNamespace(verify=lambda root,require_figures:calls.append(('verify',require_figures)) or {'status':'passed'})}

    def test_normal_pipeline_orders_inference_figures_publish_verification(self):
        calls=[]
        with tempfile.TemporaryDirectory() as folder,patch.dict(sys.modules,self.modules(calls)):
            result=run_pipeline(Path(folder),workers=2)
            self.assertEqual(calls,[('run',2),('figures',),('publish',),('verify',True),('reports',)])
            self.assertEqual(result['status'],'completed')
            self.assertTrue((Path(folder)/result['log']).is_file())

    def test_figures_only_never_runs_numerical_inference(self):
        calls=[]
        with tempfile.TemporaryDirectory() as folder,patch.dict(sys.modules,self.modules(calls)):
            base=Path(folder)/'results/inference';base.mkdir(parents=True)
            for name in ['mean_confidence_intervals.csv','paired_tests.csv','model_mean_bootstrap_replicates.npz',
                         'paired_bootstrap_replicates.npz','INFERENCE_METADATA.json']:(base/name).touch()
            result=run_pipeline(Path(folder),figures_only=True)
            self.assertEqual(calls,[('figures',),('publish',),('verify',True),('reports',)])
            self.assertTrue(result['figures_only'])

    def test_missing_existing_tables_fail_without_numerical_fallback(self):
        calls=[]
        with tempfile.TemporaryDirectory() as folder,patch.dict(sys.modules,self.modules(calls)):
            with self.assertRaises(FileNotFoundError):run_pipeline(Path(folder),figures_only=True)
            self.assertEqual(calls,[])


if __name__=='__main__':unittest.main()
