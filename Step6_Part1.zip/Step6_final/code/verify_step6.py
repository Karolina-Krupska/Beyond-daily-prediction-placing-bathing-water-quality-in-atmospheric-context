"""Independent integration checks for saved Step 6 tables and figure data.

This verifier does not reconstruct probabilities, fit models or regenerate seasons.
"""
from pathlib import Path
import json, datetime
import numpy as np
import pandas as pd
from PIL import Image
import xml.etree.ElementTree as ET
from analysis_step6 import STORIES, MODELS, BUDGETS, PAIRS, METRICS, sha256


def verify(root):
    root=Path(root);out=root/'results';checks=[]
    def check(name,condition,description):
        if not bool(condition):raise AssertionError(name+': '+description)
        checks.append({'name':name,'passed':True,'description':description})
    def close(a,b):return np.allclose(a,b,rtol=1e-12,atol=1e-12,equal_nan=True)
    required=json.loads((root/'inputs/provenance/REQUIRED_INPUTS.json').read_text())
    check('input_hashes',all(sha256(root/i['path'])==i['sha256'] for i in required),
          'Every included immutable upstream input retains its recorded SHA-256.')
    audit=pd.read_csv(out/'budget_and_precision_audit.csv',float_precision='round_trip')
    check('budget_table_coverage',len(audit)==55 and not audit.duplicated(['model','rule']).any(),
          'Eleven models and five distinct pooled budgets.')
    check('exact_pooled_counts',np.array_equal(audit.k,audit.selected_days) and (audit.pool_days==4590000).all(),
          'All selected totals exactly match the budgets over 4,590,000 days per model.')
    check('full_precision_reconciliation',audit.exact_mask_reproduced.all(),
          'Saved primary masks were reproduced using full-precision predictions in this execution.')
    # Compare table rows directly with Step 5, without relying on Step 6 summary code.
    cache={};total=0
    upstream=root/'inputs/step5/results/selected_day_metrics_by_season.csv.gz'
    current=pd.read_csv(out/'seasonal_metrics.csv.gz',chunksize=150000,float_precision='round_trip')
    reference=pd.read_csv(upstream,chunksize=180000,usecols=['model','rule','storyline','sim']+METRICS,float_precision='round_trip')
    observed_models=[]
    for model,block,ref in zip(MODELS,current,reference):
        ref=ref[ref.rule.str.startswith('topk_')].reset_index(drop=True)
        block=block.reset_index(drop=True)
        if len(block)!=150000 or block.model.nunique()!=1 or block.model.iloc[0]!=model:
            raise AssertionError('Unexpected primary seasonal table ordering or model coverage')
        if not np.array_equal(block[['model','rule','storyline','sim']+METRICS].to_numpy(),
                              ref[['model','rule','storyline','sim']+METRICS].to_numpy()):
            raise AssertionError('Current seasonal metrics differ from original authoritative Step 5 rows')
        if block.duplicated(['model','rule','storyline','sim']).any():raise AssertionError('Duplicate season rows')
        for (rule,story),group in block.groupby(['rule','storyline'],sort=False):
            if len(group)!=5000 or not np.array_equal(np.sort(group.sim.to_numpy()),np.arange(5000)):
                raise AssertionError('Season identifiers incomplete')
            cache[model,rule,story]=group.sort_values('sim')[METRICS].to_numpy()
        total+=len(block);observed_models.append(model)
    if next(current,None) is not None or next(reference,None) is not None:
        raise AssertionError('Unexpected additional primary or upstream seasonal records')
    check('primary_season_rows',total==1650000 and observed_models==MODELS,
          'All 1,650,000 current model-budget-scenario-season records match Step 5 exactly.')
    check('primary_metrics_nonnegative',all(np.isfinite(a).all() and (a>=0).all() for a in cache.values()),
          'All three seasonal metrics are finite and non-negative.')
    check('primary_run_bounds',all(np.all((a[:,1]<=a[:,0])&(a[:,2]<=a[:,0])&
          ((a[:,0]==0)==(a[:,1]==0))&((a[:,0]==0)==(a[:,2]==0))) for a in cache.values()),
          'Cluster and run counts are bounded by selected days; zero seasons are consistent.')
    summary=pd.read_csv(out/'seasonal_summary.csv',float_precision='round_trip')
    check('summary_coverage',len(summary)==990 and not summary.duplicated(['model','rule','storyline','metric']).any(),
          'Each of the 330 model-budget-scenario groups has all three summaries.')
    for row in summary.itertuples():
        a=cache[row.model,row.rule,row.storyline][:,METRICS.index(row.metric)]
        values=[a.mean(),np.median(a),*np.quantile(a,[.05,.95,.025,.975]),np.mean(a==0)]
        if not close(values,[row.mean,row.median,row.p05,row.p95,row.p025,row.p975,row.fraction_zero]):
            raise AssertionError('Summary statistics do not match complete seasonal records')
    check('summary_statistics',True,'Means, medians, four percentile bounds and zero fractions independently recomputed.')
    paired=pd.read_csv(out/'paired_model_differences.csv',float_precision='round_trip')
    check('paired_table_coverage',len(paired)==270 and set(paired.comparison)=={'E-C','F-J','G-K'},
          'All three prespecified comparisons cover five budgets, six scenarios and three metrics.')
    for row in paired.itertuples():
        high,low=row.comparison.split('-');j=METRICS.index(row.metric)
        delta=cache[high,row.rule,row.storyline][:,j]-cache[low,row.rule,row.storyline][:,j]
        if not close([delta.mean(),*np.quantile(delta,[.05,.95])],
                     [row.mean_difference,row.difference_p05,row.difference_p95]):
            raise AssertionError('Paired differences inconsistent with within-season subtraction')
    check('paired_differences',True,'Every pooled comparison is independently recomputed on identical season identifiers.')
    check('no_pooled_confidence_interval_claim',paired.mc95_lower.isna().all() and paired.mc95_upper.isna().all(),
          'Pooled fixed-selection summaries do not carry inferential confidence intervals.')
    matched=pd.read_csv(out/'matched_count_seasonal_metrics.csv.gz',float_precision='round_trip')
    check('matched_row_coverage',len(matched)==360000 and set(matched.model)==set('CEFGJK') and
          not matched.duplicated(['model','rule','storyline','sim']).any(),
          'Six prespecified comparison models, two budgets and all 30,000 seasons.')
    check('matched_counts',((matched.rule.eq('matched_05')&matched.selected_days.eq(8))|
          (matched.rule.eq('matched_10')&matched.selected_days.eq(16))).all(),
          'Every season has exactly eight or sixteen selections under the matched-count sensitivity.')
    mcache={k:g.sort_values('sim')[METRICS].to_numpy() for k,g in matched.groupby(['model','rule','storyline'],sort=False)}
    expected_groups={(m,r,s) for m in 'CEFGJK' for r in ['matched_05','matched_10'] for s in STORIES}
    if set(mcache)!=expected_groups:raise AssertionError('Incomplete matched-count scenario or model groups')
    for key,group in matched.groupby(['model','rule','storyline'],sort=False):
        if len(group)!=5000 or not np.array_equal(np.sort(group.sim.to_numpy()),np.arange(5000)):
            raise AssertionError('Matched-count season identifiers incomplete')
    mp=pd.read_csv(out/'matched_count_paired_differences.csv',float_precision='round_trip')
    check('matched_comparison_coverage',len(mp)==108 and not mp.duplicated(['comparison','rule','storyline','metric']).any(),
          'All paired matched-count contrasts cover both budgets, all scenarios and metrics; complete season identifiers verified.')
    for row in mp.itertuples():
        high,low=row.comparison.split('-');j=METRICS.index(row.metric)
        delta=mcache[high,row.rule,row.storyline][:,j]-mcache[low,row.rule,row.storyline][:,j]
        se=delta.std(ddof=1)/np.sqrt(5000)
        if not close([delta.mean(),se,delta.mean()-1.96*se,delta.mean()+1.96*se],
                     [row.mean_difference,row.mc_se,row.mc95_lower,row.mc95_upper]):
            raise AssertionError('Matched-count Monte Carlo summary incorrect')
    check('matched_differences_and_mc_intervals',True,
          'Paired means and conditional Monte Carlo interval arithmetic independently recomputed.')
    check('matched_day_difference_zero',np.all(mp.loc[mp.metric.eq('selected_days'),'mean_difference']==0),
          'Matched-count selected-day differences vanish by construction.')
    fdata=pd.read_csv(root/'figures/FIGURE_DATA.csv',float_precision='round_trip')
    meta=json.loads((root/'figures/figure_metadata.json').read_text())
    check('figure_count_and_rows',len(meta['figures'])==2 and len(fdata)==306,
          'Only the agreed main figure and supplementary sensitivity figure; 36 plus 270 plotted records.')
    main=fdata[fdata.figure.eq('Figure_Step6_Storyline_behaviour')]
    plotted=main.merge(summary,on=['model','rule','storyline','metric'],validate='one_to_one',suffixes=('_plot','_source'))
    check('main_figure_source_values',len(plotted)==36 and all(close(plotted[c+'_plot'],plotted[c+'_source']) for c in ['mean','p05','p95']),
          'Every displayed primary mean and interval endpoint agrees with the current result table.')
    supp=fdata[fdata.figure.eq('Figure_Step6_Paired_budget_sensitivity')]
    plotted=supp.merge(paired,on=['comparison','rule','storyline','metric'],validate='one_to_one',suffixes=('_plot','_source'))
    check('supplement_figure_source_values',len(plotted)==270 and close(plotted.mean_difference_plot,plotted.mean_difference_source),
          'Every supplementary heatmap value agrees with the current paired result table.')
    for item in meta['figures']:
        files=[root/p for p in item['files']]
        if len(files)!=3 or not all(p.exists() and p.stat().st_size>1000 for p in files):raise AssertionError('Missing or empty figure export')
        image=Image.open(next(p for p in files if p.suffix=='.png'))
        expected=np.array([item['width_mm'],item['height_mm']])/25.4*600
        if not np.all(np.abs(np.array(image.size)-expected)<=1):raise AssertionError('Unexpected figure pixel dimensions')
        if not np.all(np.abs(np.array(image.info.get('dpi',[0,0]))-600)<.1):raise AssertionError('PNG lacks 600 dpi metadata')
        svg=ET.parse(next(p for p in files if p.suffix=='.svg'))
        if len(svg.findall('.//{http://www.w3.org/2000/svg}text'))<10:raise AssertionError('SVG text is outlined or missing')
        pdf=next(p for p in files if p.suffix=='.pdf')
        if b'/Subtype /Type3' in pdf.read_bytes():raise AssertionError('PDF contains Type 3 fonts')
    check('figure_exports',True,'Both figures have 600 dpi PNG at declared physical dimensions and editable-text SVG/PDF exports.')
    report={'status':'passed','UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'checks_passed':len(checks),'checks':checks,
            'scope':'Numerical, source-reconciliation and figure-export checks; not physical, causal or operational validation.'}
    (out/'VERIFICATION.json').write_text(json.dumps(report,indent=2))
    print(f'Independent integration verification: {len(checks)} checks passed.',flush=True)
    return report


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent.parent)
    print(json.dumps(verify(p.parse_args().root),indent=2))
