"""Recreate the earlier grouped-bar display using current Step 6 results only.

This is a plotting module. It never fits models, selects days or recalculates
seasonal outcomes. The complete A-K comparisons are supporting displays.
"""
from __future__ import annotations

from pathlib import Path
import argparse
import json

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.patches import Patch
from matplotlib.ticker import MaxNLocator

ROOT=Path(__file__).resolve().parent.parent
MODELS=list('ABCDEFGHIJK')
STORIES=['baseline','persistent_wet','flip_wet_to_dry','dry_with_bursts',
         'persistent_dry','flip_dry_to_wet']
STORY_LABELS=['Baseline','Persistent wet','Wet to dry','Dry with storm\noutbreaks',
              'Persistent dry','Dry to wet']
RULES=['topk_01','topk_05','topk_10','topk_25','topk_50']
METRICS=['selected_days','clusters','max_run_days']
TITLES={'selected_days':'Selected days per season','clusters':'Selected-day clusters per season',
        'max_run_days':'Maximum selected-day run per season'}
STEMS={'selected_days':'Selected_days','clusters':'Clusters','max_run_days':'Maximum_run'}
UNITS={'selected_days':'Days','clusters':'Clusters','max_run_days':'Days'}
COLORS=dict(zip(MODELS,['#7A9CC6','#F0AD4E','#70AD6E','#DB7070','#B08EAD',
                       '#A68B7C','#0072B2','#7B7B7B','#78B5B1','#E09BB0','#D55E00']))
MM=1/25.4


def _settings():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.labelsize':8.5,
        'axes.titlesize':11,'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8,
        'axes.linewidth':.7,'xtick.major.width':.6,'ytick.major.width':.6,
        'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none',
        'savefig.facecolor':'white','figure.facecolor':'white','axes.facecolor':'white'})


def _labels(registry):
    labels={m:f"{m}: {registry[m]['label']}" for m in MODELS}
    labels.update({'C':'C: intensity + depth','D':'D: WP',
        'F':'F: WP + met + memory','G':'G: full model + WP',
        'H':'H: soil + rainfall memory','I':'I: meteorology',
        'J':'J: met + memory','K':'K: full model without WP'})
    return labels


def make_legacy_figures(root=ROOT):
    root=Path(root);_settings()
    folder=root/'figures/Legacy_style_updated';folder.mkdir(parents=True,exist_ok=True)
    source=pd.read_csv(root/'results/seasonal_summary.csv',float_precision='round_trip')
    registry=json.loads((root/'inputs/step5/model_registry.json').read_text())
    if list(registry)!=MODELS:raise ValueError('The current A-K registry is required')
    labels=_labels(registry);metadata=[];data=[];captions=[]
    combined=folder/'Legacy_style_All_models_All_percentages.pdf'
    with PdfPages(combined) as pages:
        for rule in RULES:
            percentage=int(rule.rsplit('_',1)[1]);target=folder/f'Top{percentage:02d}'
            target.mkdir(exist_ok=True)
            for metric in METRICS:
                values=source[(source.rule==rule)&source.metric.eq(metric)&source.model.isin(MODELS)].copy()
                keys=['model','storyline']
                expected={(m,s) for m in MODELS for s in STORIES}
                if values.duplicated(keys).any() or set(map(tuple,values[keys].to_numpy()))!=expected:
                    raise ValueError(f'Incomplete or duplicate source values: {rule}/{metric}')
                for col in ['mean','p05','p95']:
                    if not np.isfinite(values[col]).all():raise ValueError('Figure values must be finite')
                if (values.p05>values.p95).any():raise ValueError('Percentile bounds are reversed')
                stem=f'{STEMS[metric]}_Bars_Top{percentage:02d}'
                fig,ax=plt.subplots(figsize=(250*MM,140*MM))
                fig.subplots_adjust(left=.065,right=.745,top=.88,bottom=.18)
                positions=np.arange(len(STORIES));width=.80/len(MODELS)
                for i,model in enumerate(MODELS):
                    v=values[values.model.eq(model)].set_index('storyline').loc[STORIES]
                    x=positions+(i-(len(MODELS)-1)/2)*width
                    ax.bar(x,v['mean'],width=width,color=COLORS[model],edgecolor='#444444',
                           linewidth=.35,zorder=2)
                    # Draw true percentile endpoints independently of the mean.
                    # A mean outside the central range must not distort whiskers.
                    ax.vlines(x,v.p05,v.p95,color='#333333',linewidth=.7,zorder=3)
                    ax.hlines(v.p05,x-width*.22,x+width*.22,color='#333333',linewidth=.7,zorder=3)
                    ax.hlines(v.p95,x-width*.22,x+width*.22,color='#333333',linewidth=.7,zorder=3)
                maximum=float(values[['mean','p95']].max().max())
                ax.set_ylim(0,max(1,maximum*1.08));ax.set_xlim(-.55,len(STORIES)-.45)
                ax.set_xticks(positions,STORY_LABELS);ax.tick_params(axis='x',length=0,pad=9)
                ax.yaxis.set_major_locator(MaxNLocator(nbins=6,integer=True))
                ax.set_ylabel(UNITS[metric],labelpad=8)
                ax.set_title(f'{TITLES[metric]} — Top {percentage}%',loc='left',pad=16)
                ax.grid(axis='y',color='#E3E6E8',linewidth=.5,zorder=0)
                ax.set_axisbelow(True)
                for spine in ['top','right']:ax.spines[spine].set_visible(False)
                handles=[Patch(facecolor=COLORS[m],edgecolor='#444444',linewidth=.35,label=labels[m]) for m in MODELS]
                ax.legend(handles=handles,title='Model',loc='upper left',bbox_to_anchor=(1.02,1.0),
                          frameon=False,handlelength=1.4,labelspacing=.65,borderaxespad=0)
                fig.text(.065,.055,'Bars: means · Whiskers: 5th–95th percentiles across 5,000 simulated seasons per scenario',
                         fontsize=8,ha='left')
                fig.text(.065,.025,'Selection is pooled across all six scenarios separately for each model. No significance stars are shown.',
                         fontsize=7.5,ha='left',color='#444444')
                files=[]
                for extension in ['png','pdf','svg']:
                    p=target/f'{stem}.{extension}';fig.savefig(p,dpi=600)
                    files.append(str(p.relative_to(root)))
                pages.savefig(fig);plt.close(fig)
                v=values.copy();v.insert(0,'figure',stem);data.append(v)
                metadata.append(dict(stem=stem,rule=rule,percentage=percentage,metric=metric,
                    files=files,width_mm=250,height_mm=140,png_dpi=600,plotted_rows=len(values)))
                captions.append(f'{TITLES[metric]} for models A-K under Top {percentage}% pooled selection. Bars show means and whiskers the 5th-95th percentiles across 5,000 May-September seasons per scenario. These are central 90% conditional simulation ranges, not confidence intervals. Calibrated selections are retained from the final Step 5 package; selected totals can differ between scenarios. D is labelled WP and retains its four-family predictor. This is a complete model-comparison display, not evidence of operational warning performance.')
    frames=pd.concat(data,ignore_index=True)
    if len(frames)!=990:raise AssertionError('Expected 990 all-model plotted records')
    frames.to_csv(folder/'FIGURE_DATA.csv',index=False)
    report={'figures':metadata,'combined_pdf':str(combined.relative_to(root)),
        'plotted_rows':len(frames),'source':'results/seasonal_summary.csv','models':MODELS,
        'scenarios':STORIES,'fractions_percent':[1,5,10,25,50],
        'scope':'Earlier grouped-bar style, current results; three retained outcomes only',
        'interval':'Central 90% conditional simulation range, not a confidence interval',
        'significance_stars':False,'analysis_rerun':False}
    (folder/'figure_metadata.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    (folder/'captions.txt').write_text('\n\n'.join(captions)+'\n',encoding='utf-8')
    (folder/'README.txt').write_text(
        'UPDATED GROUPED-BAR COMPARISONS\n\n'
        'These figures recreate the earlier all-model bar layout using current A-K results and all six scenarios. '
        'There are three retained outcomes at each of five pooled selection fractions. '
        'The manuscript main figure is supplied separately in Main_publication. '
        'All bars and true percentile endpoints come directly from seasonal_summary.csv. '
        'The former significance stars and recovery/lead-time interpretation are not reproduced. '
        'Means can lie outside a central percentile range, so whiskers are drawn independently.\n',encoding='utf-8')
    return report


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=ROOT)
    a=p.parse_args();print(json.dumps(make_legacy_figures(a.root),indent=2))
