"""Verify figure sources and write the current Step 6 delivery pointers."""
from pathlib import Path
import json
import datetime
import html
import hashlib
import numpy as np
import pandas as pd
from PIL import Image
from pypdf import PdfReader
import xml.etree.ElementTree as ET


def verify_figure_sources(root):
    root=Path(root)
    manifest=json.loads((root/'results/storyline_inference/FIGURE_MANIFEST.json').read_text())
    figures=manifest['figures'] if isinstance(manifest,dict) else manifest
    authoritative=pd.read_csv(root/'results/storyline_inference/all_contrasts.csv',float_precision='round_trip').set_index('contrast_id')
    checked=0
    for record in figures:
        source=pd.read_csv(root/record['source_csv'],float_precision='round_trip')
        if record['kind'] not in ['pooled_storyline','matched_storyline']:
            continue
        for _,r in source.iterrows():
            a=authoritative.loc[r.contrast_id]
            for col,expected in [('plotted_point','mean_difference'),('plotted_lower','ci95_lower'),('plotted_upper','ci95_upper')]:
                np.testing.assert_allclose(r[col],a[expected],rtol=0,atol=1e-12)
            caution=str(a.diagnostic_caution).lower()=='true'
            assert r.plotted_annotation==str(a.stars)+('†' if caution else '')
            checked+=1
        for filename in record['files']:
            p=root/filename
            if p.suffix=='.png':
                with Image.open(p) as im:
                    assert all(abs(x-600)<.01 for x in im.info['dpi'])
                    assert abs(im.width/600*25.4-record['width_mm'])<.1
                    assert abs(im.height/600*25.4-record['height_mm'])<.1
            elif p.suffix=='.pdf':
                doc=PdfReader(p)
                assert len(doc.pages)==1
                box=doc.pages[0].mediabox
                assert abs(float(box.width)*25.4/72-record['width_mm'])<.1
                assert abs(float(box.height)*25.4/72-record['height_mm'])<.1
                assert not list(doc.pages[0].images)
            elif p.suffix=='.svg':
                assert any(n.tag.endswith('}text') for n in ET.parse(p).iter())
    assert len(figures)>=14 and checked==190
    # User-selected supplied figures must match the original WP test source.
    selected=root/'figures/Publication_selection'
    v=pd.read_csv(selected/'Main_paper/paired_source_Top10.csv',float_precision='round_trip')
    old=pd.read_csv(root/'results/inference/paired_tests.csv',float_precision='round_trip')
    keys=['comparison','rule','storyline','metric']
    merged=v.merge(old,on=keys,suffixes=('_supplied','_original'),validate='one_to_one')
    assert len(merged)==54
    for c in ['mean_difference','bootstrap_se','ci95_lower','ci95_upper','log_p_holm']:
        np.testing.assert_allclose(merged[c+'_supplied'],merged[c+'_original'],rtol=0,atol=1e-12)
    assert merged.stars_supplied.eq(merged.stars_original).all()
    verified={'status':'passed','UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'new_figure_sets':len(figures),'new_plotted_estimates_intervals_symbols_verified':checked,
              'supplied_WP_figure_source_rows_verified':len(merged),
              'PNG600dpi_actual_dimensions':True,'PDF_vector_editable_SVG_text':True,
              'numerical_QA_is_not_visual_inspection':True}
    (root/'results/storyline_inference/FIGURE_VERIFICATION.json').write_text(json.dumps(verified,indent=2)+'\n')
    print(f'Figure verification passed: {checked} plotted contrasts, {len(figures)} sets, 54 supplied WP rows.')
    return verified


def write_index(root):
    root=Path(root)
    manifest=json.loads((root/'results/storyline_inference/FIGURE_MANIFEST.json').read_text())
    figures=manifest['figures'] if isinstance(manifest,dict) else manifest
    rows=[]
    for r in figures:
        stem=r['stem']
        rows.append('<tr><td>'+html.escape(Path(stem).name)+'</td><td>'+html.escape(r['kind'])+'</td><td>'+ 
          ' · '.join(f'<a href="{html.escape(stem+ext)}">{label}</a>' for ext,label in [('.pdf','PDF'),('.png','PNG600'),('.svg','SVG'),('_source.csv','Source'),('_caption.txt','Caption')])+'</td></tr>')
    page='''<!doctype html><html lang="en"><meta charset="utf-8"><title>Step 6 current figures</title>
<style>body{font:16px system-ui;color:#243746;max-width:1100px;margin:36px auto;padding:0 20px;line-height:1.55}a{color:#226a83}table{border-collapse:collapse;width:100%;font-size:14px}td,th{border-bottom:1px solid #d9e2e6;padding:10px;text-align:left}h1,h2{line-height:1.25}section{background:#f0f5f4;padding:16px 22px;margin:20px 0}</style>
<h1>Step 6: current publication figures</h1>
<p>This release uses the corrected Step 4 inputs and Step 5 models. Step 6 recalculates both the weather pattern and storyline comparisons using the original methods and simulated seasons.</p>
<section><h2>Three distinct questions</h2><ol>
<li><strong>Storyline versus baseline:</strong> model G at pooled Top 10%, Holm correction across 190 contrasts.</li>
<li><strong>At fixed selected-day count:</strong> model G with sixteen selected days per season, same 190-contrast correction.</li>
<li><strong>Adding WP:</strong> the three-pair publication figure, separate Holm correction across 270 model contrasts.</li></ol>
<p><a href="figures/Publication_selection/Main_paper/Figure_Three_WP_comparisons_Top10.pdf">Selected three-pair WP publication figure</a> · <a href="figures/Publication_selection/Main_paper/Caption.txt">Caption</a></p></section>
<h2>New storyline figures</h2><p>The Main folder contains G Top10 and G sixteen-day displays; other fractions, eight days and K are supplementary. Lines show pointwise 95% conditional intervals. Symbols show the 190-test adjustment. Seasonal variability ranges are a different display.</p>
<table><thead><tr><th>Figure</th><th>Question</th><th>Files</th></tr></thead><tbody>'''+''.join(rows)+'''</tbody></table>
<h2>Retained evidence</h2><p><a href="figures/INDEX.html">Model comparison figure index</a> · <a href="figures/Publication_selection/READ_FIRST_selection_and_justification.txt">Supplied publication selection</a> · <a href="reports/storyline_amendment/RESULTS.txt">Current Results</a> · <a href="reports/storyline_amendment/METHODS.txt">Methods</a> · <a href="reports/storyline_amendment/LIMITATIONS.txt">Limitations</a> · <a href="reports/storyline_amendment/REVIEW_REPORT.txt">Review report</a></p>
<p>Storylines change occurrence and persistence together. Conditional Monte Carlo precision excludes fitting/generator uncertainty and does not establish operational warning benefit.</p></html>'''
    (root/'START_HERE.html').write_text(page,encoding='utf-8')


def current_reporting(root):
    root=Path(root)
    for src,dest in [('RESULTS.txt','RESULTS_WORDING.txt'),('METHODS.txt','METHODS.txt'),
                     ('LIMITATIONS.txt','LIMITATIONS.txt'),('REVIEW_REPORT.txt','REVIEW_REPORT.txt')]:
        source=root/'reports/storyline_amendment'/src
        (root/'reports'/dest).write_text(source.read_text(),encoding='utf-8')
    metadata=json.loads((root/'results/storyline_inference/METADATA.json').read_text())
    v=json.loads((root/'results/storyline_inference/INDEPENDENT_VERIFICATION.json').read_text())
    f=json.loads((root/'results/storyline_inference/FIGURE_VERIFICATION.json').read_text())
    unit=json.loads((root/'results/storyline_inference/UNIT_TEST_STATUS.json').read_text())
    release={'status':'completed','UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'entrypoint':'run_step6.py','current_results':'results/storyline_inference/all_contrasts.csv',
             'existing_WP_tests':'results/inference/paired_tests.csv',
             'new_contrasts':190,'new_Holm_rejections':metadata['holm_rejections'],
             'independent_verification':v['status'],'figure_verification':f['status'],
             'unit_test_status':unit['status'],'unit_tests_run':unit['tests_run'],
             'no_refitting':True,'no_weather_generation':True,
             'storyline_comparisons_reuse_corrected_step6_bootstrap_draws':True,
             'step6_bootstrap_recomputed_for_corrected_step5':True,
             'limitations':'Conditional Monte Carlo; retrospective amendment; frequency/sequence co-vary; no operational validation'}
    (root/'results/storyline_inference/RELEASE_STATUS.json').write_text(json.dumps(release,indent=2)+'\n')
    (root/'results/COMPLETION.json').write_text(json.dumps(release,indent=2)+'\n')
    with (root/'reports/REVIEW_REPORT.txt').open('a',encoding='utf-8') as handle:
        handle.write(f"\nFinal current-entry-point checks: {unit['tests_run']} unit tests, "
                     f"{f['new_plotted_estimates_intervals_symbols_verified']} plotted contrasts and "
                     f"{f['new_figure_sets']} figure sets passed. The full current runner executed successfully.\n")
    report_dir = root / 'reports/storyline_amendment'
    sources = json.loads((root / 'inputs/provenance/SOURCE_ARCHIVES.json').read_text())
    identity = ['SOURCE ARCHIVES', '']
    for name, info in sources.items():
        identity.extend([name, f"Size in bytes: {info['bytes']}", f"SHA-256: {info['sha256']}", ''])
    identity.append('The two API-corrected archives supply the inputs. The uploaded Step 6 archive defines the original methods and comparison baseline.')
    (report_dir / 'INPUT_IDENTITY.txt').write_text('\n'.join(identity) + '\n', encoding='utf-8')
    final_note = (
        'API-CORRECTED STEP 6 | VERIFICATION\n\n'
        f"The independent storyline verifier reconciled {v['pooled_verified']} pooled and "
        f"{v['matched_verified']} fixed-count storyline contrasts and "
        f"{v['covariance_identities_checked']} paired covariance identities.\n"
        f"Source checks covered {f['new_plotted_estimates_intervals_symbols_verified']} plotted "
        f"storyline contrasts and {f['supplied_WP_figure_source_rows_verified']} model-comparison rows.\n"
        f"The implementation test suite passed {unit['tests_run']} tests.\n\n"
        'Read RESULTS.txt for the corrected estimates and intervals. The separate 270 model '
        'comparisons are in results/inference/paired_tests.csv. The 190 storyline comparisons '
        'are in results/storyline_inference/all_contrasts.csv. See reports/api_update/ for '
        'the comparison with the uploaded Step 6 results.\n')
    (report_dir / 'FINAL_REVIEW.txt').write_text(final_note, encoding='utf-8')
    write_index(root)
    return release
