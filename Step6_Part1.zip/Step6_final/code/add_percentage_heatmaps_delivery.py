from pathlib import Path
import sys,json,zipfile
import pandas as pd,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
r=Path(__file__).resolve().parent.parent;sys.path.insert(0,str(r/'code'))
from figures_step6 import _configure,STORIES,STORY_LABELS,METRICS
_configure();d=pd.read_csv(r/'results/paired_model_differences.csv');f=r/'figures/Heatmaps_by_percentage';f.mkdir(exist_ok=True)
for pct in [1,5,10,25,50]:
 a=d[d.rule==f'topk_{pct:02d}'];fig,axes=plt.subplots(1,3,figsize=(10,5));fig.subplots_adjust(left=.22,right=.98,bottom=.25,top=.85,wspace=.45)
 for ax,m,title in zip(axes,METRICS,['Selected days','Clusters','Maximum run length']):
  mat=a[a.metric==m].pivot(index='storyline',columns='comparison',values='mean_difference').loc[STORIES,['E-C','F-J','G-K']].to_numpy();v=max(abs(mat).max(),.01)
  im=ax.imshow(mat,cmap='RdBu_r',vmin=-v,vmax=v,aspect='auto');ax.set_xticks(range(3),['E−C','F−J','G−K']);ax.set_yticks(range(6),STORY_LABELS if ax==axes[0] else ['']*6);ax.set_title(title)
  for i in range(6):
   for j in range(3):ax.text(j,i,f'{mat[i,j]:+.2f}',ha='center',va='center',fontsize=7,color='white' if abs(mat[i,j])>.6*v else 'black')
  fig.colorbar(im,ax=ax,orientation='horizontal',fraction=.06,pad=.12)
 fig.suptitle(f'Top {pct}%: mean change after adding WP');fig.text(.5,.03,'Conditional simulated differences; colours do not indicate statistical significance.',ha='center',fontsize=8)
 for ext in ['png','pdf','svg']:fig.savefig(f/f'Heatmaps_Top{pct:02d}.{ext}',dpi=600)
 plt.close(fig)
 a.to_csv(f/f'Heatmaps_Top{pct:02d}_data.csv',index=False)
(r/'figures/00_START_HERE.txt').write_text('ALL-MODEL BAR CHARTS: Legacy_style_updated/Top01, Top05, Top10, Top25, Top50 — three outcomes in each folder.\nHEATMAPS FOR EACH PERCENTAGE: Heatmaps_by_percentage — Top01, Top05, Top10, Top25, Top50.\nCOMBINED HEATMAP: Figure_Step6_Paired_budget_sensitivity.\nG/K THREE-PANEL FIGURES FOR EVERY PERCENTAGE: All_percentages.\nMAIN PUBLICATION FIGURE: Main_publication/Figure_Main_Top10.\nOriginal_reference_NOT_FOR_PUBLICATION contains old supplied images only.\n')
