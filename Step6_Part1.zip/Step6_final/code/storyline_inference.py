"""Retrospective storyline inference from saved results only.

No classifier/calibrator fitting, weather generation, prediction reconstruction
or new bootstrap sampling is performed. The 190 new tests form one Holm family.
"""
from pathlib import Path
import datetime
import hashlib
import json
import platform
import sys
import numpy as np
import pandas as pd
import scipy
from scipy.stats import norm, skew

ROOT = Path(__file__).resolve().parent.parent
MODELS = ['G', 'K']
METRICS = ['selected_days', 'clusters', 'max_run_days']
SCENARIOS = ['baseline','persistent_wet','persistent_dry','dry_with_bursts',
             'flip_wet_to_dry','flip_dry_to_wet']
BUDGETS = [.01,.05,.10,.25,.50]
FAMILY_SIZE = 190


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def probability_display(logp):
    if not np.isfinite(logp):
        return 'not estimable'
    return '<1e-300' if logp < np.log(1e-300) else f'{np.exp(logp):.6g}'


def numeric_probability(logp):
    """Missing numeric value under machine underflow; log/display remain valid."""
    if not np.isfinite(logp) or logp < np.log(np.nextafter(0.,1.)):
        return np.nan
    return float(np.exp(logp))


def holm_log(logp, family_size=FAMILY_SIZE):
    """Holm in log space; NE hypotheses retain a family slot conservatively."""
    a = np.asarray(logp, dtype=float)
    if len(a) != family_size:
        raise ValueError('The full declared test family is required')
    valid = np.isfinite(a)
    if np.any(a[valid] > 0):
        raise ValueError('Log p-values cannot be positive')
    work = np.where(valid, a, 0.)
    order = np.argsort(work, kind='stable')
    adjusted = np.minimum(0., np.maximum.accumulate(
        work[order] + np.log(family_size-np.arange(family_size))))
    out = np.empty(family_size)
    out[order] = adjusted
    out[~valid] = np.nan
    return out


def normal_inference(point, se):
    if not np.isfinite(point) or not np.isfinite(se) or se <= 0:
        return dict(estimable=False,status='non-finite estimate/SE or zero SE',
                    ci95_lower=np.nan,ci95_upper=np.nan,log_p_raw=np.nan)
    logp = float(np.log(2.) + norm.logsf(abs(point/se)))
    return dict(estimable=True,status='estimable; approximate normal/Wald',
                ci95_lower=point-1.96*se,ci95_upper=point+1.96*se,log_p_raw=logp)


def contains_zero(lower, upper):
    return bool(np.isfinite(lower) and np.isfinite(upper) and lower <= 0 <= upper)


def check_source_alignment(root, bundle):
    """Independently saved model-pair draws must equal differences of means."""
    names = list(bundle['models'].astype(str))
    means = bundle['means']
    if means.shape != (11,4000,5,6,3):
        raise ValueError(f'Unexpected saved draw dimensions: {means.shape}')
    if len(set(names)) != 11 or set(names) != set('ABCDEFGHIJK'):
        raise ValueError('Model labels incomplete or duplicated')
    if list(bundle['scenarios'].astype(str)) != SCENARIOS:
        raise ValueError('Scenario labels do not match the documented draw layout')
    if list(bundle['metrics'].astype(str)) != METRICS:
        raise ValueError('Outcome labels do not match documented layout')
    np.testing.assert_allclose(bundle['budgets'],BUDGETS,rtol=0,atol=1e-14)
    if not np.isfinite(means).all():
        raise ValueError('Non-finite saved mean draws')
    with np.load(root/'results/inference/paired_bootstrap_replicates.npz',allow_pickle=False) as pairs:
        for name in ['budgets','scenarios','metrics']:
            np.testing.assert_array_equal(bundle[name],pairs[name])
        errors={}
        for high,low in [('E','C'),('F','J'),('G','K')]:
            difference=means[names.index(high)]-means[names.index(low)]
            np.testing.assert_allclose(difference,pairs[f'{high}_{low}'],rtol=0,atol=1e-12)
            errors[f'{high}-{low}']=float(np.max(np.abs(difference-pairs[f'{high}_{low}'])))
    metadata=json.loads((root/'results/inference/INFERENCE_METADATA.json').read_text())
    if metadata['replicates'] != 4000 or metadata['n_units'] != 5000:
        raise ValueError('Source resampling metadata inconsistent')
    return dict(saved_draw_shape=list(means.shape),pair_alignment_max_errors=errors,
        source_weights_sha256=metadata.get('weights_sha256'),
        source_resampling=metadata['resampling'],
        code_evidence='code/inference_step6.py: one weight matrix reused by worker models and all scenarios; bootstrap_means reapplies pooled selection.',
        source_code_sha256=sha256(root/'code/inference_step6.py'),
        draws_reused=True,new_draws_generated=False)


def run(root=ROOT):
    root=Path(root)
    config=json.loads((root/'config.json').read_text())['storyline_inference_amendment']
    if config['models']!=MODELS or config['pooled_budgets']!=BUDGETS or config['matched_counts']!=[8,16]:
        raise ValueError('Configuration differs from the documented analysed scope')
    if config['family_size']!=FAMILY_SIZE or config['interval_multiplier']!=1.96:
        raise ValueError('Configuration differs from the declared inference method')
    if config['diagnostic_bias_SE_threshold']!=.25 or config['diagnostic_bootstrap_skewness_threshold']!=.5:
        raise ValueError('Diagnostic settings differ from the documented thresholds')
    out=root/'results/storyline_inference'
    out.mkdir(parents=True,exist_ok=True)
    source_names=['results/seasonal_summary.csv','results/scenario_baseline_differences.csv',
        'results/matched_count_seasonal_metrics.csv.gz','results/matched_count_summary.csv',
        'results/inference/model_mean_bootstrap_replicates.npz',
        'results/inference/paired_bootstrap_replicates.npz','results/inference/paired_tests.csv',
        'results/inference/INFERENCE_METADATA.json','code/inference_step6.py']
    input_hashes={name:sha256(root/name) for name in source_names}
    summary=pd.read_csv(root/'results/seasonal_summary.csv',float_precision='round_trip')
    keys=['model','rule','storyline','metric']
    if summary.duplicated(keys).any() or not summary.n_seasons.eq(5000).all():
        raise ValueError('Invalid seasonal summary keys or counts')
    points=summary.set_index(keys)['mean']
    old_scenario=pd.read_csv(root/'results/scenario_baseline_differences.csv',float_precision='round_trip').set_index(keys)
    rows=[];contrast_draws=[];contrast_ids=[]
    with np.load(root/'results/inference/model_mean_bootstrap_replicates.npz',allow_pickle=False) as bundle:
        alignment=check_source_alignment(root,bundle)
        names=list(bundle['models'].astype(str))
        budgets=list(bundle['budgets'])
        stories=list(bundle['scenarios'].astype(str))
        metrics=list(bundle['metrics'].astype(str))
        means=bundle['means']
        for model in MODELS:
            for budget in BUDGETS:
                b=int(np.flatnonzero(np.isclose(budgets,budget,rtol=0,atol=1e-14))[0])
                rule=f'topk_{round(budget*100):02d}'
                for story in SCENARIOS[1:]:
                    s=stories.index(story);s0=stories.index('baseline')
                    for metric in METRICS:
                        j=metrics.index(metric)
                        a=means[names.index(model),:,b,s,j]
                        baseline=means[names.index(model),:,b,s0,j]
                        draws=a-baseline
                        point=float(points.loc[(model,rule,story,metric)]-points.loc[(model,rule,'baseline',metric)])
                        np.testing.assert_allclose(point,old_scenario.loc[(model,rule,story,metric),'mean_difference'],rtol=0,atol=1e-10)
                        se=float(draws.std(ddof=1))
                        iv=normal_inference(point,se)
                        qlo,qhi=map(float,np.quantile(draws,[.025,.975]))
                        bias=float((draws.mean()-point)/se) if se>0 else np.nan
                        skewness=float(skew(draws,bias=False)) if se>0 else np.nan
                        flag=bool((abs(bias)>.25) or (abs(skewness)>.5))
                        disagreement=contains_zero(iv['ci95_lower'],iv['ci95_upper']) != contains_zero(qlo,qhi)
                        identity=f'pooled:{model}:{rule}:{story}:{metric}'
                        rows.append(dict(contrast_id=identity,analysis='pooled',model=model,rule=rule,budget=budget,
                            selected_days_per_season=np.nan,storyline=story,comparison=f'{story}-baseline',
                            metric=metric,n_pairs=5000,n_bootstrap_replicates=4000,
                            scenario_mean=float(points.loc[(model,rule,story,metric)]),
                            baseline_mean=float(points.loc[(model,rule,'baseline',metric)]),
                            mean_difference=point,standard_error=se,**iv,
                            percentile95_lower=qlo,percentile95_upper=qhi,
                            bootstrap_mean=float(draws.mean()),bias_over_se=bias,bootstrap_skewness=skewness,
                            normal_approximation_flag=flag,percentile_zero_disagreement=disagreement,
                            diagnostic_caution=flag or disagreement or not iv['estimable'],
                            bootstrap_covariance=float(np.cov(a,baseline,ddof=1)[0,1]),
                            independence_standard_error_diagnostic=float(np.hypot(a.std(ddof=1),baseline.std(ddof=1))),
                            ci_scope='Pointwise 95% original estimate +/- 1.96 paired saved-bootstrap SE; conditional on fixed fitted system',
                            test_scope='Approximate two-sided normal/Wald; new storyline Holm family190',
                            pairing='Shared simulation-index bundles; common-random-number coupling, not causal pairing'))
                        contrast_draws.append(draws);contrast_ids.append(identity)
    if len(rows)!=150: raise ValueError('Expected 150 pooled contrasts')
    matched=pd.read_csv(root/'results/matched_count_seasonal_metrics.csv.gz',float_precision='round_trip')
    if matched.duplicated(['model','rule','storyline','sim']).any():
        raise ValueError('Duplicate matched-count season identifiers')
    for (model,rule,story),group in matched.groupby(['model','rule','storyline'],sort=False):
        expected={'matched_05':8,'matched_10':16}[rule]
        if len(group)!=5000 or group.sim.nunique()!=5000 or not group.selected_days.eq(expected).all():
            raise ValueError('Missing/incorrect fixed-count seasons')
        if not group.clusters.between(1,expected).all() or not group.max_run_days.between(1,expected).all():
            raise ValueError('Invalid matched-count run metrics')
    expected_ids=set(matched[(matched.model=='G')&(matched.rule=='matched_05')&(matched.storyline=='baseline')].sim)
    matched_points=pd.read_csv(root/'results/matched_count_summary.csv',float_precision='round_trip').set_index(keys)['mean']
    for model in MODELS:
        for rule,count in [('matched_05',8),('matched_10',16)]:
            selected=matched[matched.model.eq(model)&matched.rule.eq(rule)]
            for story in SCENARIOS[1:]:
                a=selected[selected.storyline.eq(story)].set_index('sim').sort_index()
                b=selected[selected.storyline.eq('baseline')].set_index('sim').sort_index()
                if set(a.index)!=expected_ids or set(b.index)!=expected_ids:
                    raise ValueError('Simulation index mismatch')
                for metric in ['clusters','max_run_days']:
                    v=a[metric].to_numpy(dtype=float)-b[metric].to_numpy(dtype=float)
                    point=float(v.mean());se=float(v.std(ddof=1)/np.sqrt(len(v)))
                    iv=normal_inference(point,se)
                    np.testing.assert_allclose(point,matched_points.loc[(model,rule,story,metric)]-matched_points.loc[(model,rule,'baseline',metric)],rtol=0,atol=1e-10)
                    rows.append(dict(contrast_id=f'matched:{model}:{rule}:{story}:{metric}',analysis='matched',
                        model=model,rule=rule,budget=np.nan,selected_days_per_season=count,
                        actual_fraction_percent=count/153*100,storyline=story,comparison=f'{story}-baseline',
                        metric=metric,n_pairs=len(v),n_bootstrap_replicates=0,
                        scenario_mean=float(a[metric].mean()),baseline_mean=float(b[metric].mean()),
                        mean_difference=point,standard_error=se,**iv,
                        normal_approximation_flag=False,percentile_zero_disagreement=False,
                        diagnostic_caution=not iv['estimable'],
                        paired_difference_skewness=float(skew(v,bias=False)) if se>0 else np.nan,
                        paired_difference_zero_fraction=float(np.mean(v==0)),
                        paired_difference_min=float(v.min()),paired_difference_max=float(v.max()),
                        paired_difference_distinct_values=int(len(np.unique(v))),
                        ci_scope='Pointwise 95% original estimate +/- 1.96 paired-season SE; conditional Monte Carlo, not bootstrap',
                        test_scope='Approximate two-sided normal/Wald; new storyline Holm family190',
                        pairing='Shared simulation identifiers and donor-uniform coupling, not causal observational pairing'))
    frame=pd.DataFrame(rows)
    if len(frame)!=190 or frame.contrast_id.duplicated().any():
        raise ValueError('Invalid 190-contrast family')
    frame['log_p_holm']=holm_log(frame.log_p_raw)
    frame['family_id']='storyline_190'
    frame['family_size']=190
    for column in ['raw','holm']:
        frame[f'p_{column}']=frame[f'log_p_{column}'].map(numeric_probability)
        frame[f'p_{column}_display']=frame[f'log_p_{column}'].map(probability_display)
    def star(logp):
        if not np.isfinite(logp):return 'NE'
        return '***' if logp<np.log(.001) else '**' if logp<np.log(.01) else '*' if logp<np.log(.05) else 'ns'
    frame['stars']=frame.log_p_holm.map(star)
    frame['holm_reject_05']=frame.log_p_holm.lt(np.log(.05)) & frame.estimable
    for name,part in [('all_contrasts',frame),('pooled_contrasts',frame[frame.analysis.eq('pooled')]),
                      ('matched_contrasts',frame[frame.analysis.eq('matched')]),
                      ('pooled_diagnostics',frame[frame.analysis.eq('pooled')]),
                      ('flagged_pooled_diagnostics',frame[frame.analysis.eq('pooled')&frame.diagnostic_caution]),
                      ('matched_distribution_diagnostics',frame[frame.analysis.eq('matched')])]:
        part.to_csv(out/f'{name}.csv',index=False,float_format='%.17g')
    np.savez_compressed(out/'reused_pooled_contrast_draws.npz',
        contrast_ids=np.array(contrast_ids),draws=np.stack(contrast_draws))
    (out/'BOOTSTRAP_ALIGNMENT_VERIFICATION.json').write_text(json.dumps(alignment,indent=2)+'\n')
    metadata=dict(completed=True,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        amendment='Retrospective extension motivated by review of existing outputs; not prospectively prespecified',
        family_size=190,pooled_contrasts=150,matched_contrasts=40,bootstrap_replicates=4000,
        matched_seasons_per_contrast=5000,normal_interval_multiplier=1.96,
        multiplicity='One Holm family across all 190 new storyline contrasts; original270 WP-inclusion tests remain separate and unchanged',
        no_refitting=True,no_calibration=True,no_prediction_reconstruction=True,
        no_weather_generation=True,no_new_draws=True,no_external_scientific_data=True,
        pooled_diagnostic_flags=int(frame.loc[frame.analysis.eq('pooled'),'normal_approximation_flag'].sum()),
        percentile_zero_disagreements=int(frame.percentile_zero_disagreement.sum()),
        nonestimable=int((~frame.estimable).sum()),
        holm_rejections=int(frame.holm_reject_05.sum()),
        holm_rejections_by_analysis=frame.groupby('analysis').holm_reject_05.sum().astype(int).to_dict(),
        input_sha256=input_hashes,
        uncertainty='Conditional Monte Carlo: fitted models/calibrators, generator, donor library, historical inputs and ties fixed',
        zero_SE_policy='Not estimable; no significance symbol. Missing hypotheses retain a conservative family slot as p1 internally for Holm only.',
        underflow_policy='Log-tail probabilities retained. Numeric p missing if below smallest positive float; display bounds below1e-300, never p0.',
        configuration=config,
        versions={'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__})
    for name,digest in input_hashes.items():
        if sha256(root/name)!=digest:raise ValueError(f'Protected source altered: {name}')
    (out/'METADATA.json').write_text(json.dumps(metadata,indent=2)+'\n')
    print(json.dumps({k:metadata[k] for k in ['pooled_contrasts','matched_contrasts','family_size','holm_rejections','pooled_diagnostic_flags','percentile_zero_disagreements','nonestimable']},indent=2),flush=True)
    return metadata


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=ROOT)
    run(parser.parse_args().root)
