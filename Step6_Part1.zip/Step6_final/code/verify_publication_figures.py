"""Independent checks of the Top-10% publication presentation and legacy plots.

Read-only with respect to scientific inputs/results. Writes a figure-check report.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import xml.etree.ElementTree as ET

import numpy as np
import pandas as pd
from PIL import Image
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parent.parent
METRICS=['selected_days','clusters','max_run_days']
RULES=['topk_01','topk_05','topk_10','topk_25','topk_50']
STORIES=['baseline','persistent_wet','persistent_dry','dry_with_bursts',
         'flip_wet_to_dry','flip_dry_to_wet']
KEY=['model','rule','storyline','metric']

def digest(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(2**20),b''):h.update(b)
    return h.hexdigest()

def check_publication(root=ROOT,snapshot=None):
    root=Path(root);checks=[];details={}
    def check(name,condition,description):
        if not bool(condition):raise AssertionError(name+': '+description)
        checks.append(dict(name=name,passed=True,description=description))
    source=pd.read_csv(root/'results/seasonal_summary.csv',float_precision='round_trip')
    main=root/'figures/Main_publication'
    main_data=pd.read_csv(main/'FIGURE_DATA.csv',float_precision='round_trip')
    expected={(m,'topk_10',s,k) for m in ['G','K'] for s in STORIES for k in METRICS}
    check('main_record_coverage',len(main_data)==36 and not main_data.duplicated(KEY).any()
          and set(map(tuple,main_data[KEY].to_numpy()))==expected,
          'G/K, Top10%, six scenarios and the three retained outcomes.')
    def source_equal(data):
        merged=data.merge(source,on=KEY,validate='one_to_one',suffixes=('_plot','_source'))
        return len(merged)==len(data) and all(np.allclose(merged[c+'_plot'],merged[c+'_source'],
                rtol=1e-12,atol=1e-12,equal_nan=False) for c in ['mean','p05','p95'])
    check('main_means_and_ranges',source_equal(main_data),
          'All 36 publication means and 72 interval endpoints equal the existing source table.')
    check('main_finite_nonnegative_values',np.isfinite(main_data[['mean','p05','p95']]).all().all()
          and (main_data[['mean','p05','p95']]>=0).all().all(),
          'Only finite non-negative counts/durations and interval endpoints are plotted.')
    stem=main/'Figure_Main_Top10'
    for dpi,suffix in [(1200,'.png'),(600,'_600dpi.png')]:
        p=stem.with_name(stem.name+suffix)
        with Image.open(p) as im:
            expected_px=np.array([183,115])/25.4*dpi
            check(f'main_png_{dpi}_dimensions',np.all(np.abs(np.array(im.size)-expected_px)<=1),
                  f'Publication figure has physical size 183 x 115 mm at {dpi} dpi.')
            check(f'main_png_{dpi}_resolution',np.all(np.abs(np.array(im.info.get('dpi',[0,0]))-dpi)<.1),
                  f'PNG resolution metadata records {dpi} dpi.')
    def vector_checks(pdf,svg,label):
        reader=PdfReader(pdf)
        text=' '.join(p.extract_text() or '' for p in reader.pages)
        check(label+'_single_page_pdf',len(reader.pages)==1,'One page per standalone figure.')
        check(label+'_pdf_fonts',b'/Subtype /Type3' not in Path(pdf).read_bytes(),
              'PDF has no Type 3 font outlines.')
        tree=ET.parse(svg)
        check(label+'_editable_svg',len(tree.findall('.//{http://www.w3.org/2000/svg}text'))>10,
              'SVG retains editable text for labels and legend.')
        check(label+'_no_significance_stars',not re.search(r'\bp\s*[<=>]\s*0\.',text,re.I),
              'No legacy p-value significance claim is reproduced as a current result.')
        return text
    text=vector_checks(stem.with_suffix('.pdf'),stem.with_suffix('.svg'),'main')
    check('main_top10_label','Top10%' in re.sub(r'\s+','',text),
          'The main figure explicitly identifies Top10% selection.')
    check('main_WP_comparison_label','WP' in text and 'G' in text and 'K' in text,
          'The two full-model variants are labelled with/without WP.')
    supplementary=root/'figures/Supplementary'
    for pct in [1,5,25,50]:
        candidates={ext:sorted(supplementary.rglob(f'*Top{pct:02d}*.{ext}')) for ext in ['png','pdf','svg']}
        check(f'supplement_top{pct:02d}_exports',all(candidates.values()),
              'The non-main selection fraction has standalone PNG/PDF/SVG exports.')
        with Image.open(candidates['png'][0]) as im:
            check(f'supplement_top{pct:02d}_600dpi',np.all(np.abs(np.array(im.info.get('dpi',[0,0]))-600)<.1),
                  'Supplementary PNG retains 600 dpi metadata.')
        reference=root/f'figures/All_percentages/Figure_Step6_Top{pct:02d}.png'
        check(f'supplement_top{pct:02d}_source_identity',digest(candidates['png'][0])==digest(reference),
              'Supplementary plot is identical to the previously source-verified percentage plot.')
    legacy=root/'figures/Legacy_style_updated'
    legacy_data=pd.read_csv(legacy/'FIGURE_DATA.csv',float_precision='round_trip')
    expected={(m,r,s,k) for m in list('ABCDEFGHIJK') for r in RULES for s in STORIES for k in METRICS}
    check('legacy_complete_990_record_coverage',len(legacy_data)==990 and not legacy_data.duplicated(KEY).any()
          and set(map(tuple,legacy_data[KEY].to_numpy()))==expected,
          'All eleven models, five fractions, six scenarios and three outcomes are present.')
    check('legacy_means_and_ranges',source_equal(legacy_data),
          'All 990 grouped-bar means and their 1,980 percentile endpoints match the current source table.')
    export_paths={ext:sorted(legacy.rglob('*.'+ext)) for ext in ['png','pdf','svg']}
    # A combined multi-page PDF, if present, is additional to the fifteen one-page plots.
    pdfs=[p for p in export_paths['pdf'] if len(PdfReader(p).pages)==1]
    check('legacy_export_counts',len(export_paths['png'])==15 and len(export_paths['svg'])==15 and len(pdfs)==15,
          'Three retained outcomes at five fractions each have PNG/PDF/SVG exports.')
    legacy_text=[]
    for p in export_paths['png']:
        with Image.open(p) as im:
            if not np.all(np.abs(np.array(im.info.get('dpi',[0,0]))-600)<.1):
                raise AssertionError('Legacy PNG not 600 dpi: '+str(p))
    check('legacy_png_resolution',True,'All fifteen updated grouped-bar PNGs record 600 dpi.')
    for pdf in pdfs:
        svg=pdf.with_suffix('.svg')
        if not svg.exists():raise AssertionError('Missing vector companion for '+str(pdf))
        reader=PdfReader(pdf);text=' '.join(p.extract_text() or '' for p in reader.pages);legacy_text.append(text)
        if b'/Subtype /Type3' in pdf.read_bytes():raise AssertionError('Legacy PDF font outline: '+str(pdf))
        if len(ET.parse(svg).findall('.//{http://www.w3.org/2000/svg}text'))<=10:
            raise AssertionError('Legacy SVG lacks editable text: '+str(svg))
        if re.search(r'\bp\s*[<=>]\s*0\.',text,re.I):raise AssertionError('Legacy significance annotation retained')
    check('legacy_vector_text_and_no_new_pvalues',True,
          'All grouped-bar vector exports retain text and omit legacy p-value annotations.')
    check('legacy_D_label_WP',all(re.search(r'\bD\s*[:–—-]?\s*WP\b',text) for text in legacy_text),
          'Model D is displayed as WP while retaining its established underlying model.')
    verified=0
    if snapshot:
        baseline=json.loads(Path(snapshot).read_text())
        for relative,value in baseline.items():
            path=root/relative
            if not path.exists() or digest(path)!=value:raise AssertionError('Scientific input/result changed: '+relative)
        verified=len(baseline)
        check('original_inputs_and_results_unchanged',True,
              f'All {verified} original scientific input/result files are byte-identical.')
    report=dict(status='passed',checks_passed=len(checks),checks=checks,
                main_records=36,legacy_records=990,immutable_files_verified=verified,
                scope='Figure source/export and presentation checks; no new statistical or operational validation.')
    folder=root/'figures';folder.mkdir(exist_ok=True)
    (folder/'PUBLICATION_PRESENTATION_VERIFICATION.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    return report

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=ROOT)
    parser.add_argument('--snapshot',type=Path)
    args=parser.parse_args();result=check_publication(args.root,args.snapshot)
    print(json.dumps({k:result[k] for k in ['status','checks_passed','main_records','legacy_records','immutable_files_verified']},indent=2))
