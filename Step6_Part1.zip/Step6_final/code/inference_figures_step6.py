"""Read-only plotting of conditional Step 6 confidence intervals and tests.

All tests come from paired_tests.csv. Stars never follow colour or CI overlap.
"""
from pathlib import Path
import json,argparse
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.colors import TwoSlopeNorm
from matplotlib.ticker import MaxNLocator
from legacy_figures_step6 import MODELS,COLORS,_labels
from figures_step6 import STORIES,STORY_LABELS,METRICS,RULES,PAIRS,COLOURS,MM,_configure

ROOT=Path(__file__).resolve().parent.parent
TITLES=['Model-selected days','Selected-day clusters','Maximum run length']
UNITS=['Days per season','Clusters per season','Days']
STEMS=['Selected_days','Clusters','Maximum_run']
SCOPE='Conditional on fitted models and weather generator; not operational validation.'
STARS='Holm-adjusted: * p<0.05; ** p<0.01; *** p<0.001; ns: not significant. † Bootstrap diagnostic flag; see sensitivity table.'

def star(p):
    if not np.isfinite(p):return 'NA'
    return '***' if p<.001 else '**' if p<.01 else '*' if p<.05 else 'ns'

def save(fig,folder,stem,metadata,dpi=600,width=250,height=155,extra600=False):
    folder.mkdir(parents=True,exist_ok=True);paths=[]
    for ext in ['png','pdf','svg']:
        p=folder/f'{stem}.{ext}';fig.savefig(p,dpi=dpi)
        package_root=next(x.parent for x in p.parents if x.name=='figures')
        paths.append(str(p.relative_to(package_root)))
    if extra600:
        p=folder/f'{stem}_600dpi.png';fig.savefig(p,dpi=600)
        package_root=next(x.parent for x in p.parents if x.name=='figures')
        paths.append(str(p.relative_to(package_root)))
    plt.close(fig)
    metadata.append(dict(stem=stem,files=paths,width_mm=width,height_mm=height,png_dpi=dpi))

def figure_record(frame,stem,interval):
    a=frame.copy();a.insert(0,'figure',stem);a['interval_type']=interval;return a

def load(root):
    means=pd.read_csv(root/'results/inference/mean_confidence_intervals.csv',float_precision='round_trip')
    tests=pd.read_csv(root/'results/inference/paired_tests.csv',float_precision='round_trip')
    ranges=pd.read_csv(root/'results/seasonal_summary.csv',float_precision='round_trip')
    keys=['model','rule','storyline','metric']
    if len(means)!=990 or means.duplicated(keys).any():raise ValueError('Mean-CI table must contain 990 unique records')
    if len(tests)!=270 or tests.duplicated(['comparison','rule','storyline','metric']).any():raise ValueError('Expected 270 paired tests')
    tests['display_stars']=[star(p) for p in tests.p_holm]
    if 'normal_approximation_flag' in tests:
        flags=tests.normal_approximation_flag.map(lambda x: str(x).strip().lower() in ['true','1'])
        tests.loc[flags,'display_stars']=tests.loc[flags,'display_stars']+'†'
    for c in ['mean','ci95_lower','ci95_upper']:
        if not np.isfinite(means[c]).all():raise ValueError('Non-finite mean confidence interval')
    for c in ['mean_difference','ci95_lower','ci95_upper','p_raw','p_holm']:
        if not np.isfinite(tests[c]).all():raise ValueError('Non-finite paired inference value')
    a=means.merge(ranges[keys+['p05','p95']],on=keys,validate='one_to_one')
    return a,tests

def gettest(tests,pair,rule,story,metric):
    x=tests[(tests.comparison==pair)&(tests.rule==rule)&(tests.storyline==story)&(tests.metric==metric)]
    if len(x)!=1:raise ValueError('Missing or duplicated test')
    return x.iloc[0]

def bars(root,means,tests,metadata,data,range_mode=False):
    mode='Grouped_bars_90ranges' if range_mode else 'Grouped_bars_95CI'
    labels=_labels(json.loads((root/'inputs/step5/model_registry.json').read_text()))
    for rule in RULES:
      pct=int(rule[-2:])
      for j,metric in enumerate(METRICS):
        values=means[(means.rule==rule)&(means.metric==metric)].copy()
        lo='p05' if range_mode else 'ci95_lower';hi='p95' if range_mode else 'ci95_upper'
        fig,ax=plt.subplots(figsize=(250*MM,155*MM))
        fig.subplots_adjust(left=.065,right=.745,top=.86,bottom=.21)
        positions=np.arange(6);width=.80/11
        offsets={m:(i-5)*width for i,m in enumerate(MODELS)}
        for m in MODELS:
            v=values[values.model==m].set_index('storyline').loc[STORIES];x=positions+offsets[m]
            ax.bar(x,v['mean'],width=width,color=COLORS[m],edgecolor='#444444',linewidth=.35,zorder=2)
            ax.vlines(x,v[lo],v[hi],color='#292929',linewidth=.8,zorder=3)
            for c in [lo,hi]:ax.hlines(v[c],x-width*.23,x+width*.23,color='#292929',linewidth=.8,zorder=3)
        vmin=min(0,float(values[lo].min()));vmax=float(values[[hi,'mean']].max().max());span=max(1.,vmax-vmin)
        # Three non-overlapping levels per scenario; brackets refer only to the three agreed pairs.
        for i,story in enumerate(STORIES):
            local=float(values[values.storyline==story][[hi,'mean']].max().max())
            for level,pair in enumerate(PAIRS):
                high,low=pair.split('-');x1=i+offsets[low];x2=i+offsets[high]
                y=local+span*(.07+.085*level);h=span*.018
                ax.plot([x1,x1,x2,x2],[y,y+h,y+h,y],color='#222222',linewidth=.7,clip_on=False)
                t=gettest(tests,pair,rule,story,metric)
                ax.text((x1+x2)/2,y+h+span*.006,t.display_stars,ha='center',va='bottom',fontsize=7)
        ax.set_ylim(vmin-span*.015,vmax+span*.36);ax.set_xlim(-.55,5.55)
        ax.set_xticks(positions,STORY_LABELS);ax.tick_params(axis='x',length=0,pad=8,labelsize=8)
        ax.yaxis.set_major_locator(MaxNLocator(nbins=6))
        ax.set_ylabel('Clusters' if metric=='clusters' else 'Days')
        ax.set_title(f'{TITLES[j]} per season — Top {pct}%',loc='left',pad=16,fontsize=11)
        ax.grid(axis='y',color='#E3E6E8',linewidth=.5);ax.set_axisbelow(True)
        for n in ['top','right']:ax.spines[n].set_visible(False)
        ax.legend(handles=[Patch(facecolor=COLORS[m],edgecolor='#444444',linewidth=.35,label=labels[m]) for m in MODELS],
            title='Model',loc='upper left',bbox_to_anchor=(1.02,1),frameon=False,fontsize=8,labelspacing=.6)
        interval='5th–95th percentile seasonal ranges' if range_mode else '95% conditional Monte Carlo confidence intervals for means'
        fig.text(.065,.105,f'Bars: means | Whiskers: {interval}',fontsize=8)
        fig.text(.065,.075,'Brackets: E−C, F−J, G−K. '+STARS,fontsize=7.5)
        fig.text(.065,.045,'Tests: approximate normal/Wald tests with whole-season bootstrap standard errors and Holm correction across 270 contrasts.',fontsize=7)
        stem=f'{STEMS[j]}_Top{pct:02d}_{"90range" if range_mode else "95CI"}'
        save(fig,root/'figures/Inference'/mode/f'Top{pct:02d}',stem,metadata,width=250,height=155)
        values['interval_lower']=values[lo];values['interval_upper']=values[hi]
        data.append(figure_record(values,stem,'90% seasonal range' if range_mode else '95% pointwise conditional mean CI'))

def absolute(root,means,tests,metadata,data,pct=10):
    rule=f'topk_{pct:02d}';d=means[(means.rule==rule)&means.model.isin(['G','K'])].copy()
    fig,axes=plt.subplots(1,3,figsize=(183*MM,120*MM),sharey=True)
    fig.subplots_adjust(left=.23,right=.935,bottom=.23,top=.81,wspace=.57)
    y=np.arange(6)
    for j,(ax,metric) in enumerate(zip(axes,METRICS)):
        for row in [0,2,4]:ax.axhspan(row-.48,row+.48,color='#F3F5F6',lw=0)
        for model,offset,marker in [('G',-.12,'o'),('K',.12,'D')]:
            v=d[(d.model==model)&(d.metric==metric)].set_index('storyline').loc[STORIES]
            ax.hlines(y+offset,v.ci95_lower,v.ci95_upper,color=COLOURS[model],linewidth=1.2)
            ax.plot(v['mean'],y+offset,linestyle='none',marker=marker,color=COLOURS[model],markersize=4,
                    markeredgecolor='white',markeredgewidth=.4)
        bounds=d[d.metric==metric];minimum=min(0,float(bounds.ci95_lower.min()));maximum=float(bounds[['mean','ci95_upper']].max().max())
        ax.set_xlim(minimum,maximum*1.1);ax.set_ylim(5.55,-.55)
        ax.set_yticks(y,STORY_LABELS);ax.tick_params(axis='y',pad=6)
        ax.xaxis.set_major_locator(MaxNLocator(nbins=4))
        ax.set_xlabel(UNITS[j]);ax.set_title(TITLES[j],loc='left',pad=12,fontsize=8)
        ax.text(-.015,1.13,chr(97+j),transform=ax.transAxes,fontweight='bold',fontsize=10)
        ax.text(1.08,1.025,'G−K',transform=ax.transAxes,ha='center',fontsize=6.5)
        for i,story in enumerate(STORIES):
            t=gettest(tests,'G-K',rule,story,metric)
            ax.text(1.08,i,t.display_stars,transform=ax.get_yaxis_transform(),ha='center',va='center',fontsize=7)
        ax.grid(axis='x',color='#DEE3E7',linewidth=.45);ax.set_axisbelow(True)
        for name in ['top','right','left']:ax.spines[name].set_visible(False)
    handles=[Line2D([],[],color=COLOURS['G'],marker='o',linestyle='none',label='G: with WP'),
             Line2D([],[],color=COLOURS['K'],marker='D',linestyle='none',label='K: without WP')]
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.60,.985),ncol=2,frameon=False,fontsize=8)
    fig.text(.60,.115,f'Top {pct}% | Points: means | Lines: 95% conditional Monte Carlo CIs',ha='center',fontsize=7)
    fig.text(.60,.078,'G−K symbols: Holm-adjusted across 270 comparisons; ns = not significant',ha='center',fontsize=6.5)
    fig.text(.60,.043,'* p<0.05; ** p<0.01; *** p<0.001. Pointwise CIs and adjusted tests may differ.',ha='center',fontsize=6.5)
    stem=f'Figure_Main_Top{pct:02d}_95CI_significance' if pct==10 else f'Figure_Top{pct:02d}_95CI_significance'
    folder=root/'figures/Inference'/('Main_Top10' if pct==10 else f'Absolute_Top{pct:02d}')
    save(fig,folder,stem,metadata,dpi=600,width=183,height=120,extra600=pct==10)
    data.append(figure_record(d,stem,'95% pointwise conditional mean CI'))

def forest(root,tests,metadata,data):
    d=tests[(tests.comparison=='G-K')&(tests.rule=='topk_10')].copy()
    fig,axes=plt.subplots(1,3,figsize=(183*MM,115*MM),sharey=True)
    fig.subplots_adjust(left=.23,right=.94,bottom=.20,top=.84,wspace=.53);y=np.arange(6)
    for j,(ax,m) in enumerate(zip(axes,METRICS)):
        v=d[d.metric==m].set_index('storyline').loc[STORIES]
        ax.axvline(0,color='#666666',linestyle='--',linewidth=.8)
        ax.hlines(y,v.ci95_lower,v.ci95_upper,color='#0072B2',linewidth=1.3)
        ax.plot(v.mean_difference,y,'o',color='#0072B2',markersize=4)
        for i,story in enumerate(STORIES):ax.text(1.07,i,v.loc[story,'display_stars'],transform=ax.get_yaxis_transform(),ha='center',va='center',fontsize=7)
        ax.set_yticks(y,STORY_LABELS);ax.set_ylim(5.55,-.55)
        ax.set_title(TITLES[j],loc='left',fontsize=8);ax.set_xlabel('G − K ('+('clusters' if m=='clusters' else 'days')+')')
        ax.xaxis.set_major_locator(MaxNLocator(nbins=4));ax.grid(axis='x',color='#eeeeee')
        for n in ['top','right','left']:ax.spines[n].set_visible(False)
    fig.suptitle('Top 10%: paired effect of adding WP',fontsize=10,y=.98)
    fig.text(.60,.095,'Points: paired mean differences | Lines: 95% pointwise conditional Monte Carlo CIs',ha='center',fontsize=6.5)
    fig.text(.60,.055,STARS,ha='center',fontsize=6.5)
    stem='Figure_Paired_G_minus_K_Top10_95CI'
    save(fig,root/'figures/Inference/Paired_differences',stem,metadata,width=183,height=115)
    data.append(figure_record(d,stem,'95% pointwise conditional paired-difference CI'))

def heatmaps(root,tests,metadata,data):
    fig,axes=plt.subplots(3,3,figsize=(183*MM,220*MM))
    fig.subplots_adjust(left=.235,right=.985,top=.93,bottom=.16,wspace=.23,hspace=.40)
    bounds={m:max(.01,float(tests[tests.metric==m].mean_difference.abs().max())) for m in METRICS};images={}
    for row,pair in enumerate(PAIRS):
      for col,m in enumerate(METRICS):
        ax=axes[row,col];v=tests[(tests.comparison==pair)&(tests.metric==m)]
        a=v.pivot(index='storyline',columns='rule',values='mean_difference').loc[STORIES,RULES]
        st=v.pivot(index='storyline',columns='rule',values='display_stars').loc[STORIES,RULES]
        im=ax.imshow(a,cmap='RdBu_r',norm=TwoSlopeNorm(vmin=-bounds[m],vcenter=0,vmax=bounds[m]),aspect='auto');images[m]=im
        for iy in range(6):
          for ix in range(5):
            value=a.iloc[iy,ix];colour='white' if abs(value)>.6*bounds[m] else '#111111'
            ax.text(ix,iy-.13,f'{value:+.2f}',ha='center',va='center',color=colour,fontsize=6.5)
            ax.text(ix,iy+.22,st.iloc[iy,ix],ha='center',va='center',color=colour,fontsize=5.8)
        ax.set_xticks(range(5),['1','5','10','25','50']);ax.tick_params(length=0,pad=4)
        ax.set_yticks(range(6),STORY_LABELS if col==0 else ['']*6)
        if row==0:ax.set_title(TITLES[col],fontsize=8.5,pad=15)
        if row==2:ax.set_xlabel('Selected fraction (%)',fontsize=7)
        ax.text(-.02,1.06,chr(97+row*3+col),transform=ax.transAxes,fontweight='bold',fontsize=9)
        for spine in ax.spines.values():spine.set_visible(False)
      pos=axes[row,0].get_position();fig.text(.027,(pos.y0+pos.y1)/2,pair.replace('-',' − '),rotation=90,fontweight='bold',fontsize=9,va='center',ha='center')
    for col,m in enumerate(METRICS):
        pos=axes[2,col].get_position();cax=fig.add_axes([pos.x0,.09,pos.width,.012]);cb=fig.colorbar(images[m],cax=cax,orientation='horizontal')
        cb.ax.tick_params(labelsize=6.5,length=2);cb.set_label('Mean difference ('+('clusters' if m=='clusters' else 'days')+')',fontsize=6.5)
    fig.text(.60,.04,STARS,ha='center',fontsize=6.5)
    stem='Figure_Paired_budget_sensitivity_significance'
    save(fig,root/'figures/Inference/Heatmaps',stem,metadata,width=183,height=220)
    data.append(figure_record(tests,stem,'Paired effects and Holm-adjusted tests'))
    for rule in RULES:
        pct=int(rule[-2:]);d=tests[tests.rule==rule].copy()
        fig,axes=plt.subplots(1,3,figsize=(220*MM,135*MM))
        fig.subplots_adjust(left=.22,right=.98,bottom=.24,top=.85,wspace=.40)
        for j,(ax,m) in enumerate(zip(axes,METRICS)):
            v=d[d.metric==m];a=v.pivot(index='storyline',columns='comparison',values='mean_difference').loc[STORIES,PAIRS]
            st=v.pivot(index='storyline',columns='comparison',values='display_stars').loc[STORIES,PAIRS]
            im=ax.imshow(a,cmap='RdBu_r',vmin=-bounds[m],vmax=bounds[m],aspect='auto')
            for iy in range(6):
              for ix in range(3):
                value=a.iloc[iy,ix];colour='white' if abs(value)>.6*bounds[m] else '#111111'
                ax.text(ix,iy-.13,f'{value:+.2f}',ha='center',va='center',color=colour,fontsize=8)
                ax.text(ix,iy+.23,st.iloc[iy,ix],ha='center',va='center',color=colour,fontsize=6.5)
            ax.set_xticks(range(3),['E−C','F−J','G−K']);ax.set_yticks(range(6),STORY_LABELS if j==0 else ['']*6)
            ax.set_title(TITLES[j],fontsize=9);fig.colorbar(im,ax=ax,orientation='horizontal',fraction=.04,pad=.13)
        fig.suptitle(f'Top {pct}%: paired changes after adding WP',fontsize=11)
        fig.text(.60,.10,STARS,ha='center',fontsize=7)
        fig.text(.60,.055,'Colours show effect size; symbols show adjusted tests.',ha='center',fontsize=7)
        stem=f'Heatmaps_Top{pct:02d}_significance'
        save(fig,root/'figures/Inference/Heatmaps'/f'Top{pct:02d}',stem,metadata,width=220,height=135)
        data.append(figure_record(d,stem,'Paired effects and Holm-adjusted tests'))

def make_inference_figures(root=ROOT):
    root=Path(root);_configure();means,tests=load(root);metadata=[];data=[]
    for mode in [False,True]:bars(root,means,tests,metadata,data,mode)
    _configure()
    for pct in [1,5,10,25,50]:absolute(root,means,tests,metadata,data,pct)
    forest(root,tests,metadata,data);heatmaps(root,tests,metadata,data)
    folder=root/'figures/Inference';folder.mkdir(exist_ok=True)
    pd.concat(data,ignore_index=True).to_csv(folder/'FIGURE_DATA.csv',index=False)
    for item in metadata:
        item['files']=[str(Path(p).relative_to(root)) if Path(p).is_absolute() else str(p) for p in item['files']]
    report={'figures':metadata,'figure_count':len(metadata),'mean_source':'results/inference/mean_confidence_intervals.csv',
        'test_source':'results/inference/paired_tests.csv','multiplicity':'Holm across 270 unique displayed comparisons',
        'tests':'Approximate normal/Wald tests with bootstrap standard errors after whole-season resampling and pooled Top-k re-selection',
        'confidence_intervals':'95% pointwise conditional Monte Carlo CIs, excluding model-fitting and generator uncertainty',
        'stars':STARS,'scope':SCOPE,'model_fitting':False}
    (folder/'figure_metadata.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    captions='''CONDITIONAL INFERENCE FIGURES

Grouped_bars_95CI: Bars show mean seasonal selected days, clusters or maximum run length for A-K. Whiskers show 95% pointwise conditional Monte Carlo confidence intervals for the means. Brackets compare E-C, F-J and G-K on matched simulated seasons. Symbols use Holm-adjusted p-values across all 270 unique comparisons.

Grouped_bars_90ranges: The same bars and statistical annotations, but whiskers show 5th-95th percentile ranges across simulated seasons. These are seasonal variability ranges, not confidence intervals. These versions are retained to reproduce the earlier graphical convention without relabelling uncertainty.

Main_Top10 and Absolute_TopXX: Full hydrometeorological models with WP (G) and without WP (K), with identical numerical predictor sets. Points are seasonal means; lines are 95% pointwise conditional Monte Carlo confidence intervals. G-K symbols refer to the paired model-difference test, not overlap between marginal confidence intervals.

Paired_differences: G minus K mean differences at Top10, with 95% pointwise conditional Monte Carlo confidence intervals. The zero line indicates no mean difference. The corresponding multiplicity-adjusted symbols may disagree with exclusion of zero by a pointwise confidence interval because adjustment covers 270 contrasts.

Heatmaps: Cells show mean differences after adding WP; symbols are the same adjusted tests used on the grouped bars. Colour intensity describes effect magnitude, not significance. ns means not significant after Holm adjustment, not proof of equivalence.

For every figure: * adjusted p<0.05; ** p<0.01; *** p<0.001. A dagger (†) marks a bootstrap diagnostic flag for the normal approximation; consult the sensitivity table before interpreting those tests. The dagger is not an additional significance level. Tests are approximate normal/Wald tests using whole-simulation-bundle bootstrap standard errors, with pooled Top-k selection repeated in every replicate. Intervals and tests are conditional on the fixed fitted models, calibrators, weather generator and donor library. They do not propagate model-fitting or generator-parameter uncertainty or establish improved real-world warnings.
'''
    (folder/'CAPTIONS_AND_INTERVAL_DEFINITIONS.txt').write_text(captions,encoding='utf-8')
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=ROOT)
    print(json.dumps(make_inference_figures(p.parse_args().root),indent=2))
