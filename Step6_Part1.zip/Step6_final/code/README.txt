STEP 6 IMPLEMENTATION

Use the commands in ../README.txt. The full numerical entry point is ../rerun_step6_analysis.py. The main sequence uses analysis_step6.py for seasonal outcomes and equal-count selection, inference_step6.py and weighted_topk_bootstrap.py for conditional inference, publication_diagnostics.py for checks on the saved bootstrap estimates, and storyline_inference.py for the separate 190 storyline comparisons. The 270 model comparisons and 190 storyline comparisons each have their own Holm correction.

The shorter ../run_step6.py refreshes the storyline analysis from saved results. The plotting, reporting and verification modules use the outputs of the corresponding numerical stages. See ../START_HERE.html for the publication figures and ../reports/ for current results and checks.
