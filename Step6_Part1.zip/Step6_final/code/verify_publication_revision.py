"""Independent checks of publication exports against immutable saved results.

This module reads saved tables and figure exports only. It does not fit models,
generate weather, or draw new bootstrap samples. Statistical coverage is not
established by successful arithmetic or export checks.
"""
from pathlib import Path
import argparse, csv, datetime, hashlib, json
import xml.etree.ElementTree as ET
import numpy as np
import pandas as pd
from PIL import Image
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parent.parent
KEY=['model','rule','storyline','metric']
TKEY=['comparison','rule','storyline','metric']
STORIES={'baseline','persistent_wet','persistent_dry','dry_with_bursts','flip_wet_to_dry','flip_dry_to_wet'}
METRICS={'selected_days','clusters','max_run_days'}

def _read(path):
    return pd.read_csv(path,float_precision='round_trip')

def _equal(a,b):
    return bool(np.allclose(np.asarray(a,dtype=float),np.asarray(b,dtype=float),rtol=1e-11,atol=1e-12,equal_nan=True))

def _table_check(plot,source,keys,numeric,text=()):
    if plot.duplicated(keys).any():raise AssertionError('Repeated plotted source key')
    merged=plot.merge(source,on=keys,validate='one_to_one',suffixes=('_plot','_saved'))
    if len(merged)!=len(plot):raise AssertionError('Missing saved source row')
    for name in numeric:
        if not _equal(merged[name+'_plot'],merged[name+'_saved']):raise AssertionError('Plotted value disagrees with saved '+name)
    for name in text:
        if not np.array_equal(merged[name+'_plot'].astype(str),merged[name+'_saved'].astype(str)):
            raise AssertionError('Plotted annotation disagrees with saved '+name)
    return merged

def verify(root=ROOT):
    root=Path(root).resolve();checks=[]
    def check(name,ok,detail):
        if not bool(ok):raise AssertionError(name+': '+detail)
        checks.append(dict(name=name,passed=True,detail=detail))
    baseline=root/'inputs/provenance/PUBLICATION_SCIENTIFIC_BASELINE.csv'
    rows=list(csv.DictReader(baseline.open(encoding='utf-8')))
    check('scientific_input_baseline',len(rows)>0 and all((root/r['path']).is_file() and
          hashlib.sha256((root/r['path']).read_bytes()).hexdigest()==r['sha256'] for r in rows),
          f'All {len(rows)} recorded upstream inputs and original scientific result files retain their exact bytes.')
    config=json.loads((root/'config.json').read_text())
    check('publication_budget',config['primary_budget']==.1 and config['publication_main_budget']==.1,
          'The current primary/publication presentation is unambiguously Top 10%.')
    check('five_budget_sensitivity',set(config['pooled_budgets'])=={.01,.05,.1,.25,.5},
          'All five requested pooled selection fractions remain available.')
    means=_read(root/'results/inference/mean_confidence_intervals.csv')
    tests=_read(root/'results/inference/paired_tests.csv')
    matched=_read(root/'results/matched_count_paired_differences.csv')
    diagnostic=_read(root/'results/publication_revision/flagged_interval_diagnostics.csv')
    metadata=json.loads((root/'figures/publication_revision_metadata.json').read_text())
    items=metadata['figures']
    check('publication_figure_coverage',len(items)==3,'Main six-panel figure, matched-count figure and flagged-interval diagnostic figure are declared.')
    seen=set();export_count=0
    for item in items:
        stem=item['stem'];kind=item.get('kind','')
        if not kind:
            kind='matched' if 'Matched' in stem else ('diagnostic' if 'Flagged' in stem else 'main')
        seen.add(kind)
        files=[root/p for p in item['files']]
        check('exports_'+kind,all(p.is_file() and p.stat().st_size>1000 for p in files) and
              {'.png','.pdf','.svg'}.issubset({p.suffix for p in files}),
              'PNG, PDF and SVG files exist for '+stem+'.')
        for path in files:
            export_count+=1
            if path.suffix=='.png':
                with Image.open(path) as im:
                    dpi=im.info.get('dpi',(0,0))
                    if not _equal(np.asarray(dpi).round(1),[600.,600.]):raise AssertionError('PNG must be 600 dpi')
                    expected=np.array([item['width_mm'],item['height_mm']])/25.4*600
                    if not np.all(np.abs(np.array(im.size)-expected)<=2):raise AssertionError('PNG dimensions disagree with intended publication size')
            elif path.suffix=='.svg':
                xml=ET.parse(path)
                if not xml.findall('.//{http://www.w3.org/2000/svg}text'):raise AssertionError('SVG does not contain editable text')
            elif path.suffix=='.pdf':
                reader=PdfReader(path)
                if len(reader.pages)!=1:raise AssertionError('Expected a single-page scientific figure')
                page=reader.pages[0]
                if not (page.extract_text() or '').strip():raise AssertionError('PDF has no extractable text')
                dims=np.array([float(page.mediabox.width),float(page.mediabox.height)])/72*25.4
                if not _equal(dims,[item['width_mm'],item['height_mm']]):raise AssertionError('PDF physical dimensions disagree with metadata')
                if 'Conditional on fitted models and weather generator; not operational validation' in (page.extract_text() or ''):
                    raise AssertionError('Removed graphic disclaimer remains on the figure')
        check('format_quality_'+kind,True,'600-dpi PNG physical size and text-bearing vector PDF/SVG exports verified.')
        frame=_read(root/item['source_csv'])
        if kind=='main':
            m=frame[frame.record_type.eq('mean')].copy();t=frame[frame.record_type.eq('paired')].copy()
            check('main_mean_coverage',len(m)==36 and set(m.model)=={'G','K'} and set(m.storyline)==STORIES and set(m.metric)==METRICS and set(m.rule)=={'topk_10'},
                  'All 36 G/K mean records cover six scenarios and three outcomes at Top 10%.')
            _table_check(m,means,KEY,['mean','ci95_lower','ci95_upper'])
            check('main_mean_values',True,'Every left-panel mean and confidence endpoint matches the saved authoritative mean table.')
            check('main_paired_coverage',len(t)==18 and set(t.comparison)=={'G-K'} and set(t.storyline)==STORIES and set(t.metric)==METRICS and set(t.rule)=={'topk_10'},
                  'All 18 paired G-K records cover the same scenarios and outcomes.')
            _table_check(t,tests,TKEY,['mean_difference','ci95_lower','ci95_upper'],['stars'])
            check('main_paired_values_and_stars',True,'Every right-panel difference, confidence endpoint and adjusted significance symbol matches the saved paired table.')
        elif kind=='matched':
            check('matched_plot_coverage',len(frame)==24 and set(frame.comparison)=={'G-K'} and set(frame.rule)=={'matched_05','matched_10'} and set(frame.metric)=={'clusters','max_run_days'} and set(frame.storyline)==STORIES,
                  'All 24 fixed-count comparisons cover two counts, six scenarios and two temporal-organisation outcomes.')
            _table_check(frame,matched,TKEY,['mean_difference','mc95_lower','mc95_upper'])
            check('matched_plot_values',True,'All paired means and pointwise Monte Carlo endpoints exactly match existing equal-count results.')
            check('matched_plot_count_labels',set(frame.selected_days_per_season)=={8,16} and
                  _equal(frame.actual_fraction_percent,frame.selected_days_per_season/153*100),
                  'Eight/sixteen selected-day labels and actual 5.23%/10.46% seasonal fractions are correct.')
            # CSS uses '*' as a wildcard; only visible text can be a significance annotation.
            svgtxt=' '.join(''.join(node.itertext()) for p in files if p.suffix=='.svg'
                           for node in ET.parse(p).findall('.//{http://www.w3.org/2000/svg}text'))
            check('matched_no_new_significance', '*' not in svgtxt,
                  'No significance stars were added to the matched-count graphic.')
        elif kind=='diagnostic':
            check('diagnostic_plot_coverage',len(frame)==len(diagnostic) and set(map(tuple,frame[TKEY].to_numpy()))==set(map(tuple,diagnostic[TKEY].to_numpy())) and frame.normal_approximation_flag.all(),
                  'The diagnostic plot covers all and only the contrasts flagged in the verified table.')
            _table_check(frame,diagnostic,TKEY,['mean_difference','ci95_lower','ci95_upper','percentile95_lower','percentile95_upper','bias_over_se','bootstrap_skewness'],['stars'])
            check('diagnostic_plot_values',True,'Normal/percentile intervals, mean effects, bias/skew diagnostics and saved test symbols match the verified diagnostic table.')
            transforms=[('normal_standardised_lower','ci95_lower'),('normal_standardised_upper','ci95_upper'),
                        ('percentile_standardised_lower','percentile95_lower'),('percentile_standardised_upper','percentile95_upper')]
            check('diagnostic_standardised_intervals',all(_equal(frame[derived],
                  (frame[original]-frame.mean_difference)/frame.bootstrap_se) for derived,original in transforms),
                  'All four standardised interval-shape coordinates equal (endpoint minus original effect) divided by the saved bootstrap SE; their zero is the original estimate, not the null.')
        else:raise AssertionError('Unknown publication figure kind: '+kind)
    check('three_presentation_roles',seen=={'main','matched','diagnostic'},'All three intended publication presentation roles are present.')
    mc=json.loads((root/'results/publication_revision/MATCHED_COUNT_VERIFICATION.json').read_text())
    check('matched_audit_evidence',mc['status']=='passed' and mc['checks_passed']==11 and mc['new_pvalues'] is False and mc['new_resampling'] is False,
          'Existing equal-count data passed the separately executed 11-check audit; no new p-values or resampling were introduced.')
    dg=json.loads((root/'results/publication_revision/DIAGNOSTIC_REVIEW.json').read_text())
    check('diagnostic_audit_evidence',dg['status']=='passed' and dg['paired_contrasts_verified']==270 and dg['new_bootstrap_draws']==0,
          'All 270 saved paired bootstrap distributions were checked without new bootstrap draws.')
    report=dict(status='passed',UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),checks_passed=len(checks),checks=checks,
                exports_checked=export_count,scientific_baseline_files=len(rows),models_refitted=False,probabilities_recalibrated=False,
                weather_regenerated=False,new_bootstrap_draws=0,
                scope='Current-run arithmetic, data-source and export consistency checks only. They do not establish nominal statistical coverage, operational forecast validity or journal acceptance. Existing full-size bootstrap validation evidence is inherited unless separately rerun.')
    target=root/'results/publication_revision/VERIFICATION.json';target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({'status':'passed','checks_passed':len(checks)},indent=2));return report

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=ROOT)
    verify(p.parse_args().root)
