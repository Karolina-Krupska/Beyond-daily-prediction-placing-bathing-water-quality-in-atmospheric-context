"""Publication figures for saved within-model storyline contrasts.

This module consumes result tables. It does not calculate p-values, confidence
intervals, predictions or simulations. Run after storyline_inference.py.
"""
from pathlib import Path
import argparse
import json
import math
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

ROOT = Path(__file__).resolve().parent.parent
MM = 1 / 25.4
STORIES = ['persistent_wet', 'flip_wet_to_dry', 'dry_with_bursts',
           'persistent_dry', 'flip_dry_to_wet']
LABELS = {'persistent_wet': 'Persistent wet',
          'flip_wet_to_dry': 'Wet to dry',
          'dry_with_bursts': 'Dry with storm\noutbreaks',
          'persistent_dry': 'Persistent dry',
          'flip_dry_to_wet': 'Dry to wet'}
METRICS = ['selected_days', 'clusters', 'max_run_days']
TITLES = {'selected_days': 'Model-selected days',
          'clusters': 'Selected-day clusters',
          'max_run_days': 'Maximum run length'}
SHORT = {'selected_days': 'days', 'clusters': 'clusters', 'max_run_days': 'maximum run'}
COLOURS = {'G': '#397C98', 'K': '#5C857B'}
INK = '#233C4B'


def configure():
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 8,
                         'axes.labelsize': 8, 'axes.titlesize': 8.5,
                         'xtick.labelsize': 8, 'ytick.labelsize': 8,
                         'axes.spines.top': False, 'axes.spines.right': False,
                         'svg.fonttype': 'none', 'pdf.fonttype': 42,
                         'ps.fonttype': 42, 'text.color': INK,
                         'axes.labelcolor': INK, 'xtick.color': INK,
                         'ytick.color': INK})


def truth(value):
    if pd.isna(value):
        return False
    if isinstance(value, str):
        return value.strip().lower() in ('true', '1', 'yes')
    return bool(value)


def annotation(row):
    stars = str(row.get('stars', 'NE'))
    caution = truth(row.get('diagnostic_caution', False))
    return stars + ('†' if caution else '')


def clean_json(value):
    """Convert pandas/numpy records to strict JSON with null for unavailable."""
    if isinstance(value, dict):
        return {str(k): clean_json(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean_json(v) for v in value]
    if isinstance(value, np.generic):
        return clean_json(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def save(root, fig, stem, kind, source, caption, width=180, height=100):
    path = root / stem
    path.parent.mkdir(parents=True, exist_ok=True)
    # Locator algorithms may retain tick-label artists outside the view limits.
    # Make the publication ticks explicit and in-range before applying the
    # unchanged full-figure text-boundary check.
    for a in fig.axes:
        lo, hi = sorted(a.get_xlim())
        ticks = np.asarray(a.get_xticks(), dtype=float)
        a.set_xticks(ticks[(ticks >= lo) & (ticks <= hi)])
    fig.canvas.draw()
    # Check all axes and figure text against the export boundary before saving.
    renderer = fig.canvas.get_renderer()
    outside = []
    for t in fig.findobj(matplotlib.text.Text):
        if not t.get_visible() or not t.get_text():
            continue
        b = t.get_window_extent(renderer)
        if (b.x0 < -.5 or b.y0 < -.5 or b.x1 > fig.bbox.width + .5
                or b.y1 > fig.bbox.height + .5):
            outside.append(t.get_text())
    if outside:
        raise ValueError('Text outside figure bounds: ' + repr(outside))
    files = []
    for ext in ['png', 'pdf', 'svg']:
        f = path.with_suffix('.' + ext)
        fig.savefig(f, dpi=600, facecolor='white')
        files.append(f.relative_to(root).as_posix())
    # A moderate-size preview is only for QA; the publication PNG remains 600 dpi.
    preview = root / 'results/storyline_inference/figure_previews' / (path.name + '.png')
    preview.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(preview, dpi=150, facecolor='white')
    source_path = path.with_name(path.name + '_source.csv')
    source.to_csv(source_path, index=False, float_format='%.17g')
    cap_path = path.with_name(path.name + '_caption.txt')
    cap_path.write_text(caption.rstrip() + '\n', encoding='utf-8')
    plt.close(fig)
    record = {'kind': kind, 'stem': path.relative_to(root).as_posix(),
              'files': files, 'source_csv': source_path.relative_to(root).as_posix(),
              'caption': cap_path.relative_to(root).as_posix(),
              'preview': preview.relative_to(root).as_posix(),
              'width_mm': width, 'height_mm': height, 'png_dpi': 600,
              'font_minimum_pt': 8, 'plotted_rows': clean_json(source.to_dict('records'))}
    return record


def style(ax):
    for row in [0, 2, 4]:
        ax.axhspan(row - .47, row + .47, color='#F1F4F5', lw=0, zorder=0)
    ax.axvline(0, color='#77858D', ls=(0, (3, 2)), lw=.8, zorder=1)
    ax.set_ylim(4.65, -.65)
    ax.set_yticks(np.arange(5))
    ax.grid(axis='x', color='#DEE5E8', lw=.55)
    ax.set_axisbelow(True)
    ax.spines['left'].set_visible(False)
    ax.spines['bottom'].set_color('#8C9BA4')
    ax.tick_params(axis='y', length=0, pad=6)
    ax.xaxis.set_major_locator(MaxNLocator(nbins=3, min_n_ticks=3))


def check_subset(table, model, rule, metrics):
    part = table[table.model.eq(model) & table.rule.eq(rule)
                 & table.metric.isin(metrics)].copy()
    assert len(part) == 5 * len(metrics), (model, rule, len(part))
    assert not part.duplicated(['storyline', 'metric']).any()
    assert set(part.storyline) == set(STORIES)
    return part


def contrast_plot(root, table, model, rule, matched=False):
    metrics = ['clusters', 'max_run_days'] if matched else METRICS
    part = check_subset(table, model, rule, metrics)
    count = 8 if rule == 'matched_05' else 16
    top = int(rule.split('_')[1])
    is_main = model == 'G' and rule in ['topk_10', 'matched_10']
    destination = 'Main' if is_main else 'Supplement'
    folder = Path('figures/Storyline_comparisons') / destination
    if matched:
        stem = folder / f'Figure_{model}_Matched{count:02d}_Storyline_minus_baseline'
        title = f'{model}: storyline minus baseline | Exactly {count} selected days'
    else:
        stem = folder / f'Figure_{model}_Top{top:02d}_Storyline_minus_baseline'
        title = f'{model}: storyline minus baseline | Pooled Top {top}%'
    n = len(metrics)
    fig, axes = plt.subplots(1, n, figsize=(180 * MM, 102 * MM), sharey=True,
                             squeeze=False)
    axes = axes[0]
    fig.subplots_adjust(left=.25, right=.945, top=.77, bottom=.23,
                        wspace=.47 if n == 3 else .30)
    y = np.arange(5)
    plotted = []
    for j, (ax, metric) in enumerate(zip(axes, metrics)):
        v = part[part.metric.eq(metric)].set_index('storyline').loc[STORIES].copy()
        style(ax)
        finite = np.isfinite(v[['mean_difference', 'ci95_lower', 'ci95_upper']]).all(axis=1)
        ax.hlines(y[finite], v.loc[finite, 'ci95_lower'], v.loc[finite, 'ci95_upper'],
                  color=COLOURS[model], lw=1.3, zorder=3)
        ax.plot(v.mean_difference, y, 'o', color=COLOURS[model], ms=4.2,
                mec='white', mew=.35, zorder=4)
        # Match G/K axis limits for a given rule and outcome, avoiding a change
        # in apparent effect size between the primary and supporting figures.
        domain = table[table.rule.eq(rule) & table.metric.eq(metric)
                       & table.model.isin(['G', 'K'])]
        valid = np.r_[domain.ci95_lower[np.isfinite(domain.ci95_lower)],
                      domain.ci95_upper[np.isfinite(domain.ci95_upper)],
                      domain.mean_difference[np.isfinite(domain.mean_difference)], 0]
        lo, hi = float(valid.min()), float(valid.max())
        pad = max((hi - lo) * .12, .015)
        ax.set_xlim(lo - pad, hi + pad)
        if j == 0:
            ax.set_yticklabels([LABELS[s] for s in STORIES])
        else:
            ax.tick_params(axis='y', labelleft=False)
        ax.set_xlabel('Difference (' + ('clusters' if metric == 'clusters' else 'days') + ')',
                      labelpad=6)
        ax.set_title(TITLES[metric], loc='left', pad=11, fontsize=8.4)
        # Letters sit in a separate band above the panel titles.
        pos = ax.get_position()
        fig.text(pos.x0, .89, chr(97 + j), fontsize=10.5, fontweight='bold')
        for i, story in enumerate(STORIES):
            r = v.loc[story]
            annot = annotation(r)
            ax.text(1.055, i, annot, transform=ax.get_yaxis_transform(),
                    ha='left', va='center', fontsize=8, clip_on=False)
            rec = r.to_dict()
            rec.update({'storyline': story, 'panel': chr(97 + j),
                        'plot_y': i, 'plotted_annotation': annot,
                        'plotted_point': r['mean_difference'],
                        'plotted_lower': r['ci95_lower'], 'plotted_upper': r['ci95_upper']})
            plotted.append(rec)
    fig.text(.25, .967, title, fontsize=9.4, fontweight='bold', ha='left')
    fig.text(.055, .095, 'Points: mean differences | Lines: pointwise 95% confidence intervals', fontsize=8)
    fig.text(.055, .038, 'Holm-adjusted: * p < 0.05; ** < 0.01; *** < 0.001; ns: not significant; † diagnostic flag', fontsize=8)
    source = pd.DataFrame(plotted)
    primary = 'full hydrometeorological model with WP' if model == 'G' else 'same numerical predictors without WP'
    if matched:
        actual = count / 153 * 100
        details = (
            f'Each model season contains exactly {count} selected days ({actual:.4f}% of 153 days). '
            'This is a within-model comparison between atmospheric storylines, not G−K, '
            'and differs from pooled Top-k selection. For each altered storyline, the outcome '
            'is paired with baseline through the existing simulation identifier. Lines show '
            'mean ±1.96×SD of the 5,000 paired seasonal differences/√5,000. These are '
            'normal-approximation conditional Monte Carlo intervals, not bootstrap intervals. '
            'Selected-day differences are zero by construction and are not tested. ')
    else:
        details = (
            f'The Top {top}% budget is pooled across six ensembles, each containing 5,000 '
            '153-day seasons, separately for each model. It is not a fixed probability '
            'threshold or a fixed fraction within each season or storyline. Pointwise '
            'normal-approximation intervals use the original contrast ±1.96 times the '
            'standard deviation of the 4,000 saved paired contrast draws. Altered-storyline '
            'and baseline means are subtracted within each matching saved bootstrap '
            'replicate, preserving whole-season bundle resampling, covariance and repeated '
            'pooled selection. No new bootstrap draws were generated. ')
    caption = (
        f'Figure. Within-model storyline-minus-baseline contrasts for model {model} '
        f'({primary}). Panels show ' + ', '.join(f'{TITLES[m].lower()} ({chr(97+i)})' for i,m in enumerate(metrics)) + '. '
        'Positive differences indicate more selected days, more clusters or longer maximum runs; '
        'negative differences indicate fewer or shorter outcomes. Dashed lines denote zero '
        'difference. Points show original mean differences. ' + details +
        'The displayed symbols use approximate two-sided normal/Wald tests adjusted by Holm '
        'across the single family of 190 new within-model storyline contrasts. This family is '
        'separate from the 270 existing with-WP versus without-WP comparisons. Pointwise '
        'confidence intervals are not simultaneous intervals, and their exclusion of zero '
        'does not by itself establish Holm-adjusted significance. † identifies a retained '
        'diagnostic caution; inspect the supplied interval diagnostics. These comparisons '
        'are retrospective additions following review of existing outputs. All uncertainty '
        'is conditional on fixed fitted models, calibrators, historical inputs and weather '
        'generator. Common-random-number coupling is numerical coupling, not causal '
        'observational pairing. Model-selected days are not observed contamination episodes '
        'or issued warnings. The storyline design may alter frequencies and sequencing '
        'together; these results do not isolate a causal persistence effect.')
    return save(root, fig, stem, 'matched_storyline' if matched else 'pooled_storyline',
                source, caption, 180, 102)


def diagnostic_plots(root, table):
    flags = table[table.normal_approximation_flag.map(truth)].copy()
    flags = flags.sort_values(['model', 'rule', 'metric', 'storyline']).reset_index(drop=True)
    results = []
    if not len(flags):
        folder = root/'figures/Storyline_comparisons/Supplement/Diagnostics'
        folder.mkdir(parents=True, exist_ok=True)
        (folder/'NO_FLAGGED_POOLED_CONTRASTS.txt').write_text(
            'No new pooled storyline contrasts cross the retained bias/SE or skewness thresholds.\n'
            'This does not establish correct interval coverage. See the full diagnostic table.\n')
        return results
    # Standardisation permits an uncluttered comparison across mixed outcome units.
    for i in range(0, len(flags), 18):
        part = flags.iloc[i:i+18].copy()
        n = len(part)
        for source, dest in [('ci95_lower', 'normal_standardised_lower'),
                             ('ci95_upper', 'normal_standardised_upper'),
                             ('percentile95_lower', 'percentile_standardised_lower'),
                             ('percentile95_upper', 'percentile_standardised_upper')]:
            part[dest] = (part[source]-part.mean_difference)/part.standard_error
        height = max(120, 37 + 7.5*n)
        fig, ax = plt.subplots(figsize=(180*MM, height*MM))
        fig.subplots_adjust(left=.55, right=.96, top=.83, bottom=.20)
        y = np.arange(n)
        for k in range(0,n,2): ax.axhspan(k-.48,k+.48,color='#F1F4F5',lw=0)
        for lo, hi, offset, colour, label in [
            ('normal_standardised_lower','normal_standardised_upper',-.13,'#788B95','Normal'),
            ('percentile_standardised_lower','percentile_standardised_upper',.13,'#397C98','Percentile')]:
            ax.hlines(y+offset,part[lo],part[hi],color=colour,lw=1.3,label=label)
        ax.axvline(0,color='#7C8D96',ls='--',lw=.7)
        labs=[f"{r.model} | {int(r.rule[-2:])}% | {LABELS[r.storyline].replace(chr(10),' ')} | {SHORT[r.metric]}"
              for r in part.itertuples()]
        ax.set_yticks(y,labs,fontsize=8)
        ax.set_ylim(n-.6,-.6)
        ax.tick_params(axis='y',length=0,pad=7)
        ax.spines['left'].set_visible(False)
        ax.grid(axis='x',color='#DEE5E8',lw=.5)
        ax.set_axisbelow(True)
        ax.set_xlabel('(Interval endpoint − estimate) / standard error',fontsize=8,labelpad=7)
        ax.legend(loc='upper center',bbox_to_anchor=(.5,1.12),ncol=2,frameon=False,fontsize=8)
        fig.text(.05,.965,'Flagged storyline contrasts: interval sensitivity',fontsize=10,fontweight='bold')
        fig.text(.05,.10,'Normal and percentile pointwise 95% intervals; no new test in this display.',fontsize=8)
        fig.text(.05,.045,'Dashed zero: original estimate, not a null difference. See original-unit source table.',fontsize=8)
        part['display_scale']='(interval endpoint − original estimate) / standard error'
        caption=(
            'Figure S. Normal and percentile pointwise 95% intervals for new pooled storyline '
            'contrasts crossing |bootstrap bias|/SE >0.25 or |bootstrap skewness| >0.5. '
            'Endpoints are centred on each original estimate and divided by its bootstrap '
            'standard error so different outcome units can share an axis. The dashed zero '
            'line represents the original estimate, not a null difference; this normalised '
            'display cannot determine statistical significance. Original-unit estimates, '
            'endpoints, zero-inclusion diagnostics, approximate p-values and Holm-adjusted '
            'results are retained in the source table. Neither agreement nor disagreement '
            'between interval methods automatically resolves coverage or validates a '
            'preferred significance result. Saved bootstrap draws only; no refitting or '
            'new resampling. All intervals condition on the fitted simulation system.')
        stem=Path('figures/Storyline_comparisons/Supplement/Diagnostics')/f'Figure_Interval_sensitivity_{i//18+1:02d}'
        results.append(save(root,fig,stem,'diagnostic',part,caption,180,height))
    return results


def run(root=ROOT):
    root = Path(root)
    configure()
    folder = root/'results/storyline_inference'
    pooled = pd.read_csv(folder/'pooled_contrasts.csv',float_precision='round_trip')
    matched = pd.read_csv(folder/'matched_contrasts.csv',float_precision='round_trip')
    figures=[]
    for model in ['G','K']:
        for percent in [1,5,10,25,50]:
            figures.append(contrast_plot(root,pooled,model,f'topk_{percent:02d}'))
        for rule in ['matched_05','matched_10']:
            figures.append(contrast_plot(root,matched,model,rule,matched=True))
    figures.extend(diagnostic_plots(root,pooled))
    manifest={'figure_count':len(figures),'figures':figures,
              'source_tables':['results/storyline_inference/pooled_contrasts.csv',
                               'results/storyline_inference/matched_contrasts.csv'],
              'source_only':True,'p_values_or_intervals_calculated_here':False,
              'palette':COLOURS,'primary_model':'G','primary_fraction':.1,
              'primary_matched_count':16,'new_holm_family_size':190,
              'minimum_font_pt':8,'vector_text':True}
    (folder/'FIGURE_MANIFEST.json').write_text(json.dumps(clean_json(manifest),indent=2),encoding='utf-8')
    print(f'Exported {len(figures)} storyline figure sets as PDF/SVG and 600 dpi PNG.')
    return manifest


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=ROOT)
    args=parser.parse_args()
    run(args.root)
