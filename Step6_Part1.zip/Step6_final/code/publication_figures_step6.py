"""Main Top-10% publication figure, supplements and earlier-style comparisons.

This is a presentation layer over saved tables. It never fits or reselects.
"""
from pathlib import Path
import argparse,json,shutil,hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator
from figures_step6 import STORIES,STORY_LABELS,METRICS,COLOURS,MM,_configure,make_percentage_figures

ROOT=Path(__file__).resolve().parent.parent

def make_main(root):
    root=Path(root);folder=root/'figures/Main_publication';folder.mkdir(parents=True,exist_ok=True)
    _configure()
    s=pd.read_csv(root/'results/seasonal_summary.csv',float_precision='round_trip')
    d=s[(s.rule=='topk_10') & s.model.isin(['G','K']) & s.metric.isin(METRICS)].copy()
    if len(d)!=36 or d.duplicated(['model','storyline','metric']).any():raise ValueError('Main-figure coverage conflict')
    fig,axes=plt.subplots(1,3,figsize=(183*MM,115*MM),sharey=True)
    fig.subplots_adjust(left=.23,right=.985,bottom=.17,top=.81,wspace=.36)
    y=np.arange(6)
    titles=['Selected days','Clusters','Maximum run length']
    units=['Days per season','Clusters per season','Days']
    for j,(ax,metric) in enumerate(zip(axes,METRICS)):
        for row in [0,2,4]:ax.axhspan(row-.48,row+.48,color='#F3F5F6',zorder=0,lw=0)
        for model,offset,marker in [('G',-.12,'o'),('K',.12,'D')]:
            v=d[(d.model==model)&(d.metric==metric)].set_index('storyline').loc[STORIES]
            ax.hlines(y+offset,v.p05,v.p95,color=COLOURS[model],linewidth=1.0,zorder=2)
            for endpoint in [v.p05,v.p95]:
                ax.vlines(endpoint,y+offset-.045,y+offset+.045,color=COLOURS[model],linewidth=.65,zorder=2)
            ax.plot(v['mean'],y+offset,linestyle='none',marker=marker,color=COLOURS[model],
                markersize=4.3 if model=='G' else 3.8,markeredgecolor='white',markeredgewidth=.45,zorder=3)
        maximum=float(d[d.metric==metric][['mean','p95']].max().max())
        ax.set_xlim(0,maximum*1.08);ax.set_ylim(5.55,-.55)
        ax.xaxis.set_major_locator(MaxNLocator(nbins=4,integer=True))
        ax.set_yticks(y,STORY_LABELS);ax.tick_params(axis='y',pad=7)
        ax.set_xlabel(units[j],labelpad=7)
        ax.set_title(titles[j],loc='left',pad=12,fontsize=8.2)
        ax.text(-.01,1.135,chr(97+j),transform=ax.transAxes,fontweight='bold',fontsize=10)
        ax.grid(axis='x',color='#DEE3E7',linewidth=.45,zorder=1);ax.set_axisbelow(True)
        for name in ['top','right','left']:ax.spines[name].set_visible(False)
    handles=[Line2D([],[],color=COLOURS['G'],marker='o',linestyle='none',markersize=4.8,label='G: with WP'),
             Line2D([],[],color=COLOURS['K'],marker='D',linestyle='none',markersize=4.3,label='K: without WP')]
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.60,.985),ncol=2,
        frameon=False,columnspacing=2.2,handletextpad=.5,fontsize=8)
    fig.text(.60,.045,'Top 10% pooled selection | 5,000 simulated seasons per scenario',ha='center',fontsize=7)
    fig.text(.60,.015,'Points: means | Lines: central 90% simulation ranges',ha='center',fontsize=7)
    stem='Figure_Main_Top10'
    for ext in ['pdf','svg']:fig.savefig(folder/f'{stem}.{ext}')
    fig.savefig(folder/f'{stem}.png',dpi=1200)
    fig.savefig(folder/f'{stem}_600dpi.png',dpi=600)
    plt.close(fig)
    d.insert(0,'figure',stem);d.to_csv(folder/'FIGURE_DATA.csv',index=False)
    caption=('Figure. Organisation of model-selected days under Top-10% selection. Panels show seasonal selected days, clusters and maximum run length for the full hydrometeorological model with weather-pattern (WP) information (G) and the equivalent model without WP (K). Both models use the same numerical predictors. Points are means and lines are 5th-95th percentiles across 5,000 simulated seasons per scenario. Selection is applied separately to each model across all six scenarios pooled. Ranges describe conditional simulated variability, not confidence intervals or observed contamination duration.\n')
    (folder/'caption.txt').write_text(caption)
    meta={'rule':'topk_10','selection_fraction':.10,'models':['G','K'],'width_mm':183,'height_mm':115,
        'png_dpi':1200,'alternate_png_dpi':600,'formats':['png','pdf','svg'],
        'plotted_rows':36,'main_paper':True,'source':'results/seasonal_summary.csv','analysis_rerun':False}
    (folder/'figure_metadata.json').write_text(json.dumps(meta,indent=2))
    return meta

def make_publication_set(root=ROOT,include_legacy=True):
    root=Path(root)
    if not (root/'figures/All_percentages/Figure_Step6_Top50.png').exists():make_percentage_figures(root)
    main=make_main(root)
    supplement=root/'figures/Supplementary';supplement.mkdir(exist_ok=True)
    records=[]
    for pct in [1,5,25,50]:
        target=supplement/f'Top{pct:02d}';target.mkdir(exist_ok=True)
        for ext in ['png','pdf','svg']:
            source=root/f'figures/All_percentages/Figure_Step6_Top{pct:02d}.{ext}'
            dest=target/source.name;shutil.copy2(source,dest)
            records.append({'path':str(dest.relative_to(root)),'percentage':pct,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()})
    for ext in ['png','pdf','svg']:
        p=root/f'figures/Figure_Step6_Paired_budget_sensitivity.{ext}'
        if p.exists():shutil.copy2(p,supplement/p.name)
    (supplement/'README.txt').write_text('Supplementary absolute plots: Top 1%, 5%, 25% and 50%. The publication main figure is Top 10%, in Main_publication. The paired-budget heatmap shows all five fractions. All values come from the existing results; axis limits adapt to each fraction.\n')
    (supplement/'copied_figure_inventory.json').write_text(json.dumps(records,indent=2))
    if include_legacy:
        from legacy_figures_step6 import make_legacy_figures
        make_legacy_figures(root)
    (root/'figures/00_START_HERE.txt').write_text('MAIN PAPER: Main_publication/Figure_Main_Top10.png (1200 dpi), with PDF/SVG and a 600-dpi PNG alternative.\nSUPPLEMENT: Supplementary/Top01, Top05, Top25, Top50 and paired-budget sensitivity.\nEARLIER GROUPED-BAR STYLE, UPDATED NUMBERS: Legacy_style_updated (all A-K, six scenarios, three outcomes, five budgets).\nALL ABSOLUTE PERCENTAGES IN ONE PDF: Figure_Step6_All_percentages.pdf.\nORIGINAL SUPPLIED IMAGES: Original_reference_NOT_FOR_PUBLICATION (old data and annotations; reference only).\nEarlier root-level Top-1% figures are retained for compatibility and are supplementary, not the current main-paper figure.\n')
    return {'main':main,'supplementary_percentages':[1,5,25,50],'legacy_style_included':include_legacy,
        'all_fractions_retained':[1,5,10,25,50],'analysis_rerun':False}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=ROOT)
    p.add_argument('--no-legacy',action='store_true');a=p.parse_args()
    print(json.dumps(make_publication_set(a.root,not a.no_legacy),indent=2))
