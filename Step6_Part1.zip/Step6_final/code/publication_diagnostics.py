"""Audit saved Step 6 bootstrap draws without fitting or generating simulations.

Normal and percentile intervals are pointwise diagnostics, not simultaneous
intervals or replacements for the stored Holm-adjusted normal/Wald tests.
"""
from pathlib import Path
import argparse, json
import numpy as np
import pandas as pd
from scipy.special import log_ndtr
from scipy.stats import skew

Z = 1.959963984540054


def run(root):
    root = Path(root)
    source = root / 'results/inference'
    out = root / 'results/publication_revision'
    out.mkdir(parents=True, exist_ok=True)
    tests = pd.read_csv(source / 'paired_tests.csv', float_precision='round_trip')
    summary = pd.read_csv(root / 'results/seasonal_summary.csv', float_precision='round_trip')
    draws = np.load(source / 'paired_bootstrap_replicates.npz', allow_pickle=False)
    budgets = draws['budgets'].tolist()
    scenarios = draws['scenarios'].tolist()
    metrics = draws['metrics'].tolist()
    assert len(tests) == 270
    assert not tests.duplicated(['comparison', 'rule', 'storyline', 'metric']).any()
    rows = []
    for saved in tests.itertuples():
        high, low = saved.comparison.split('-')
        def point(model):
            selected = summary[(summary.model == model) & (summary.rule == saved.rule)
                               & (summary.storyline == saved.storyline) & (summary.metric == saved.metric)]
            assert len(selected) == 1
            return float(selected['mean'].iloc[0])
        estimate = point(high) - point(low)
        bi = budgets.index(int(saved.rule.removeprefix('topk_')) / 100)
        v = draws[high + '_' + low][:, bi, scenarios.index(saved.storyline), metrics.index(saved.metric)]
        assert len(v) == 4000 and np.isfinite(v).all()
        se = float(v.std(ddof=1))
        centre = float(v.mean())
        bias = centre - estimate
        bias_over_se = bias / se if se else 0.
        skewness = float(skew(v, bias=False)) if se else 0.
        normal_low, normal_high = estimate - Z * se, estimate + Z * se
        percentile_low, percentile_high = np.quantile(v, [.025, .975])
        # Numeric results are independently recomputed from saved draws.
        expected = [estimate, se, centre, bias_over_se, skewness, normal_low, normal_high,
                    percentile_low, percentile_high]
        actual = [saved.mean_difference, saved.bootstrap_se, saved.bootstrap_mean,
                  saved.bias_over_se, saved.bootstrap_skewness, saved.ci95_lower,
                  saved.ci95_upper, saved.percentile95_lower, saved.percentile95_upper]
        np.testing.assert_allclose(expected, actual, rtol=1e-10, atol=1e-12)
        log_raw = float(np.log(2.) + log_ndtr(-abs(estimate / se))) if se else 0.
        np.testing.assert_allclose(log_raw, saved.log_p_raw, rtol=1e-10, atol=1e-12)
        flag_bias = abs(bias_over_se) > .25
        flag_skew = abs(skewness) > .5
        flag = flag_bias or flag_skew
        assert flag == bool(saved.normal_approximation_flag)
        normal_zero = normal_low <= 0 <= normal_high
        percentile_zero = percentile_low <= 0 <= percentile_high
        rows.append(dict(comparison=saved.comparison, rule=saved.rule,
                         selected_fraction_percent=round(budgets[bi] * 100),
                         storyline=saved.storyline, metric=saved.metric,
                         mean_difference=estimate, bootstrap_replicates=len(v),
                         bootstrap_se=se, bootstrap_mean=centre, bootstrap_bias=bias,
                         bias_over_se=bias_over_se, bootstrap_skewness=skewness,
                         bias_flag=flag_bias, skewness_flag=flag_skew,
                         normal_approximation_flag=flag,
                         ci95_lower=normal_low, ci95_upper=normal_high,
                         percentile95_lower=float(percentile_low),
                         percentile95_upper=float(percentile_high),
                         normal_includes_zero=normal_zero, percentile_includes_zero=percentile_zero,
                         zero_inclusion_disagreement=normal_zero != percentile_zero,
                         p_holm=saved.p_holm, p_holm_display=saved.p_holm_display,
                         log_p_raw=log_raw, log_p_holm=saved.log_p_holm,
                         stars=saved.stars, holm_below_005=saved.p_holm < .05))
    frame = pd.DataFrame(rows)
    # Recompute Holm adjustment in log space; no zero-valued tail approximations.
    order = np.argsort(frame.log_p_raw.to_numpy())
    adjusted_sorted = np.minimum(0., np.maximum.accumulate(frame.log_p_raw.to_numpy()[order]
                                  + np.log(len(frame) - np.arange(len(frame)))))
    adjusted = np.empty(len(frame)); adjusted[order] = adjusted_sorted
    np.testing.assert_allclose(adjusted, frame.log_p_holm, rtol=1e-10, atol=1e-12)
    flagged = frame[frame.normal_approximation_flag].copy()
    frame.to_csv(out / 'all_interval_diagnostics.csv', index=False, float_format='%.17g')
    flagged.to_csv(out / 'flagged_interval_diagnostics.csv', index=False, float_format='%.17g')
    report = dict(status='passed', paired_contrasts_verified=len(frame),
                  bootstrap_replicates_per_contrast=4000,
                  flagged_contrasts=len(flagged),
                  flagged_by_comparison={str(k): int(v) for k, v in flagged.comparison.value_counts().items()},
                  flagged_holm_below_005=int(flagged.holm_below_005.sum()),
                  zero_inclusion_disagreements_all=int(frame.zero_inclusion_disagreement.sum()),
                  zero_inclusion_disagreements_flagged=int(flagged.zero_inclusion_disagreement.sum()),
                  flagged_normal_excludes_zero=int((~flagged.normal_includes_zero).sum()),
                  flagged_percentile_excludes_zero=int((~flagged.percentile_includes_zero).sum()),
                  maximum_absolute_bias_over_se=float(frame.bias_over_se.abs().max()),
                  maximum_absolute_skewness=float(frame.bootstrap_skewness.abs().max()),
                  new_bootstrap_draws=0, models_refitted=False, probabilities_recalibrated=False,
                  weather_simulations_regenerated=False,
                  inference='Normal/Wald Holm-adjusted results are retained; percentile intervals are pointwise sensitivity diagnostics only.',
                  claim_assessment=(f"The diagnostic flags include {sum(flagged.comparison.eq('G-K'))} G-K contrasts. "
                                    f"Normal and percentile intervals disagree on inclusion of zero in "
                                    f"{int(flagged.zero_inclusion_disagreement.sum())} flagged comparisons. "
                                    "These are pointwise checks of interval shape."))
    (out / 'DIAGNOSTIC_REVIEW.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    text = f'''FLAGGED INFERENCE REVIEW — SAVED DRAW AUDIT

Scope and checks
All {len(frame)} paired contrasts were recalculated directly from the existing 4,000 bootstrap draws per contrast. Original mean differences were verified against the seasonal summary. Bootstrap standard errors, mean shifts relative to the original estimate, bias/SE, sample skewness, normal 95% intervals, percentile 95% intervals and raw log-tail probabilities agree with the saved tables. Holm adjustment was independently recalculated in log space across all 270 comparisons. No model fitting, recalibration, bootstrap generation or weather simulation was performed.

Findings
The existing diagnostic rule flags absolute bias/SE greater than 0.25 or absolute skewness greater than 0.5. It identifies {len(flagged)} contrasts ({', '.join(k + ': ' + str(v) for k, v in report['flagged_by_comparison'].items())}); {int(flagged.holm_below_005.sum())} carry an existing Holm-adjusted p<0.05. Normal and percentile pointwise intervals disagree about inclusion of zero in {int(frame.zero_inclusion_disagreement.sum())} of all {len(frame)} contrasts and {int(flagged.zero_inclusion_disagreement.sum())} of the flagged contrasts. Both methods exclude zero for {int((~flagged.normal_includes_zero).sum())} flagged contrasts and include zero for {int(flagged.normal_includes_zero.sum())}. The largest absolute bias/SE is {frame.bias_over_se.abs().max():.4f}; the largest absolute skewness is {frame.bootstrap_skewness.abs().max():.4f}.

Interpretation
Agreement in the zero-inclusion classification provides a limited check that the pointwise directional interpretation is not solely an artefact of the selected normal interval. It does not establish nominal coverage, remove the diagnostic flags, validate the normal/Wald p-values or supply an adjusted percentile test. Do not calculate new stars from the percentile intervals. Retain the original adjusted tests and visible diagnostic daggers, and avoid making a substantive conclusion rest solely on flagged E-C significance.

Dependence of conclusions
{report['claim_assessment']} The source table retains each diagnostic alongside the Holm-adjusted result.

Files
results/publication_revision/all_interval_diagnostics.csv: all 270 independently recalculated contrasts.
results/publication_revision/flagged_interval_diagnostics.csv: flagged subset for the supplementary figure and table.
results/publication_revision/DIAGNOSTIC_REVIEW.json: machine-readable completed checks and limitations.
'''
    (root / 'reports/FLAGGED_INFERENCE_REVIEW.txt').write_text(text, encoding='utf-8')
    print(json.dumps(report, indent=2))
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent.parent)
    run(parser.parse_args().root)
