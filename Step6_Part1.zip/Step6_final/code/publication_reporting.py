"""Generate current publication reporting from saved Step 6 results only.

No model fitting, calibration, simulation or resampling is performed here.
"""
from pathlib import Path
import argparse
import html
import json
import pandas as pd


def _read_json(path):
    return json.loads(path.read_text(encoding='utf-8')) if path.exists() else None


def _verification_sentence(path, label):
    report=_read_json(path)
    if report is None:
        return f'{label}: no execution report is present.'
    count=report.get('checks_passed',report.get('tests_run',report.get('cases')))
    return f"{label}: recorded status {report.get('status','not specified')}"+(f'; count {count}.' if count is not None else '.')


def write_reports(root):
    root=Path(root);results=root/'results';reports=root/'reports';figures=root/'figures'
    reports.mkdir(exist_ok=True);figures.mkdir(exist_ok=True)
    tests=pd.read_csv(results/'inference/paired_tests.csv',float_precision='round_trip')
    means=pd.read_csv(results/'inference/mean_confidence_intervals.csv',float_precision='round_trip')
    matched=pd.read_csv(results/'matched_count_paired_differences.csv',float_precision='round_trip')
    flags=tests.normal_approximation_flag.astype(str).str.lower().eq('true')
    flagged=tests[flags]
    normal_zero=(flagged.ci95_lower<=0)&(flagged.ci95_upper>=0)
    percentile_zero=(flagged.percentile95_lower<=0)&(flagged.percentile95_upper>=0)
    disagree=int((normal_zero!=percentile_zero).sum())
    primary=tests[(tests.comparison=='G-K')&(tests.rule=='topk_10')]
    def nsignificant(frame):
        return int(frame.stars.isin(['*','**','***']).sum())
    def effect_range(frame):
        return f"{frame.mean_difference.min():.4f} to {frame.mean_difference.max():.4f}"
    mg=matched[(matched.comparison=='G-K')&matched.metric.isin(['clusters','max_run_days'])]
    def mean(model,story,metric):
        v=means[(means.model==model)&(means.rule=='topk_10')&(means.storyline==story)&(means.metric==metric)]
        if len(v)!=1:raise ValueError('Expected one current mean record')
        return float(v['mean'].iloc[0])
    sources=_read_json(root/'inputs/provenance/PUBLICATION_REVISION_SOURCES.json')
    metadata=_read_json(figures/'publication_revision_metadata.json') or {}
    verification=results/'publication_revision/VERIFICATION.json'
    methods='''STEP 6 — TEMPORAL ORGANISATION OF MODEL-SELECTED DAYS

Calibrated probabilities from the supplied final Step 5 models were evaluated for six atmospheric scenarios, each comprising 5,000 simulated seasons. April provided initialisation; the evaluated season was 1 May–30 September (153 consecutive days). The year 2001 is a synthetic calendar label, not the date of an historical observation. This publication revision used existing result tables and saved bootstrap draws. It did not refit microbiological models, re-estimate calibrators, regenerate weather simulations or generate new bootstrap replicates.

For each model separately, calibrated probabilities were ranked over all six equally sized scenario ensembles: 6 × 5,000 × 153 = 4,590,000 evaluated days. Top 10% is the main publication presentation, selecting exactly 459,000 days per model across this entire pool. The 1%, 5%, 25% and 50% results are retained as selection-fraction sensitivities. This is a pooled analytical selection budget, not a prescribed rate of issued warnings, not a fixed fraction within every scenario and not a probability threshold. Selected totals within scenarios and individual seasons may differ while the pooled total remains fixed. The source calculations use full-precision calibrated probabilities and shared pseudorandom tie priorities, SeedSequence [42, 5, 700]. In the saved bootstrap, identical replicated days retain those priorities, with copy ordinal resolving a partial boundary allocation.

Three outcomes were calculated within each individual season: number of model-selected days; number of separate uninterrupted selected-day clusters; and maximum run length of consecutive selected days. Isolated selected days form one cluster. Outcomes are zero in seasons with no selected days, and sequences never cross season boundaries. Model G includes the WP family predictor; K uses the same numerical predictors without WP. G−K is the principal paired contrast; E−C and F−J are supporting contrasts. WP is the four-family predictor, including in model D, which is displayed as WP rather than as 30 separate patterns.

The saved uncertainty analysis contains 4,000 paired whole-simulation-bundle bootstrap replicates. Each draw resampled 5,000 simulation indices with replacement, retaining all six complete scenario seasons for an index and using common weights across models. Pooled Top-k selection was reapplied separately for every model, fraction and draw, preserving exact quotas. Bootstrap standard deviations provide standard errors. Pointwise normal-approximation 95% confidence intervals are the original estimate ±1.96 standard errors; saved percentile 95% intervals provide a diagnostic sensitivity. Approximate two-sided normal/Wald tests assess zero conditional mean differences. Their p-values are Holm-adjusted over all 270 unique contrasts: three model pairs × five fractions × six scenarios × three outcomes. Repeated appearances of a contrast use the same adjusted result. These are not empirical bootstrap-tail p-values. Significance symbols are * adjusted p<0.05, ** p<0.01 and *** p<0.001; ns means not significant after adjustment, not equivalence. Pointwise confidence intervals are not simultaneous and may exclude zero when an adjusted test is ns.

The matched-count sensitivity selects exactly eight or sixteen days within every season for each comparison model, using shared within-season tie priorities, SeedSequence [42, 6, 800]. These counts equal 5.23% and 10.46% of 153 days. This is a different estimand from pooled Top-5% and Top-10% selection: it controls selected-day count by construction. Existing paired G−K differences in clusters and maximum run length use mean ±1.96 × SD(paired seasonal differences)/√5,000. These are pointwise conditional Monte Carlo intervals; no new p-values or significance stars are added to this display.

Bootstrap diagnostic flags use |bootstrap bias|/SE >0.25 or |skewness| >0.5. The publication diagnostic table and figure compare normal and percentile intervals for every flagged model contrast using the saved draws. A difference in interval inclusion of zero is a diagnostic, not a multiplicity-adjusted significance decision or a reason to select whichever method gives a preferred result. Flags and their cautions remain visible in supporting heatmaps and bar charts.

The main figure shows G/K seasonal means on the left and paired G−K differences on the right, with 95% pointwise confidence intervals. Separate supplementary plots retain the 5th–95th percentiles across individual seasons: these are central 90% seasonal variability ranges, not confidence intervals for means. All figures are generated from current tables and exported as 600-dpi PNG and vector PDF/SVG with editable text.
'''
    limitations='''INTERPRETATION AND LIMITATIONS

The observations available to this study are microbiological water-quality measurements. They are not records of issued advice against bathing or operational warning decisions. Step 5 evaluates prediction of observed intestinal enterococci exceedances; Step 6 explores how model-selected days are organised under specified simulated conditions. Step 6 does not validate observed contamination duration, actual warnings, prospective lead time or public-health benefit.

Confidence intervals and tests quantify conditional Monte Carlo uncertainty under fixed fitted microbiological models, calibrators, historical inputs, donor library, weather generator and saved tie scheme. They exclude historical sampling uncertainty, model and calibration fitting uncertainty, generator-parameter uncertainty and structural error. More simulated seasons can reduce numerical uncertainty without resolving those exclusions. A small adjusted p-value can accompany a small effect; effects must be interpreted in their original units.

Normal/Wald inference remains approximate. Bootstrap bias and skewness flags are not resolved merely by increasing the number of resamples or by obtaining stable significance decisions. Percentile intervals are a diagnostic sensitivity, not an automatic correction. Flagged supporting comparisons should not carry strong claims without qualification; consult the diagnostic table and report. Pointwise interval overlap is not the paired significance test, and pointwise exclusion of zero is not equivalent to Holm-adjusted significance.

Step 4 rainfall persistence remains underestimated. The historical input retains 74 missing rainfall dates; rare donor pools constrain support, and soil/rainfall-memory indicators are resampled or derived without a dynamical water balance. Regional predictors and retrospective full-day information limit operational interpretation. These limitations remain after numerical checks pass.

Pooled Top-k selection redistributes a fixed total across scenarios and seasons. More selected days can themselves create longer runs or different cluster counts. The matched-count analysis controls that count difference but changes the estimand and does not establish causality. Neither selection fraction nor significance should be presented as evidence of improved operational warning performance. Source-code consistency and numerical tests do not guarantee nominal confidence-interval coverage or reviewer acceptance.
'''
    resulttext=f'''STEP 6 — CURRENT RESULTS WORDING

At pooled Top 10%, the six scenario ensembles share exactly 459,000 model-selected days per model, but selection totals within individual scenarios differ. For model G, mean selected days per season were {mean('G','persistent_wet','selected_days'):.2f} under persistent wet conditions and {mean('G','flip_dry_to_wet','selected_days'):.2f} under dry-to-wet conditions, compared with {mean('G','baseline','selected_days'):.2f} for baseline. These are simulated model selections, not observed exceedance episodes or issued warnings.

Adding WP to the full hydrometeorological model produced small, scenario-dependent changes. At Top 10%, G−K cluster differences ranged from {effect_range(primary[primary.metric=='clusters'])} clusters per season; {nsignificant(primary[primary.metric=='clusters'])} of six corresponding Holm-adjusted tests were below 0.05. G−K maximum-run differences ranged from {effect_range(primary[primary.metric=='max_run_days'])} days. The adjusted tests were below 0.05 for {nsignificant(primary[primary.metric=='max_run_days'])} of the six maximum-run comparisons. See the paired table for scenario-specific estimates and intervals.

In the matched-count sensitivity, G−K cluster differences ranged from {effect_range(mg[mg.metric=='clusters'])}; maximum-run differences ranged from {effect_range(mg[mg.metric=='max_run_days'])} days across both counts and all scenarios. This analysis controls selected-day totals by construction; consult the paired intervals rather than treating the point estimates alone as evidence. It assesses temporal organisation at a fixed count and does not establish improved prediction or operational benefit.

The saved test table contains {len(flagged)} diagnostic flags, of which {int((flagged.comparison=='E-C').sum())} are E−C contrasts. Normal and percentile pointwise intervals disagree on inclusion of zero for {disagree} flagged contrasts. Such agreement or disagreement does not replace the multiplicity-adjusted tests and does not establish nominal coverage. Flagged results warrant checking against the percentile intervals. All comparisons remain conditional on the fitted simulation system.

These results support small changes in simulated temporal organisation when WP information is included. Claims about prediction of observed water-quality exceedances belong to Step 5 and should retain its separate validation results and limitations.
'''
    checks=[_verification_sentence(verification,'Current publication revision verification'),
            _verification_sentence(results/'publication_revision/MATCHED_COUNT_VERIFICATION.json','Matched-count verification'),
            _verification_sentence(results/'publication_revision/DIAGNOSTIC_REVIEW.json','Flagged-interval diagnostics'),
            _verification_sentence(results/'inference/VERIFICATION.json','Inference arithmetic/export verification report'),
            _verification_sentence(results/'VERIFICATION.json','Original arithmetic/source-verification report')]
    review='''STEP 6 — PUBLICATION REVISION REVIEW

SCOPE
This revision preserves the supplied scientific concept, fitted models, probabilities and existing simulation outcomes. It introduces no fitting, recalibration, weather generation or new bootstrap draws. The authoritative source inventory is inputs/provenance/PUBLICATION_REVISION_SOURCES.json. Its archive filenames, versions and SHA-256 hashes should be consulted instead of choosing inputs by modification date.

PRESENTATION CHANGES
The main display is the six-panel Top-10% G/K figure: seasonal outcomes on the left and paired G−K effects on the right. The matched-count supplementary figure separates temporal organisation from selected-day counts. The flagged interval plot compares two existing interval constructions. All annotated heatmaps, selection-fraction sensitivities and seasonal-range displays are retained. Detailed assumptions are in captions and Methods, rather than on the main graphic. The historical Top-1% setting is retained only as provenance, while Top 10% is the current publication presentation choice.

RECORDED CHECKS
'''+ '\n'.join(checks)+f'''

The full-size bootstrap validation report records the literal-expansion cases checked using the corrected inputs. This reporting stage reads those results. The current logs and verification JSON files identify checks actually executed. Passing numerical checks supports consistency, not physical validity or nominal statistical coverage.

INFERENCE FINDINGS
Current saved tables contain {len(flagged)} flagged contrasts and {disagree} flagged normal-versus-percentile disagreements on inclusion of zero. Diagnostic calculations are checked from saved draws; no interval method is selected to obtain a favourable finding. Stars remain the original Holm-adjusted approximate normal/Wald results across 270 contrasts. The separate diagnostic and matched-count reviews give detailed findings. No new significance test is attached to the matched-count figure.

UNRESOLVED LIMITATIONS
Conditional Monte Carlo inference excludes historical/model/generator fitting uncertainty. Rainfall persistence bias, 74 missing historical rainfall dates, rare donor pools, absence of a dynamical water balance and retrospective predictor timing remain. Significant effects can be small. Interpret flagged contrasts alongside their bias, skewness and percentile intervals, and Step 6 cannot demonstrate operational warning improvements or contamination duration. No guarantee of reviewer acceptance is made.
'''
    for name,content in [('METHODS.txt',methods),('LIMITATIONS.txt',limitations),('RESULTS_WORDING.txt',resulttext),('REVIEW_REPORT.txt',review)]:
        (reports/name).write_text(content,encoding='utf-8')
    guide='''MODEL COMPARISON FIGURES

For the overall figure index, including storyline comparisons, open ../START_HERE.html.

POOLED MODEL COMPARISON
Main_publication/Figure_Main_Top10.png, .pdf, .svg
Six panels: G/K seasonal means on the left; paired G−K differences on the right.
Rows: model-selected days, selected-day clusters and maximum run length.
Top 10%; pointwise 95% conditional Monte Carlo intervals. Adjusted stars appear on paired panels only.

NEW SUPPORTING FIGURES
Supplementary/Matched_count/Figure_Matched_count_GK — equal selected-day counts of 8 or 16 per season; clusters and maximum run length, with existing 95% intervals and no new stars.
Supplementary/Diagnostics/Figure_Flagged_EC_intervals — normal and percentile intervals for flagged model comparisons.

RETAINED SUPPORTING FIGURES
Inference/Heatmaps/Figure_Paired_budget_sensitivity_significance — all five fractions.
Heatmaps_by_percentage/ — individual 1%, 5%, 10%, 25%, 50% displays.
Inference/Grouped_bars_90ranges/ — 5th–95th seasonal variability ranges with adjusted tests; these are not mean confidence intervals.
Inference/Grouped_bars_95CI/ — all-model confidence-interval bars.
All_percentages/ — retained G/K outcomes at each selection fraction.

Use INDEX.html for direct links. Captions and source tables accompany the publication figures. The two old root Figure_Step6 compatibility plots/source metadata are retained for original arithmetic checks, not as current main figures.
'''
    (figures/'00_START_HERE.txt').write_text(guide,encoding='utf-8')
    readme='''STEP 6 — FINAL PUBLICATION REVISION

OPEN FIRST
figures/INDEX.html — current figure index.
figures/Main_publication/Figure_Main_Top10.png — main six-panel Top-10% figure.
reports/REVIEW_REPORT.txt — changes, recorded checks and unresolved limitations.
reports/METHODS.txt, LIMITATIONS.txt and RESULTS_WORDING.txt — current copy-ready wording.

The package is self-contained. It retains the supplied Step 5 fitted models, exact selections and Step 4 donor/driver sequences. This publication revision uses existing result tables and saved bootstrap draws only; no microbiological fitting, recalibration, weather generation or new bootstrap replicates were performed. Historical data provenance is retained; observational water-quality results are not records of issued warnings.

CURRENT PRESENTATION
Top 10% is the main publication fraction; 1%, 5%, 25% and 50% are sensitivities. Main panels compare G (with WP) and K (without WP), retaining identical numerical predictor sets. D remains displayed as WP and still uses four families. Supporting E−C/F−J tests are in the supplement. Historical publication settings are inactive provenance, not a second current primary specification.

REPRODUCE THIS REVISION
Extract the ZIP into a new empty folder, rather than merging it with an earlier version, and install the pinned requirements in a Python environment. Use the publication-revision entry point supplied at the package root (run_publication_revision.py). That workflow reads existing saved tables and draws, regenerates diagnostics and figures, verifies source values and writes reports. Consult --help for its options. Do not use the historical analysis/re-bootstrap entry points merely to redraw publication figures. The code modules are also callable using their documented --root arguments. Actual execution logs are in logs/.

KEY DATA
results/seasonal_summary.csv — original means and seasonal percentiles.
results/inference/mean_confidence_intervals.csv — conditional confidence intervals for model means.
results/inference/paired_tests.csv — original paired effects, intervals and Holm-adjusted tests.
results/inference/*bootstrap_replicates.npz — saved draws, reused without new resampling.
results/matched_count_* — original equal-count seasonal metrics and paired summaries.
results/publication_revision/ — current diagnostic tables, plot sources and verification reports.
inputs/provenance/PUBLICATION_REVISION_SOURCES.json — authoritative source identifiers and hashes.

INTERPRETATION
Top-k selection is pooled across all six scenario ensembles separately for each model. Ten per cent means 459,000 of 4,590,000 evaluated days overall, not ten per cent within each season or scenario. Seasonal ranges show between-season variation; confidence intervals show conditional numerical precision. Stars use the same 270-comparison Holm correction wherever a contrast is displayed. Pointwise intervals may exclude zero while an adjusted test is ns. The matched-count analysis is distinct from pooled selection, and adds no new significance claims.

No model-selected day is described as an issued advisory or observed contamination episode. Step 5 observational prediction evidence and Step 6 simulation results remain separate. Read the limitations: the revision does not resolve model/generator uncertainty or establish operational warning benefit. Earlier versions are explicitly inactive; use the current figure index and reports.
'''
    # The full release README also covers the upstream recalculation and storyline tests.
    if not (root/'README.txt').exists():
        (root/'README.txt').write_text(readme,encoding='utf-8')
    entries=[('Main paper: seasonal outcomes and paired WP effects','Main_publication/Figure_Main_Top10'),
             ('Supplement: matched-count G−K comparison','Supplementary/Matched_count/Figure_Matched_count_GK'),
             ('Supplement: flagged model-comparison interval diagnostics','Supplementary/Diagnostics/Figure_Flagged_EC_intervals')]
    rows=['<!doctype html><html lang="en"><meta charset="utf-8"><title>Step 6 publication figures</title>',
          '<style>body{font:16px Arial;max-width:1100px;margin:40px auto}li{margin:12px 0}small{color:#444}</style>',
          '<h1>Step 6: publication figure index</h1>',
          '<p>Top 10% is the main presentation. Confidence intervals describe conditional Monte Carlo precision; seasonal ranges describe variability between individual seasons.</p>',
          '<h2>Main and new supplementary figures</h2><ul>']
    for title,stem in entries:
        rows.append('<li>'+html.escape(title)+': '+ ' | '.join(f'<a href="{stem}.{e}">{e.upper()}</a>' for e in ['png','pdf','svg'])+'</li>')
    rows.extend(['</ul><h2>Retained supplementary figures</h2>',
                 '<p>Stars retain Holm adjustment over the same 270 unique comparisons. † marks a diagnostic caution, not another significance level.</p><ul>'])
    old=_read_json(figures/'Inference/figure_metadata.json') or {'figures':[]}
    for item in old['figures']:
        paths={Path(p).suffix:p.removeprefix('figures/') for p in item['files'] if not p.endswith('_600dpi.png')}
        rows.append('<li>'+html.escape(item['stem'])+': '+' | '.join(f'<a href="{paths[e]}">{e[1:].upper()}</a>' for e in ['.png','.pdf','.svg'] if e in paths)+'</li>')
    rows.extend(['</ul><p><a href="00_START_HERE.txt">Figure guide</a> | <a href="../reports/METHODS.txt">Methods</a> | <a href="../reports/LIMITATIONS.txt">Limitations</a></p></html>'])
    (figures/'INDEX.html').write_text('\n'.join(rows),encoding='utf-8')
    return {'reports_written':4,'figure_index_entries':len(entries)+len(old['figures']),
            'diagnostic_flags':len(flagged),'flagged_interval_zero_disagreements':disagree,
            'sources_inventory_present':sources is not None,'publication_figure_metadata_present':bool(metadata)}


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent.parent)
    print(json.dumps(write_reports(parser.parse_args().root),indent=2))
