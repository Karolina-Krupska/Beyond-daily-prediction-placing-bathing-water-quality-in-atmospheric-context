"""Publication displays from frozen saved Step6 tables; no numerical modelling."""
from pathlib import Path
import json,shutil
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
STORIES=['baseline','persistent_wet','flip_wet_to_dry','dry_with_bursts','persistent_dry','flip_dry_to_wet']
LABELS=['Baseline','Persistent wet','Wet to dry','Dry with storm\noutbreaks','Persistent dry','Dry to wet']
METRICS=['selected_days','clusters','max_run_days'];TITLES=['Model-selected days','Selected-day clusters','Maximum run length'];SHORT=dict(zip(METRICS,['Selected days','Clusters','Maximum run']))
COLOURS={'G':'#0072B2','K':'#D55E00'};MM=1/25.4

def configure():
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','pdf.fonttype':42})

def save(root,fig,stem,kind,source,caption,width,height):
 stem=root/stem;stem.parent.mkdir(parents=True,exist_ok=True);files=[]
 for ext in ['png','pdf','svg']:
  p=stem.with_suffix('.'+ext);fig.savefig(p,dpi=600);files.append(p.relative_to(root).as_posix())
 source_path=stem.with_name(stem.name+'_source.csv');source.to_csv(source_path,index=False,float_format='%.17g')
 stem.with_name(stem.name+'_caption.txt').write_text(caption,encoding='utf-8');plt.close(fig)
 return dict(kind=kind,stem=stem.stem,files=files,source_csv=source_path.relative_to(root).as_posix(),width_mm=width,height_mm=height,png_dpi=600,caption=stem.with_name(stem.name+'_caption.txt').relative_to(root).as_posix())

def style(ax):
 for row in [0,2,4]:ax.axhspan(row-.48,row+.48,color='#F3F5F6',lw=0)
 ax.set_ylim(5.55,-.55);ax.grid(axis='x',color='#dfe4e7',lw=.5);ax.set_axisbelow(True);ax.spines['left'].set_visible(False);ax.tick_params(axis='y',length=0,pad=7)

def main(root):
 means=pd.read_csv(root/'results/inference/mean_confidence_intervals.csv',float_precision='round_trip');tests=pd.read_csv(root/'results/inference/paired_tests.csv',float_precision='round_trip')
 m=means[(means.rule=='topk_10')&means.model.isin(['G','K'])].copy();t=tests[(tests.rule=='topk_10')&tests.comparison.eq('G-K')].copy();assert len(m)==36 and len(t)==18
 fig,axes=plt.subplots(3,2,figsize=(183*MM,235*MM));fig.subplots_adjust(left=.22,right=.935,top=.89,bottom=.115,hspace=.58,wspace=.60);y=np.arange(6)
 for j,(metric,title) in enumerate(zip(METRICS,TITLES)):
  ax,bx=axes[j]
  for model,offset,marker in [('G',-.12,'o'),('K',.12,'D')]:
   v=m[(m.model==model)&(m.metric==metric)].set_index('storyline').loc[STORIES]
   ax.hlines(y+offset,v.ci95_lower,v.ci95_upper,color=COLOURS[model],lw=1.2);ax.plot(v['mean'],y+offset,marker,ms=4,color=COLOURS[model],mec='white',mew=.3)
  ax.set_yticks(y,LABELS);ax.set_xlim(left=0);ax.set_xlabel('Clusters per season' if metric=='clusters' else 'Days per season');ax.set_title(title,loc='left',fontsize=9,pad=10)
  v=t[t.metric==metric].set_index('storyline').loc[STORIES]
  bx.axvline(0,color='#777777',ls='--',lw=.8);bx.hlines(y,v.ci95_lower,v.ci95_upper,color=COLOURS['G'],lw=1.3);bx.plot(v.mean_difference,y,'o',color=COLOURS['G'],ms=4);bx.set_yticks(y,[]);bx.set_xlabel('Difference ('+('clusters' if metric=='clusters' else 'days')+')');bx.set_title(title,loc='left',fontsize=9,pad=10)
  for i,s in enumerate(STORIES):bx.text(1.055,i,v.loc[s,'stars'],transform=bx.get_yaxis_transform(),fontsize=8,ha='left',va='center')
  for k,q in enumerate([ax,bx]):style(q);q.text(-.09,1.12,chr(97+2*j+k),transform=q.transAxes,fontweight='bold',fontsize=11)
 fig.text(.22,.94,'Seasonal outcomes',fontsize=10,fontweight='bold');fig.text(.665,.94,'WP effect: G − K',fontsize=10,fontweight='bold')
 fig.legend([Line2D([],[],color=COLOURS['G'],marker='o',ls='none'),Line2D([],[],color=COLOURS['K'],marker='D',ls='none')],['G: with WP','K: without WP'],loc='upper center',bbox_to_anchor=(.48,.995),ncol=2,frameon=False,fontsize=9)
 fig.text(.22,.045,'Top 10% | Points: means | Lines: 95% confidence intervals',fontsize=7)
 fig.text(.22,.022,'G − K: * adjusted p < 0.05; ** < 0.01; *** < 0.001; ns: not significant',fontsize=6.7)
 m['record_type']='mean';t['record_type']='paired';source=pd.concat([m,t],ignore_index=True)
 caption='Figure. Seasonal outcomes and the effect of weather-pattern information under six atmospheric scenarios at a pooled Top-10% selection fraction. Left panels show means for the full model with WP (G) and identical numerical predictors without WP (K): model-selected days (a), selected-day clusters (c) and maximum run length (e). Right panels show corresponding paired differences G−K (b, d, f); dashed lines denote zero difference. Lines are pointwise95% conditional Monte Carlo confidence intervals from the existing4,000 whole-simulation-bundle bootstrap resamples, with exact pooled selection repeated in each resample. Symbols use approximate normal/Wald tests adjusted by Holm across270 unique contrasts. Pointwise CIs and adjusted significance need not agree. The pooled budget covers4,590,000 days per model across six equally sized ensembles, selecting459,000 days; scenario and seasonal totals can differ. Intervals exclude model-fitting, calibration and weather-generator estimation uncertainty. These are model selections, not issued advice or observed contamination episodes. WP denotes the four-family predictor.'
 return save(root,fig,Path('figures/Main_publication/Figure_Main_Top10'),'main',source,space(caption),183,235)

def matched(root):
 d=pd.read_csv(root/'results/publication_revision/matched_GK_plot_source.csv',float_precision='round_trip');fig,axes=plt.subplots(2,2,figsize=(183*MM,175*MM));fig.subplots_adjust(left=.22,right=.97,top=.87,bottom=.16,hspace=.52,wspace=.36);y=np.arange(6)
 for row,rule in enumerate(['matched_05','matched_10']):
  count=8 if row==0 else 16
  for col,metric in enumerate(['clusters','max_run_days']):
   ax=axes[row,col];v=d[(d.rule==rule)&(d.metric==metric)].set_index('storyline').loc[STORIES];style(ax);ax.axvline(0,ls='--',color='#777777',lw=.8);ax.hlines(y,v.mc95_lower,v.mc95_upper,color=COLOURS['G'],lw=1.3);ax.plot(v.mean_difference,y,'o',color=COLOURS['G'],ms=4);ax.set_yticks(y,LABELS if col==0 else []);ax.set_xlabel('G − K ('+('clusters' if col==0 else 'days')+')');ax.set_title(f'{SHORT[metric]}: {count} selected days',loc='left',fontsize=8.5,pad=10);ax.text(-.09,1.12,chr(97+2*row+col),transform=ax.transAxes,fontweight='bold',fontsize=10)
 fig.suptitle('Temporal organisation at equal selected-day counts',fontsize=11,y=.98)
 fig.text(.22,.065,'Points: paired mean differences | Lines: 95% confidence intervals',fontsize=7)
 fig.text(.22,.032,'Exactly 8 or 16 days per season (5.23% or 10.46% of 153 days)',fontsize=7)
 caption='Figure S. Paired G−K differences in selected-day clusters (a, c) and maximum run length (b, d) when each model selects exactly8 or16 days within every153-day season. All six scenarios have5,000 paired seasons. The counts correspond to5.23% and10.46%, not pooled Top-5% and Top-10% selection. Points show mean differences; lines show the existing pointwise95% normal-approximation conditional Monte Carlo intervals (mean±1.96×SD of paired seasonal differences/√5000). These intervals condition on fixed models, generator and within-season selection and are not simultaneous intervals. No new p-values or significance stars are assigned. Equal counts control count differences when evaluating organisation; they do not establish a causal effect or observed contamination duration.'
 return save(root,fig,Path('figures/Supplementary/Matched_count/Figure_Matched_count_GK'),'matched',d,space(caption),183,175)

def diagnostics(root):
 d=pd.read_csv(root/'results/publication_revision/flagged_interval_diagnostics.csv',float_precision='round_trip').copy();d=d.sort_values(['comparison','rule','metric','storyline']).reset_index(drop=True)
 # Standardise each interval around its own point estimate so differently sized effects/units remain comparable.
 for source,dest in [('ci95_lower','normal_standardised_lower'),('ci95_upper','normal_standardised_upper'),('percentile95_lower','percentile_standardised_lower'),('percentile95_upper','percentile_standardised_upper')]:d[dest]=(d[source]-d.mean_difference)/d.bootstrap_se
 fig,ax=plt.subplots(figsize=(183*MM,235*MM));fig.subplots_adjust(left=.53,right=.97,top=.90,bottom=.11);y=np.arange(len(d))
 for i in range(0,len(d),2):ax.axhspan(i-.48,i+.48,color='#F3F5F6',lw=0)
 for lo,hi,offset,colour,label in [('normal_standardised_lower','normal_standardised_upper',-.13,'#777777','Normal'),('percentile_standardised_lower','percentile_standardised_upper',.13,'#0072B2','Percentile')]:
  ax.hlines(y+offset,d[lo],d[hi],color=colour,lw=1.4,label=label)
 ax.axvline(0,color='#777777',ls='--',lw=.7)
 names=dict(zip(STORIES,[s.replace('\n',' ') for s in LABELS]));labs=[f"{r.comparison} | {int(r.rule[-2:])}% | {names[r.storyline]} | {SHORT[r.metric]}" for r in d.itertuples()]
 ax.set_yticks(y,labs,fontsize=6.4);ax.tick_params(axis='y',length=0,pad=6);ax.set_ylim(len(d)-.5,-.5);ax.set_xlabel('(Interval endpoint − estimate) / bootstrap SE',fontsize=7);ax.grid(axis='x',color='#e4e4e4',lw=.5);ax.set_axisbelow(True);ax.spines['left'].set_visible(False)
 fig.suptitle(f'Flagged model comparisons: normal and percentile intervals (n = {len(d)})',fontsize=9,y=.98)
 ax.legend(loc='upper center',bbox_to_anchor=(.5,1.08),ncol=2,frameon=False,fontsize=7)
 fig.text(.10,.055,'Intervals are centred on each contrast’s estimate and scaled by its bootstrap SE.',fontsize=7)
 fig.text(.10,.03,'The dashed zero line is the original estimate, not the null effect. No new significance test.',fontsize=7)
 caption='Figure S. Comparison of existing pointwise95% normal and percentile bootstrap intervals for the diagnostic-flagged model contrasts. For visual comparison across differently sized effects and outcome units, each endpoint is shown as(endpoint−original estimate)/bootstrap SE. Thus the dashed zero line denotes the original estimate, not a null model difference; this graphic must not be used to infer significance. Original-unit endpoints, bias/SE, skewness, Holm-adjusted results and zero-inclusion diagnostics are supplied in the source table and flagged_interval_diagnostics.csv. Interval inclusion of zero is assessed in original outcome units in that table. Agreement between methods does not establish valid coverage or validate adjusted normal/Wald tests. All diagnostic flags are retained.'
 return save(root,fig,Path('figures/Supplementary/Diagnostics/Figure_Flagged_EC_intervals'),'diagnostic',d,space(caption),183,235)

def space(s):
 for a,b in [('pointwise95','pointwise 95'),('existing4','existing 4'),('across270','across 270'),('covers4','covers 4'),('selecting459','selecting 459'),('exactly8','exactly 8'),('or16','or 16'),('every153','every 153'),('have5','have 5'),('to5.23','to 5.23'),('and10.46','and 10.46'),('as(endpoint','as (endpoint')]:s=s.replace(a,b)
 return s+'\n'

def make_figures(root):
 root=Path(root);configure();folder=root/'figures/Main_publication'
 if not (folder/'PUBLICATION_REVISION.txt').exists():
  archive=root/'archive_superseded/pre_publication_revision/figures_Main_publication'
  if folder.exists() and not archive.exists():shutil.copytree(folder,archive)
  if folder.exists():shutil.rmtree(folder)
  folder.mkdir(parents=True,exist_ok=True)
  (folder/'PUBLICATION_REVISION.txt').write_text('Current main: six-panel Top10% G/K seasonal means and paired G-K differences.\n')
 meta={'figures':[main(root),matched(root),diagnostics(root)],'scope':'Saved results and draws only; no statistical-method selection or new modelling.','primary_fraction':.10}
 aliases=root/'figures/INFERENCE_ALIASES.json'
 if aliases.exists():
  retained=[x for x in json.loads(aliases.read_text()) if '/Main_publication/' not in x['alias']]
  aliases.write_text(json.dumps(retained,indent=2))
 (root/'figures/publication_revision_metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
 return meta

if __name__=='__main__':make_figures(Path(__file__).resolve().parent.parent)
