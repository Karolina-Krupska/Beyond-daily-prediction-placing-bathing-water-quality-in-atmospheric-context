STEP 6 | SEASONAL ORGANISATION OF MODEL-SELECTED DAYS

This standalone package uses the corrected Step 4 historical antecedent precipitation index (API) and the fitted models and calibrated probabilities from the corrected Step 5. The six simulated weather sequences, the model definitions, selection rules, tie priorities, bootstrap design and multiplicity adjustments follow the original analysis. Step 6 calculates seasonal metrics from those inputs. The bootstrap replicates, contrasts, intervals and publication figures are recalculated for this release.

Read the results
- START_HERE.html opens the publication figures and their source tables.
- reports/storyline_amendment/RESULTS.txt summarises the corrected storyline results. The before-and-after report is reports/api_update/comparison/STEP6_BEFORE_AND_AFTER.txt.
- figures/Storyline_comparisons/Main/Figure_G_Top10_Storyline_minus_baseline.pdf shows the main pooled comparison. The companion Figure_G_Matched16_Storyline_minus_baseline.pdf in the same folder compares seasons with sixteen model-selected days each.
- figures/Publication_selection/Main_paper/Figure_Three_WP_comparisons_Top10.pdf shows all three model comparisons.
- results/seasonal_summary.csv gives the seasonal outcomes for all eleven models. The primary pooled analysis selects the top 10% of days across all six equally sized storylines separately for each model, giving 459,000 of 4,590,000 evaluated days. The selected-day count can vary from one season to another. Other pooled fractions are 1%, 5%, 25% and 50%.
- results/inference/paired_tests.csv gives the 270 comparisons of models with and without the four-family weather pattern predictor. E-C compares rainfall models, F-J compares meteorology and wetness models, and G-K compares models using all numerical predictors.
- results/storyline_inference/all_contrasts.csv gives the 190 comparisons between altered storylines and baseline within models G and K. The 150 pooled comparisons and 40 equal-count comparisons form one Holm adjustment family, separate from the 270 model comparisons.
- results/matched_count_summary.csv gives seasonal outcomes at exactly 8 or 16 selected days per season. Equal counts allow clustering and maximum run length to be compared independently of differences in the number of selected days.
- results/inference/mean_confidence_intervals.csv gives conditional intervals for the means. Seasonal percentiles in seasonal_summary.csv describe variability between seasons.

Run the package
Extract the complete ZIP into a new folder. From that folder, install the versions listed in requirements.txt in a Python environment, then choose the command for your purpose.

  python rerun_step6_analysis.py --help
  python rerun_step6_analysis.py

The full numerical runner uses the included corrected inputs and writes a new run to a separate directory. It recalculates the seasonal and matched-count outcomes, the 4,000 whole-simulation-bundle bootstrap replicates, the 270 model comparisons and the 190 storyline comparisons. Previously fitted Step 5 models and the same Step 4 weather sequences are used throughout.

  python run_step6.py

The shorter command refreshes the 190 storyline comparisons, storyline figures and reports in an extracted package from its saved, corrected Step 6 seasonal records and bootstrap results. To check the saved storyline tables and figure sources, use python run_step6.py --verify-only.

Limitations
The interval and testing procedures quantify Monte Carlo uncertainty conditional on the fitted models, calibration, weather generator and historical data. Simulated model-selected days describe the timing of elevated modelled exceedance probabilities. The study did not evaluate operational warning decisions.
