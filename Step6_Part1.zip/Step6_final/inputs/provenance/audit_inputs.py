"""Verify the supplied corrected Step 4/5 ZIPs and the embedded Step 6 scientific inputs.

Usage: python inputs/provenance/audit_inputs.py Step4_API_corrected.zip Step5_API_corrected.zip
"""
from pathlib import Path
import argparse
import csv
import datetime as dt
import hashlib
import io
import json
import zipfile
import numpy as np


def digest(content):
    return hashlib.sha256(content).hexdigest()


def archive_hash(path):
    h = hashlib.sha256()
    with path.open('rb') as src:
        for block in iter(lambda: src.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def write_csv(path, rows):
    with path.open('w', newline='') as target:
        out = csv.DictWriter(target, fieldnames=rows[0]); out.writeheader(); out.writerows(rows)


def run(root, step4_path, step5_path):
    out = root/'inputs/provenance'
    sources = json.loads((out/'SOURCE_ARCHIVES.json').read_text())
    checked = json.loads((out/'REQUIRED_INPUTS.json').read_text())
    config = json.loads((root/'inputs/step5/config.json').read_text())
    registry = json.loads((root/'inputs/step5/model_registry.json').read_text())
    for path in (step4_path, step5_path):
        expected = sources[path.name]
        if expected['sha256'] != archive_hash(path) or expected['bytes'] != path.stat().st_size:
            raise ValueError(f'Archive differs from recorded release: {path.name}')
    comparisons, audit, probabilities, masks = [], [], [], []
    with zipfile.ZipFile(step5_path) as z5, zipfile.ZipFile(step4_path) as z4:
        for row in checked:
            rel = row['path'].removeprefix('inputs/step5/')
            member = 'Step5_final/' + rel
            data = z5.read(member); h = digest(data)
            if data != (root/row['path']).read_bytes() or h != row['sha256'] or len(data) != row['bytes']:
                raise ValueError(f'Embedded input differs from Step 5: {member}')
            if rel.startswith(('inputs/step4/', 'inputs/step4_evidence/')):
                source4 = 'Step4_final/' + rel.split('/', 2)[2]
                original = z4.read(source4)
                if data != original:
                    raise ValueError(f'Upstream Step 4/5 difference: {member}')
                comparisons.append(dict(step5_member=member,step4_member=source4,exists=True,
                    sha256_step5=h,sha256_step4=digest(original),byte_identical=True,bytes=len(data)))
        for name in ['INPUT_MANIFEST.csv','PACKAGE_MANIFEST.csv','ADDITIONAL_FIGURES_MANIFEST.csv']:
            rows = list(csv.DictReader(io.StringIO(z5.read('Step5_final/'+name).decode('utf-8-sig'))))
            for row in rows:
                rel = next(row[k] for k in ('relative_path','path','file') if k in row)
                if digest(z5.read('Step5_final/'+rel)) != row['sha256']:
                    raise ValueError(f'Step 5 source manifest mismatch in {name}: {rel}')
            audit.append(dict(manifest=name,n_records=len(rows),n_hash_matches=len(rows),errors=[]))
        for scenario in config['scenarios']:
            member = f'Step5_final/simulation_probabilities/{scenario}_probabilities.npz'
            with np.load(io.BytesIO(z5.read(member)), allow_pickle=False) as p:
                dates = p['evaluation_dates'].astype('datetime64[D]'); sims = p['sim']; models = list(p['models'])
                assert models == list(registry) and len(dates) == 153 and len(np.unique(sims)) == 5000
                assert np.all(np.diff(dates) == np.timedelta64(1,'D'))
                entry = dict(scenario=scenario,models=models,n_unique_sim_ids=len(np.unique(sims)),
                             date_first=str(dates[0]),date_last=str(dates[-1]),dates_consecutive=True)
                for key in ('p_raw','p_cal'):
                    v = p[key]; assert v.shape == (11,5000,153) and np.isfinite(v).all() and (0<=v).all() and (v<=1).all()
                    entry[key] = dict(shape=list(v.shape),dtype=str(v.dtype),min=float(v.min()),max=float(v.max()),all_finite=True)
                probabilities.append(entry)
        for letter in registry:
            previous = None
            for fraction in config['topk_budgets']:
                rule = f'topk_{round(fraction*100):02d}'
                path = root/f'inputs/step5/simulation_probabilities/selection_masks/{letter}_{rule}.npz'
                with np.load(path,allow_pickle=False) as z:
                    shape = tuple(map(int,z['shape'])); assert shape == (6,5000,153)
                    bits = np.unpackbits(z['packed'],bitorder=str(z['bitorder']))[:np.prod(shape)].astype(bool)
                    n = int(bits.sum()); expected = round(bits.size * fraction)
                    assert n == expected and (previous is None or np.all(~previous | bits))
                    masks.append(dict(model=letter,rule=rule,shape=str(shape),selected=n,expected=expected,exact_count=True,nested_vs_previous=True))
                    previous = bits
    report_path = out/'INPUT_PROVENANCE_AUDIT.json'
    audit_utc = json.loads(report_path.read_text())['audit_utc'] if report_path.exists() else dt.datetime.now(dt.timezone.utc).isoformat()
    report = dict(audit_utc=audit_utc,source_archives=sources,
        scope='Original Step 6 archive defines the scientific specification. All embedded Step 5 files and Step 4 inputs are verified against corrected releases.',
        config=config,model_registry=registry,embedded_step5_exact_members=len(checked),step4_nested_input_comparison=dict(n=len(comparisons),all_present=True,all_byte_identical=True),
        step5_manifest_audits=audit,simulation_probability_schema=probabilities,
        selection_mask_checks=dict(n_masks=len(masks),all_exact_count=True,all_nested=True),mismatches_found=[])
    write_csv(out/'selection_mask_inventory.csv',masks)
    write_csv(out/'step4_step5_input_hash_comparison.csv',comparisons)
    (out/'INPUT_PROVENANCE_AUDIT.json').write_text(json.dumps(report,indent=2)+'\n')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('step4',type=Path); parser.add_argument('step5',type=Path)
    args = parser.parse_args()
    r=run(Path(__file__).resolve().parents[2],args.step4,args.step5)
    print('Verified',r['embedded_step5_exact_members'],'embedded Step 5 files,',r['step4_nested_input_comparison']['n'],'corresponding Step 4 files and',r['selection_mask_checks']['n_masks'],'masks.')
