"""Audit and publish Step6 from saved results and draws only; no fitting or new simulations."""
from pathlib import Path
import sys,argparse,json,datetime,contextlib,unittest
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'code'))
class Tee:
 def __init__(self,*handles):self.handles=handles
 def write(self,s):
  for h in self.handles:h.write(s);h.flush()
 def flush(self):
  for h in self.handles:h.flush()
def run(root=ROOT,redraw_retained=True):
 root=Path(root).resolve();(root/'logs').mkdir(exist_ok=True)
 log=root/'logs'/('publication_revision_'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d_%H%M%S')+'.log')
 with log.open('w',encoding='utf-8') as h,contextlib.redirect_stdout(Tee(sys.stdout,h)),contextlib.redirect_stderr(Tee(sys.stderr,h)):
  print('Publication revision started',datetime.datetime.now(datetime.timezone.utc).isoformat())
  print('Saved data/draws only. No model fitting, recalibration, weather generation or new bootstrap draws.')
  from publication_matched_check import run as check_matched
  from publication_diagnostics import run as check_diagnostics
  check_matched(root);check_diagnostics(root)
  if redraw_retained:
   from inference_figures_step6 import make_inference_figures
   make_inference_figures(root)
   from publish_inference_figures import publish
   publish(root)
   # The legacy exporter writes an older main alias; remove its current marker so the new main replaces it cleanly.
   (root/'figures/Main_publication/PUBLICATION_REVISION.txt').unlink(missing_ok=True)
  from publication_revision_figures import make_figures
  make_figures(root)
  with (root/'logs/publication_unit_tests.log').open('w',encoding='utf-8') as unit:
   suite=unittest.defaultTestLoader.discover(str(root/'code'),pattern='test*.py')
   tests=unittest.TextTestRunner(stream=Tee(sys.stdout,unit),verbosity=2).run(suite)
  if not tests.wasSuccessful():raise RuntimeError('Unit tests failed')
  status={'status':'passed','tests_run':tests.testsRun,'log':'logs/publication_unit_tests.log','scope':'Implementation tests only; not interval-coverage or physical validation.'}
  (root/'results/publication_revision/UNIT_TEST_STATUS.json').write_text(json.dumps(status,indent=2))
  from verify_step6 import verify as verify_original
  from verify_inference_step6 import verify as verify_inference
  verify_original(root);verify_inference(root)
  from verify_publication_revision import verify
  verification=verify(root)
  from publication_reporting import write_reports
  write_reports(root)
  print('Publication revision completed',datetime.datetime.now(datetime.timezone.utc).isoformat())
  return verification
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=ROOT);p.add_argument('--skip-retained-redraw',action='store_true',help='Retain existing42supplementary displays; regenerate only main/matched/diagnostic figures.')
 a=p.parse_args();run(a.root,not a.skip_retained_redraw)
