"""Current Step6 entry point. In IDLE press F5; saved results and draws only."""
from run_storyline_amendment import ROOT,run
if __name__=='__main__':
 import argparse
 from pathlib import Path
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--root',type=Path,default=ROOT)
 p.add_argument('--verify-only',action='store_true')
 a=p.parse_args();run(a.root,a.verify_only)
