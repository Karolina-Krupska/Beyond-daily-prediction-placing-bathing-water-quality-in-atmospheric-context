from pathlib import Path
import pandas as pd,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator
ROOT=Path(__file__).resolve().parent;d=pd.read_csv(ROOT/'matched_three_pairs_source.csv',float_precision='round_trip');assert len(d)==72
stories=['baseline','persistent_wet','flip_wet_to_dry','dry_with_bursts','persistent_dry','flip_dry_to_wet'];labels=['Baseline','Persistent wet','Wet to dry','Dry with storm\noutbreaks','Persistent dry','Dry to wet'];pairs=['E-C','F-J','G-K']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False})
fig,axes=plt.subplots(3,2,figsize=(183/25.4,225/25.4),sharey=True);fig.subplots_adjust(left=.22,right=.97,top=.88,bottom=.12,hspace=.56,wspace=.37);y=np.arange(6)
for row,pair in enumerate(pairs):
 for col,metric in enumerate(['clusters','max_run_days']):
  ax=axes[row,col]
  for i in [0,2,4]:ax.axhspan(i-.48,i+.48,color='#F3F5F6',lw=0)
  ax.axvline(0,ls='--',color='#777777',lw=.7)
  for rule,offset,colour,marker in [('matched_05',-.13,'#0072B2','o'),('matched_10',.13,'#D55E00','D')]:
   v=d[(d.comparison==pair)&(d.metric==metric)&(d.rule==rule)].set_index('storyline').loc[stories]
   ax.hlines(y+offset,v.mc95_lower,v.mc95_upper,color=colour,lw=1.1);ax.plot(v.mean_difference,y+offset,marker,color=colour,ms=3.8)
  ax.set_yticks(y,labels);ax.tick_params(axis='y',length=0,pad=6,labelleft=col==0);ax.set_ylim(5.55,-.55);ax.grid(axis='x',color='#e4e4e4',lw=.5);ax.set_axisbelow(True);ax.spines['left'].set_visible(False);ax.xaxis.set_major_locator(MaxNLocator(nbins=4));ax.set_xlabel('Difference ('+('clusters' if col==0 else 'days')+')');ax.set_title(pair.replace('-',' − ')+': '+('selected-day clusters' if col==0 else 'maximum run'),loc='left',fontsize=8.5,pad=10);ax.text(-.07,1.12,chr(97+2*row+col),transform=ax.transAxes,fontweight='bold',fontsize=10)
fig.legend([Line2D([],[],marker='o',ls='none',color='#0072B2'),Line2D([],[],marker='D',ls='none',color='#D55E00')],['8 selected days per season','16 selected days per season'],loc='upper center',bbox_to_anchor=(.55,.98),ncol=2,frameon=False,fontsize=8)
fig.text(.22,.06,'Points: paired mean differences | Lines: 95% confidence intervals',fontsize=7)
fig.text(.22,.032,'Equal counts: 5.23% or 10.46% of 153 days; not pooled Top-5% or Top-10%.',fontsize=7)
for ext in ['png','pdf','svg']:fig.savefig(ROOT/f'Figure_Matched_all_three_pairs.{ext}',dpi=600)
