"""Redraw the main comparison using saved Top10 paired results only."""
from pathlib import Path
import numpy as np,pandas as pd,json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
from matplotlib.lines import Line2D
ROOT=Path(__file__).resolve().parent
pairs=['E-C','F-J','G-K'];metrics=['selected_days','clusters','max_run_days'];stories=['baseline','persistent_wet','flip_wet_to_dry','dry_with_bursts','persistent_dry','flip_dry_to_wet'];labels=['Baseline','Persistent wet','Wet to dry','Dry with storm\noutbreaks','Persistent dry','Dry to wet'];titles=['Model-selected days','Selected-day clusters','Maximum run length'];headers=['Rainfall\nE − C','Meteorology + memory\nF − J','Full hydrometeorology\nG − K'];colours=['#0072B2','#009E73','#D55E00']
d=pd.read_csv(ROOT/'paired_source_Top10.csv',float_precision='round_trip');assert len(d)==54 and not d.duplicated(['comparison','storyline','metric']).any()
registry=json.loads((ROOT/'model_registry.json').read_text())
for pair in pairs:
 hi,lo=pair.split('-');assert registry[hi]['numerical']==registry[lo]['numerical'];assert registry[hi]['categorical']==['family'] and registry[lo]['categorical']==[]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':7.5,'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False})
fig,axes=plt.subplots(3,3,figsize=(183/25.4,225/25.4),sharey=True);fig.subplots_adjust(left=.235,right=.95,top=.86,bottom=.14,wspace=.29,hspace=.57)
y=np.arange(6)
for row,metric in enumerate(metrics):
 b=d[d.metric==metric];lo=min(0,b.ci95_lower.min());hi=max(0,b.ci95_upper.max());span=hi-lo;lims=(lo-.12*span,hi+.12*span)
 for col,pair in enumerate(pairs):
  ax=axes[row,col];v=b[b.comparison==pair].set_index('storyline').loc[stories]
  for i in [0,2,4]:ax.axhspan(i-.48,i+.48,color='#F3F5F6',lw=0)
  ax.axvline(0,ls='--',lw=.75,color='#777777');ax.hlines(y,v.ci95_lower,v.ci95_upper,color=colours[col],lw=1.1);ax.plot(v.mean_difference,y,'o',ms=3.7,color=colours[col])
  for i,s in enumerate(stories):
   p=float(v.loc[s,'p_holm']);star='***' if p<.001 else '**' if p<.01 else '*' if p<.05 else 'ns'
   assert star==v.loc[s,'stars']
   flag=str(v.loc[s,'normal_approximation_flag']).lower() in ['true','1'];ax.text(1.035,i,star+('†' if flag else ''),transform=ax.get_yaxis_transform(),fontsize=6.3,ha='left',va='center')
  ax.set_yticks(y,labels);ax.tick_params(axis='y',length=0,pad=6,labelleft=(col==0));ax.set_ylim(5.55,-.55);ax.set_xlim(*lims);ax.xaxis.set_major_locator(MaxNLocator(nbins=3));ax.grid(axis='x',color='#e1e5e8',lw=.5);ax.set_axisbelow(True);ax.spines['left'].set_visible(False);ax.set_xlabel('Difference ('+('clusters' if metric=='clusters' else 'days')+')',fontsize=7)
  ax.set_title(titles[row],loc='left',fontsize=7.3,pad=9);ax.text(-.18,1.14,chr(97+3*row+col),transform=ax.transAxes,fontweight='bold',fontsize=10)
for col in range(3):
 p=axes[0,col].get_position();fig.text((p.x0+p.x1)/2,.925,headers[col],ha='center',va='center',fontsize=8.3,fontweight='bold')
fig.text(.235,.975,'Effect of adding WP at Top 10% selection',fontsize=11,fontweight='bold')
fig.text(.235,.065,'Points: paired mean differences | Lines: 95% confidence intervals',fontsize=7)
fig.text(.235,.041,'Holm-adjusted: * p < 0.05; ** < 0.01; *** < 0.001; ns: not significant',fontsize=6.5)
fig.text(.235,.018,'† Bootstrap diagnostic flag: interpret cautiously; see supplementary interval checks.',fontsize=6.5)
for ext in ['png','pdf','svg']:fig.savefig(ROOT/f'Figure_Three_WP_comparisons_Top10.{ext}',dpi=600)
fig.savefig(ROOT/'preview.png',dpi=150)
