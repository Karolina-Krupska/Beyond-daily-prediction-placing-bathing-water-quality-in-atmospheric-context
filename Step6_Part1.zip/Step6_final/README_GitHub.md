# Step 6 | Seasonal organisation of model-selected days

Open START_HERE.html for the main and supplementary storyline figures and their source tables. README.txt explains the analysis, selection rules and uncertainty estimates.

## Archive guide

Each ZIP opens independently. Extract the parts into the same parent directory, merging their Step6_final folders. Part 01 is the starting point for reading the analysis. It contains the Step 6 scripts, reports, seasonal records, summary tables and publication figure selection.

| Part | Contents |
| --- | --- |
| 02 | Saved model and storyline bootstrap draws |
| 03 | Inference figures, diagnostic figures and supplementary figures |
| 04 | Additional and earlier figure versions, and superseded material |
| 05 | Upstream fitted models, six simulated weather sequences, Step 5 code and reference results |
| 06 | Step 5 selection masks for the simulated days |
| 07 | Local historical inputs, including the bathing-water workbook, site-day reference table, classifications and prepared historical drivers |

## Reproducing the analysis

Combine all seven parts to restore the complete original distribution. Part 07 is a separate local input supplement. If it is withheld from the public repository, the original inputs at the paths and hashes listed in inputs/provenance/REQUIRED_INPUTS.json are required for a full rerun.

From Step6_final, install the pinned packages with `python -m pip install -r requirements.txt`. Run `python run_step6.py --verify-only` to check the saved results. Run `python rerun_step6_analysis.py` for the full numerical analysis, including 4,000 bootstrap replicates. The full runner creates a new output directory. Commands and figure-refresh options are described in README.txt.
