"""Current Step6: saved-result inference, figures, reporting and verification.

In IDLE open this file or run_step6.py and press F5. No models are fitted,
weather generated or new scientific bootstrap draws sampled.
"""
from pathlib import Path
import argparse
import contextlib
import datetime
import json
import sys
import unittest
ROOT=Path(__file__).resolve().parent


class Tee:
    def __init__(self,*streams):self.streams=streams
    def write(self,s):
        for stream in self.streams:stream.write(s);stream.flush()
        return len(s)
    def flush(self):
        for stream in self.streams:stream.flush()


def run(root=ROOT,verify_only=False):
    root=Path(root).resolve()
    sys.path.insert(0,str(root/'code'))
    from storyline_inference import run as analyse
    from verify_storyline_inference import verify
    from storyline_figures import run as draw
    from storyline_reporting import run as report
    from storyline_delivery import verify_figure_sources,current_reporting
    logs=root/'logs';logs.mkdir(exist_ok=True)
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d_%H%M%S')
    path=logs/f'storyline_full_workflow_{stamp}.log'
    with path.open('w',encoding='utf-8') as handle:
        with contextlib.redirect_stdout(Tee(sys.stdout,handle)),contextlib.redirect_stderr(Tee(sys.stderr,handle)):
            print('Current Step6 storyline amendment: saved data/draws only.',flush=True)
            if not verify_only:analyse(root)
            verify(root)
            if not verify_only:draw(root)
            verify_figure_sources(root)
            suite=unittest.defaultTestLoader.discover(str(root/'code'),pattern='test_*.py')
            tests=unittest.TextTestRunner(stream=sys.stdout,verbosity=2).run(suite)
            unit_status={'status':'passed' if tests.wasSuccessful() else 'failed',
                         'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
                         'tests_run':tests.testsRun,'failures':len(tests.failures),
                         'errors':len(tests.errors),'scientific_models_or_simulations_run':False}
            (root/'results/storyline_inference/UNIT_TEST_STATUS.json').write_text(json.dumps(unit_status,indent=2)+'\n')
            if not tests.wasSuccessful():raise RuntimeError('Unit checks failed; release not completed')
            report(root)
            result=current_reporting(root)
            print(json.dumps(result,indent=2),flush=True)
    print('Workflow log:',path)
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=ROOT)
    parser.add_argument('--verify-only',action='store_true')
    args=parser.parse_args()
    run(args.root,args.verify_only)
