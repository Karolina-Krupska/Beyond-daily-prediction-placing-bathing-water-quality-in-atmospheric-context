"""Recalculate Step 6 numerical outputs in a fresh directory using the bundled inputs."""
from pathlib import Path
import argparse
import os
import shutil
import sys

ROOT = Path(__file__).resolve().parent


def reproduce(destination, workers):
    if workers < 1:
        raise ValueError('Choose at least one worker.')
    destination = destination.resolve()
    if any(destination.is_relative_to(ROOT / folder) for folder in ('inputs', 'code')):
        raise ValueError('Choose an output directory outside inputs and code.')
    destination.mkdir(parents=True, exist_ok=False)
    for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
        os.environ[key] = '1'
    for folder in ('inputs', 'code'):
        shutil.copytree(ROOT / folder, destination / folder, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    shutil.copy2(ROOT / 'config.json', destination / 'config.json')
    sys.path.insert(0, str(destination / 'code'))
    from analysis_step6 import run as calculate_seasons
    from inference_step6 import run as calculate_model_comparisons
    from verify_inference_step6 import verify as verify_model_comparisons
    from storyline_inference import run as calculate_storyline_comparisons
    calculate_seasons(destination)
    calculate_model_comparisons(destination, workers=workers)
    verify_model_comparisons(destination, require_figures=False)
    calculate_storyline_comparisons(destination)

    import pandas as pd
    for name in ('seasonal_summary.csv', 'matched_count_summary.csv', 'inference/paired_tests.csv',
                 'storyline_inference/all_contrasts.csv'):
        saved = pd.read_csv(ROOT / 'results' / name, float_precision='round_trip')
        fresh = pd.read_csv(destination / 'results' / name, float_precision='round_trip')
        pd.testing.assert_frame_equal(saved, fresh, rtol=1e-10, atol=1e-12)
    print('Recalculated seasonal summaries and both families of tests match the delivered results.')
    print('Recalculated tables and draws:', destination / 'results')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT.parent / 'Step6_recalculated',
                        help='A new directory for the numerical rerun. Existing directories are preserved.')
    parser.add_argument('--workers', type=int, default=3)
    args = parser.parse_args()
    reproduce(args.output, args.workers)
