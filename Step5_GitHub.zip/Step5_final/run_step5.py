"""Rebuild Step 5 from corrected inputs; run all prespecified assessments."""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import argparse,json,sys,time,platform,importlib.metadata,warnings,hashlib,csv,shutil,datetime
import numpy as np,pandas as pd,joblib
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'code'))
from models import REGISTRY,LABELS,features,nested_loyo,fit_base,fit_calibrator
from prepare import prepare
from assessment import summarise,bootstrap_pairs,reliability

def main():
    global ROOT
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--resume',action='store_true');args=parser.parse_args()
    if (ROOT/'results/RUN_COMPLETION.json').exists() and not args.resume:
        original=ROOT;ROOT=original/'runs'/('Step5_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S'))
        ROOT.mkdir(parents=True)
        for name in ['inputs','code']:shutil.copytree(original/name,ROOT/name)
        for name in ['run_step5.py','export_probabilities.py','verify_results.py','config.json','INPUT_MANIFEST.csv','requirements.txt']:
            shutil.copy2(original/name,ROOT/name)
        print('New isolated run folder:',ROOT,flush=True)
    out=ROOT/'results';out.mkdir(parents=True,exist_ok=True)
    for record in csv.DictReader((ROOT/'INPUT_MANIFEST.csv').open()):
        p=ROOT/record['relative_path']
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=record['sha256']:
            raise ValueError('Input hash differs from the recorded authoritative version: '+str(p))
    signature=hashlib.sha256(b''.join((ROOT/p).read_bytes() for p in
        ['code/models.py','code/prepare.py','run_step5.py','INPUT_MANIFEST.csv','config.json'])).hexdigest()
    signature_file=ROOT/'results/FIT_CACHE_SIGNATURE.json'
    if args.resume and any((ROOT/'results').glob('oof_predictions_*.csv.gz')):
        if not signature_file.exists() or json.loads(signature_file.read_text())['sha256']!=signature:
            raise ValueError('Resume cache does not match the locked code, inputs and specification; start a fresh run.')
    signature_file.parent.mkdir(exist_ok=True,parents=True)
    signature_file.write_text(json.dumps({'sha256':signature,'scope':'fitting code, source manifest and specification'},indent=2))
    start=time.time();d,lag=prepare(ROOT,out)
    (ROOT/'model_registry.json').write_text(json.dumps({k:dict(label=LABELS[k],numerical=v[0],categorical=v[1]) for k,v in REGISTRY.items()},indent=2))
    allpred=[];allaudit=[]
    complete=d[features('G')].notna().all(axis=1)
    settings=[('primary',d,list(REGISTRY),'balanced'),('unweighted',d,list(REGISTRY),'unweighted'),
        ('complete_case',d.loc[complete].copy(),['C','E','F','G','J','K'],'balanced'),
        ('prior_day',lag,['G','K'],'balanced')]
    for name,frame,letters,weight in settings:
        path=out/f'oof_predictions_{name}.csv.gz';ap=out/f'fold_audit_{name}.csv'
        if args.resume and path.exists() and ap.exists():
            pred=pd.read_csv(path,parse_dates=['date'],float_precision='round_trip');audit=pd.read_csv(ap)
        else:
            pred,audit=nested_loyo(frame,letters,weight,name)
            pred.to_csv(path,index=False);audit.to_csv(ap,index=False)
        assert len(pred)==len(frame)*len(letters) and np.isfinite(pred[['p_raw','p_cal','score_raw']]).all().all()
        allpred.append(pred);allaudit.append(audit)
    predictions=pd.concat(allpred,ignore_index=True);summarise(predictions,out)
    bootstrap_pairs(predictions,out);reliability(predictions,out)
    # Fit each final model on all observed site-days. Calibration uses outer raw OOF scores.
    modeldir=ROOT/'fitted_models';modeldir.mkdir(exist_ok=True)
    primary=allpred[0]
    for letter in REGISTRY:
        g=primary[primary.model.eq(letter)].sort_values('row_id')
        assert np.array_equal(g.row_id,d.row_id)
        final=fit_base(d,letter,'balanced');cal=fit_calibrator(g.score_raw.to_numpy(),g.y_exceed)
        joblib.dump(dict(base=final,calibrator=cal,features=features(letter),model=letter),modeldir/f'{letter}.joblib')
    from storylines import run_storylines
    run_storylines(ROOT,out)
    from figures import make_figures
    make_figures(ROOT,out)
    metadata=dict(status='completed',elapsed_seconds=time.time()-start,seed=42,
      bootstrap_replicates=4000,outer_years=13,settings=[s[0] for s in settings],
      software={k:importlib.metadata.version(k) for k in ['numpy','pandas','scikit-learn','scipy','matplotlib','openpyxl','joblib']},
      python=platform.python_version(),interpretation='Retrospective regional site-day predictions; not operational forecast validation')
    (out/'RUN_COMPLETION.json').write_text(json.dumps(metadata,indent=2))
    print('ALL STEP 5 TASKS COMPLETED',metadata,flush=True)
if __name__=='__main__':main()
