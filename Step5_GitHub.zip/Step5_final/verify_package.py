"""Read-only verification of every file listed in this package's SHA-256 inventory."""
from pathlib import Path
import csv,hashlib
root=Path(__file__).resolve().parent
items=list(csv.DictReader((root/'PACKAGE_MANIFEST.csv').open(encoding='utf-8',newline='')))
failed=[]
for item in items:
    p=root/item['relative_path']
    if not p.is_file() or p.stat().st_size!=int(item['bytes']) or hashlib.sha256(p.read_bytes()).hexdigest()!=item['sha256']:
        failed.append(item['relative_path'])
if failed:raise SystemExit('Package verification failed: '+', '.join(failed))
print(f'PASS: all {len(items)} listed files match their recorded sizes and hashes.')
