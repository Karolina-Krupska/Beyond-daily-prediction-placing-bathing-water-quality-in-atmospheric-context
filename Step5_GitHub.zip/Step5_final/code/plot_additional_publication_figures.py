"""Combine saved final Step 5 results. No model fitting or simulation generation."""
from pathlib import Path
import argparse
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from sklearn.metrics import roc_curve,roc_auc_score

def plot(results,output):
    output.mkdir(parents=True,exist_ok=True)
    pooled=pd.read_csv(results/'performance_pooled.csv')
    oof=pd.read_csv(results/'oof_predictions_primary.csv.gz',float_precision='round_trip')
    intervals=pd.read_csv(results/'paired_bootstrap_intervals.csv')
    differences=pd.read_csv(results/'storyline_paired_model_differences.csv')
    names=['Intensity','Depth','Rainfall','WP','Rainfall + WP',
        'Met + memory + WP','Full + WP','Soil + rainfall memory',
        'Meteorology','Met + memory','Full without WP']
    colors=['#555555','#E69F00','#0072B2','#CC79A7','#0072B2',
        '#009E73','#D55E00','#882255','#56B4E9','#009E73','#D55E00']
    styles=[':','-','-','-','--','--','-','-.','-','-','--']
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.titlesize':11,
        'axes.labelsize':9,'axes.spines.top':False,'axes.spines.right':False,
        'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none'})
    fig=plt.figure(figsize=(12.8,14.2),layout='constrained')
    fig.get_layout_engine().set(h_pad=.20,w_pad=.12,hspace=.16,wspace=.12)
    gs=fig.add_gridspec(3,1,height_ratios=[1.35,.85,1.15],hspace=.24)
    top=gs[0].subgridspec(1,3,width_ratios=[1.15,.85,1.0],wspace=.16)
    roc=fig.add_subplot(top[0]);legend=fig.add_subplot(top[1]);brier=fig.add_subplot(top[2])
    handles=[]
    for letter,name,color,style in zip('ABCDEFGHIJK',names,colors,styles):
        g=oof[oof.model.eq(letter)];fpr,tpr,_=roc_curve(g.y_exceed,g.p_raw)
        auc=roc_auc_score(g.y_exceed,g.p_raw)
        roc.plot(fpr,tpr,color=color,ls=style,lw=1.35,alpha=.95)
        handles.append(Line2D([0],[0],color=color,ls=style,lw=1.6,label=f'{letter}  {name} ({auc:.3f})'))
    roc.plot([0,1],[0,1],color='.65',ls='--',lw=.8)
    roc.set(xlim=(0,1),ylim=(0,1),xlabel='False positive rate',ylabel='True positive rate')
    roc.set_title('a  Daily discrimination',loc='left',fontweight='bold',pad=10)
    legend.axis('off');legend.legend(handles=handles,loc='center',frameon=False,
        fontsize=7.7,handlelength=2.2,labelspacing=.85,title='Model and pooled raw AUC',title_fontsize=8)
    current=pooled[(pooled.setting=='primary')&(pooled.probability=='calibrated')].set_index('model').reindex(list('ABCDEFGHIJK'))
    y=np.arange(11)
    for j,color in enumerate(colors):brier.plot(current.brier.iloc[j],j,'o',color=color,ms=5)
    reference=pooled[(pooled.setting=='primary')&(pooled.probability=='prevalence')].brier.iloc[0]
    brier.axvline(reference,color='.5',ls='--',lw=.9)
    brier.set_yticks(y,list('ABCDEFGHIJK'));brier.invert_yaxis()
    brier.grid(axis='x',alpha=.15);brier.set_xlabel('Calibrated Brier score (lower is better)')
    brier.set_title('b  Probability accuracy',loc='left',fontweight='bold',pad=10)
    brier.text(.98,.025,'Dashed: training-prevalence benchmark',transform=brier.transAxes,
        ha='right',va='bottom',fontsize=6.7)
    middle=gs[1].subgridspec(1,2,wspace=.24)
    for ix,(metric,kind,title,xlabel) in enumerate([
        ('delta_auc','raw','c  Incremental discrimination','Raw AUC difference: with WP − without WP'),
        ('brier_improvement','calibrated','d  Incremental probability accuracy','Calibrated Brier improvement: without WP − with WP')]):
        ax=fig.add_subplot(middle[ix])
        v=intervals[(intervals.setting=='primary')&(intervals.metric==metric)&(intervals.probability==kind)].set_index('comparison').reindex(['E-C','F-J','G-K'])
        yy=np.arange(3);ax.hlines(yy,v.ci_lower,v.ci_upper,color='#0072B2',lw=1.8)
        ax.plot(v.estimate,yy,'o',color='#0072B2',ms=5);ax.axvline(0,ls='--',color='.5',lw=.9)
        ax.set_yticks(yy,['E − C: rainfall','F − J: met + memory','G − K: full model'])
        ax.set_ylim(2.6,-.6);ax.set_xlabel(xlabel);ax.set_title(title,loc='left',fontweight='bold',pad=10)
        ax.grid(axis='x',alpha=.12);ax.ticklabel_format(axis='x',style='plain',useOffset=False)
    bottom=gs[2].subgridspec(1,3,wspace=.20)
    cases=['baseline','persistent_wet','persistent_dry','dry_with_bursts','flip_wet_to_dry','flip_dry_to_wet']
    labels=['Baseline','Persistent wet','Persistent dry','Dry with bursts','Wet → dry','Dry → wet']
    budgets=['topk_01','topk_05','topk_10','topk_25','topk_50']
    for j,(metric,title,unit) in enumerate([
       ('selected_days','e  Selected days','days'),('clusters','f  Clusters','clusters'),
       ('max_run_days','g  Maximum run length','days')]):
        ax=fig.add_subplot(bottom[j]);d=differences[(differences.comparison=='G-K')&differences.metric.eq(metric)&differences.rule.isin(budgets)]
        matrix=d.pivot(index='storyline',columns='rule',values='mean_difference').reindex(index=cases,columns=budgets).to_numpy()
        bound=max(np.abs(matrix).max(),.01)
        im=ax.imshow(matrix,cmap='BrBG',vmin=-bound,vmax=bound,aspect='auto')
        for row in range(6):
            for col in range(5):
                value=matrix[row,col];label=f'{value:.2f}' if abs(value)>=.005 else '0.00'
                ax.text(col,row,label,ha='center',va='center',fontsize=7.5,
                    color='white' if abs(value)>.65*bound else '#111111')
        ax.set_xticks(range(5),['1','5','10','25','50']);ax.set_yticks(range(6),labels if j==0 else ['']*6)
        ax.set_xlabel('Pooled selection budget (%)');ax.set_title(title,loc='left',fontweight='bold',pad=10)
        cb=fig.colorbar(im,ax=ax,location='bottom',shrink=.86,pad=.10,aspect=25)
        cb.set_label(f'Mean G − K difference ({unit})',fontsize=8);cb.ax.tick_params(labelsize=7)
    for suffix in ['png','pdf','svg']:
        fig.savefig(output/f'Figure_Step5_combined.{suffix}',dpi=600,bbox_inches='tight',facecolor='white')
    plt.close(fig)
    caption=(
      'Combined Step 5 evaluation of intestinal enterococci exceedance models. '
      '(a) Pooled outer leave-one-year-out ROC curves for all eleven models; the external legend gives raw AUC. '
      '(b) Calibrated Brier scores; the dashed line is the training-only prevalence benchmark. '
      '(c,d) Prespecified incremental weather-pattern-family comparisons. Lines show pointwise 95% whole-year '
      'percentile bootstrap intervals from 4,000 resamples of fixed out-of-fold predictions; positive values favour WP. '
      'These intervals do not propagate full model-refitting uncertainty and are not multiplicity-adjusted. '
      '(e–g) Mean paired G−K differences in model-selected-day metrics across six synthetic scenarios, '
      'each with 5,000 seasons and 153 evaluation days. Each model’s selection budget is pooled across all '
      '4,590,000 scenario days; individual scenario totals can differ. Colours and cell values do not indicate '
      'statistical significance. Memory includes soil moisture and rainfall-memory predictors. '
      'The analysis uses 35,518 observed site-days from 194 sites. It is retrospective; simulated selections '
      'are not issued advisories or observed contamination episodes. Heatmaps use separate zero-centred scales with labelled units. '
      'All panels derive from saved final Step 5 results; no models were refitted or simulations regenerated.\n')
    (output/'Figure_Step5_combined_caption.txt').write_text(caption,encoding='utf-8')

def plot_all_models_roc(results,output):
    """Plot stored out-of-fold predictions only. No fitting."""
    oof=pd.read_csv(results/'oof_predictions_primary.csv.gz',float_precision='round_trip')
    expected=pd.read_csv(results/'performance_pooled.csv')
    expected=expected[(expected.setting=='primary')&(expected.probability=='raw')].set_index('model')
    letters=list('ABCDEFGHIJK')
    names=['Intensity','Depth','Rainfall','WP','Rainfall + WP',
        'Met + memory + WP','Full + WP','Soil + rainfall memory',
        'Meteorology','Met + memory','Full without WP']
    colors=['#555555','#E69F00','#0072B2','#CC79A7','#0072B2',
        '#009E73','#D55E00','#882255','#56B4E9','#009E73','#D55E00']
    styles=[':','-','-','-','--','--','-','-.','-','-','--']
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,
        'axes.spines.top':False,'axes.spines.right':False,
        'pdf.fonttype':42,'svg.fonttype':'none'})
    fig,ax=plt.subplots(figsize=(10.4,6.2),layout='constrained')
    for letter,name,color,style in zip(letters,names,colors,styles):
        g=oof[oof.model.eq(letter)]
        assert len(g)==35518 and not g.row_id.duplicated().any()
        score=roc_auc_score(g.y_exceed,g.p_raw)
        np.testing.assert_allclose(score,expected.loc[letter,'auc'],rtol=0,atol=1e-12)
        fpr,tpr,_=roc_curve(g.y_exceed,g.p_raw)
        ax.plot(fpr,tpr,color=color,ls=style,lw=1.55,
            label=f'{letter}: {name} (AUC = {score:.3f})')
    ax.plot([0,1],[0,1],color='.55',ls='--',lw=1.0,zorder=0)
    ax.set(xlim=(0,1),ylim=(0,1),xlabel='False positive rate',ylabel='True positive rate')
    ax.set_aspect('equal',adjustable='box')
    ax.set_title('ROC curves: observed IE threshold exceedances',loc='left',fontsize=12,pad=12)
    ax.legend(loc='center left',bbox_to_anchor=(1.04,.5),frameon=False,fontsize=9,
        title='Models A–K: pooled outer-LOYO predictions',title_fontsize=9.5,
        handlelength=2.8,labelspacing=1.0)
    for suffix in ['png','pdf','svg']:
        fig.savefig(output/f'Figure_Step5_ROC_all_models.{suffix}',dpi=600,bbox_inches='tight',facecolor='white')
    plt.close(fig)

if __name__=='__main__':
    root=Path(__file__).resolve().parents[1]
    p=argparse.ArgumentParser(description='Regenerate only the two additional publication figures from saved final Step 5 results.')
    p.add_argument('--results',type=Path,default=root/'results')
    p.add_argument('--output',type=Path,default=root/'figures')
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    plot(a.results,a.output)
    plot_all_models_roc(a.results,a.output)
