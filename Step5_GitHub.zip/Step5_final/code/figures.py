"""Publication figures generated exclusively from this run's tables."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np,pandas as pd
from models import REGISTRY,LABELS,PAIRS
from storylines import STORIES
COLORS=['#0072B2','#D55E00','#009E73','#CC79A7']

def save(fig,folder,name):
    fig.tight_layout()
    for ext in ['png','pdf','svg']:fig.savefig(folder/f'{name}.{ext}',dpi=600,bbox_inches='tight')
    plt.close(fig)

def depth_table(d,out):
    edges=[0,.2,.5,1,2,3,5,8,12,20,np.inf]
    labels=['0–0.2','0.2–0.5','0.5–1','1–2','2–3','3–5','5–8','8–12','12–20','>20']
    use=d[d.depth_mm.notna()].copy();use['bin']=pd.cut(use.depth_mm,edges,labels=labels,include_lowest=True)
    years=np.sort(d.year.unique());weights=np.random.default_rng(4253).multinomial(len(years),np.ones(len(years))/len(years),size=4000)
    rows=[]
    for family in sorted(d.family.unique()):
      for i,label in enumerate(labels):
        g=use[use.family.eq(family)&use['bin'].eq(label)]
        ns=g.groupby('year').size().reindex(years,fill_value=0).to_numpy()
        es=g.groupby('year').y_exceed.sum().reindex(years,fill_value=0).to_numpy()
        den=weights@ns;v=np.divide(weights@es,den,out=np.full(4000,np.nan),where=den>0)
        lo,hi=np.nanquantile(v,[.025,.975]) if len(g) else [np.nan,np.nan]
        rows.append(dict(family=family,bin=label,bin_order=i,n=len(g),exceedances=g.y_exceed.sum(),
          fraction=g.y_exceed.mean(),ci_lower=lo,ci_upper=hi,bootstrap_defined=int(np.isfinite(v).sum()),sparse=len(g)<30))
    table=pd.DataFrame(rows);table.to_csv(out/'rainfall_bin_exceedance.csv',index=False);return table

def make_figures(root,out):
    folder=root/'figures';folder.mkdir(exist_ok=True)
    plt.rcParams.update({'font.size':8,'axes.spines.top':False,'axes.spines.right':False,
        'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','axes.titlesize':9})
    pooled=pd.read_csv(out/'performance_pooled.csv');annual=pd.read_csv(out/'performance_by_year.csv')
    p=pooled[pooled.setting.eq('primary')];letters=list(REGISTRY);y=np.arange(11)
    fig,axes=plt.subplots(1,2,figsize=(7.2,4.0))
    for ax,kind,metric,title in [(axes[0],'raw','auc','a  Discrimination'),(axes[1],'calibrated','brier','b  Probability error')]:
        v=p[p.probability.eq(kind)].set_index('model').reindex(letters)
        ax.plot(v[metric],y,'o',color=COLORS[0],ms=4);ax.set_yticks(y,[f'{k}  {LABELS[k]}' for k in letters]);ax.invert_yaxis()
        ax.set_title(title,loc='left');ax.grid(axis='x',alpha=.15)
        if metric=='auc':ax.axvline(.5,ls='--',lw=.8,color='.5');ax.set_xlabel('Pooled raw out-of-fold AUC')
        else:
            ref=p[p.probability.eq('prevalence')].brier.iloc[0];ax.axvline(ref,ls='--',lw=.8,color='.5')
            ax.set_xlabel('Pooled calibrated Brier score');ax.text(.98,.02,'Dashed: training-prevalence benchmark',transform=ax.transAxes,ha='right',fontsize=6)
    save(fig,folder,'Figure_1_model_performance')
    fig,ax=plt.subplots(figsize=(7.2,3.7));g=annual[(annual.setting=='primary')&(annual.probability=='raw')]
    ax.boxplot([g.loc[g.model.eq(k),'auc'].dropna() for k in letters],showmeans=True,
       meanprops={'marker':'o','markerfacecolor':COLORS[0],'markeredgecolor':COLORS[0],'markersize':3})
    ax.set_xticks(np.arange(1,12),letters);ax.axhline(.5,ls='--',lw=.8,color='.5');ax.set_ylabel('Held-out-year AUC');ax.set_xlabel('Model')
    ax.grid(axis='y',alpha=.15);save(fig,folder,'Figure_2_annual_AUC')
    b=pd.read_csv(out/'paired_bootstrap_intervals.csv');b=b[b.setting.eq('primary')]
    fig,axes=plt.subplots(1,2,figsize=(7.2,2.7))
    for ax,metric,kind,title in [(axes[0],'delta_auc','raw','a  AUC improvement'),(axes[1],'brier_improvement','calibrated','b  Brier improvement')]:
        v=b[(b.metric==metric)&(b.probability==kind)].set_index('comparison').reindex(['E-C','F-J','G-K'])
        yy=np.arange(3);ax.hlines(yy,v.ci_lower,v.ci_upper,color=COLORS[0]);ax.plot(v.estimate,yy,'o',color=COLORS[0],ms=4)
        ax.axvline(0,ls='--',lw=.8,color='.5');ax.set_yticks(yy,v.index);ax.invert_yaxis();ax.set_title(title,loc='left');ax.set_xlabel('With WP minus without WP benefit')
    save(fig,folder,'Figure_3_paired_WP_comparisons')
    from sklearn.metrics import roc_curve,roc_auc_score
    oof=pd.read_csv(out/'oof_predictions_primary.csv.gz',float_precision='round_trip')
    fig,axes=plt.subplots(1,3,figsize=(7.2,2.7))
    for ax,(wp,base),letter in zip(axes,PAIRS,'abc'):
        for model,color in [(base,COLORS[1]),(wp,COLORS[0])]:
            v=oof[oof.model.eq(model)];fpr,tpr,_=roc_curve(v.y_exceed,v.p_raw)
            ax.plot(fpr,tpr,lw=1,color=color,label=f'{model}: AUC {roc_auc_score(v.y_exceed,v.p_raw):.3f}')
        ax.plot([0,1],[0,1],'--',lw=.6,color='.5');ax.set(xlim=(0,1),ylim=(0,1),xlabel='False positive rate',ylabel='True positive rate')
        ax.set_title(f'{letter}  {wp} versus {base}',loc='left');ax.legend(fontsize=6,loc='lower right',frameon=False)
    save(fig,folder,'Figure_S4_ROC_key_pairs')
    rel=pd.read_csv(out/'reliability_bins.csv')
    fig,axes=plt.subplots(2,3,figsize=(7.2,4.9))
    for row,kind in enumerate(['raw','calibrated']):
      for col,(wp,base) in enumerate(PAIRS):
        ax=axes[row,col]
        for letter,color in [(base,COLORS[1]),(wp,COLORS[0])]:
            v=rel[(rel.model==letter)&(rel.probability==kind)]
            ax.errorbar(v.predicted,v.observed,yerr=[v.observed-v.ci_lower,v.ci_upper-v.observed],fmt='o-',ms=2.8,lw=.9,elinewidth=.5,color=color,label=f'{letter}: {LABELS[letter]}')
        v=rel[rel.model.isin([wp,base])&rel.probability.eq(kind)]
        lim=max(.35,float(max(v.predicted.max(),v.ci_upper.max()))*1.08)
        ax.plot([0,lim],[0,lim],'--',color='.5',lw=.7);ax.set(xlim=(0,lim),ylim=(0,lim))
        ax.set_title(f'{chr(97+row*3+col)}  {wp} versus {base}: {kind}',loc='left')
        ax.set_xlabel('Mean predicted probability');ax.set_ylabel('Observed fraction');ax.legend(fontsize=5.5,loc='upper left',frameon=False)
    save(fig,folder,'Figure_4_calibration_key_pairs')
    fig,axes=plt.subplots(3,4,figsize=(7.2,6.3))
    for ax,letter in zip(axes.ravel(),letters):
        v=rel[(rel.model==letter)&(rel.probability=='calibrated')];lim=max(.35,float(max(v.predicted.max(),v.ci_upper.max()))*1.08)
        ax.errorbar(v.predicted,v.observed,yerr=[v.observed-v.ci_lower,v.ci_upper-v.observed],fmt='o-',ms=2,lw=.7,elinewidth=.5,color=COLORS[0])
        ax.plot([0,lim],[0,lim],'--',lw=.6,color='.5');ax.set(xlim=(0,lim),ylim=(0,lim));ax.set_title(f'{letter}: {LABELS[letter]}',fontsize=7)
        ax.set_xlabel('Predicted',fontsize=7);ax.set_ylabel('Observed',fontsize=7)
    axes.ravel()[-1].set_visible(False);save(fig,folder,'Figure_S1_calibration_all_models')
    d=pd.read_csv(out/'modelling_dataset.csv');tab=depth_table(d,out)
    fig,axes=plt.subplots(2,2,figsize=(7.2,5.0))
    for ax,(family,g),color in zip(axes.ravel(),tab.groupby('family',sort=True),COLORS):
        good=g[g.n.gt(0)]
        ax.vlines(good.bin_order,good.ci_lower,good.ci_upper,color=color,lw=.7)
        for _,r in good.iterrows():
            ax.plot(r.bin_order,r.fraction,'o',ms=4,markerfacecolor='white' if r['sparse'] else color,markeredgecolor=color)
            ax.annotate(f'n={r.n}',(r.bin_order,r.ci_upper),xytext=(0,3),textcoords='offset points',ha='center',fontsize=6,rotation=45)
        ax.set_xticks(g.bin_order,g['bin'],rotation=50,ha='right',fontsize=6)
        ax.set_title(family,loc='left',fontsize=8);ax.set_ylim(-.02,min(1.08,max(.45,good.ci_upper.max()+.15)))
        ax.set_ylabel('IE exceedance fraction');ax.set_xlabel('Regional daily depth bin (mm)')
    save(fig,folder,'Figure_5_depth_exceedance_by_family')
    diff=pd.read_csv(out/'storyline_paired_model_differences.csv')
    cases=['Baseline','Persistent wet','Persistent dry','Dry with bursts','Wet to dry','Dry to wet']
    for pair,name in [('G-K','Figure_6_full_model_temporal_comparison'),('E-C','Figure_S2_rainfall_temporal_comparison'),('F-J','Figure_S3_met_memory_temporal_comparison')]:
      fig,axes=plt.subplots(1,3,figsize=(7.2,3.2))
      for j,(ax,metric) in enumerate(zip(axes,['selected_days','clusters','max_run_days'])):
        v=diff[(diff.comparison==pair)&(diff.metric==metric)&diff.rule.str.startswith('topk')]
        matrix=v.pivot(index='storyline',columns='rule',values='mean_difference').reindex(index=STORIES,columns=['topk_01','topk_05','topk_10','topk_25','topk_50'])
        a=matrix.to_numpy();limit=max(abs(a).max(),.01);im=ax.imshow(a,cmap='BrBG',vmin=-limit,vmax=limit,aspect='auto')
        for ii in range(6):
          for jj in range(5):
            label=f'{a[ii,jj]:.2f}' if abs(a[ii,jj])>=.005 else '0.00'
            ax.text(jj,ii,label,ha='center',va='center',fontsize=6,color='white' if abs(a[ii,jj])>.65*limit else 'black')
        ax.set_xticks(range(5),['1','5','10','25','50']);ax.set_yticks(range(6),cases if j==0 else ['']*6)
        ax.set_title(f'{chr(97+j)}  {metric.replace("_"," ")}',loc='left',fontsize=8);ax.set_xlabel('Pooled selection budget (%)')
        fig.colorbar(im,ax=ax,shrink=.7,label=f'Mean {pair} difference')
      save(fig,folder,name)
    (root/'FIGURE_CAPTIONS.txt').write_text(
      'All plots are newly generated from the current numerical tables. PNG:600 dpi; PDF/SVG:vector text.\n\n'
      'Figure 1. Pooled primary outer-LOYO performance. Panel a uses raw probabilities; panel b uses calibrated probabilities. '
      'The dashed Brier reference is the training-only prevalence benchmark. Points are estimates without individual-model confidence intervals.\n\n'
      'Figure 2. Annual raw AUC distributions across held-out years. Boxes show quartiles and medians, circles mark means; '
      'whiskers follow the standard 1.5 IQR rule. They are not confidence intervals. The dashed line marks AUC0.5.\n\n'
      'Figure 3. Prespecified incremental weather-pattern comparisons. AUC uses raw scores; Brier uses calibrated probabilities. '
      'Lines are pointwise95% whole-year percentile bootstrap intervals from4000 resamples of fixed out-of-fold predictions. '
      'They do not propagate full refitting uncertainty; training folds overlap. Positive differences favour WP.\n\n'
      'Figure S4. Raw out-of-fold ROC curves for the three prespecified pairs, with pooled AUC estimates.\n\n'
      'Figure 4 and S1. Reliability diagrams from outer-held-out predictions. Quantile bins keep tied scores together. '
      'Vertical lines are pointwise95% whole-year bootstrap intervals for observed bin fractions, with fixed prediction bins. '
      'The diagonal is perfect agreement; bin counts are in reliability_bins.csv. Axis ranges are explicitly limited to displayed support.\n\n'
      'Figure 5. Observed site-day exceedance fractions by rainfall-depth bin and weather-pattern family. '
      'Pointwise95% intervals resample whole years. Open points identify bins with fewer than30 site-days; empty bins are absent. '
      'Counts are shown; points are not joined. The upper bin includes depth>20mm. These are descriptive, unadjusted associations.\n\n'
      'Figure 6 and S2–S3. Mean paired differences in model-selected-day metrics under pooled Top-k budgets, '
      'using5000 synthetic seasons in each of six scenarios. The same simulation identifiers are paired between models. '
      'Selected-day totals may differ by scenario because only the pooled fraction is fixed. These are model comparisons, '
      'not observed contamination episodes or actual issued warnings. Conditional simulation ranges and Monte Carlo SEs '
      'are in storyline_paired_model_differences.csv; heatmap colours alone imply no significance test.\n',encoding='utf-8')

if __name__=='__main__':
    from pathlib import Path
    r=Path(__file__).resolve().parents[1];make_figures(r,r/'results')
