"""Out-of-fold diagnostics and conditional whole-year paired bootstrap intervals."""
import numpy as np
import pandas as pd
from scipy.special import expit,logit
from scipy.optimize import minimize,brentq
from sklearn.metrics import roc_auc_score,brier_score_loss
from models import PAIRS

def calibration_diagnostics(y,p):
    x=logit(np.clip(p,1e-12,1-1e-12));y=np.asarray(y)
    intercept=brentq(lambda a:np.mean(expit(x+a))-np.mean(y),-50,50) if 0<np.mean(y)<1 else np.nan
    if np.std(x)<1e-10 or len(np.unique(y))<2:return intercept,np.nan,np.nan
    def fn(b):
        s=b[0]+b[1]*x;err=expit(s)-y
        return np.mean(np.logaddexp(0,s)-y*s),np.array([err.mean(),np.mean(err*x)])
    fit=minimize(fn,[0.,1.],jac=True,method='BFGS',options={'gtol':1e-8})
    if not fit.success and np.linalg.norm(fit.jac)>1e-5:return intercept,np.nan,np.nan
    return intercept,float(fit.x[0]),float(fit.x[1])

def metrics(y,p):
    return dict(auc=roc_auc_score(y,p) if len(np.unique(y))==2 else np.nan,
        brier=brier_score_loss(y,p),n=len(y),exceedances=int(np.sum(y)))

def summarise(pred,out):
    rows=[];annual=[]
    for (setting,model),g in pred.groupby(['setting','model'],sort=False):
        for kind,col in [('raw','p_raw'),('calibrated','p_cal'),('prevalence','p_prevalence')]:
            m=metrics(g.y_exceed,g[col]);ci,cj,cs=calibration_diagnostics(g.y_exceed,g[col])
            rows.append(dict(setting=setting,model=model,probability=kind,**m,
                calibration_intercept_offset=ci,calibration_joint_intercept=cj,calibration_slope=cs))
            for year,a in g.groupby('year'):
                annual.append(dict(setting=setting,model=model,probability=kind,year=year,**metrics(a.y_exceed,a[col])))
    pooled=pd.DataFrame(rows);yearly=pd.DataFrame(annual)
    pooled.to_csv(out/'performance_pooled.csv',index=False);yearly.to_csv(out/'performance_by_year.csv',index=False)
    yr=yearly.groupby(['setting','model','probability']).agg(n_years=('year','size'),
      annual_auc_mean=('auc','mean'),annual_auc_sd=('auc','std'),annual_auc_min=('auc','min'),annual_auc_max=('auc','max'),
      annual_brier_mean=('brier','mean'),annual_brier_sd=('brier','std')).reset_index()
    yr.to_csv(out/'performance_annual_summary.csv',index=False)
    paired=[]
    for setting in yearly.setting.unique():
      for wp,base in PAIRS:
       for kind in ['raw','calibrated']:
        a=yearly.query('setting==@setting and model==@wp and probability==@kind').set_index('year')
        b=yearly.query('setting==@setting and model==@base and probability==@kind').set_index('year')
        for y in sorted(set(a.index)&set(b.index)):
         paired.append(dict(setting=setting,comparison=f'{wp}-{base}',probability=kind,year=y,
          delta_auc=a.loc[y,'auc']-b.loc[y,'auc'],brier_improvement=b.loc[y,'brier']-a.loc[y,'brier']))
    pd.DataFrame(paired).to_csv(out/'paired_differences_by_year.csv',index=False)
    return pooled,yearly

def weighted_auc_by_year(y,p,year,years,weights):
    """Exact pooled AUC for repeated whole-year rows, including tied scores."""
    unique,inverse=np.unique(p,return_inverse=True);pos=np.zeros((len(years),len(unique)));neg=pos.copy()
    indices=pd.Index(years).get_indexer(year)
    np.add.at(pos,(indices,inverse),np.asarray(y));np.add.at(neg,(indices,inverse),1-np.asarray(y))
    values=[]
    for start in range(0,len(weights),200):
        a=weights[start:start+200]@pos;b=weights[start:start+200]@neg
        den=a.sum(axis=1)*b.sum(axis=1)
        values.extend(np.divide(np.sum(a*(np.cumsum(b,axis=1)-.5*b),axis=1),den,
            out=np.full(len(a),np.nan),where=den>0))
    return np.asarray(values)

def bootstrap_pairs(pred,out,n=4000,seed=42):
    records=[]
    for setting,g in pred.groupby('setting',sort=False):
      years=np.sort(g.year.unique());w=np.random.default_rng(np.random.SeedSequence([seed,5,len(years)])).multinomial(len(years),np.ones(len(years))/len(years),size=n)
      pd.DataFrame(w,columns=years).to_csv(out/f'bootstrap_year_weights_{setting}.csv',index=False)
      for wp,base in PAIRS:
       a=g[g.model.eq(wp)].sort_values('row_id');b=g[g.model.eq(base)].sort_values('row_id')
       if len(a)==0 or len(b)==0:continue
       assert np.array_equal(a.row_id,b.row_id) and np.array_equal(a.y_exceed,b.y_exceed)
       y=a.y_exceed.to_numpy();yr=a.year.to_numpy();yi=pd.Index(years).get_indexer(yr)
       ns=np.bincount(yi,minlength=len(years));den=w@ns
       for kind,col in [('raw','p_raw'),('calibrated','p_cal')]:
        pa=a[col].to_numpy();pb=b[col].to_numpy()
        da=weighted_auc_by_year(y,pa,yr,years,w)-weighted_auc_by_year(y,pb,yr,years,w)
        losses=np.bincount(yi,weights=(y-pb)**2-(y-pa)**2,minlength=len(years))
        db=(w@losses)/den
        for metric,point,values in [('delta_auc',roc_auc_score(y,pa)-roc_auc_score(y,pb),da),
             ('brier_improvement',np.mean((y-pb)**2-(y-pa)**2),db)]:
         lo,hi=np.nanquantile(values,[.025,.975]);records.append(dict(setting=setting,comparison=f'{wp}-{base}',
           probability=kind,metric=metric,estimate=point,ci_lower=lo,ci_upper=hi,n_years=len(years),bootstrap_replicates=n,
           interval_scope='Pointwise whole-year percentile bootstrap, fixed OOF predictions; no refitting'))
    table=pd.DataFrame(records);table.to_csv(out/'paired_bootstrap_intervals.csv',index=False)
    return table

def reliability(pred,out,n_boot=4000):
    rows=[]
    for model,g in pred[pred.setting.eq('primary')].groupby('model'):
      years=np.sort(g.year.unique());yi=pd.Index(years).get_indexer(g.year)
      weights=np.random.default_rng(4252).multinomial(len(years),np.ones(len(years))/len(years),size=n_boot)
      for kind,col in [('raw','p_raw'),('calibrated','p_cal')]:
       p=g[col].to_numpy();y=g.y_exceed.to_numpy();edges=np.unique(np.quantile(p,np.linspace(0,1,11)))
       if len(edges)<2:edges=np.array([-np.inf,np.inf])
       edges[0]=-np.inf;edges[-1]=np.inf;idx=np.searchsorted(edges,p,side='right')-1
       for i in range(len(edges)-1):
        use=idx==i;n=use.sum()
        if not n:continue
        ns=np.bincount(yi[use],minlength=len(years));es=np.bincount(yi[use],weights=y[use],minlength=len(years))
        den=weights@ns;freq=np.divide(weights@es,den,out=np.full(n_boot,np.nan),where=den>0)
        lo,hi=np.nanquantile(freq,[.025,.975])
        rows.append(dict(model=model,probability=kind,bin=i+1,n=n,exceedances=int(y[use].sum()),
          predicted=p[use].mean(),observed=y[use].mean(),ci_lower=lo,ci_upper=hi,
          lower_edge=edges[i],upper_edge=edges[i+1],bootstrap_defined=int(np.isfinite(freq).sum())))
    table=pd.DataFrame(rows);table.to_csv(out/'reliability_bins.csv',index=False);return table
