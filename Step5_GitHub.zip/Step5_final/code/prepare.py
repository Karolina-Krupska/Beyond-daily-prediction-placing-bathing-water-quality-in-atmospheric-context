"""Rebuild outcomes from the authoritative workbook and join current daily drivers."""
from pathlib import Path
import re,json,hashlib
import numpy as np
import pandas as pd
from models import REGISTRY,features

def classify(value,threshold=63):
    if pd.isna(value):return np.nan,'missing'
    s=str(value).strip().replace(',','')
    match=re.fullmatch(r'(<=|>=|<|>|≤|≥)?\s*([0-9]+(?:\.[0-9]+)?)',s)
    if not match:return np.nan,'uninterpretable'
    qualifier,number=match.groups();x=float(number)
    if qualifier in ['<','≤','<=']:
        if x<threshold or (qualifier=='<' and x==threshold):return 0.,'left_censored_classifiable'
        return np.nan,'threshold_indeterminate'
    if qualifier in ['>','≥','>=']:
        if x>=threshold:return 1.,'right_censored_classifiable'
        return np.nan,'threshold_indeterminate'
    return float(x>=threshold),'numeric'

def prepare(root,out):
    audit=out/'audit';audit.mkdir(parents=True,exist_ok=True)
    book=root/'inputs/bathing_water_records_2012_2024.xlsx'
    d=pd.read_excel(book,sheet_name='Records');register=pd.read_excel(book,sheet_name='Site_register')
    d['source_record_id']=np.arange(len(d))+2
    d['date']=pd.to_datetime(d.Date,errors='raise').dt.normalize()
    d['site_id']=d.site_id.astype(str)
    allowed=set(register.site_id.astype(str));assert set(d.site_id)<=allowed
    if d[['lat','lon']].isna().any().any():raise ValueError('Missing supplied site coordinates')
    domain=d.lat.between(49,52)&d.lon.between(-6,-2)
    if not domain.all():raise ValueError('Corrected approved workbook contains out-of-domain records')
    for c in ['SMPT_USER_REFERENCE','SMPT_SHORT_NAME','NGR','coordinate_basis','coordinate_source']:
        if c not in d:raise ValueError('Required provenance column absent: '+c)
    d[['site_id','SMPT_USER_REFERENCE','SMPT_SHORT_NAME','lat','lon','coordinate_basis','coordinate_source']].drop_duplicates().to_csv(audit/'site_alias_coordinates.csv',index=False)
    parsed=d['3723 IE Conf (CFU/0_1l)'].map(classify)
    d['outcome_record']=[v[0] for v in parsed];d['outcome_status']=[v[1] for v in parsed]
    season=d.date.dt.year.between(2012,2024)&d.date.dt.month.between(5,9)
    d.loc[~season].to_csv(audit/'outside_season.csv',index=False)
    d=d.loc[season].copy();d.loc[d.outcome_record.isna()].to_csv(audit/'unevaluable_IE_records.csv',index=False)
    d.to_csv(audit/'in_season_records_with_qualifiers.csv.gz',index=False)
    duplicate=d.duplicated(['site_id','date','SAMP_LAB_REF_NO'],keep=False)&d.SAMP_LAB_REF_NO.notna()
    d.loc[duplicate].to_csv(audit/'repeated_site_date_lab.csv',index=False)
    g=d.groupby(['site_id','date'],sort=True).agg(y_exceed=('outcome_record','max'),
        n_records=('source_record_id','size'),n_evaluable=('outcome_record','count'),
        any_routine=('SAMP_PURPOSE_CODE',lambda x:x.eq('MS').any())).reset_index()
    g[g.n_records.gt(1)].to_csv(audit/'multiple_record_site_days.csv',index=False)
    g[g.n_evaluable.eq(0)].to_csv(audit/'site_days_without_evaluable_IE.csv',index=False)
    g=g[g.n_evaluable.gt(0)].copy();g['y_exceed']=g.y_exceed.astype(int)
    g['year']=g.date.dt.year;g['month']=g.date.dt.month
    history=pd.read_csv(root/'inputs/step4/completed_run/prepared/historical_daily_calendar.csv',
        parse_dates=['date'],float_precision='round_trip')
    if history.date.duplicated().any():raise ValueError('Non-unique historical predictor date')
    if len(history)!=2379:raise ValueError('Unexpected Step 4 calendar length')
    fm=pd.read_csv(root/'inputs/step4/Step4_available_inputs/02_classification/weather_pattern_family_mapping.csv')
    mapping=dict(zip(fm.regime,fm.group))
    assert len(mapping)==30 and set(mapping)==set(range(1,31))
    assert history.family.eq(history.regime.map(mapping)).all()
    predictor_cols=features('G')+['regime','p7_before_mm','api_before','swvl1']
    merged=g.merge(history[['date']+predictor_cols],on='date',how='left',validate='many_to_one',indicator=True)
    assert merged._merge.eq('both').all();merged=merged.drop(columns='_merge')
    merged=merged.sort_values(['date','site_id']).reset_index(drop=True);merged['row_id']=np.arange(len(merged))
    merged.to_csv(out/'modelling_dataset.csv',index=False)
    pd.DataFrame([{'predictor':c,'missing_site_days':int(merged[c].isna().sum()),
       'missing_sampling_dates':int(merged.loc[merged[c].isna(),'date'].nunique())} for c in predictor_cols]).to_csv(audit/'predictor_missingness.csv',index=False)
    annual=merged.groupby('year').agg(site_days=('y_exceed','size'),exceedances=('y_exceed','sum'),sites=('site_id','nunique'),sampling_dates=('date','nunique'))
    annual['exceedance_fraction']=annual.exceedances/annual.site_days;annual.to_csv(audit/'annual_cohort.csv')
    summary=dict(workbook_rows=len(pd.read_excel(book,sheet_name='Records')),in_season_records=len(d),
        evaluable_records=int(d.outcome_record.notna().sum()),unevaluable_records=int(d.outcome_record.isna().sum()),
        evaluable_site_days=len(merged),sites=merged.site_id.nunique(),exceedance_site_days=int(merged.y_exceed.sum()),
        sampling_dates=merged.date.nunique(),all_outcome_missing_site_days=int(g.shape[0]-len(merged)),
        partial_missing_evaluable_site_days=int(((merged.n_evaluable<merged.n_records)).sum()))
    # The excluded-all-missing count is calculated directly from the audit, not inferred after filtering.
    summary['all_outcome_missing_site_days']=len(pd.read_csv(audit/'site_days_without_evaluable_IE.csv'))
    (audit/'cohort_summary.json').write_text(json.dumps(summary,indent=2))
    pd.DataFrame([{'stage':k,'count':v} for k,v in summary.items()]).to_csv(audit/'observation_flow.csv',index=False)
    # Reconcile the independently rebuilt outcome against the supplied association output.
    ref=pd.read_csv(root/'inputs/previous_site_day_REFERENCE.csv',parse_dates=['Date'])
    chk=merged[['site_id','date','y_exceed']].merge(ref[['site_id','Date','exceedance']],
        left_on=['site_id','date'],right_on=['site_id','Date'],validate='one_to_one',how='outer',indicator=True)
    assert chk._merge.eq('both').all() and chk.y_exceed.eq(chk.exceedance).all()
    (audit/'outcome_reconciliation.txt').write_text(f'PASS: independently rebuilt {len(merged)} site-day outcomes exactly match the corrected association dataset.\n')
    # Prior-day sensitivity shifts ALL predictors, including circulation, by one actual calendar day.
    lag=history[['date']+features('G')].copy();lag['date']=lag.date+pd.Timedelta(days=1)
    lagged=g.merge(lag,on='date',how='left',validate='many_to_one').sort_values(['date','site_id']).reset_index(drop=True)
    lagged['row_id']=merged.row_id
    assert np.array_equal(lagged[['site_id','date']].values,merged[['site_id','date']].values)
    lagged.to_csv(out/'modelling_dataset_prior_day.csv',index=False)
    return merged,lagged
