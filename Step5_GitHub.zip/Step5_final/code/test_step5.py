"""Focused numerical fixtures for corrected outcome, validation and selection logic."""
import unittest,sys
from pathlib import Path
import numpy as np,pandas as pd
from sklearn.metrics import roc_auc_score
from prepare import classify
from models import REGISTRY,features,nested_loyo
from assessment import weighted_auc_by_year
from storylines import reconstruct,run_metrics

class Step5Tests(unittest.TestCase):
    def test_missing_outcome_is_not_zero(self):
        self.assertTrue(np.isnan(classify(np.nan)[0]));self.assertTrue(np.isnan(classify('bad')[0]))
    def test_censor_boundaries(self):
        for v,want in [('<63',0),('<10',0),('63',1),('>63',1),('>=63',1),('62',0),('≤62',0)]:self.assertEqual(classify(v)[0],want)
        for v in ['<=63','>62','<100']:self.assertTrue(np.isnan(classify(v)[0]))
    def test_K_is_G_without_family(self):
        self.assertEqual(REGISTRY['G'][0],REGISTRY['K'][0]);self.assertEqual(REGISTRY['G'][1],['family']);self.assertEqual(REGISTRY['K'][1],[])
    def test_interrun_gap_not_recovery(self):
        m=run_metrics([[1,1,0,0,1,0]])[0]
        np.testing.assert_array_equal(m[:3],[3,2,2]);self.assertEqual(m[3],1.5);self.assertEqual(m[4],2)
    def test_empty_full_singleton_runs(self):
        m=run_metrics([[0,0,0],[1,1,1],[0,1,0]])
        np.testing.assert_array_equal(m[:,:3],[[0,0,0],[3,1,3],[1,1,1]])
        self.assertTrue(np.isnan(m[:,4]).all())
    def test_no_cross_season_runs(self):
        m=run_metrics([[0,1,1],[1,1,0]])
        np.testing.assert_array_equal(m[:,2],[2,2])
    def test_weighted_bootstrap_auc_includes_ties(self):
        y=np.array([0,1,1,0,1,0]);p=np.array([.1,.5,.5,.5,.9,.9]);year=np.array([1,1,2,2,3,3])
        weights=np.array([[1,1,1],[2,1,0],[0,1,2]])
        got=weighted_auc_by_year(y,p,year,np.array([1,2,3]),weights)
        for i,w in enumerate(weights):
            ix=np.concatenate([np.tile(np.flatnonzero(year==j+1),k) for j,k in enumerate(w)])
            self.assertAlmostEqual(got[i],roc_auc_score(y[ix],p[ix]),places=14)
    def test_joint_donor_and_antecedent_timing(self):
        lib=pd.DataFrame({k:np.arange(1,11,dtype=float) for k in ['depth_mm','intensity_q95_mmph','wind_speed','uvb_Wm2','ssrd_Wm2','t2m_C','swvl1','ssr_Wm2']})
        a=reconstruct(lib,np.arange(10)[None,:],.85)
        self.assertTrue(np.isnan(a['p7_mm'][0,5]));self.assertEqual(a['p7_mm'][0,6],28)
        self.assertEqual(a['p7_before_mm'][0,7],28);self.assertAlmostEqual(a['api'][0,1],2.85)
    def test_topk_exact_and_deterministic_ties(self):
        p=np.array([.8,.8,.2,.8]);u=np.array([.9,.2,.0,.3]);order=np.lexsort((u,-p))
        self.assertEqual(order[:2].tolist(),[1,3]);self.assertEqual(order[-1],2)
    def test_nested_folds_exclude_outer_year(self):
        n=32;d=pd.DataFrame({'row_id':range(n),'site_id':['a']*n,'date':pd.date_range('2012-01-01',periods=n),
           'year':np.repeat([2012,2013,2014,2015],8),'y_exceed':np.tile([0,0,1,0,1,0,1,0],4),
           'intensity_q95_mmph':np.tile([1.,2.,3.,4.,5.,6.,7.,8.],4)})
        pred,audit=nested_loyo(d,['A'],'balanced','fixture')
        self.assertEqual(len(pred),n);self.assertFalse(audit.outer_year_used_for_fitting.any())
        self.assertTrue(audit.inner_scores_complete.all());self.assertTrue(np.isfinite(pred.p_cal).all())
        self.assertTrue(audit.inner_folds.eq(3).all())

if __name__=='__main__':unittest.main()
