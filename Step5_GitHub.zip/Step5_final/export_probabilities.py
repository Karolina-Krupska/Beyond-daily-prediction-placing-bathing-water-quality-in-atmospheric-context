"""Export stored probabilities, or reconstruct full-precision values from fitted models."""
from pathlib import Path
import argparse,sys,json,gzip,contextlib
import numpy as np,pandas as pd,joblib
from scipy.special import expit
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'code'))
from storylines import STORIES,DATES,SUMMER,daily_frame
from models import REGISTRY

def export(root,story,full=False,n_seasons=None,output=None):
    source=root/'inputs/step4/completed_run'
    lib=pd.read_csv(source/'prepared/historical_donor_library.csv',parse_dates=['date'],float_precision='round_trip')
    meta=json.loads((source/'run_metadata.json').read_text())
    with np.load(source/f'simulations/{story}_AprSep.npz') as z:
        donor=z['donor_row'];states=z['states']
    if n_seasons is not None:donor=donor[:n_seasons];states=states[:n_seasons]
    suffix='float64_recomputed' if full else 'float32_stored'
    folder=root/'exported_probabilities';folder.mkdir(exist_ok=True)
    target=Path(output) if output else folder/f'{story}_{suffix}.csv.gz'
    with contextlib.ExitStack() as stack:
      p=None if full else stack.enter_context(np.load(root/f'simulation_probabilities/{story}_probabilities.npz'))
      letters=list(REGISTRY) if full else p['models'].tolist()
      raw_stored=None if full else p['p_raw']
      cal_stored=None if full else p['p_cal']
      with gzip.open(target,'wt',encoding='utf-8',newline='') as h:
       for first in range(0,len(donor),250):
        last=min(first+250,len(donor));ix=donor[first:last];state=states[first:last]
        frame=daily_frame(lib,ix,state,meta['api_alpha']);n=last-first
        frame.insert(0,'date',np.tile(DATES[SUMMER].strftime('%Y-%m-%d'),n));frame.insert(0,'sim',np.repeat(np.arange(first,last),153));frame.insert(0,'storyline',story)
        frame['donor_row']=ix[:,SUMMER].ravel();frame['donor_date']=lib.date.dt.strftime('%Y-%m-%d').to_numpy()[frame.donor_row]
        frame['donor_regime']=lib.regime.to_numpy()[frame.donor_row]
        for k,letter in enumerate(letters):
            if full:
                m=joblib.load(root/f'fitted_models/{letter}.joblib');s=m['base'].decision_function(frame[m['features']])
                frame[f'p_raw_{letter}']=expit(s);frame[f'p_cal_{letter}']=m['calibrator'].predict_proba(s.reshape(-1,1))[:,1]
            else:
                frame[f'p_raw_{letter}']=raw_stored[k,first:last].ravel();frame[f'p_cal_{letter}']=cal_stored[k,first:last].ravel()
        frame.to_csv(h,index=False,header=first==0)
    return target

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--scenario',choices=STORIES,default='baseline')
    p.add_argument('--full-precision',action='store_true');p.add_argument('--n-seasons',type=int)
    a=p.parse_args();print(export(ROOT,a.scenario,a.full_precision,a.n_seasons))
