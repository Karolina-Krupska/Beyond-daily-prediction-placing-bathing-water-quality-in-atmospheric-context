"""Read-only source, cohort, prediction, selection and exporter reconciliation."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import csv,hashlib,json,sys,tempfile
import numpy as np,pandas as pd,joblib
from scipy.special import expit
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'code'))
from models import REGISTRY,features
from storylines import STORIES,DATES,SUMMER,daily_frame,run_metrics,BUDGETS
from export_probabilities import export

def main():
    for record in csv.DictReader((ROOT/'INPUT_MANIFEST.csv').open()):
        p=ROOT/record['relative_path'];assert p.stat().st_size==int(record['bytes']) and hashlib.sha256(p.read_bytes()).hexdigest()==record['sha256']
    out=ROOT/'results';d=pd.read_csv(out/'modelling_dataset.csv',parse_dates=['date'])
    assert len(d)==35518 and d.site_id.nunique()==194 and d.y_exceed.sum()==3727
    assert not d.duplicated(['site_id','date']).any() and not d.y_exceed.isna().any()
    folds=[]
    for setting,count in [('primary',11),('unweighted',11),('complete_case',6),('prior_day',2)]:
        p=pd.read_csv(out/f'oof_predictions_{setting}.csv.gz',float_precision='round_trip')
        audit=pd.read_csv(out/f'fold_audit_{setting}.csv')
        assert not audit.outer_year_used_for_fitting.any() and audit.inner_scores_complete.all()
        assert np.isfinite(p[['p_raw','p_cal','score_raw','p_prevalence']]).all().all()
        assert not p.duplicated(['model','row_id']).any() and p.model.nunique()==count
        for wp,base in [('E','C'),('F','J'),('G','K')]:
            a=p[p.model.eq(wp)].sort_values('row_id');b=p[p.model.eq(base)].sort_values('row_id')
            if len(a) and len(b):np.testing.assert_array_equal(a.row_id,b.row_id)
        folds.append(dict(setting=setting,rows=len(p),model_folds=len(audit),years=p.year.nunique()))
    source=ROOT/'inputs/step4/completed_run'
    lib=pd.read_csv(source/'prepared/historical_donor_library.csv',parse_dates=['date'],float_precision='round_trip')
    alpha=json.loads((source/'run_metadata.json').read_text())['api_alpha']
    simulations=[]
    for story in STORIES:
        with np.load(source/f'simulations/{story}_AprSep.npz') as z:donor=z['donor_row'];states=z['states']
        assert donor.shape==states.shape==(5000,183)
        np.testing.assert_array_equal(lib.state.to_numpy()[donor],states)
        np.testing.assert_array_equal(lib.month.to_numpy()[donor],np.broadcast_to(DATES.month.to_numpy(),states.shape))
        frame=daily_frame(lib,donor[:2],states[:2],alpha)
        with np.load(ROOT/f'simulation_probabilities/{story}_probabilities.npz') as p:
            assert p['p_raw'].shape==p['p_cal'].shape==(11,5000,153)
            raw=p['p_raw'];cal=p['p_cal'];assert np.isfinite(raw).all() and np.isfinite(cal).all()
            assert raw.min()>=0 and raw.max()<=1 and cal.min()>=0 and cal.max()<=1
            for k,letter in enumerate(p['models']):
                model=joblib.load(ROOT/f'fitted_models/{letter}.joblib')
                score=model['base'].decision_function(frame[model['features']]);pr=expit(score)
                pc=model['calibrator'].predict_proba(score.reshape(-1,1))[:,1]
                np.testing.assert_array_equal(raw[k,:2].ravel(),pr.astype(np.float32))
                np.testing.assert_array_equal(cal[k,:2].ravel(),pc.astype(np.float32))
        with tempfile.TemporaryDirectory() as temporary:
            file=Path(temporary)/'test.csv.gz';export(ROOT,story,True,2,file)
            full=pd.read_csv(file,float_precision='round_trip')
            assert len(full)==306 and full.groupby('sim').size().eq(153).all()
            for letter in REGISTRY:
                model=joblib.load(ROOT/f'fitted_models/{letter}.joblib');score=model['base'].decision_function(frame[model['features']])
                np.testing.assert_array_equal(full[f'p_raw_{letter}'],expit(score))
                np.testing.assert_array_equal(full[f'p_cal_{letter}'],model['calibrator'].predict_proba(score.reshape(-1,1))[:,1])
        simulations.append(dict(storyline=story,simulations=5000,days=153,models=11,
            stored_predictions_checked=True,full_precision_CSV_first_two_seasons_exact=True))
        print('PASS probabilities and actual CSV exporter:',story,flush=True)
    table=pd.read_csv(out/'pooled_topk_budget_audit.csv')
    mask_checks=[]
    for letter in REGISTRY:
      previous=None
      for budget in BUDGETS:
        rule=f'topk_{int(budget*100):02d}';file=ROOT/f'simulation_probabilities/selection_masks/{letter}_{rule}.npz'
        with np.load(file) as z:shape=tuple(z['shape']);mask=np.unpackbits(z['packed'],bitorder='little')[:np.prod(shape)].reshape(shape).astype(bool)
        k=int(np.ceil(budget*4590000));assert mask.sum()==k
        row=table[(table.model==letter)&(table.rule==rule)].iloc[0];assert row.k==row.selected_days==k
        if previous is not None:assert np.all(~previous|mask)
        previous=mask
        for s,story in enumerate(STORIES):
            m=run_metrics(mask[s]);summary=pd.read_csv(out/'selected_day_metrics_summary.csv')
            for j,name in enumerate(['selected_days','clusters','max_run_days','mean_run_days','mean_interrun_gap_days']):
                row=summary[(summary.model==letter)&(summary.rule==rule)&(summary.storyline==story)&(summary.metric==name)].iloc[0]
                np.testing.assert_allclose(np.nanmean(m[:,j]),row['mean'],rtol=1e-12,atol=1e-12,equal_nan=True)
      mask_checks.append(dict(model=letter,exact_budget_and_nested_selection=True))
    report=dict(status='passed',folds=folds,simulations=simulations,selection_checks=mask_checks,
        raw_probability_values=50490000,calibrated_probability_values=50490000,
        source_hashes_verified=True,cohort_verified=True)
    (out/'INTEGRATION_VERIFICATION.json').write_text(json.dumps(report,indent=2))
    print('ALL INTEGRATION CHECKS PASSED',flush=True)
if __name__=='__main__':main()
