# Step 1: weather-pattern family baseline — final uncertainty package

This revised package excludes rainfall dates whose source histograms cannot be reconstructed from the retained archive. It retains **1,940 rainfall days** with readable source histograms and matching reconstructed metrics. The original four-family mapping remains fixed. This final package adds whole-season bootstrap confidence intervals and leave-one-season-out stability checks.

## What changed

The earlier Step 1 package used 1,969 processed rainfall records. This revision excludes **29 records: 23 with unreadable source CSVs and six with absent source files**. All 29 exclusions are listed with dates, families, original metrics and reasons in `results/excluded_rainfall_records.csv`.

This is a **source-reproducibility restriction**. It does not establish that the excluded rainfall values were incorrect or that an extreme was false. No intensity threshold or outlier clipping was applied. The exclusions occur in 2013 (three), 2017 (19) and 2019 (seven); they are not evenly distributed through time.

The original input workbook remains unchanged for traceability. The analysis code applies the explicit eligibility rule and exports the 1,940 retained daily records separately.

## Denominators

| Quantity | Number |
|---|---:|
| Complete May–September seasons, 2012–2024 | 13 |
| Weather-calendar days | 1,989 |
| Eligible next-day weather transitions | 1,976 |
| Observed within-season family runs | 733 |
| Original processed SWEW rainfall records | 1,969 |
| Newly excluded rainfall records | 29 |
| Retained rainfall records | 1,940 |
| Originally missing processed rainfall dates | 20 |
| Total dates without eligible rainfall in the joined matrix | 49 |

| Family | Calendar days | Original rainfall days | Newly excluded | Retained rainfall days |
|---|---:|---:|---:|---:|
| Cyclonic Atlantic (frontal) | 786 | 777 | 9 | 768 |
| Showery maritime / unsettled | 400 | 400 | 5 | 395 |
| Convective extremes | 662 | 652 | 11 | 641 |
| Settled anticyclonic quiet | 141 | 140 | 4 | 136 |

**Weather occurrence, runs and transitions use all 1,989 classified days.** Rainfall summaries use the 1,940 eligible daily records. Missing or excluded rainfall never becomes zero and does not remove a date from the weather calendar.

The 20 originally missing rainfall dates are 10 May 2018; 31 August–14 September 2022 inclusive; 15–16 May 2023; and 22–23 July 2023. They are kept separate from the 29 new exclusions.

## Files to use

- `data/input/fullrange_noqc_stats.xlsx`: original supplied workbook, copied unchanged; the analysis reads `daily_metrics` and `bins_metadata`, selects SWEW and the stated period, then applies the source-eligibility rule.
- `data/input/classifications_30regimes.csv`: original supplied weather calendar, copied unchanged under a portable name.
- `data/input/readable_histograms.zip`: **all 1,940 retained daily histogram CSVs**. These are processed regional histograms, not original radar scans. CSVs contain multiple regions; the source check uses the SWEW row.
- `data/processed/daily_metrics_SWEW_MaySep_NOQC.csv`: the **1,940-row rainfall table to use for this revised Step 1 analysis**.
- `data/processed/weather_rainfall_daily_matrix.csv`: the 1,989-date calendar joined to eligible rainfall. The `rainfall_available` flag is true on 1,940 dates; metric cells are blank on 49 dates. `processed_source_record_exists` and `rainfall_source_status` distinguish originally missing records from source exclusions.
- `data/processed/weather_calendar.csv`: complete selected weather calendar.
- `data/processed/weather_pattern_family_mapping.csv`: final, complete and non-overlapping WP1–WP30 assignment.
- `results/`: descriptive summaries, individual runs, transition matrices, missing dates, exclusions, metadata and manuscript-ready methods/results text.
- `results/rainfall_summary_changes.csv`: previous and revised rainfall statistics. Means and percentiles have been recalculated; this revision is not just a count change.
- `results/retained_source_check/`: reconstruction of all 1,940 retained daily records from the histograms included in this ZIP.
- `data/provenance/`: historical source audit documenting the original 23 unreadable and six absent sources. This is the reproducible eligibility record; it is tied to the input workbook by SHA-256.
- `figures/`: updated main, transition-interval and leave-one-season-out figures in 600 dpi PNG and vector PDF/SVG formats, with captions.
- `code/`: analysis, uncertainty estimation, reporting, plotting, focused tests, independent result verification and histogram reconstruction.
- `archive/`: the original Step 1 script, retained unchanged for provenance.
- `data/data_dictionary.csv`: units and definitions.
- `SHA256SUMS.txt`: release file-integrity hashes.

## Reproduce

Use Python 3.11 or later. Extract the ZIP fully, open a terminal in the extracted `Step1_weather_baseline` folder, and run:

```bash
python -m pip install -r requirements.txt
python code/step1_baseline.py
python code/test_step1.py
python code/test_uncertainty.py
python code/verify_saved_results.py
python code/audit_histogram_sources.py --eligible-only
```

No personal paths need editing. The final command uses the packaged `readable_histograms.zip` and writes a new source check to `results/retained_source_check/`. It does not overwrite the historical exclusion record in `data/provenance/`.

The main script replaces its generated results, processed CSVs, manuscript text and figures. It does not modify the input workbook, the classifications or the archived original script. The source audit is tied to the exact workbook by its hash; changing the workbook requires a corresponding source audit.

To redraw the saved figure only:

```bash
python code/plot_step1.py
```

To write a separate output set, use `python code/step1_baseline.py --outdir path/to/new_outputs`. The published outputs in this ZIP correspond to the default May–September 2012–2024 period.

## Definitions and equations

**Occurrence.** Family frequency is the number of its calendar days divided by 1,989. These counts are days, not microbiological samples, sites or site-days.

**Observed runs.** A run contains consecutive selected days in the same family. It ends at a family change, date gap or annual analysis-window boundary. A family run can contain different individual weather patterns. Boundary-touching runs are included and flagged; they may be truncated by the May–September window. Empirical P90 and P95 use linear interpolation and can be fractional. They are not confidence intervals or necessarily full atmospheric episode durations.

**Transitions.** For current family i and next-day family j:

`P(i,j) = N(i,j) / sum_j N(i,j)`

N(i,j) counts genuinely adjacent classified dates within the selected annual window. Rows denote the current family and columns the next day. Denominators are eligible origin days, not all days in the family. The 13 seasons contribute 13 × 152 = 1,976 pairs. September-to-May gaps never contribute transitions.

Monthly transitions belong to the origin month, including 31 May → 1 June. Eligible monthly pair totals are May 403; June 390; July 403; August 403; September 377. These are descriptive summaries and do not validate a first-order Markov simulation assumption.

**Rainfall.** Family summaries pool eligible daily records; they are not averages of the weather-pattern summary means. Stored rainfall values are not altered. The source generator uses:

- `total_samples`: histogram pixel–time counts, not bathing-water samples.
- `wet_fraction`: proportion of pooled pixel–time observations in wet bins, starting at 0.0625 mm h⁻¹. The first bin is treated as dry. This is not the fraction of geographical area wet at an instant.
- Positive-bin representative `r = (b − a) / [ln(b) − ln(a)]`, with representative zero for the first bin. The open top bin beginning at 256 mm h⁻¹ is assigned a pseudo-upper edge of 512 mm h⁻¹.
- `mean_rate_mmph = sum(count × representative) / total_samples`.
- `daily_depth_mm = 24 × mean_rate_mmph`. This is a histogram-derived domain-average depth estimate. With incomplete sampling, the conversion assumes that available observations represent the day; readable input alone does not validate that assumption.
- Daily `q50_mmph`, `q90_mmph` and `q95_mmph` are wet-only rain-rate quantiles with within-bin logarithmic interpolation. Panel d's P95 is instead the percentile across daily rainfall depths.

## Validation and interpretation

The code checks family membership, complete classification coverage, unique dates, finite and admissible metrics, positive integer histogram totals, ordered quantiles, bin definitions, mean-rate/depth consistency and rainfall/calendar classification agreement. It reconciles calendar counts, runs, transition denominators and weighted rainfall means. Source eligibility requires a readable source histogram and reconstructed metric agreement.

Every retained daily rainfall record has been reconstructed from the packaged histograms, with all seven metrics matching within floating-point precision. This establishes implementation and source consistency under the stated grouped-bin assumptions. It does not independently validate radar measurement accuracy or individual extreme events.

The mean rainfall ordering remains Cyclonic Atlantic, Showery maritime, Convective extremes, then Settled anticyclonic. **The P95 ordering changes:** Convective extremes now exceeds Showery maritime. Do not describe the exclusion as having no scientific effect or assume that the temporally concentrated missingness is unbiased.

The four families are treated as a **fixed, previously defined mapping** in this descriptive step. Their original 1,969-day construction diagnostics have not been recalculated here. This package does not establish that their membership would remain unchanged if the family-construction procedure were repeated on 1,940 days.

This revision updates Step 1 rainfall summaries and figures. Other rainfall-dependent family diagnostics, predictive models, storyline drivers and manuscript values based on 1,969 dates require the same eligibility rule when updated, or an explicit explanation of their different analysis population. No microbiological models or storyline simulations have been rerun in this package.


## Confidence intervals and sensitivity checks

The main script now runs 10,000 whole-season bootstrap resamples with seed 42
and all 13 leave-one-season-out calculations before drawing the figures.
No predictive model fitting or storyline simulation is involved.

For each bootstrap replicate, 13 summer identifiers are sampled with replacement
from the 13 observed summers. The same draw is used jointly for weather and
rainfall. Each summer retains its observed dates, missingness, runs and eligible
transitions. Repeated summers contribute repeated copies of their original
statistics; they are never concatenated into artificial cross-season runs or
transitions.

The target statistics retain their pooled estimands. For example, with seasonal
multiplicities w(y):

- Mean run length = sum_y[w(y) × total observed run days(y)] /
  sum_y[w(y) × number of observed runs(y)].
- Same-family transition probability = sum_y[w(y) × N(i,i,y)] /
  sum_y[w(y) × eligible origin days(i,y)].
- Mean rainfall depth = sum_y[w(y) × total retained daily depth(i,y)] /
  sum_y[w(y) × retained rainfall days(i,y)].

These are not unweighted averages of annual means. Empirical rainfall P95 is
recalculated from the replicated daily-depth distribution using linear
interpolation. Ratios with a zero denominator are unavailable rather than set
to zero, and the number of valid replicates is reported.

The 2.5th and 97.5th percentiles of the bootstrap estimates define approximate
**pointwise 95% confidence intervals** for family calendar fractions, mean run
lengths, same-family transition probabilities, mean daily depth and rainfall
P95. All 16 transition probabilities also have interval estimates.

**Assumptions and limits:** seasons are treated as approximately exchangeable
resampling units. Dependence within each season is retained; dependence or
systematic change between seasons is not modelled. Thirteen seasons provide
limited information about interannual variability, regardless of the number
of bootstrap draws. Intervals are conditional on the fixed family mapping
and observed source-eligible rainfall records. They do not quantify radar
measurement error, missing-data bias or uncertainty in constructing the
family classification. They are not simultaneous or adjusted for multiple
comparisons, and are not used to declare family differences statistically
significant.

The leave-one-season-out check recalculates the same statistics after omitting
each summer. Its minimum–maximum ranges and ordering counts are sensitivity
summaries, **not confidence intervals, p-values or probabilities that an
ordering is true**. This is not predictive cross-validation.

### Added outputs

- `results/uncertainty/bootstrap_confidence_intervals.csv`: point estimates,
  approximate 95% intervals and valid bootstrap counts for the five principal
  family statistics.
- `results/uncertainty/bootstrap_transition_intervals.csv`: all 16 transition
  probabilities with approximate 95% intervals.
- `results/uncertainty/leave_one_season_out.csv`: every estimate after each
  summer is omitted.
- `results/uncertainty/stability_summary.csv`: ranges, largest changes and the
  most influential omitted year for each statistic.
- `results/uncertainty/family_rank_stability.csv`: descriptive ordering stability.
- `results/uncertainty/annual_family_statistics.csv`: annual components used
  in the resampling calculations.
- `results/uncertainty/bootstrap_draws.npz`: saved resampling draws and
  statistics for reproducibility.
- `results/uncertainty/bootstrap_metadata.json`: exact method, seed, replicate
  counts, assumptions and interval interpretation.
- `results/uncertainty/publication_table.csv`: the principal estimates and
  interval limits in one numeric table.
- `results/uncertainty/uncertainty_summary.txt`: readable full reporting.
- `results/uncertainty/manuscript_addition.txt`: copy-ready methods and findings.
- `figures/`: the main figure now distinguishes mean confidence intervals
  from P95 dots. Separate supplementary figures report transition intervals
  and leave-one-season-out sensitivity.

The main figure's **P95 dots describe distribution tails**. Its **95% confidence
whiskers describe uncertainty in the means**. These must not be conflated.

### Why no additional p-value tests?

Step 1 describes observed circulation and rainfall organisation and reports
uncertainty and sensitivity. It does not claim that every family difference
has been established by a formal hypothesis test. Rainfall diagnostics helped
construct the families, so significance testing of rainfall separation in
overlapping data would not independently validate the classification.
No null-hypothesis tests or p-values have been added merely to label the
figure as significant. If a later manuscript makes a specific inferential
contrast, that contrast needs a suitable dependence-aware test and any
necessary multiple-comparison adjustment.

These checks do not establish that a first-order Markov storyline generator
reproduces observed sequences. Generator evaluation belongs to the storyline
stage.

Methodological background: Wilks, D. S. (1997), “Resampling Hypothesis Tests for
Autocorrelated Fields”, Journal of Climate, 10, 65–82. The paper supports
preserving dependence when resampling atmospheric data; the whole-season
implementation, pooled estimands and assumptions used here are specified above.
https://journals.ametsoc.org/view/journals/clim/10/1/1520-0442_1997_010_0065_rhtfaf_2.0.co_2.xml

## Findings from the added checks

The complete family ordering was preserved in all 13 season omissions for
calendar frequency, mean observed run length, same-family next-day probability
and mean daily rainfall depth. For rainfall-depth P95, the ordering was
preserved in seven of 13 omissions; the Showery maritime and Convective
extremes families switched places when 2012, 2013, 2015, 2017, 2022 or 2024 was
omitted. This supports reporting stable mean/persistence orderings across
these particular omissions, while avoiding a claim of stable relative P95
rainfall depth between the showery and convective families.

All 10,000 bootstrap estimates were finite for each principal statistic
and each of the 16 transitions. All intervals are reported without significance
stars or p-values. The narrowness of an interval is not evidence of independent
radar validation.

The figure files are:
- `figures/step1_summary_figure.png` — 4,488 × 4,251 pixels at 600 dpi.
- `figures/step1_transition_confidence_intervals.png` — 4,488 × 3,543 pixels.
- `figures/step1_leave_one_season_out.png` — 4,488 × 3,661 pixels.

Each has a PDF, SVG and caption counterpart. Figure numbering should be
assigned when the material is inserted into the manuscript.
