"""Whole-season uncertainty and leave-one-season-out checks for Step 1.

Resamples annual May–September windows jointly for weather and rainfall. Runs
and transitions are computed within each observed season before resampling.
No independently resampled days, artificial season joins or new model fits.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
from pathlib import Path

import numpy as np
import pandas as pd

from step1_baseline import GROUP_ORDER, consecutive_pairs, observed_runs, transition_matrices

ROOT = Path(__file__).resolve().parents[1]
METRICS = ["calendar_fraction", "mean_run_days", "same_family_transition_probability",
           "mean_daily_depth_mm", "p95_daily_depth_mm"]


@dataclass
class SeasonalStatistics:
    years: np.ndarray
    calendar_days: np.ndarray
    family_days: np.ndarray
    run_counts: np.ndarray
    run_days: np.ndarray
    transitions: np.ndarray
    rainfall_counts: np.ndarray
    rainfall_sums: np.ndarray
    rainfall_values: list[np.ndarray]
    rainfall_year_indices: list[np.ndarray]


def safe_ratio(numerator: np.ndarray, denominator: np.ndarray) -> np.ndarray:
    """Zero-denominator statistics remain unavailable, never zero."""
    numerator, denominator = np.broadcast_arrays(numerator, denominator)
    result = np.full(numerator.shape, np.nan, dtype=float)
    return np.divide(numerator, denominator, out=result, where=denominator > 0)


def weighted_linear_quantile(values: np.ndarray, weights: np.ndarray, q: float) -> float:
    """Exact linear quantile of integer-frequency replicated observations.

    This is equivalent to np.quantile(np.repeat(values, weights), q,
    method='linear'), without physically replicating every observation.
    """
    values = np.asarray(values, dtype=float)
    weights = np.asarray(weights)
    if values.ndim != 1 or weights.shape != values.shape or not 0 <= q <= 1:
        raise ValueError("Provide aligned one-dimensional values/weights and q within 0–1.")
    if not np.isfinite(values).all() or not np.isfinite(weights).all():
        raise ValueError("Quantile inputs must be finite.")
    if (weights < 0).any() or not np.equal(weights % 1, 0).all():
        raise ValueError("Quantile weights must be non-negative integer frequencies.")
    order = np.argsort(values, kind="stable")
    values, weights = values[order], weights[order].astype(np.int64)
    cumulative = np.cumsum(weights)
    total = int(cumulative[-1]) if len(cumulative) else 0
    if total == 0:
        return float("nan")
    rank = (total - 1) * q
    low, high = int(np.floor(rank)), int(np.ceil(rank))
    lower_value = values[np.searchsorted(cumulative, low, side="right")]
    upper_value = values[np.searchsorted(cumulative, high, side="right")]
    return float(lower_value + (rank - low) * (upper_value - lower_value))


def build_seasonal_statistics(weather: pd.DataFrame, rain: pd.DataFrame) -> SeasonalStatistics:
    """Pool sums/counts by year; every run and transition retains its boundary."""
    weather = weather.copy().sort_values("date").reset_index(drop=True)
    rain = rain.copy().sort_values("date").reset_index(drop=True)
    for label, frame in [("weather", weather), ("rainfall", rain)]:
        if frame.date.duplicated().any() or frame.date.isna().any():
            raise ValueError(f"{label} dates must be unique and non-missing.")
        if not frame.year.eq(frame.date.dt.year).all():
            raise ValueError(f"{label} year fields disagree with dates.")
        if not frame.group.isin(GROUP_ORDER).all():
            raise ValueError(f"{label} has an unknown family.")
    if not set(rain.date).issubset(set(weather.date)):
        raise ValueError("Rainfall dates must belong to the selected weather calendar.")
    if not np.isfinite(rain.daily_depth_mm).all() or (rain.daily_depth_mm < 0).any():
        raise ValueError("Daily rainfall depths must be finite and non-negative.")
    matched = rain[["date", "group"]].merge(weather[["date", "group"]], on="date", validate="one_to_one")
    if not matched.group_x.eq(matched.group_y).all():
        raise ValueError("Weather and rainfall family assignments disagree.")

    years = np.array(sorted(weather.year.unique()), dtype=int)
    if len(years) < 2:
        raise ValueError("At least two annual windows are required for the sensitivity analysis.")
    ny, ng = len(years), len(GROUP_ORDER)
    calendar_days = np.zeros(ny, dtype=np.int64)
    family_days = np.zeros((ny, ng), dtype=np.int64)
    run_counts = np.zeros((ny, ng), dtype=np.int64)
    run_days = np.zeros((ny, ng), dtype=np.int64)
    transitions = np.zeros((ny, ng, ng), dtype=np.int64)
    rainfall_counts = np.zeros((ny, ng), dtype=np.int64)
    rainfall_sums = np.zeros((ny, ng), dtype=float)
    for i, year in enumerate(years):
        season = weather.loc[weather.year.eq(year)].copy()
        calendar_days[i] = len(season)
        family_days[i] = season.group.value_counts().reindex(GROUP_ORDER, fill_value=0).values
        runs = observed_runs(season)
        run_counts[i] = runs.groupby("group").size().reindex(GROUP_ORDER, fill_value=0).values
        run_days[i] = runs.groupby("group").run_length.sum().reindex(GROUP_ORDER, fill_value=0).values
        transitions[i] = transition_matrices(consecutive_pairs(season))[0].values
        season_rain = rain.loc[rain.year.eq(year)]
        rainfall_counts[i] = season_rain.groupby("group").size().reindex(GROUP_ORDER, fill_value=0).values
        rainfall_sums[i] = season_rain.groupby("group").daily_depth_mm.sum().reindex(GROUP_ORDER, fill_value=0).values
    if not np.array_equal(run_days, family_days):
        raise AssertionError("Run days do not reconcile to annual family counts.")
    year_index = {int(year): i for i, year in enumerate(years)}
    rainfall_values, rainfall_year_indices = [], []
    for family in GROUP_ORDER:
        selected = rain.loc[rain.group.eq(family)].sort_values("daily_depth_mm", kind="stable")
        rainfall_values.append(selected.daily_depth_mm.to_numpy(dtype=float))
        rainfall_year_indices.append(selected.year.map(year_index).to_numpy(dtype=int))
    return SeasonalStatistics(years, calendar_days, family_days, run_counts, run_days, transitions,
                              rainfall_counts, rainfall_sums, rainfall_values, rainfall_year_indices)


def summarise_weights(stats: SeasonalStatistics, weights: np.ndarray) -> tuple[dict[str, np.ndarray], np.ndarray]:
    """Calculate the original pooled estimands for each season-multiplicity row."""
    weights = np.atleast_2d(np.asarray(weights))
    if weights.shape[1] != len(stats.years) or not np.isfinite(weights).all():
        raise ValueError("Season weights must align with the available years.")
    if (weights < 0).any() or not np.equal(weights % 1, 0).all() or (weights.sum(axis=1) == 0).any():
        raise ValueError("Each draw needs non-negative integer year multiplicities and at least one season.")
    transitions = np.einsum("by,yij->bij", weights, stats.transitions)
    probabilities = safe_ratio(transitions, transitions.sum(axis=2, keepdims=True))
    estimates = {
        "calendar_fraction": safe_ratio(weights @ stats.family_days, (weights @ stats.calendar_days)[:, None]),
        "mean_run_days": safe_ratio(weights @ stats.run_days, weights @ stats.run_counts),
        "same_family_transition_probability": np.diagonal(probabilities, axis1=1, axis2=2).copy(),
        "mean_daily_depth_mm": safe_ratio(weights @ stats.rainfall_sums, weights @ stats.rainfall_counts),
    }
    quantiles = np.full((len(weights), len(GROUP_ORDER)), np.nan)
    for j, (values, indices) in enumerate(zip(stats.rainfall_values, stats.rainfall_year_indices)):
        if len(values) == 0:
            continue
        # Values are already sorted. Integer frequencies reproduce linear
        # order-statistic interpolation exactly, including duplicated seasons.
        day_weights = weights[:, indices].astype(np.int64)
        cumulative = np.cumsum(day_weights, axis=1)
        totals = cumulative[:, -1]
        valid = totals > 0
        rank = np.maximum(totals - 1, 0) * .95
        lower_rank, upper_rank = np.floor(rank).astype(int), np.ceil(rank).astype(int)
        lower_index = (cumulative > lower_rank[:, None]).argmax(axis=1)
        upper_index = (cumulative > upper_rank[:, None]).argmax(axis=1)
        quantiles[valid, j] = (values[lower_index] + (rank - lower_rank) *
                               (values[upper_index] - values[lower_index]))[valid]
    estimates["p95_daily_depth_mm"] = quantiles
    return estimates, probabilities


def draw_season_weights(n_seasons: int, n_boot: int, seed: int) -> np.ndarray:
    if n_seasons < 2 or n_boot < 2:
        raise ValueError("At least two seasons and two bootstrap replicates are required.")
    rng = np.random.default_rng(seed)
    draws = rng.integers(0, n_seasons, size=(n_boot, n_seasons))
    weights = np.zeros((n_boot, n_seasons), dtype=np.int64)
    np.add.at(weights, (np.repeat(np.arange(n_boot), n_seasons), draws.ravel()), 1)
    return weights


def percentile_interval(draws: np.ndarray, confidence: float) -> tuple[float, float, int]:
    valid = np.asarray(draws, dtype=float)
    valid = valid[np.isfinite(valid)]
    if not len(valid):
        return float("nan"), float("nan"), 0
    alpha = (1 - confidence) / 2
    low, high = np.quantile(valid, [alpha, 1 - alpha], method="linear")
    return float(low), float(high), len(valid)


def family_order(values: np.ndarray) -> str:
    if not np.isfinite(values).all():
        return "unavailable"
    order = np.argsort(-np.asarray(values), kind="stable")
    return " > ".join(GROUP_ORDER[i] for i in order)


def _write(frame: pd.DataFrame, path: Path) -> None:
    frame.to_csv(path, index=False, float_format="%.15g")


def run_uncertainty(package_root: Path = ROOT, n_boot: int = 10000, seed: int = 42,
                    confidence: float = .95) -> dict:
    if not 0 < confidence < 1:
        raise ValueError("Confidence level must lie between zero and one.")
    package_root = Path(package_root)
    output = package_root / "results/uncertainty"
    output.mkdir(parents=True, exist_ok=True)
    weather = pd.read_csv(package_root / "data/processed/weather_calendar.csv", parse_dates=["date"])
    rain = pd.read_csv(package_root / "data/processed/daily_metrics_SWEW_MaySep_NOQC.csv", parse_dates=["date"])
    stored_runs = pd.read_csv(package_root / "results/observed_family_runs.csv", parse_dates=["start_date", "end_date"])
    reconstructed_runs = observed_runs(weather)
    for field in ["group", "start_date", "end_date", "run_length", "year"]:
        if not stored_runs[field].equals(reconstructed_runs[field]):
            raise ValueError(f"Saved run records disagree with the weather calendar: {field}.")
    stats = build_seasonal_statistics(weather, rain)
    ng, ny = len(GROUP_ORDER), len(stats.years)
    full, full_transition = summarise_weights(stats, np.ones((1, ny), dtype=int))
    for metric in METRICS:
        full[metric] = full[metric][0]
    full_transition = full_transition[0]

    saved_transition = pd.read_csv(package_root / "results/transition_probs.csv", index_col=0).reindex(
        index=GROUP_ORDER, columns=GROUP_ORDER).to_numpy()
    if not np.allclose(full_transition, saved_transition, equal_nan=True, rtol=1e-12, atol=1e-12):
        raise ValueError("Season-pooled transition estimates disagree with the baseline output.")
    saved_counts = pd.read_csv(package_root / "results/group_counts_fractions.csv").set_index("group").reindex(GROUP_ORDER)
    saved_runs = pd.read_csv(package_root / "results/run_length_summary.csv").set_index("group").reindex(GROUP_ORDER)
    saved_rain = pd.read_csv(package_root / "results/SWEW_rainfall_by_group.csv").set_index("group").reindex(GROUP_ORDER)
    for metric, saved in [("calendar_fraction", saved_counts.fraction), ("mean_run_days", saved_runs["mean"]),
                          ("mean_daily_depth_mm", saved_rain.mean_mm), ("p95_daily_depth_mm", saved_rain.p95_mm)]:
        if not np.allclose(full[metric], saved, equal_nan=True, rtol=1e-12, atol=1e-12):
            raise ValueError(f"Season-pooled estimate disagrees with the baseline output: {metric}.")

    weights = draw_season_weights(ny, n_boot, seed)
    bootstrap, bootstrap_transition = summarise_weights(stats, weights)
    ci_rows = []
    for metric in METRICS:
        for j, group in enumerate(GROUP_ORDER):
            low, high, n_valid = percentile_interval(bootstrap[metric][:, j], confidence)
            ci_rows.append({"group": group, "metric": metric, "estimate": full[metric][j],
                            "ci_lower": low, "ci_upper": high, "confidence_level": confidence,
                            "n_boot_valid": n_valid})
    _write(pd.DataFrame(ci_rows), output / "bootstrap_confidence_intervals.csv")
    transition_rows = []
    for i, origin in enumerate(GROUP_ORDER):
        for j, target in enumerate(GROUP_ORDER):
            low, high, n_valid = percentile_interval(bootstrap_transition[:, i, j], confidence)
            transition_rows.append({"from_group": origin, "to_group": target,
                "estimate": full_transition[i, j], "ci_lower": low, "ci_upper": high,
                "confidence_level": confidence, "n_boot_valid": n_valid})
    _write(pd.DataFrame(transition_rows), output / "bootstrap_transition_intervals.csv")
    np.savez_compressed(output / "bootstrap_draws.npz", years=stats.years,
        group_names=np.array(GROUP_ORDER), year_weights=weights,
        transition_probabilities=bootstrap_transition, **bootstrap)

    loso_weights = np.ones((ny, ny), dtype=int) - np.eye(ny, dtype=int)
    loso, _ = summarise_weights(stats, loso_weights)
    loso_rows, stability_rows, rank_rows, rank_detail = [], [], [], []
    for metric in METRICS:
        full_order = family_order(full[metric])
        orders = [family_order(loso[metric][i]) for i in range(ny)]
        rank_rows.append({"metric": metric, "full_order": full_order,
            "rank_order_preserved_count": sum(order == full_order and order != "unavailable" for order in orders),
            "n_omissions": ny, "n_omissions_with_complete_estimates": sum(order != "unavailable" for order in orders)})
        for i, year in enumerate(stats.years):
            rank_detail.append({"omitted_year": int(year), "metric": metric,
                                "full_order": full_order, "leave_one_out_order": orders[i],
                                "rank_order_preserved": orders[i] == full_order and orders[i] != "unavailable"})
        for j, group in enumerate(GROUP_ORDER):
            values = loso[metric][:, j]
            changes = values - full[metric][j]
            valid = np.isfinite(changes)
            influential = int(stats.years[np.nanargmax(np.abs(changes))]) if valid.any() else None
            stability_rows.append({"group": group, "metric": metric, "full_estimate": full[metric][j],
                "loso_min": np.nanmin(values) if np.isfinite(values).any() else np.nan,
                "loso_max": np.nanmax(values) if np.isfinite(values).any() else np.nan,
                "max_abs_change": np.nanmax(np.abs(changes)) if valid.any() else np.nan,
                "most_influential_year": influential})
            for i, year in enumerate(stats.years):
                loso_rows.append({"omitted_year": int(year), "group": group, "metric": metric,
                                  "estimate": values[i], "full_estimate": full[metric][j], "difference": changes[i]})
    _write(pd.DataFrame(loso_rows), output / "leave_one_season_out.csv")
    _write(pd.DataFrame(stability_rows), output / "stability_summary.csv")
    _write(pd.DataFrame(rank_rows), output / "family_rank_stability.csv")
    _write(pd.DataFrame(rank_detail), output / "family_rank_stability_by_omitted_year.csv")

    annual_rows, annual_transition_rows = [], []
    for y, year in enumerate(stats.years):
        for g, group in enumerate(GROUP_ORDER):
            annual_rows.append({"year": int(year), "group": group,
                "calendar_days": int(stats.calendar_days[y]), "family_days": int(stats.family_days[y, g]),
                "run_count": int(stats.run_counts[y, g]), "run_days": int(stats.run_days[y, g]),
                "eligible_transition_origins": int(stats.transitions[y, g].sum()),
                "same_family_transitions": int(stats.transitions[y, g, g]),
                "rainfall_count": int(stats.rainfall_counts[y, g]), "rainfall_sum_mm": stats.rainfall_sums[y, g]})
            for target, target_group in enumerate(GROUP_ORDER):
                annual_transition_rows.append({"year": int(year), "from_group": group,
                                               "to_group": target_group, "count": int(stats.transitions[y, g, target])})
    _write(pd.DataFrame(annual_rows), output / "annual_family_statistics.csv")
    _write(pd.DataFrame(annual_transition_rows), output / "annual_transition_counts.csv")

    metadata = {
        "method": "Non-parametric whole-season cluster bootstrap with percentile intervals",
        "n_bootstrap_replicates": n_boot, "seed": seed, "confidence_level": confidence,
        "n_season_clusters": ny, "years": stats.years.tolist(),
        "weather_days": len(weather), "rainfall_days": len(rain),
        "resampling_unit": "Entire observed annual selected window; same year multiplicities for all weather and rainfall metrics",
        "no_artificial_season_joins": True, "ratio_estimands": "Pool numerators and denominators before division",
        "run_definition": "Observed within-season runs including potentially truncated boundary-touching runs",
        "p95_estimation": "Exact linear quantile of the season-multiplicity replicated daily depth distribution",
        "interval_scope": "Approximate pointwise intervals, not simultaneous or multiplicity-adjusted",
        "assumptions": ["Observed seasons are treated as approximately independent and exchangeable sampling clusters",
            "Only the observed season distribution is resampled; trends and interannual dependence are not explicitly modelled",
            "Family membership and rainfall eligibility remain fixed in every replicate"],
        "limitations": [f"Only {ny} seasons provide information about interannual uncertainty; more replicates do not increase that information",
            "Intervals do not include radar measurement error, grouped-bin approximation error or uncertainty from constructing the families",
            "Available-record rainfall means remain conditional on the retained dates; resampling does not recover excluded or missing rainfall",
            "P95 depth intervals may be especially variable in less frequent families",
            "These intervals do not independently validate rainfall-based family construction or a Markov/storyline generator"],
        "significance_testing": "No p-values, null-hypothesis tests or significance labels are generated; Stage 1 is descriptive",
        "leave_one_season_out": "Each observed season omitted once; rankings and changes are descriptive stability checks, not significance tests",
        "invalid_bootstrap_counts": {metric: (n_boot - np.isfinite(values).sum(axis=0)).tolist()
                                      for metric, values in bootstrap.items()},
        "invalid_transition_bootstrap_counts": (n_boot - np.isfinite(bootstrap_transition).sum(axis=0)).tolist(),
    }
    (output / "bootstrap_metadata.json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"n_seasons": ny, "n_bootstrap_replicates": n_boot, "seed": seed,
                      "confidence_level": confidence,
                      "rank_stability": [{"metric": row["metric"], "preserved": row["rank_order_preserved_count"],
                                           "omissions": ny} for row in rank_rows]}, indent=2))
    return metadata


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package-root", type=Path, default=ROOT)
    parser.add_argument("--n-bootstrap", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--confidence", type=float, default=.95)
    args = parser.parse_args()
    run_uncertainty(args.package_root, args.n_bootstrap, args.seed, args.confidence)


if __name__ == "__main__":
    main()
