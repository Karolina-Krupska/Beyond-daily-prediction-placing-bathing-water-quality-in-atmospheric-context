"""Optional source-reconstruction audit; never changes or filters Step 1 data.

Can use the packaged readable-histogram ZIP. Reconstructs the saved metric
conversions without fitting statistical models. Historical exclusion files
are not overwritten by the default output location.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import re
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
EDGES = np.array([0, .0625, .125, .25, .5, 1, 2, 4, 8, 16, 32, 64, 128, 256.])
UPPERS = np.r_[EDGES[1:], 512.]
REPRESENTATIVES = np.r_[0., (UPPERS[1:] - EDGES[1:]) / (np.log(UPPERS[1:]) - np.log(EDGES[1:]))]
FIELDS = ["total_samples", "wet_fraction", "q50_mmph", "q90_mmph", "q95_mmph", "mean_rate_mmph", "daily_depth_mm"]


def wet_quantile(counts: np.ndarray, q: float) -> float:
    weights = counts[1:]
    total = weights.sum()
    if total <= 0:
        return 0.
    cumulative = np.cumsum(weights)
    i = min(int(np.searchsorted(cumulative, q * total, side="left")), len(weights) - 1)
    fraction = np.clip((q * total - (cumulative[i] - weights[i])) / weights[i], 0, 1)
    return float(np.exp(np.log(EDGES[i + 1]) + fraction * (np.log(UPPERS[i + 1]) - np.log(EDGES[i + 1]))))


def audit(archive: Path, workbook: Path, out: Path, eligible_dates: Path | None = None) -> dict:
    out.mkdir(parents=True, exist_ok=True)
    stored = pd.read_excel(workbook, sheet_name="daily_metrics")
    stored["date"] = pd.to_datetime(stored.date)
    stored = stored.loc[stored.region.eq("SWEW") & stored.date.dt.year.between(2012, 2024)
                        & stored.date.dt.month.between(5, 9)].sort_values("date")
    if stored.date.duplicated().any():
        raise ValueError("Duplicate SWEW daily keys in workbook.")
    if eligible_dates is not None:
        requested = pd.read_csv(eligible_dates, usecols=["date"], parse_dates=["date"])
        if requested.date.duplicated().any() or not set(requested.date).issubset(set(stored.date)):
            raise ValueError("Eligible-date table contains duplicates or dates absent from the workbook.")
        stored = stored.loc[stored.date.isin(requested.date)]
    rows = []
    maximum_errors = {field: 0. for field in FIELDS}
    with zipfile.ZipFile(archive) as source:
        names = {}
        for name in source.namelist():
            match = re.search(r"(?:^|/)rainfall_linear_all_regions_(\d{8})\.csv$", name)
            if match:
                date = pd.to_datetime(match.group(1), format="%Y%m%d")
                if date in names:
                    raise ValueError(f"More than one source histogram for {date.date()}.")
                names[date] = name
        for _, saved in stored.iterrows():
            date = saved.date
            record = {"date": date.strftime("%Y-%m-%d"), "regime": int(saved.regime),
                      "archive_entry": names.get(date, ""), "status": "absent_source_file",
                      "all_metrics_match": "", "note": ""}
            if date not in names:
                rows.append(record)
                continue
            try:
                table = pd.read_csv(io.BytesIO(source.read(names[date])))
            except Exception as error:
                record.update(status="unreadable_source_file", note=type(error).__name__)
                rows.append(record)
                continue
            if "region" not in table.columns:
                record.update(status="invalid_source_structure", note="Missing region column")
                rows.append(record)
                continue
            selected = table.loc[table.region.astype(str).str.strip().eq("SWEW")]
            if len(selected) != 1:
                record.update(status="invalid_source_structure", note=f"SWEW rows: {len(selected)}")
                rows.append(record)
                continue
            columns = {}
            for column in table.columns:
                try:
                    columns[float(column)] = column
                except (TypeError, ValueError):
                    pass
            if any(edge not in columns for edge in EDGES):
                record.update(status="invalid_source_structure", note="Missing canonical bin column")
                rows.append(record)
                continue
            try:
                counts = np.array([float(selected.iloc[0][columns[edge]]) for edge in EDGES])
            except (TypeError, ValueError):
                record.update(status="invalid_histogram_counts", note="Unparseable count")
                rows.append(record)
                continue
            if not np.isfinite(counts).all() or (counts < 0).any() or counts.sum() <= 0:
                record.update(status="invalid_histogram_counts", note="Non-finite, negative or zero-total counts")
                rows.append(record)
                continue
            total = counts.sum()
            mean = float(np.dot(counts, REPRESENTATIVES) / total)
            calculated = [total, 1 - counts[0] / total, wet_quantile(counts, .5), wet_quantile(counts, .9),
                          wet_quantile(counts, .95), mean, mean * 24]
            matches = []
            for field, value in zip(FIELDS, calculated):
                error = abs(float(saved[field]) - value)
                maximum_errors[field] = max(maximum_errors[field], error)
                record[f"abs_difference_{field}"] = error
                matches.append(bool(np.isclose(float(saved[field]), value, rtol=1e-10, atol=1e-10)))
            record.update(status="readable_metrics_match" if all(matches) else "readable_metrics_mismatch",
                          all_metrics_match=all(matches))
            rows.append(record)
    report = pd.DataFrame(rows)
    report.to_csv(out / "histogram_source_status.csv", index=False, float_format="%.15g")
    digest = hashlib.sha256()
    with archive.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    summary = {"scope": "SWEW; May–September 2012–2024", "processed_dates": len(report),
               "archive_filename": archive.name, "archive_sha256": digest.hexdigest(),
               "workbook_sha256": hashlib.sha256(workbook.read_bytes()).hexdigest(),
               "source_histogram_filenames_in_archive": len(names),
               "status_counts": report.status.value_counts().to_dict(),
               "maximum_absolute_metric_differences": maximum_errors,
               "tolerance": {"rtol": 1e-10, "atol": 1e-10},
               "interpretation": "Implementation consistency under the stated bin assumptions; not independent measurement validation",
               "audit_itself_modifies_workbook": False}
    (out / "histogram_source_audit.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, default=ROOT / "data/input/readable_histograms.zip")
    parser.add_argument("--workbook", type=Path, default=ROOT / "data/input/fullrange_noqc_stats.xlsx")
    parser.add_argument("--outdir", type=Path, default=ROOT / "results/retained_source_check")
    parser.add_argument("--eligible-only", action="store_true", help="Check only the dates retained in Step 1")
    args = parser.parse_args()
    eligible = ROOT / "data/processed/daily_metrics_SWEW_MaySep_NOQC.csv" if args.eligible_only else None
    audit(args.archive, args.workbook, args.outdir, eligible)
