"""Create reporting tables and text from saved uncertainty results."""
from __future__ import annotations

from pathlib import Path
import json

import pandas as pd

GROUPS = ["Cyclonic Atlantic (frontal)", "Showery maritime / unsettled",
          "Convective extremes", "Settled anticyclonic quiet"]
LABELS = {
    "calendar_fraction": ("Calendar frequency", "%", 100),
    "mean_run_days": ("Mean observed within-season run", "days", 1),
    "same_family_transition_probability": ("Same-family next-day probability", "probability", 1),
    "mean_daily_depth_mm": ("Mean daily rainfall depth", "mm", 1),
    "p95_daily_depth_mm": ("95th percentile of daily rainfall depth", "mm", 1),
}


def write_report(root: Path) -> None:
    root = Path(root)
    output = root / "results/uncertainty"
    ci = pd.read_csv(output / "bootstrap_confidence_intervals.csv")
    stability = pd.read_csv(output / "stability_summary.csv")
    rank = pd.read_csv(output / "family_rank_stability.csv")
    denominators = pd.read_csv(root / "results/analysis_denominators.csv").set_index("group")
    indexed = ci.set_index(["group", "metric"])
    metadata = json.loads((output / "bootstrap_metadata.json").read_text())
    if metadata["confidence_level"] != .95 or not ci.confidence_level.eq(.95).all():
        raise ValueError("This publication report expects 95% confidence intervals.")
    config = {"seed": metadata["seed"]}
    n_boot = metadata["n_bootstrap_replicates"]
    rows = []
    lines = ["STEP 1 UNCERTAINTY AND SENSITIVITY", "",
        f"Approximate pointwise 95% percentile intervals: {n_boot:,} whole-season bootstrap resamples; "
        f"seed {config['seed']}. The 13 season identifiers are sampled jointly for circulation and rainfall. "
        "Original within-season runs and adjacent-day transitions are preserved. Intervals are conditional "
        "on the fixed family mapping and the retained rainfall records. They assume seasons are suitable "
        "approximately exchangeable resampling units and do not measure radar accuracy, missing-data "
        "bias or uncertainty in constructing the family classification. These are pointwise rather than "
        "simultaneous intervals; no familywise significance claims are made.", ""]
    for group in GROUPS:
        lines.append(group)
        row = {"group": group, "calendar_days": int(denominators.loc[group, "calendar_days"]),
               "rainfall_days": int(denominators.loc[group, "rainfall_days"])}
        for metric, (label, unit, scale) in LABELS.items():
            result = indexed.loc[(group, metric)]
            point, low, high = [float(result[name]) for name in ["estimate", "ci_lower", "ci_upper"]]
            row.update({metric: point, f"{metric}_ci_lower": low, f"{metric}_ci_upper": high})
            digits = 3 if unit == "probability" else 2
            lines.append(f"  {label}: {point*scale:.{digits}f} {unit}; "
                         f"95% interval {low*scale:.{digits}f} to {high*scale:.{digits}f} {unit}.")
        rows.append(row)
    lines.extend(["", "LEAVE-ONE-SEASON-OUT SENSITIVITY",
        "Each summer was omitted once. The ranges below are sensitivity ranges, not confidence intervals."])
    for _, row in stability.iterrows():
        label, unit, scale = LABELS[row.metric]
        change_unit = "percentage points" if row.metric == "calendar_fraction" else unit
        lines.append(f"{row.group}; {label}: full estimate {row.full_estimate*scale:.3f} {unit}; "
                     f"leave-one-season-out range {row.loso_min*scale:.3f} to {row.loso_max*scale:.3f} {unit}; "
                     f"largest absolute change {row.max_abs_change*scale:.3f} {change_unit} "
                     f"when omitting {int(row.most_influential_year)}.")
    lines.extend(["", "DESCRIPTIVE ORDERING STABILITY"])
    for _, row in rank.iterrows():
        label = LABELS[row.metric][0]
        lines.append(f"{label}: the complete-data family ordering was preserved in "
                     f"{int(row.rank_order_preserved_count)} of {int(row.n_omissions)} omissions. "
                     "This is a sensitivity summary, not a p-value or a probability that the ordering is true.")
    lines.extend(["", "SOURCE-EXCLUSION SENSITIVITY",
        "The 1,969-to-1,940 record comparison remains in results/rainfall_summary_changes.csv. "
        "Mean rainfall ordering is unchanged. The P95 ordering of the showery and convective families "
        "changes, so the source restriction must not be described as having no scientific effect.", "",
        "No null-hypothesis significance tests were added. This step describes observed circulation and "
        "rainfall organisation; rainfall diagnostics also helped define the families. Tests of rainfall "
        "separation in overlapping data would not independently validate the classification. The bootstrap "
        "intervals do not establish operational forecast skill or the adequacy of a storyline generator."])
    (output / "uncertainty_summary.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    pd.DataFrame(rows).to_csv(output / "publication_table.csv", index=False, float_format="%.15g")

    full = GROUPS[0]
    cyclone_run = indexed.loc[(full, "mean_run_days")]
    cyclone_self = indexed.loc[(full, "same_family_transition_probability")]
    cyclone_rain = indexed.loc[(full, "mean_daily_depth_mm")]
    paragraph = (
        "Uncertainty was summarised using approximate pointwise 95% whole-season bootstrap intervals "
        f"({n_boot:,} resamples), with each of the 13 summers treated as a joint circulation–rainfall "
        "resampling unit. Estimates and intervals are conditional on the fixed family mapping and "
        "the source-eligible rainfall records. Cyclonic Atlantic conditions had a mean observed "
        f"within-season run length of {cyclone_run.estimate:.2f} days "
        f"(95% interval {cyclone_run.ci_lower:.2f}–{cyclone_run.ci_upper:.2f}), "
        f"a same-family next-day probability of {cyclone_self.estimate:.2f} "
        f"({cyclone_self.ci_lower:.2f}–{cyclone_self.ci_upper:.2f}), and mean daily rainfall depth of "
        f"{cyclone_rain.estimate:.2f} mm ({cyclone_rain.ci_lower:.2f}–{cyclone_rain.ci_upper:.2f}). "
        "Leave-one-season-out results were used to assess sensitivity to individual summers; "
        "their ranges were not interpreted as confidence intervals."
    )
    ordering = []
    for metric in ["mean_run_days", "same_family_transition_probability", "mean_daily_depth_mm", "p95_daily_depth_mm"]:
        record = rank.loc[rank.metric.eq(metric)].iloc[0]
        ordering.append(f"The full family ordering for {LABELS[metric][0].lower()} was preserved "
                        f"in {int(record.rank_order_preserved_count)} of {int(record.n_omissions)} "
                        "leave-one-season-out calculations.")
    text = paragraph + "\n\n" + " ".join(ordering) + "\n\n" + (
        "Interpretation: thirteen seasons provide limited information about interannual uncertainty. "
        "The intervals and sensitivity results do not validate radar extremes, account for family-construction "
        "uncertainty, or establish that family differences are statistically significant.\n")
    (output / "manuscript_addition.txt").write_text(text, encoding="utf-8")


if __name__ == "__main__":
    write_report(Path(__file__).resolve().parents[1])
