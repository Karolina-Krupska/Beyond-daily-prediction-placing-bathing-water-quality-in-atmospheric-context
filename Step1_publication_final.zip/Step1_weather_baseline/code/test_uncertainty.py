"""Focused tests of season resampling, pooled estimands and quantile weights."""
from __future__ import annotations

import unittest
import numpy as np
import pandas as pd

from step1_baseline import GROUP_ORDER, consecutive_pairs, observed_runs, transition_matrices
from step1_uncertainty import (build_seasonal_statistics, draw_season_weights,
    percentile_interval, summarise_weights, weighted_linear_quantile)


def fixtures():
    a, b, c, d = GROUP_ORDER
    rows = []
    for year, groups in [(2018, [a, a, a, b, c, d]), (2019, [a, b, b, b, c, d])]:
        for date, group in zip(pd.date_range(f"{year}-05-01", periods=len(groups)), groups):
            rows.append({"date": date, "year": year, "month": 5, "group": group})
    weather = pd.DataFrame(rows)
    rainfall = pd.DataFrame([
        {"date": pd.Timestamp("2018-05-01"), "year": 2018, "group": a, "daily_depth_mm": 1.},
        {"date": pd.Timestamp("2018-05-02"), "year": 2018, "group": a, "daily_depth_mm": 5.},
        {"date": pd.Timestamp("2018-05-04"), "year": 2018, "group": b, "daily_depth_mm": 8.},
        {"date": pd.Timestamp("2019-05-01"), "year": 2019, "group": a, "daily_depth_mm": 12.},
        {"date": pd.Timestamp("2019-05-02"), "year": 2019, "group": b, "daily_depth_mm": 2.},
    ])
    return weather, rainfall


class SeasonUncertaintyTests(unittest.TestCase):
    def test_integer_weighted_quantile_equals_physical_replication(self):
        rng = np.random.default_rng(13)
        for n in range(1, 20):
            values = rng.integers(0, 8, size=n).astype(float)
            weights = rng.integers(0, 5, size=n)
            if not weights.sum():
                weights[0] = 1
            for q in [0, .5, .95, 1]:
                expected = np.quantile(np.repeat(values, weights), q, method="linear")
                self.assertAlmostEqual(weighted_linear_quantile(values, weights, q), expected)

    def test_zero_weight_and_non_integer_quantile_input(self):
        self.assertTrue(np.isnan(weighted_linear_quantile(np.array([1., 3.]), np.array([0, 0]), .95)))
        with self.assertRaisesRegex(ValueError, "integer"):
            weighted_linear_quantile(np.array([1., 3.]), np.array([.5, 1.]), .95)

    def test_pooled_rainfall_mean_is_not_an_average_of_annual_means(self):
        weather, rain = fixtures()
        stats = build_seasonal_statistics(weather, rain)
        estimates, _ = summarise_weights(stats, np.array([[2, 1]]))
        self.assertAlmostEqual(estimates["mean_daily_depth_mm"][0, 0], 24 / 5)
        self.assertNotAlmostEqual(estimates["mean_daily_depth_mm"][0, 0], (2 * 3 + 12) / 3)
        self.assertAlmostEqual(estimates["p95_daily_depth_mm"][0, 0], np.quantile([1, 5, 1, 5, 12], .95))

    def test_duplicated_seasons_match_individual_season_summaries_without_joins(self):
        weather, rain = fixtures()
        stats = build_seasonal_statistics(weather, rain)
        estimates, transitions = summarise_weights(stats, np.array([[2, 1]]))
        expected_transitions = np.zeros((4, 4), dtype=int)
        run_lengths = []
        for year in [2018, 2018, 2019]:
            season = weather.loc[weather.year.eq(year)]
            expected_transitions += transition_matrices(consecutive_pairs(season))[0].to_numpy()
            runs = observed_runs(season)
            run_lengths.extend(runs.loc[runs.group.eq(GROUP_ORDER[0]), "run_length"].tolist())
        self.assertAlmostEqual(transitions[0, 0, 0], 4 / 7)
        self.assertAlmostEqual(estimates["mean_run_days"][0, 0], np.mean(run_lengths))
        self.assertEqual(int(expected_transitions.sum()), 15)
        self.assertTrue(np.allclose(transitions[0, :3],
            expected_transitions[:3] / expected_transitions[:3].sum(axis=1, keepdims=True)))

    def test_missing_rainfall_does_not_change_weather_denominators(self):
        weather, rain = fixtures()
        stats = build_seasonal_statistics(weather, rain)
        reduced = build_seasonal_statistics(weather, rain.iloc[:2])
        weights = np.array([[1, 1]])
        a, ta = summarise_weights(stats, weights)
        b, tb = summarise_weights(reduced, weights)
        self.assertTrue(np.allclose(a["calendar_fraction"], b["calendar_fraction"]))
        self.assertTrue(np.allclose(ta, tb, equal_nan=True))
        self.assertAlmostEqual(a["calendar_fraction"][0, 0], 4 / 12)
        self.assertTrue(np.isnan(b["mean_daily_depth_mm"][0, 1]))

    def test_fixed_seed_draws_and_invalid_interval_count(self):
        a = draw_season_weights(13, 100, 42)
        b = draw_season_weights(13, 100, 42)
        self.assertTrue(np.array_equal(a, b))
        self.assertTrue(np.array_equal(a.sum(axis=1), np.full(100, 13)))
        low, high, n = percentile_interval(np.array([np.nan, 1., 2., 3., np.inf]), .95)
        self.assertEqual(n, 3)
        self.assertAlmostEqual(low, 1.05)
        self.assertAlmostEqual(high, 2.95)


if __name__ == "__main__":
    unittest.main(verbosity=2)
