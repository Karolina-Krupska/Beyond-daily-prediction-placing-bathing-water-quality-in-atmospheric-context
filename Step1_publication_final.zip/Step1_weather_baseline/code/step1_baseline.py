"""Step 1: descriptive circulation frequency, persistence, transitions and rainfall.

Run from any directory: python path/to/code/step1_baseline.py
Uses the supplied classification CSV, fullrange_noqc_stats.xlsx and its
archived histogram-source eligibility record.
No microbiological data, predictive fitting or storyline simulation is performed.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import platform
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
GROUP_MEMBERS = {
    "Cyclonic Atlantic (frontal)": [1, 5, 7, 8, 11, 19, 21, 22, 24, 28, 29, 30],
    "Showery maritime / unsettled": [2, 4, 14, 15, 20, 26],
    "Convective extremes": [3, 6, 9, 10, 12, 16, 17, 18, 27],
    "Settled anticyclonic quiet": [13, 23, 25],
}
GROUP_ORDER = list(GROUP_MEMBERS)
REGIME_TO_GROUP_4 = {wp: group for group, members in GROUP_MEMBERS.items() for wp in members}
CANON_BINS = np.array([0, .0625, .125, .25, .5, 1, 2, 4, 8, 16, 32, 64, 128, 256.])
RAIN_COLUMNS = ["total_samples", "wet_fraction", "q50_mmph", "q90_mmph", "q95_mmph",
                "mean_rate_mmph", "daily_depth_mm"]


def verify_mapping() -> None:
    members = [wp for values in GROUP_MEMBERS.values() for wp in values]
    if len(members) != 30 or len(set(members)) != 30 or set(members) != set(range(1, 31)):
        raise ValueError("Family membership must cover WP1–WP30 exactly once.")


def expected_calendar(start_year: int, end_year: int, months: list[int]) -> pd.DatetimeIndex:
    if start_year > end_year or not months or any(m not in range(1, 13) for m in months):
        raise ValueError("Choose start-year <= end-year and at least one month in 1–12.")
    dates = pd.date_range(f"{start_year}-01-01", f"{end_year}-12-31", freq="D")
    return dates[dates.month.isin(months)]


def reject_duplicate_dates(frame: pd.DataFrame, label: str) -> None:
    duplicated = frame.loc[frame.date.duplicated(keep=False), "date"]
    if not duplicated.empty:
        names = duplicated.dt.strftime("%Y-%m-%d").unique().tolist()[:8]
        raise ValueError(f"{label}: duplicate daily keys, for example {names}.")


def integer_column(values: pd.Series, name: str) -> pd.Series:
    numeric = pd.to_numeric(values, errors="raise")
    if not np.isfinite(numeric.to_numpy(dtype=float)).all() or not np.equal(numeric % 1, 0).all():
        raise ValueError(f"{name} must contain finite integers.")
    return numeric.astype(int)


def load_weather(path: Path, dates: pd.DatetimeIndex) -> pd.DataFrame:
    raw = pd.read_csv(path, comment="#")
    required = {"year", "month", "day", "regime"}
    if not required.issubset(raw.columns):
        raise ValueError(f"Classification CSV lacks columns: {sorted(required - set(raw.columns))}.")
    raw["date"] = pd.to_datetime(raw[["year", "month", "day"]], errors="raise")
    weather = raw.loc[raw.date.isin(dates), ["date", "regime"]].copy()
    reject_duplicate_dates(weather, "Weather calendar")
    missing = dates.difference(pd.DatetimeIndex(weather.date))
    if len(missing):
        raise ValueError(f"Weather calendar is incomplete: {len(missing)} requested dates missing.")
    weather["regime"] = integer_column(weather.regime, "Calendar regime")
    if not weather.regime.between(1, 30).all():
        raise ValueError("Calendar regime outside 1–30.")
    weather["group"] = weather.regime.map(REGIME_TO_GROUP_4)
    weather["year"] = weather.date.dt.year
    weather["month"] = weather.date.dt.month
    return weather.sort_values("date").reset_index(drop=True)


def validate_rainfall(rain: pd.DataFrame, weather: pd.DataFrame) -> pd.DataFrame:
    """Validate already scoped SWEW rows; never fill absent rainfall values."""
    required = {"date", "regime", *RAIN_COLUMNS}
    if not required.issubset(rain.columns):
        raise ValueError(f"Rainfall table lacks columns: {sorted(required - set(rain.columns))}.")
    rain = rain.copy()
    reject_duplicate_dates(rain, "SWEW rainfall")
    if rain.empty:
        raise ValueError("No SWEW rainfall records within the requested calendar.")
    rain["regime"] = integer_column(rain.regime, "Rainfall regime")
    if not rain.regime.between(1, 30).all():
        raise ValueError("Rainfall regime outside 1–30.")
    for name in RAIN_COLUMNS:
        rain[name] = pd.to_numeric(rain[name], errors="raise")
        if not np.isfinite(rain[name].to_numpy(dtype=float)).all():
            raise ValueError(f"SWEW rainfall contains non-finite {name}; investigate the source.")
    if (rain.total_samples <= 0).any() or not np.equal(rain.total_samples % 1, 0).all():
        raise ValueError("Histogram totals must be positive integer pixel–time counts.")
    if not rain.wet_fraction.between(0, 1).all():
        raise ValueError("Wet fractions must be within 0–1.")
    if (rain[["q50_mmph", "q90_mmph", "q95_mmph", "mean_rate_mmph", "daily_depth_mm"]] < 0).any().any():
        raise ValueError("Rainfall rates, depths and quantiles cannot be negative.")
    if ((rain.q50_mmph > rain.q90_mmph) | (rain.q90_mmph > rain.q95_mmph)).any():
        raise ValueError("Wet-only quantiles must satisfy q50 <= q90 <= q95.")
    if not np.allclose(rain.daily_depth_mm, rain.mean_rate_mmph * 24, rtol=1e-10, atol=1e-10):
        raise ValueError("Daily depth does not match mean rate multiplied by 24.")
    comparison = rain[["date", "regime"]].merge(
        weather[["date", "regime"]], on="date", how="left", suffixes=("_rain", "_calendar"),
        validate="one_to_one", indicator=True)
    if not comparison._merge.eq("both").all():
        raise ValueError("A rainfall record has no matching classification date.")
    if not comparison.regime_rain.eq(comparison.regime_calendar).all():
        bad = comparison.loc[comparison.regime_rain.ne(comparison.regime_calendar), "date"]
        raise ValueError(f"Rainfall/calendar regime mismatch: {bad.dt.strftime('%Y-%m-%d').tolist()[:8]}.")
    rain["group"] = rain.regime.map(REGIME_TO_GROUP_4)
    rain["year"] = rain.date.dt.year
    rain["month"] = rain.date.dt.month
    return rain.sort_values("date").reset_index(drop=True)


def load_rainfall(path: Path, weather: pd.DataFrame, region: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    raw = pd.read_excel(path, sheet_name="daily_metrics")
    if not {"date", "region"}.issubset(raw.columns):
        raise ValueError("The daily_metrics sheet needs date and region columns.")
    raw["date"] = pd.to_datetime(raw.date, errors="raise")
    if not raw.date.eq(raw.date.dt.normalize()).all():
        raise ValueError("Rainfall dates include times; do not silently aggregate them.")
    scoped = raw.loc[raw.region.astype(str).str.strip().eq(region) & raw.date.isin(weather.date)].copy()
    rain = validate_rainfall(scoped, weather)
    meta = pd.read_excel(path, sheet_name="bins_metadata")
    needed = {"bin_lower_mmph", "bin_upper_mmph", "rep_logmean_mmph"}
    if not needed.issubset(meta.columns) or len(meta) != len(CANON_BINS):
        raise ValueError("Unexpected or missing bin metadata.")
    uppers = np.r_[CANON_BINS[1:], CANON_BINS[-1] * 2]
    reps = np.r_[0., (uppers[1:] - CANON_BINS[1:]) / (np.log(uppers[1:]) - np.log(CANON_BINS[1:]))]
    for column, expected in [("bin_lower_mmph", CANON_BINS), ("bin_upper_mmph", uppers),
                             ("rep_logmean_mmph", reps)]:
        if not np.allclose(meta[column], expected, rtol=1e-10, atol=1e-10):
            raise ValueError(f"Unexpected {column}; update method definitions before proceeding.")
    return rain, meta


def consecutive_pairs(weather: pd.DataFrame) -> pd.DataFrame:
    frame = weather[["date", "group", "year", "month"]].copy()
    frame["next_date"] = frame.date.shift(-1)
    frame["next_group"] = frame.group.shift(-1)
    adjacent = frame.next_date.eq(frame.date + pd.Timedelta(days=1))
    same_year = frame.year.eq(frame.year.shift(-1))
    return frame.loc[adjacent & same_year].reset_index(drop=True)


def transition_matrices(pairs: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    if pairs.empty:
        counts = pd.DataFrame(0, index=GROUP_ORDER, columns=GROUP_ORDER)
    else:
        counts = pd.crosstab(pairs.group, pairs.next_group).reindex(
            index=GROUP_ORDER, columns=GROUP_ORDER, fill_value=0).fillna(0).astype(int)
    counts.index.name = "from_group"
    counts.columns.name = "to_group"
    probabilities = counts.div(counts.sum(axis=1).replace(0, np.nan), axis=0)
    return counts, probabilities


def observed_runs(weather: pd.DataFrame) -> pd.DataFrame:
    """Runs within selected annual windows, including boundary-touching runs."""
    frame = weather.sort_values("date").reset_index(drop=True)
    gap_before = frame.date.diff().ne(pd.Timedelta(days=1)) | frame.year.ne(frame.year.shift())
    gap_after = frame.date.shift(-1).sub(frame.date).ne(pd.Timedelta(days=1)) | frame.year.ne(frame.year.shift(-1))
    frame["run_id"] = (gap_before | frame.group.ne(frame.group.shift())).cumsum()
    frame["left_boundary"] = gap_before
    frame["right_boundary"] = gap_after
    runs = frame.groupby("run_id", sort=True).agg(
        group=("group", "first"), start_date=("date", "min"), end_date=("date", "max"),
        run_length=("date", "size"), year=("year", "first"),
        touches_left_boundary=("left_boundary", "any"),
        touches_right_boundary=("right_boundary", "any"))
    return runs.reset_index()


def run_summary(runs: pd.DataFrame) -> pd.DataFrame:
    summary = runs.groupby("group").agg(
        n_runs=("run_length", "size"), mean=("run_length", "mean"), median=("run_length", "median"),
        max=("run_length", "max"), p90=("run_length", lambda s: s.quantile(.90, interpolation="linear")),
        p95=("run_length", lambda s: s.quantile(.95, interpolation="linear")),
    ).reindex(GROUP_ORDER).join(
        runs.assign(boundary_touching=runs.touches_left_boundary | runs.touches_right_boundary)
        .groupby("group").boundary_touching.sum().rename("boundary_touching_runs"))
    for field in ["n_runs", "boundary_touching_runs"]:
        summary[field] = summary[field].fillna(0).astype(int)
    return summary


def rainfall_summary(rain: pd.DataFrame) -> pd.DataFrame:
    summary = rain.groupby("group").agg(
        n_days=("daily_depth_mm", "size"), mean_mm=("daily_depth_mm", "mean"),
        median_mm=("daily_depth_mm", "median"),
        p90_mm=("daily_depth_mm", lambda s: s.quantile(.90, interpolation="linear")),
        p95_mm=("daily_depth_mm", lambda s: s.quantile(.95, interpolation="linear")),
        mean_wet_fraction=("wet_fraction", "mean"), median_wet_fraction=("wet_fraction", "median"),
    ).reindex(GROUP_ORDER)
    summary["n_days"] = summary.n_days.fillna(0).astype(int)
    return summary


def write_csv(frame: pd.DataFrame, path: Path, index: bool = False) -> None:
    frame.to_csv(path, index=index, date_format="%Y-%m-%d", float_format="%.15g")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def source_readability_selection(rain: pd.DataFrame, workbook: Path,
                                provenance_dir: Path) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Keep only dates reconstructed from readable source histograms.

    The audit is tied to the exact input workbook by SHA-256. This is a
    provenance-based eligibility rule, not an intensity or outlier filter.
    """
    audit = json.loads((provenance_dir / "histogram_source_audit.json").read_text(encoding="utf-8"))
    if audit.get("workbook_sha256") != sha256(workbook):
        raise ValueError("The source audit does not match this workbook; repeat the source audit first.")
    status = pd.read_csv(provenance_dir / "histogram_source_status.csv", parse_dates=["date"])
    reject_duplicate_dates(status, "Histogram source audit")
    valid_statuses = {"readable_metrics_match", "unreadable_source_file", "absent_source_file"}
    if not set(status.status).issubset(valid_statuses):
        raise ValueError("Source audit contains a mismatch or invalid histogram; review it before selection.")
    reviewed = rain.merge(status[["date", "regime", "status", "all_metrics_match", "archive_entry"]],
                          on="date", how="left", validate="one_to_one", suffixes=("", "_audit"))
    if reviewed.status.isna().any() or not reviewed.regime.eq(reviewed.regime_audit).all():
        raise ValueError("Source audit is incomplete or disagrees with the rainfall classifications.")
    keep = reviewed.status.eq("readable_metrics_match")
    if not reviewed.loc[keep, "all_metrics_match"].astype(str).str.lower().eq("true").all():
        raise ValueError("A retained source date lacks a confirmed metric match.")
    selected = rain.loc[rain.date.isin(reviewed.loc[keep, "date"])].copy()
    if selected.empty:
        raise ValueError("No rainfall dates satisfy the source-readability eligibility rule.")
    excluded = reviewed.loc[~keep].drop(columns=["regime_audit"])
    return selected.reset_index(drop=True), excluded.reset_index(drop=True), status


def run_analysis(classifications: Path, rainfall: Path, out: Path, start_year: int = 2012,
                 end_year: int = 2024, months: list[int] | None = None, region: str = "SWEW",
                 make_figures: bool = True, n_bootstrap: int = 10000,
                 bootstrap_seed: int = 42) -> dict:
    verify_mapping()
    months = sorted(set(months if months is not None else [5, 6, 7, 8, 9]))
    dates = expected_calendar(start_year, end_year, months)
    weather = load_weather(classifications, dates)
    original_rain, bins = load_rainfall(rainfall, weather, region)
    provenance = ROOT / "data/provenance"
    rain, excluded, source_status = source_readability_selection(original_rain, rainfall, provenance)
    results = out / "results"
    processed = out / "data" / "processed"
    results.mkdir(parents=True, exist_ok=True)
    processed.mkdir(parents=True, exist_ok=True)

    counts = weather.group.value_counts().reindex(GROUP_ORDER, fill_value=0).rename("days").to_frame()
    counts.index.name = "group"
    counts["fraction"] = counts.days / len(weather)
    pairs = consecutive_pairs(weather)
    transition_counts, transition_probs = transition_matrices(pairs)
    runs = observed_runs(weather)
    runs_by_group = run_summary(runs)
    rain_by_group = rainfall_summary(rain)
    joined = weather.merge(rain.drop(columns=["group", "year", "month", "regime"]),
                           on="date", how="left", validate="one_to_one")
    joined["rainfall_available"] = joined.total_samples.notna()
    joined["processed_source_record_exists"] = joined.date.isin(original_rain.date)
    source_lookup = source_status.set_index("date").status
    joined["rainfall_source_status"] = joined.date.map(source_lookup).fillna("no_processed_rainfall_record")
    missing = joined.loc[~joined.rainfall_available, ["date", "regime", "group", "year", "month",
                                                    "processed_source_record_exists", "rainfall_source_status"]]
    originally_missing = missing.loc[~missing.processed_source_record_exists].copy()

    # Reconcile weighted summaries and preserve calendar days regardless of rainfall missingness.
    if counts.days.sum() != len(dates) or runs.run_length.sum() != len(dates):
        raise AssertionError("Calendar counts/runs fail reconciliation.")
    if int(transition_counts.to_numpy().sum()) != len(pairs):
        raise AssertionError("Transition totals fail reconciliation.")
    eligible = transition_counts.sum(axis=1)
    if not np.allclose(transition_probs.loc[eligible.gt(0)].sum(axis=1), 1):
        raise AssertionError("Non-empty transition rows must sum to one.")
    if int(rain_by_group.n_days.fillna(0).sum()) + len(missing) != len(weather):
        raise AssertionError("Rainfall coverage fails reconciliation.")
    mean_depth = np.average(rain_by_group.loc[rain_by_group.n_days.gt(0), "mean_mm"],
                            weights=rain_by_group.loc[rain_by_group.n_days.gt(0), "n_days"])
    if not np.isclose(mean_depth, rain.daily_depth_mm.mean(), rtol=1e-12, atol=1e-12):
        raise AssertionError("Family rainfall means fail weighted reconciliation.")

    write_csv(counts, results / "group_counts_fractions.csv", index=True)
    write_csv(transition_counts, results / "transition_counts.csv", index=True)
    write_csv(transition_probs, results / "transition_probs.csv", index=True)
    write_csv(runs, results / "observed_family_runs.csv")
    write_csv(runs_by_group, results / "run_length_summary.csv", index=True)
    write_csv(rain_by_group, results / "SWEW_rainfall_by_group.csv", index=True)
    comparison = rainfall_summary(original_rain).add_suffix("_previous_1969").join(
        rain_by_group.add_suffix("_revised_1940"))
    comparison["excluded_days"] = comparison.n_days_previous_1969 - comparison.n_days_revised_1940
    write_csv(comparison, results / "rainfall_summary_changes.csv", index=True)
    write_csv(missing, results / "missing_rainfall_dates.csv")
    write_csv(originally_missing, results / "originally_missing_rainfall_dates.csv")
    write_csv(excluded, results / "excluded_rainfall_records.csv")
    write_csv(weather, processed / "weather_calendar.csv")
    write_csv(rain, processed / "daily_metrics_SWEW_MaySep_NOQC.csv")
    write_csv(joined, processed / "weather_rainfall_daily_matrix.csv")
    write_csv(bins, processed / "bins_metadata.csv")
    write_csv(pd.DataFrame([{"regime": wp, "group": REGIME_TO_GROUP_4[wp]}
                            for wp in range(1, 31)]), processed / "weather_pattern_family_mapping.csv")

    denominator = pd.DataFrame({"group": GROUP_ORDER,
        "calendar_days": counts.days.values,
        "rainfall_days": rain_by_group.n_days.fillna(0).astype(int).values,
        "missing_rainfall_days": counts.days.values - rain_by_group.n_days.fillna(0).astype(int).values,
        "originally_missing_rainfall_days": counts.days.values - original_rain.group.value_counts().reindex(GROUP_ORDER, fill_value=0).values,
        "source_readability_excluded_days": excluded.group.value_counts().reindex(GROUP_ORDER, fill_value=0).values,
        "eligible_transition_origins": eligible.values,
        "within_season_runs": runs_by_group.n_runs.fillna(0).astype(int).values})
    write_csv(denominator, results / "analysis_denominators.csv")
    year_rows = []
    for year in range(start_year, end_year + 1):
        year_weather = weather[weather.year.eq(year)]
        year_rain = rain[rain.year.eq(year)]
        for group in GROUP_ORDER:
            a = year_weather.group.eq(group).sum()
            b = year_rain.group.eq(group).sum()
            year_rows.append({"year": year, "group": group, "calendar_days": a,
                              "calendar_fraction": a / len(year_weather),
                              "rainfall_days": b, "missing_rainfall_days": a - b})
    write_csv(pd.DataFrame(year_rows), results / "annual_family_counts.csv")

    monthly_counts = []
    monthly_transitions = []
    for month in months:
        month_weather = weather[weather.month.eq(month)]
        c, p = transition_matrices(pairs[pairs.month.eq(month)])
        for group in GROUP_ORDER:
            n = int(month_weather.group.eq(group).sum())
            monthly_counts.append({"month": month, "group": group, "days": n,
                                   "fraction_within_month": n / len(month_weather)})
            for target in GROUP_ORDER:
                monthly_transitions.append({"source_month": month, "from_group": group,
                    "to_group": target, "count": int(c.loc[group, target]),
                    "eligible_origin_days": int(c.loc[group].sum()),
                    "probability": p.loc[group, target]})
    write_csv(pd.DataFrame(monthly_counts), results / "monthly_family_counts.csv")
    write_csv(pd.DataFrame(monthly_transitions), results / "monthly_transition_probabilities.csv")

    coverage = {
        "analysis": "Descriptive Step 1 baseline; no model fitting or storyline simulation",
        "start_year": start_year, "end_year": end_year, "months": months, "region": region,
        "expected_calendar_days": len(dates), "weather_calendar_days": len(weather),
        "rainfall_days": len(rain), "missing_rainfall_days": len(missing),
        "original_processed_rainfall_days": len(original_rain),
        "originally_missing_rainfall_days": len(originally_missing),
        "source_readability_excluded_days": len(excluded),
        "source_readability_exclusion_reasons": excluded.status.value_counts().to_dict(),
        "valid_next_day_transitions": len(pairs), "within_season_runs": len(runs),
        "rainfall_source": "fullrange_noqc_stats.xlsx:daily_metrics",
        "rainfall_values_modified": False, "rainfall_gap_filling": False,
        "rainfall_eligibility_rule": "Retain only dates with readable source histograms and matching reconstructed daily metrics",
        "run_boundaries": "Non-consecutive dates and annual analysis-window boundaries break runs",
        "monthly_transitions": "Assigned to source month, including adjacent within-season month boundaries",
        "percentiles": "Across-day or across-run linear-interpolation empirical quantiles; not confidence intervals",
        "source_files": {"classifications": {"filename": classifications.name, "sha256": sha256(classifications)},
                         "rainfall": {"filename": rainfall.name, "sha256": sha256(rainfall)},
                         "histogram_source_status": {"filename": "histogram_source_status.csv", "sha256": sha256(provenance / "histogram_source_status.csv")}},
        "software": {"python": platform.python_version(), **{
            name: importlib.metadata.version(name) for name in ["numpy", "pandas", "matplotlib", "openpyxl"]}},
    }
    (results / "run_metadata.json").write_text(json.dumps(coverage, indent=2) + "\n", encoding="utf-8")
    checks = [
        ("Complete weather calendar", len(weather) == len(dates), f"{len(weather)} dates"),
        ("Unique weather dates", not weather.date.duplicated().any(), "One row per calendar day"),
        ("Unique rainfall dates", not rain.date.duplicated().any(), "One SWEW row per available rainfall day"),
        ("Rainfall/calendar classifications agree", True, "All matched dates checked during loading"),
        ("Finite rainfall metrics", True, "All seven required numeric metrics checked during loading"),
        ("Bin metadata matches generator assumptions", True, "14 bins; logarithmic means; top-bin upper edge 512 mm/hour"),
        ("Daily depth equals mean rate times 24", True, "All rainfall rows checked during loading"),
        ("Family counts sum to calendar total", int(counts.days.sum()) == len(weather), "Complete calendar denominator"),
        ("Run lengths sum to calendar total", int(runs.run_length.sum()) == len(weather), "No days lost or counted twice"),
        ("Transition counts sum to eligible pairs", int(transition_counts.to_numpy().sum()) == len(pairs), "Only consecutive within-year dates"),
        ("Non-empty transition rows sum to one", True, "Checked before export; zero-denominator rows remain missing"),
        ("Rainfall plus missing dates equals calendar", len(rain) + len(missing) == len(weather), "Missing rainfall never becomes zero"),
        ("Weighted family rainfall means reconcile", True, "Compared with overall daily-depth mean"),
        ("Retained rainfall dates have readable matching histogram sources", True, f"{len(rain)} retained; {len(excluded)} excluded with individual reasons"),
    ]
    write_csv(pd.DataFrame(checks, columns=["check", "passed", "detail"]), results / "validation_checks.csv")

    # Whole seasons are resampled jointly for circulation and rainfall. This
    # preserves the temporal sequences used to define runs and adjacent pairs.
    from step1_uncertainty import run_uncertainty
    uncertainty = run_uncertainty(out, n_boot=n_bootstrap, seed=bootstrap_seed, confidence=.95)
    coverage["uncertainty"] = {"method": "Whole-season percentile bootstrap",
                               "confidence_level": .95, "n_bootstrap": n_bootstrap,
                               "seed": bootstrap_seed,
                               "sensitivity": "Leave one season out; source-exclusion comparison"}
    (results / "run_metadata.json").write_text(json.dumps(coverage, indent=2) + "\n", encoding="utf-8")

    period_label = f"May–September {start_year}–{end_year}" if months == [5, 6, 7, 8, 9] else f"{start_year}–{end_year}; months {','.join(map(str, months))}"
    if make_figures:
        from plot_step1 import plot_summary
        plot_summary(results, out / "figures", period_label, len(weather), len(rain))

    statements = [f"STEP 1 METHODS ({period_label})",
        "The 30 daily weather patterns were assigned to the four previously defined rainfall process families. "
        "Family frequencies, observed within-season run lengths and next-day transition probabilities were "
        "summarised using the complete weather-pattern calendar. Runs ended at a change of family or an "
        "analysis-window boundary. Only consecutive dates within the same annual window contributed "
        "transitions. Transition probabilities were row-normalised by the number of eligible origin days. "
        "Monthly transitions were assigned to the month of the origin day, including adjacent month boundaries "
        "within the season. SWEW daily rainfall metrics were taken without alteration from the daily_metrics "
        "sheet of fullrange_noqc_stats.xlsx. Rainfall summaries were restricted to dates with readable source "
        "histograms whose reconstructed daily metrics matched the saved records; dates with unreadable or "
        "absent source files were excluded, with no intensity-based filtering or gap filling. "
        "Means and empirical percentiles are descriptive; P95 denotes a percentile, not a confidence interval. "
        f"Approximate pointwise 95% confidence intervals were estimated using {n_bootstrap:,} whole-season "
        "bootstrap resamples, jointly resampling years for circulation and rainfall and retaining original "
        "within-season runs and transitions. Stability was examined by omitting each season in turn. "
        "Intervals are conditional on the fixed family mapping and assume the seasons are suitable "
        "approximately exchangeable resampling units; thirteen seasons provide limited interannual information. "
        "These intervals do not quantify radar measurement or family-construction uncertainty. "
        "Runs touching the seasonal boundaries may be truncated and do not establish complete atmospheric "
        "episode durations.", "", "STEP 1 RESULTS",
        f"The weather calendar contained {len(weather):,} days and {len(pairs):,} eligible next-day transitions. "
        f"Of {len(original_rain):,} processed rainfall records, {len(excluded)} were excluded because their "
        f"source histograms could not be reconstructed, leaving {len(rain):,} analysis days. Together with "
        f"{len(originally_missing)} originally missing records, {len(missing)} calendar dates did not contribute "
        "to rainfall summaries. Weather-calendar calculations retained all classified days."]
    for group in GROUP_ORDER:
        if counts.loc[group, "days"] == 0:
            statements.append(f"{group}: no calendar days in this selected period; run and rainfall statistics unavailable.")
            continue
        if rain_by_group.loc[group, "n_days"] == 0:
            statements.append(f"{group}: {counts.loc[group, 'days']:,} calendar days; no available rainfall records.")
            continue
        statements.append(f"{group}: {counts.loc[group, 'days']:,} calendar days "
            f"({counts.loc[group, 'fraction']*100:.1f}%), {int(rain_by_group.loc[group, 'n_days']):,} rainfall days; "
            f"mean observed run {runs_by_group.loc[group, 'mean']:.2f} days, "
            f"P95 {runs_by_group.loc[group, 'p95']:.2f} days; "
            f"mean daily rainfall depth {rain_by_group.loc[group, 'mean_mm']:.2f} mm, "
            f"P95 {rain_by_group.loc[group, 'p95_mm']:.2f} mm.")
    (results / "manuscript_text.txt").write_text("\n".join(statements) + "\n", encoding="utf-8")
    from report_step1_uncertainty import write_report
    write_report(out)
    print(json.dumps({k: coverage[k] for k in ["weather_calendar_days", "rainfall_days", "missing_rainfall_days",
                                               "valid_next_day_transitions", "within_season_runs"]}, indent=2))
    return coverage


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--classifications", type=Path, default=ROOT / "data/input/classifications_30regimes.csv")
    parser.add_argument("--rainfall", type=Path, default=ROOT / "data/input/fullrange_noqc_stats.xlsx")
    parser.add_argument("--outdir", type=Path, default=ROOT)
    parser.add_argument("--start-year", type=int, default=2012)
    parser.add_argument("--end-year", type=int, default=2024)
    parser.add_argument("--months", default="5,6,7,8,9")
    parser.add_argument("--no-figures", action="store_true", help="Only regenerate data and result tables")
    parser.add_argument("--n-bootstrap", type=int, default=10000, help="Whole-season bootstrap resamples")
    parser.add_argument("--bootstrap-seed", type=int, default=42)
    args = parser.parse_args()
    run_analysis(args.classifications, args.rainfall, args.outdir, args.start_year, args.end_year,
                 [int(m.strip()) for m in args.months.split(",") if m.strip()], make_figures=not args.no_figures,
                 n_bootstrap=args.n_bootstrap, bootstrap_seed=args.bootstrap_seed)


if __name__ == "__main__":
    main()
