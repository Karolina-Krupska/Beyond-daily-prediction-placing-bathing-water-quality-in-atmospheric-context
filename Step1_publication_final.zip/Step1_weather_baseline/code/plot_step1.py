"""Draw the Step 1 descriptive summary from saved result tables.

This module never refits models or changes rainfall or weather classifications.
Run ``python code/plot_step1.py`` from the package root to redraw the figures.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
import numpy as np
import pandas as pd


GROUP_ORDER = [
    "Cyclonic Atlantic (frontal)",
    "Showery maritime / unsettled",
    "Convective extremes",
    "Settled anticyclonic quiet",
]
SHORT_LABELS = [
    "Cyclonic\nAtlantic",
    "Showery\nmaritime",
    "Convective\nextremes",
    "Settled\nanticyclonic",
]
COLOURS = ["#0072B2", "#009E73", "#D55E00", "#777777"]
STYLE = {
    "font.family": "DejaVu Sans", "font.size": 8, "axes.linewidth": 0.6,
    "pdf.fonttype": 42, "ps.fonttype": 42, "svg.fonttype": "none",
    "savefig.facecolor": "white",
}


def _save_formats(fig: plt.Figure, figures_dir: Path, stem: str, title: str) -> dict[str, str]:
    paths = {}
    for extension in ("png", "pdf", "svg"):
        path = figures_dir / f"{stem}.{extension}"
        fig.savefig(path, dpi=600, metadata={"Title": title})
        paths[extension] = str(path)
    plt.close(fig)
    return paths


def _mean_intervals(table: pd.DataFrame, metric: str, estimates: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    subset = table.loc[table.metric.eq(metric)].set_index("group")
    if subset.index.duplicated().any() or set(subset.index) != set(GROUP_ORDER):
        raise ValueError(f"Expected exactly four family intervals for {metric}")
    subset = subset.reindex(GROUP_ORDER)
    if not np.allclose(subset.estimate, estimates, rtol=1e-10, atol=1e-10):
        raise ValueError(f"Saved confidence interval estimates disagree with {metric}")
    if not np.allclose(subset.confidence_level, .95):
        raise ValueError("This publication figure expects 95% confidence intervals")
    bounds = subset[["ci_lower", "ci_upper"]].to_numpy(dtype=float)
    if not np.isfinite(bounds).all() or np.any(bounds[:, 0] > bounds[:, 1]):
        raise ValueError(f"Invalid confidence limits for {metric}")
    return bounds[:, 0], bounds[:, 1]


def _interval_whiskers(ax: plt.Axes, y: np.ndarray, lower: np.ndarray, upper: np.ndarray) -> None:
    # Draw limits directly: a percentile interval need not contain its point estimate.
    ax.hlines(y, lower, upper, colors="#171717", linewidth=1.05, zorder=4)
    ax.vlines(lower, y - .105, y + .105, colors="#171717", linewidth=.85, zorder=4)
    ax.vlines(upper, y - .105, y + .105, colors="#171717", linewidth=.85, zorder=4)


def _read_group_table(path: Path) -> pd.DataFrame:
    frame = pd.read_csv(path)
    if "group" not in frame.columns:
        raise ValueError(f"Expected a 'group' column in {path.name}")
    if frame["group"].duplicated().any():
        raise ValueError(f"Duplicate family rows in {path.name}")
    frame = frame.set_index("group")
    if set(frame.index) != set(GROUP_ORDER):
        raise ValueError(f"Expected the four final rainfall families in {path.name}")
    return frame.reindex(GROUP_ORDER)


def _plain_axes(ax: plt.Axes, xlabel: str, xmax: float) -> None:
    ax.spines[["top", "right", "left"]].set_visible(False)
    ax.spines["bottom"].set_color("#666666")
    ax.spines["bottom"].set_linewidth(0.6)
    ax.set_axisbelow(True)
    ax.grid(axis="x", color="#E6E6E6", linewidth=0.5)
    ax.tick_params(axis="both", width=0.6, length=2.5, labelsize=7.5)
    ax.tick_params(axis="y", length=0, pad=5)
    ax.set_yticks(np.arange(4), SHORT_LABELS, fontsize=7.5)
    ax.set_ylim(3.55, -0.55)
    ax.set_xlim(0, xmax)
    ax.set_xlabel(xlabel, fontsize=8, labelpad=5)
    ax.xaxis.set_major_locator(plt.MaxNLocator(nbins=4, min_n_ticks=3))


def _heading(ax: plt.Axes, letter: str, title: str, subtitle: str) -> None:
    ax.text(-0.40, 1.17, letter, transform=ax.transAxes,
            fontsize=10, fontweight="bold", va="bottom")
    ax.text(0, 1.17, title, transform=ax.transAxes,
            fontsize=9, fontweight="medium", va="bottom")
    ax.text(0, 1.055, subtitle, transform=ax.transAxes,
            fontsize=7.3, color="#555555", va="bottom")


def plot_summary(
    results_dir: Path,
    figures_dir: Path,
    period_label: str = "May–September 2012–2024",
    calendar_days: int = 1989,
    rainfall_days: int = 1940,
) -> dict[str, str]:
    """Export a 600 dpi PNG, vector PDF/SVG and a separate figure caption.

    P95 markers are empirical 95th percentiles, not confidence intervals.
    Whiskers on means are pointwise whole-season bootstrap 95% intervals.
    Family run statistics use the season-bounded runs saved by Step 1.
    """
    results_dir = Path(results_dir)
    figures_dir = Path(figures_dir)
    figures_dir.mkdir(parents=True, exist_ok=True)
    counts = _read_group_table(results_dir / "group_counts_fractions.csv")
    runs = _read_group_table(results_dir / "run_length_summary.csv")
    rainfall = _read_group_table(results_dir / "SWEW_rainfall_by_group.csv")
    uncertainty_dir = results_dir / "uncertainty"
    intervals = pd.read_csv(uncertainty_dir / "bootstrap_confidence_intervals.csv")
    n_seasons = pd.read_csv(uncertainty_dir / "leave_one_season_out.csv", usecols=["omitted_year"]).omitted_year.nunique()
    transitions = pd.read_csv(results_dir / "transition_probs.csv", index_col=0)
    transitions = transitions.reindex(index=GROUP_ORDER, columns=GROUP_ORDER)
    transition_counts = pd.read_csv(results_dir / "transition_counts.csv", index_col=0)
    transition_counts = transition_counts.reindex(index=GROUP_ORDER, columns=GROUP_ORDER)
    if int(counts["days"].sum()) != int(calendar_days):
        raise ValueError("Figure calendar denominator disagrees with the saved counts")
    if int(rainfall["n_days"].sum()) != int(rainfall_days):
        raise ValueError("Figure rainfall denominator disagrees with the saved counts")
    valid_pairs = int(transition_counts.to_numpy().sum())
    matrix = transitions.to_numpy(dtype=float)
    eligible_rows = transition_counts.sum(axis=1).to_numpy() > 0
    if not np.isfinite(matrix[eligible_rows]).all() or np.any((matrix < 0) | (matrix > 1)):
        raise ValueError("Expected valid next-day probabilities between zero and one")
    if not np.isnan(matrix[~eligible_rows]).all():
        raise ValueError("A zero-denominator transition row must be unavailable")
    if not np.allclose(matrix[eligible_rows].sum(axis=1), 1.0):
        raise ValueError("Each transition probability row must sum to one")

    with plt.rc_context(STYLE):
        fig = plt.figure(figsize=(190 / 25.4, 180 / 25.4), facecolor="white")
        grid = fig.add_gridspec(2, 2, left=0.145, right=0.975, bottom=0.20,
                                top=0.89, wspace=0.75, hspace=0.85)
        ax_a = fig.add_subplot(grid[0, 0])
        ax_b = fig.add_subplot(grid[0, 1])
        ax_c = fig.add_subplot(grid[1, 0])
        ax_d = fig.add_subplot(grid[1, 1])
        y = np.arange(4)

        # a: all selected calendar days, including those without rainfall data.
        day_values = counts["days"].to_numpy(dtype=float)
        ax_a.barh(y, day_values, height=0.56, color=COLOURS, linewidth=0)
        _plain_axes(ax_a, "Days", float(day_values.max()) * 1.23)
        ax_a.xaxis.set_major_locator(plt.MaxNLocator(nbins=4, integer=True))
        for yy, value in zip(y, day_values):
            ax_a.text(value + day_values.max() * 0.035, yy, f"{value:,.0f}",
                      va="center", ha="left", fontsize=7.5)
        _heading(ax_a, "a", "Family occurrence", f"{calendar_days:,} calendar days")

        # b: mean uncertainty and the empirical run-length tail are distinct.
        mean_runs = runs["mean"].to_numpy(dtype=float)
        p95_runs = runs["p95"].to_numpy(dtype=float)
        run_lower, run_upper = _mean_intervals(intervals, "mean_run_days", mean_runs)
        ax_b.barh(y, mean_runs, height=0.56, color=COLOURS, linewidth=0)
        _interval_whiskers(ax_b, y, run_lower, run_upper)
        ax_b.scatter(p95_runs, y, s=24, color="#222222", edgecolors="white",
                     linewidths=0.5, zorder=3)
        _plain_axes(ax_b, "Consecutive days", max(1., float(np.nanmax([mean_runs, p95_runs, run_upper])) * 1.15))
        _heading(ax_b, "b", "Family persistence", "Runs bounded by the selected seasons")

        # c: row-conditional transitions, only between actual adjacent dates.
        cmap = plt.get_cmap("cividis").copy()
        cmap.set_bad("#F1F1F1")
        image = ax_c.imshow(np.ma.masked_invalid(matrix), vmin=0, vmax=1, cmap=cmap, aspect="equal")
        ax_c.set_xticks(y, ["CA", "SM", "CE", "SA"], fontsize=7.5)
        ax_c.set_yticks(y, SHORT_LABELS, fontsize=7.5)
        ax_c.tick_params(axis="both", length=0, pad=5)
        ax_c.set_xlabel("Next-day family", fontsize=8, labelpad=7)
        ax_c.set_ylabel("Current family", fontsize=8, labelpad=7)
        for spine in ax_c.spines.values():
            spine.set_visible(False)
        for i in range(4):
            for j in range(4):
                value = matrix[i, j]
                # cividis luminance increases monotonically with probability.
                colour = "white" if np.isfinite(value) and value < 0.42 else "#171717"
                label = f"{value:.2f}" if np.isfinite(value) else "–"
                ax_c.text(j, i, label, ha="center", va="center",
                          color=colour, fontsize=8)
        # Keep the colour bar separate so the heatmap stays legible.
        cax = ax_c.inset_axes([0, -0.44, 1, 0.055])
        colour_bar = fig.colorbar(image, cax=cax, orientation="horizontal", ticks=[0, 0.5, 1])
        colour_bar.outline.set_visible(False)
        colour_bar.ax.tick_params(length=2, width=0.5, labelsize=6.8, pad=2)
        _heading(ax_c, "c", "Next-day transitions", f"{valid_pairs:,} adjacent-day pairs")

        # d: rainfall summaries use available daily records, not calendar zeros.
        rain_mean = rainfall["mean_mm"].to_numpy(dtype=float)
        rain_p95 = rainfall["p95_mm"].to_numpy(dtype=float)
        rain_lower, rain_upper = _mean_intervals(intervals, "mean_daily_depth_mm", rain_mean)
        ax_d.barh(y, rain_mean, height=0.56, color=COLOURS, linewidth=0)
        _interval_whiskers(ax_d, y, rain_lower, rain_upper)
        ax_d.scatter(rain_p95, y, s=24, color="#222222", edgecolors="white",
                     linewidths=0.5, zorder=3)
        _plain_axes(ax_d, "Regional daily rainfall depth (mm)",
                    max(1., float(np.nanmax([rain_mean, rain_p95, rain_upper])) * 1.15))
        _heading(ax_d, "d", "SWEW rainfall", f"{rainfall_days:,} analysed daily records")

        fig.text(0.145, 0.995, period_label, fontsize=8, color="#333333", va="top")
        fig.legend(
            handles=[Patch(facecolor="#777777", edgecolor="none", label="Mean"),
                     Line2D([0], [0], marker="o", linestyle="none", color="#222222",
                            markersize=4.5, label="95th percentile"),
                     Line2D([0, 1], [0, 0], color="#171717", linewidth=1,
                            marker="|", markersize=5, label="95% CI for mean")],
            loc="lower center", bbox_to_anchor=(0.55, 0.005), frameon=False, ncol=3,
            title="Panels b and d", title_fontsize=7, fontsize=7.5,
            handlelength=1.1, columnspacing=1.2,
        )
        paths = _save_formats(fig, figures_dir, "step1_summary_figure", "Weather-pattern family baseline")

    caption = (
        f"Figure. Weather-pattern family baseline for SWEW, {period_label}. "
        f"(a) Family occurrence across {calendar_days:,} calendar days. "
        "(b) Mean and 95th percentile of observed consecutive-day family runs, "
        "bounded by each selected season and any calendar gaps. "
        f"(c) Row-normalised next-day transition probabilities from {valid_pairs:,} "
        "adjacent-day pairs; rows denote the current family and columns the following day. "
        f"(d) Mean and 95th percentile of regional daily rainfall depth across {rainfall_days:,} "
        "daily records with readable, matching source histograms. Bars and dots in (b) and (d) show means and "
        "95th percentiles; whiskers show approximate pointwise 95% confidence intervals for the means, "
        f"resampling {n_seasons} whole summers and holding family membership fixed. P95 dots are not confidence limits. "
        "Missing or source-excluded rainfall dates "
        "do not contribute to (d) or shorten the weather calendar in (a)–(c). "
        "CA, Cyclonic Atlantic (frontal); SM, Showery maritime / unsettled; "
        "CE, Convective extremes; SA, Settled anticyclonic quiet."
    )
    caption_path = figures_dir / "figure_caption.txt"
    caption_path.write_text(caption + "\n", encoding="utf-8")
    paths["caption"] = str(caption_path)
    extra = plot_uncertainty_figures(results_dir, figures_dir, period_label)
    paths.update(extra)
    return paths


def plot_uncertainty_figures(results_dir: Path, figures_dir: Path,
                             period_label: str = "May–September 2012–2024") -> dict[str, str]:
    """Plot transition intervals and all leave-one-season-out estimates from saved CSVs."""
    results_dir, figures_dir = Path(results_dir), Path(figures_dir)
    figures_dir.mkdir(parents=True, exist_ok=True)
    directory = results_dir / "uncertainty"
    transitions = pd.read_csv(directory / "bootstrap_transition_intervals.csv")
    loso = pd.read_csv(directory / "leave_one_season_out.csv")
    n_seasons = loso.omitted_year.nunique()
    if transitions.duplicated(["from_group", "to_group"]).any() or len(transitions) != 16:
        raise ValueError("Expected all 16 unique transition intervals")
    if not np.allclose(transitions.confidence_level, .95):
        raise ValueError("This publication figure expects 95% transition intervals")
    paths = {}
    with plt.rc_context(STYLE):
        fig, axes = plt.subplots(2, 2, figsize=(190 / 25.4, 150 / 25.4))
        fig.subplots_adjust(left=.145, right=.975, bottom=.14, top=.87, wspace=.75, hspace=.72)
        for i, (ax, current) in enumerate(zip(axes.flat, GROUP_ORDER)):
            table = transitions.loc[transitions.from_group.eq(current)].set_index("to_group").reindex(GROUP_ORDER)
            values = table.estimate.to_numpy(dtype=float)
            lower, upper = table.ci_lower.to_numpy(dtype=float), table.ci_upper.to_numpy(dtype=float)
            if not np.isfinite(np.r_[values, lower, upper]).all() or np.any(lower > upper):
                raise ValueError("Invalid transition intervals")
            y = np.arange(4)
            _plain_axes(ax, "Next-day probability", 1.)
            ax.hlines(y, lower, upper, color=COLOURS, linewidth=1.25, zorder=3)
            ax.scatter(values, y, c=COLOURS, s=23, edgecolors="white", linewidth=.4, zorder=4)
            for yy, value, hi in zip(y, values, upper):
                ax.text(min(hi + .025, .94), yy, f"{value:.2f}", va="center", fontsize=7)
            current_label = SHORT_LABELS[i].replace("\n", " ")
            ax.set_title(f"Current: {current_label}", loc="left", fontsize=8.5, pad=12)
            ax.text(-.40, 1.09, "abcd"[i], transform=ax.transAxes, fontsize=10, fontweight="bold", va="bottom")
        fig.text(.145, .985, period_label, fontsize=8, va="top", color="#333333")
        fig.text(.145, .945, "Next-day transition probabilities with 95% confidence intervals", fontsize=9, va="top")
        paths.update({f"transition_{key}": value for key, value in _save_formats(
            fig, figures_dir, "step1_transition_confidence_intervals", "Next-day transition uncertainty").items()})
    caption = (
        f"Figure. Next-day family transition probabilities, {period_label}. Panels condition on the current "
        "family; rows within panels identify the following-day family. Points are observed conditional "
        f"probabilities and lines are approximate pointwise 95% confidence intervals from resampling {n_seasons} whole summers. "
        "Whole summers are resampled without joining their boundaries. Intervals are conditional on the "
        "fixed family mapping and are not simultaneous intervals or tests of family differences."
    )
    caption_path = figures_dir / "step1_transition_confidence_intervals_caption.txt"
    caption_path.write_text(caption + "\n", encoding="utf-8")
    paths["transition_caption"] = str(caption_path)

    metric_definitions = [
        ("mean_run_days", "Mean family run", "Consecutive days"),
        ("same_family_transition_probability", "Same-family next day", "Probability"),
        ("mean_daily_depth_mm", "Mean daily rainfall depth", "Rainfall depth (mm)"),
        ("p95_daily_depth_mm", "Daily rainfall depth P95", "Rainfall depth (mm)"),
    ]
    with plt.rc_context(STYLE):
        fig, axes = plt.subplots(2, 2, figsize=(190 / 25.4, 155 / 25.4))
        fig.subplots_adjust(left=.145, right=.975, bottom=.16, top=.86, wspace=.75, hspace=.75)
        years = sorted(loso.omitted_year.unique())
        offsets = np.linspace(-.17, .17, len(years))
        for i, (ax, definition) in enumerate(zip(axes.flat, metric_definitions)):
            metric, title, xlabel = definition
            subset = loso.loc[loso.metric.eq(metric)]
            if subset.duplicated(["omitted_year", "group"]).any():
                raise ValueError(f"Duplicated leave-one-season-out estimates for {metric}")
            observed = subset.estimate.to_numpy(dtype=float)
            full = subset.full_estimate.to_numpy(dtype=float)
            if not np.isfinite(np.r_[observed, full]).all():
                raise ValueError(f"Non-finite leave-one-season-out estimates for {metric}")
            maximum = 1. if metric == "same_family_transition_probability" else max(1., float(np.max(np.r_[observed, full])) * 1.2)
            _plain_axes(ax, xlabel, maximum)
            for g, group in enumerate(GROUP_ORDER):
                values = subset.loc[subset.group.eq(group)].set_index("omitted_year").reindex(years)
                if values.estimate.isna().any() or values.full_estimate.nunique() != 1:
                    raise ValueError(f"Incomplete season omission estimates for {group}: {metric}")
                ax.hlines(g, values.estimate.min(), values.estimate.max(), color="#B5B5B5", linewidth=1, zorder=2)
                ax.scatter(values.estimate, g + offsets, color=COLOURS[g], s=12, alpha=.75,
                           linewidths=0, zorder=3)
                ax.scatter(values.full_estimate.iloc[0], g, color="#151515", s=34, marker="D",
                           edgecolors="white", linewidths=.45, zorder=4)
            ax.set_title(title, loc="left", fontsize=8.2, pad=12)
            ax.text(-.40, 1.09, "abcd"[i], transform=ax.transAxes, fontsize=10, fontweight="bold", va="bottom")
        fig.text(.145, .985, period_label, fontsize=8, va="top", color="#333333")
        fig.text(.145, .945, "Leave-one-season-out sensitivity", fontsize=9, va="top")
        fig.legend(handles=[
            Line2D([0], [0], marker="o", linestyle="none", color="#777777", markersize=4,
                   label="One summer omitted"),
            Line2D([0], [0], marker="D", linestyle="none", color="#151515", markersize=4.5,
                   label="All summers")],
            loc="lower center", bbox_to_anchor=(.56, .02), ncol=2, frameon=False, fontsize=7.5)
        paths.update({f"loso_{key}": value for key, value in _save_formats(
            fig, figures_dir, "step1_leave_one_season_out", "Leave-one-season-out sensitivity").items()})
    caption = (
        f"Figure. Leave-one-season-out sensitivity, {period_label}. Each coloured point is an estimate "
        "after omitting one summer; black diamonds use all summers. Thin grey lines span the omission "
        "estimates and are not confidence intervals. Panels show mean observed family run length, "
        "same-family next-day probability, mean daily rainfall depth and its across-day 95th percentile. "
        "The original season boundaries, rainfall eligibility rule and family mapping are retained. "
        "Values are recalculated from the remaining pooled observations, not averages of annual estimates."
    )
    caption_path = figures_dir / "step1_leave_one_season_out_caption.txt"
    caption_path.write_text(caption + "\n", encoding="utf-8")
    paths["loso_caption"] = str(caption_path)
    return paths


def main() -> None:
    package_root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results-dir", type=Path, default=package_root / "results")
    parser.add_argument("--figures-dir", type=Path, default=package_root / "figures")
    parser.add_argument("--period-label", default="May–September 2012–2024")
    args = parser.parse_args()
    counts = _read_group_table(args.results_dir / "group_counts_fractions.csv")
    rain = _read_group_table(args.results_dir / "SWEW_rainfall_by_group.csv")
    paths = plot_summary(args.results_dir, args.figures_dir, args.period_label,
                         int(counts["days"].sum()), int(rain["n_days"].sum()))
    for kind, path in paths.items():
        print(f"{kind}: {path}")


if __name__ == "__main__":
    main()
