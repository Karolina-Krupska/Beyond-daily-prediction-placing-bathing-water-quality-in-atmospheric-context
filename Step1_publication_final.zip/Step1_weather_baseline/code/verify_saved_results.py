"""Independently reconcile publication-period saved outputs with the inputs."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]


def verify(root: Path = ROOT) -> list[str]:
    results = root / "results"
    calendar = pd.read_csv(root / "data/input/classifications_30regimes.csv", comment="#")
    calendar["date"] = pd.to_datetime(calendar[["year", "month", "day"]])
    calendar = calendar[calendar.year.between(2012, 2024) & calendar.month.between(5, 9)].sort_values("date")
    mapping = pd.read_csv(root / "data/processed/weather_pattern_family_mapping.csv")
    assert len(mapping) == mapping.regime.nunique() == 30
    calendar = calendar.merge(mapping, on="regime", validate="many_to_one").sort_values("date")
    assert len(calendar) == calendar.date.nunique() == 1989
    saved_weather = pd.read_csv(root / "data/processed/weather_calendar.csv", parse_dates=["date"])
    pd.testing.assert_frame_equal(calendar[["date", "regime", "group"]].reset_index(drop=True),
                                  saved_weather[["date", "regime", "group"]], check_dtype=False)

    source = pd.read_excel(root / "data/input/fullrange_noqc_stats.xlsx", sheet_name="daily_metrics")
    source["date"] = pd.to_datetime(source.date)
    source = source.loc[source.region.eq("SWEW") & source.date.dt.year.between(2012, 2024)
                        & source.date.dt.month.between(5, 9)].sort_values("date").reset_index(drop=True)
    assert len(source) == source.date.nunique() == 1969
    original_dates = set(source.date)
    source_status = pd.read_csv(root / "data/provenance/histogram_source_status.csv", parse_dates=["date"])
    allowed_dates = set(source_status.loc[source_status.status.eq("readable_metrics_match"), "date"])
    source = source.loc[source.date.isin(allowed_dates)].reset_index(drop=True)
    saved = pd.read_csv(root / "data/processed/daily_metrics_SWEW_MaySep_NOQC.csv", parse_dates=["date"])
    assert len(source) == source.date.nunique() == len(saved) == 1940
    for column in source.columns:
        if pd.api.types.is_numeric_dtype(source[column]):
            assert np.allclose(source[column], saved[column], rtol=1e-12, atol=1e-12), column
        else:
            assert source[column].equals(saved[column]), column

    counts = pd.read_csv(results / "group_counts_fractions.csv").set_index("group")
    actual_counts = calendar.group.value_counts().reindex(counts.index)
    assert np.array_equal(counts.days, actual_counts)
    assert np.allclose(counts.fraction, counts.days / 1989)
    assert counts.days.tolist() == [786, 400, 662, 141]

    independent_counts = pd.DataFrame(0, index=counts.index, columns=counts.index)
    independent_run_lengths = {family: [] for family in counts.index}
    for _, season in calendar.groupby("year"):
        rows = list(season[["date", "group"]].itertuples(index=False, name=None))
        length = 1
        for (previous_date, previous_family), (date, family) in zip(rows, rows[1:]):
            if date - previous_date == pd.Timedelta(days=1):
                independent_counts.loc[previous_family, family] += 1
            if family == previous_family and date - previous_date == pd.Timedelta(days=1):
                length += 1
            else:
                independent_run_lengths[previous_family].append(length)
                length = 1
        independent_run_lengths[rows[-1][1]].append(length)
    transitions = pd.read_csv(results / "transition_counts.csv", index_col=0)
    assert np.array_equal(transitions, independent_counts)
    assert int(transitions.to_numpy().sum()) == 1976
    probabilities = pd.read_csv(results / "transition_probs.csv", index_col=0)
    assert np.allclose(probabilities, independent_counts.div(independent_counts.sum(axis=1), axis=0))
    runs = pd.read_csv(results / "run_length_summary.csv").set_index("group")
    for family, lengths in independent_run_lengths.items():
        for field, value in {"n_runs": len(lengths), "mean": np.mean(lengths), "median": np.median(lengths),
                             "max": max(lengths), "p90": np.quantile(lengths, .9), "p95": np.quantile(lengths, .95)}.items():
            assert np.isclose(runs.loc[family, field], value), (family, field)

    family_rain = source.merge(mapping, on="regime", validate="many_to_one")
    rain_summary = pd.read_csv(results / "SWEW_rainfall_by_group.csv").set_index("group")
    for family, values in family_rain.groupby("group"):
        assert len(values) == rain_summary.loc[family, "n_days"]
        assert np.isclose(values.daily_depth_mm.mean(), rain_summary.loc[family, "mean_mm"])
        assert np.isclose(values.daily_depth_mm.quantile(.95), rain_summary.loc[family, "p95_mm"])
    assert rain_summary.n_days.tolist() == [768, 395, 641, 136]
    missing = pd.read_csv(results / "missing_rainfall_dates.csv", parse_dates=["date"])
    assert len(missing) == 49
    assert set(missing.date) == set(calendar.date) - set(source.date)
    original_missing = pd.read_csv(results / "originally_missing_rainfall_dates.csv", parse_dates=["date"])
    exclusions = pd.read_csv(results / "excluded_rainfall_records.csv", parse_dates=["date"])
    assert len(original_missing) == 20
    assert set(original_missing.date) == set(calendar.date) - original_dates
    assert len(exclusions) == 29
    assert set(exclusions.date) == original_dates - set(source.date)
    assert exclusions.status.value_counts().to_dict() == {"unreadable_source_file": 23, "absent_source_file": 6}
    matrix = pd.read_csv(root / "data/processed/weather_rainfall_daily_matrix.csv", parse_dates=["date"])
    assert len(matrix) == matrix.date.nunique() == 1989
    assert matrix.daily_depth_mm.isna().sum() == 49
    assert matrix.rainfall_available.sum() == 1940
    assert matrix.processed_source_record_exists.sum() == 1969
    monthly = pd.read_csv(results / "monthly_transition_probabilities.csv")
    assert monthly.groupby("source_month")["count"].sum().tolist() == [403, 390, 403, 403, 377]

    methods_metadata = json.loads((results / "run_metadata.json").read_text())
    assert methods_metadata["rainfall_days"] == 1940
    verify_uncertainty(root, calendar, family_rain, list(counts.index))
    return ["Input and saved daily values agree", "Calendar and family counts agree",
            "Independent next-day transition reconstruction agrees", "Independent run reconstruction agrees",
            "Family rainfall summaries agree", "Missing rainfall remains missing on the full calendar",
            "Monthly eligible transition totals agree", "All 29 source-recoverability exclusions are recorded",
            "Season bootstrap draws and confidence limits reconcile",
            "Independent physical season replication agrees with selected bootstrap estimates",
            "All leave-one-season-out estimates independently reconstructed"]


def verify_uncertainty(root: Path, weather: pd.DataFrame, rain: pd.DataFrame, groups: list[str]) -> None:
    """Check saved CIs/draws without importing the resampling implementation."""
    rain = rain.copy()
    rain["year"] = rain.date.dt.year
    folder = root / "results/uncertainty"
    ci = pd.read_csv(folder / "bootstrap_confidence_intervals.csv")
    transition_ci = pd.read_csv(folder / "bootstrap_transition_intervals.csv")
    loso = pd.read_csv(folder / "leave_one_season_out.csv")
    metadata = json.loads((folder / "bootstrap_metadata.json").read_text())
    with np.load(folder / "bootstrap_draws.npz", allow_pickle=False) as draws:
        years = draws["years"]
        weights = draws["year_weights"]
        assert len(years) == 13 and set(years) == set(weather.year)
        assert len(weights) == metadata["n_bootstrap_replicates"]
        assert np.array_equal(draws["group_names"], np.array(groups))
        assert weights.shape[1] == len(years) and (weights >= 0).all()
        assert np.equal(weights % 1, 0).all() and (weights.sum(axis=1) == 13).all()
        for _, row in ci.iterrows():
            values = draws[row.metric][:, groups.index(row.group)]
            valid = values[np.isfinite(values)]
            alpha = (1 - row.confidence_level) / 2
            low, high = np.quantile(valid, [alpha, 1 - alpha], method="linear")
            assert len(valid) == row.n_boot_valid
            assert np.allclose([low, high], [row.ci_lower, row.ci_upper], rtol=1e-12, atol=1e-12)
        for _, row in transition_ci.iterrows():
            values = draws["transition_probabilities"][:, groups.index(row.from_group), groups.index(row.to_group)]
            valid = values[np.isfinite(values)]
            alpha = (1 - row.confidence_level) / 2
            low, high = np.quantile(valid, [alpha, 1 - alpha], method="linear")
            assert len(valid) == row.n_boot_valid
            assert np.allclose([low, high], [row.ci_lower, row.ci_upper], rtol=1e-12, atol=1e-12)
        assert np.allclose(draws["calendar_fraction"].sum(axis=1), 1)
        assert np.allclose(draws["transition_probabilities"].sum(axis=2), 1)

        def direct_statistics(selected_years):
            counts = dict.fromkeys(groups, 0)
            lengths = {g: [] for g in groups}
            transitions = np.zeros((4, 4), dtype=int)
            rain_parts = []
            total_days = 0
            for year in selected_years:
                block = weather.loc[weather.year.eq(year)].sort_values("date")
                total_days += len(block)
                rows = list(block[["date", "group"]].itertuples(index=False, name=None))
                for _, group in rows:
                    counts[group] += 1
                length = 1
                for (a_date, a_group), (b_date, b_group) in zip(rows, rows[1:]):
                    adjacent = b_date - a_date == pd.Timedelta(days=1)
                    if adjacent:
                        transitions[groups.index(a_group), groups.index(b_group)] += 1
                    if adjacent and a_group == b_group:
                        length += 1
                    else:
                        lengths[a_group].append(length)
                        length = 1
                lengths[rows[-1][1]].append(length)
                rain_parts.append(rain.loc[rain.year.eq(year)])
            duplicated_rain = pd.concat(rain_parts, ignore_index=True)
            probabilities = transitions / transitions.sum(axis=1, keepdims=True)
            output = {}
            for j, group in enumerate(groups):
                values = duplicated_rain.loc[duplicated_rain.group.eq(group), "daily_depth_mm"]
                output[group] = {"calendar_fraction": counts[group] / total_days,
                    "mean_run_days": np.mean(lengths[group]),
                    "same_family_transition_probability": probabilities[j, j],
                    "mean_daily_depth_mm": values.mean(), "p95_daily_depth_mm": values.quantile(.95)}
            return output, probabilities

        # Independently replicate selected seasons physically. This catches
        # accidental cross-season joins and averaging of annual ratios.
        for index in sorted(set([0, 1, 2, min(42, len(weights) - 1), len(weights) - 1])):
            selected_years = np.repeat(years, weights[index])
            expected, probabilities = direct_statistics(selected_years)
            assert np.allclose(probabilities, draws["transition_probabilities"][index], rtol=1e-12, atol=1e-12)
            for j, group in enumerate(groups):
                for metric, value in expected[group].items():
                    assert np.isclose(value, draws[metric][index, j], rtol=1e-12, atol=1e-12)
        for omitted in years:
            expected, _ = direct_statistics([year for year in years if year != omitted])
            subset = loso.loc[loso.omitted_year.eq(omitted)]
            for _, row in subset.iterrows():
                assert np.isclose(row.estimate, expected[row.group][row.metric], rtol=1e-12, atol=1e-12)


if __name__ == "__main__":
    messages = verify()
    print("Verified the supplied May–September 2012–2024 package:")
    for message in messages:
        print(f"- {message}")
