"""Focused scientific boundary and input-integrity tests. Uses no new models."""
from __future__ import annotations

import unittest
import hashlib
import json
import tempfile
from pathlib import Path
import numpy as np
import pandas as pd

from step1_baseline import (GROUP_ORDER, consecutive_pairs, expected_calendar, observed_runs,
                            reject_duplicate_dates, transition_matrices, validate_rainfall,
                            verify_mapping, source_readability_selection)


def weather_frame(dates, groups):
    frame = pd.DataFrame({"date": pd.to_datetime(dates), "group": groups, "regime": 1})
    frame["year"] = frame.date.dt.year
    frame["month"] = frame.date.dt.month
    return frame


def valid_rain(weather):
    data = weather[["date", "regime"]].copy()
    for name, value in {"total_samples": 100, "wet_fraction": .1, "q50_mmph": .1,
                        "q90_mmph": .2, "q95_mmph": .3, "mean_rate_mmph": .01,
                        "daily_depth_mm": .24}.items():
        data[name] = value
    return data


class ScientificBoundaryTests(unittest.TestCase):
    def test_calendar_and_mapping(self):
        verify_mapping()
        dates = expected_calendar(2012, 2024, [5, 6, 7, 8, 9])
        self.assertEqual(len(dates), 1989)
        self.assertEqual(len(set(dates)), 1989)

    def test_same_family_does_not_bridge_season_gap(self):
        weather = weather_frame(["2020-09-29", "2020-09-30", "2021-05-01", "2021-05-02"],
                                [GROUP_ORDER[0]] * 4)
        runs = observed_runs(weather)
        self.assertEqual(runs.run_length.tolist(), [2, 2])
        self.assertEqual(len(consecutive_pairs(weather)), 2)
        self.assertTrue(runs.touches_left_boundary.all())
        self.assertTrue(runs.touches_right_boundary.all())

    def test_missing_calendar_date_breaks_run_and_transition(self):
        weather = weather_frame(["2020-05-01", "2020-05-03"], [GROUP_ORDER[0]] * 2)
        self.assertEqual(observed_runs(weather).run_length.tolist(), [1, 1])
        self.assertTrue(consecutive_pairs(weather).empty)

    def test_month_boundary_is_assigned_to_origin_month(self):
        weather = weather_frame(["2020-05-31", "2020-06-01", "2020-06-02"],
                                [GROUP_ORDER[0], GROUP_ORDER[1], GROUP_ORDER[1]])
        pairs = consecutive_pairs(weather)
        self.assertEqual(pairs.month.tolist(), [5, 6])
        counts, probabilities = transition_matrices(pairs)
        self.assertEqual(counts.loc[GROUP_ORDER[0], GROUP_ORDER[1]], 1)
        self.assertEqual(probabilities.loc[GROUP_ORDER[0], GROUP_ORDER[1]], 1)
        self.assertTrue(probabilities.loc[GROUP_ORDER[2]].isna().all())

    def test_missing_rainfall_is_not_a_zero_or_a_calendar_deletion(self):
        weather = weather_frame(["2020-05-01", "2020-05-02", "2020-05-03"],
                                [GROUP_ORDER[0]] * 3)
        rain = valid_rain(weather).iloc[[0, 2]].copy()
        validated = validate_rainfall(rain, weather)
        merged = weather.merge(validated[["date", "daily_depth_mm"]], on="date", how="left")
        self.assertEqual(len(merged), 3)
        self.assertTrue(np.isnan(merged.loc[1, "daily_depth_mm"]))
        self.assertEqual(len(consecutive_pairs(weather)), 2)

    def test_duplicate_daily_key_fails(self):
        weather = weather_frame(["2020-05-01", "2020-05-01"], [GROUP_ORDER[0]] * 2)
        with self.assertRaisesRegex(ValueError, "duplicate"):
            reject_duplicate_dates(weather, "test")

    def test_mismatched_classification_fails(self):
        weather = weather_frame(["2020-05-01"], [GROUP_ORDER[0]])
        rain = valid_rain(weather)
        rain.loc[0, "regime"] = 2
        with self.assertRaisesRegex(ValueError, "mismatch"):
            validate_rainfall(rain, weather)

    def test_nonfinite_metric_and_wrong_conversion_fail(self):
        weather = weather_frame(["2020-05-01"], [GROUP_ORDER[0]])
        rain = valid_rain(weather)
        rain.loc[0, "daily_depth_mm"] = np.nan
        with self.assertRaisesRegex(ValueError, "non-finite"):
            validate_rainfall(rain, weather)
        rain.loc[0, "daily_depth_mm"] = 99.
        with self.assertRaisesRegex(ValueError, "multiplied by 24"):
            validate_rainfall(rain, weather)

    def test_source_exclusions_and_stale_workbook_audit(self):
        weather = weather_frame(["2020-05-01", "2020-05-02", "2020-05-03"], [GROUP_ORDER[0]] * 3)
        rain = valid_rain(weather)
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            workbook = root / "source_identity.bin"
            workbook.write_bytes(b"identity of the audited source")
            manifest = {"workbook_sha256": hashlib.sha256(workbook.read_bytes()).hexdigest()}
            (root / "histogram_source_audit.json").write_text(json.dumps(manifest))
            status = weather[["date", "regime"]].copy()
            status["status"] = ["readable_metrics_match", "unreadable_source_file", "absent_source_file"]
            status["all_metrics_match"] = [True, "", ""]
            status["archive_entry"] = ["readable.csv", "unreadable.csv", ""]
            status.to_csv(root / "histogram_source_status.csv", index=False)
            selected, excluded, _ = source_readability_selection(rain, workbook, root)
            self.assertEqual(selected.date.tolist(), [pd.Timestamp("2020-05-01")])
            self.assertEqual(len(excluded), 2)
            self.assertEqual(len(rain), 3)
            workbook.write_bytes(b"changed source")
            with self.assertRaisesRegex(ValueError, "does not match"):
                source_readability_selection(rain, workbook, root)


if __name__ == "__main__":
    unittest.main(verbosity=2)
