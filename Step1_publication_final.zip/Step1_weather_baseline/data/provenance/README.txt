Historical source eligibility record

The historical source audit compared 1,969 processed SWEW rainfall dates with
the recovered archive: 1,940 readable matching histograms; 23 unreadable source
CSVs; six absent files.

The revised Step 1 analysis retains only the 1,940 readable matching dates.
The original input workbook remains unchanged. Excluded records and reasons
are exported to results/excluded_rainfall_records.csv.

These 29 exclusions are separate from the 20 dates originally missing from the
processed workbook. The joined 1,989-date matrix therefore has 49 dates without
eligible rainfall metrics.

All 1,940 retained histogram CSVs are included in data/input/readable_histograms.zip.
To check them from the package root:
python code/audit_histogram_sources.py --eligible-only

The check writes to results/retained_source_check/ and preserves this historical
audit. Exclusion is based on source reproducibility, not evidence that the
discarded rainfall values or extremes were physically incorrect.
