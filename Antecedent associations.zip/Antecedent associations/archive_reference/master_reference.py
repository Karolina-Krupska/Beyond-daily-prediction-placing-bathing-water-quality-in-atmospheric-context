#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Reviewer-proof lag / climatology / persistence / priming analysis
=================================================================

Uses ONE canonical bathing-water population: modelling_dataset_swew.csv.
Raw bathing-water workbooks are audit-only and never redefine the sample set.

Main outputs
------------
1) Bathing-water sample audit and raw-vs-canonical audit.
2) May-Sep meteorological and sampling-opportunity climatology.
3) Lag 0/-1/-2/-3 exceedance composition and enrichment ratios.
4) Empirical persistence-conditioned expectation from the full daily WP sequence.
5) Modified Poisson lag models with month/year fixed effects and two-way
   clustered SE by bathing-water site and sampling date.
6) Antecedent-family models adjusted for the sampling-day family.
7) Priming tests using previous-3-day Cyclonic count and radar P3 rainfall.
8) Unique-date descriptive sensitivity analysis.

No site is silently removed by name. With STOP_IF_SUSPICIOUS_SITE_NAMES=True,
the script stops before analysis if the canonical Step 5 file contains names
such as RIVER/STREAM/BROOK/POWER STATION/FISH COLUMN/TRAC so they can be checked.

Required packages:
    pip install numpy pandas scipy statsmodels matplotlib openpyxl
"""

from __future__ import annotations

import json
import platform
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import chi2, norm
import statsmodels.api as sm
import statsmodels.formula.api as smf


# =============================================================================
# PATHS — exact paths supplied by the user
# =============================================================================

MODELLING_DATA = Path(
    r"C:\Users\earth\OneDrive - University of Reading\PHD 2\Chapters\Paper 2\Codes 2\Analytical procedure\Step 5 Models A-J\outputs_step5_models_2012-2024_May-Sep_20260518_195421\modelling_dataset_swew.csv"
)

FAMILY_ASSIGNMENTS = Path(
    r"C:\Users\earth\OneDrive - University of Reading\PHD 2\Chapters\Paper 2\Codes 2\3. 30 wp into 4 families\storylines_swew_maysep_noqc_audit 1\storyline_assignments.csv"
)

DAILY_RADAR_METRICS = Path(
    r"C:\Users\earth\OneDrive - University of Reading\PHD 2\Chapters\Paper 2\Codes 2\3. 30 wp into 4 families\storylines_swew_maysep_noqc_audit 1\daily_metrics_filtered.csv"
)

CLASSIFICATIONS = Path(
    r"C:\Users\earth\OneDrive - University of Reading\PHD 2\Chapters\Paper 2\Codes 2\Weather pattern composition at lag 0, −1, −2 and −3\classifications_30regimes(21) (4).csv"
)

RAW_BW_FILES = [
    Path(r"C:\Users\earth\OneDrive - University of Reading\PHD 2\Chapters\Paper 2\Codes 2\Analytical procedure\Step 5 Models A-J\BW chem all data 2012 2021.xlsx"),
    Path(r"C:\Users\earth\OneDrive - University of Reading\PHD 2\Chapters\Paper 2\Codes 2\Analytical procedure\Step 5 Models A-J\BW chem data 2022.xlsx"),
    Path(r"C:\Users\earth\OneDrive - University of Reading\PHD 2\Chapters\Paper 2\Codes 2\Analytical procedure\Step 5 Models A-J\BW chem data 2023.xlsx"),
    Path(r"C:\Users\earth\OneDrive - University of Reading\PHD 2\Chapters\Paper 2\Codes 2\Analytical procedure\Step 5 Models A-J\BW chem data 2024.xlsx"),
]

OUT_BASE = Path(
    r"C:\Users\earth\OneDrive - University of Reading\PHD 2\Chapters\Paper 2\Codes 2\Weather pattern composition at lag 0, −1, −2 and −3"
)


# =============================================================================
# SETTINGS
# =============================================================================

YEAR_MIN = 2012
YEAR_MAX = 2024
MONTHS_KEEP = [5, 6, 7, 8, 9]
LAGS = [0, -1, -2, -3]
IE_THRESHOLD = 63.0

FAMILY_ORDER = [
    "Cyclonic Atlantic (frontal)",
    "Showery maritime / unsettled",
    "Convective extremes",
    "Settled anticyclonic quiet",
]
REFERENCE_FAMILY = "Settled anticyclonic quiet"
CYCLONIC_FAMILY = "Cyclonic Atlantic (frontal)"

USE_COMPLETE_LAG_SAMPLE = True
STOP_IF_SUSPICIOUS_SITE_NAMES = True
DPI = 300
SEED = 42

SUSPICIOUS_SITE_REGEX = re.compile(
    r"\bRIVER\b|\bSTREAM\b|\bBROOK\b|\bPOWER\s+STATION\b|"
    r"\bFISH\s+COLUMN\b|\bTRAC\b",
    flags=re.IGNORECASE,
)


# =============================================================================
# GENERAL HELPERS
# =============================================================================

def stamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def assert_file(path: Path, label: str) -> None:
    if not path.exists():
        raise FileNotFoundError(f"{label} not found:\n{path}")


def normalise_id(x) -> str:
    if pd.isna(x):
        return ""
    s = str(x).strip()
    if re.fullmatch(r"-?\d+\.0", s):
        s = s[:-2]
    return s


def first_existing(columns: Iterable[str], candidates: Sequence[str]) -> Optional[str]:
    exact = {str(c).strip().lower(): c for c in columns}
    for cand in candidates:
        if cand.lower() in exact:
            return exact[cand.lower()]
    return None


def bh_fdr(pvals: Sequence[float]) -> np.ndarray:
    p = np.asarray(pvals, dtype=float)
    out = np.full(len(p), np.nan, dtype=float)
    valid = np.isfinite(p)
    if not valid.any():
        return out
    pv = p[valid]
    m = len(pv)
    order = np.argsort(pv)
    ranked = pv[order]
    q = ranked * m / np.arange(1, m + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    q = np.minimum(q, 1.0)
    tmp = np.empty(m, dtype=float)
    tmp[order] = q
    out[np.where(valid)[0]] = tmp
    return out


def safe_ratio(num: float, den: float) -> float:
    if pd.isna(num) or pd.isna(den) or den == 0:
        return np.nan
    return float(num / den)


def save_fig(fig, outdir: Path, stem: str) -> None:
    fig.savefig(outdir / f"{stem}.png", dpi=DPI, bbox_inches="tight")
    fig.savefig(outdir / f"{stem}.pdf", bbox_inches="tight")
    plt.close(fig)


# =============================================================================
# FINAL WP -> FOUR-FAMILY MAPPING
# =============================================================================

def parse_regime_number(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series.astype(str).str.extract(r"(\d+)")[0], errors="coerce")


def read_family_mapping(path: Path) -> pd.DataFrame:
    assert_file(path, "Final family assignment file")
    df = pd.read_csv(path)
    if "group_final4" not in df.columns:
        raise ValueError(
            f"{path.name} must contain group_final4. Columns: {list(df.columns)}"
        )

    regime_col = first_existing(df.columns, ["regime", "wp", "weather_pattern", "pattern"])
    if regime_col is None:
        if len(df) != 30:
            raise ValueError("Could not identify WP/regime column and file does not have 30 rows.")
        regime = pd.Series(np.arange(1, 31), index=df.index)
    else:
        regime = parse_regime_number(df[regime_col])

    out = pd.DataFrame({
        "regime": regime,
        "family": df["group_final4"].astype(str).str.strip(),
    }).dropna(subset=["regime"])
    out["regime"] = out["regime"].astype(int)
    out = out.drop_duplicates("regime").sort_values("regime").reset_index(drop=True)

    missing = sorted(set(range(1, 31)) - set(out["regime"]))
    extra = sorted(set(out["regime"]) - set(range(1, 31)))
    bad = sorted(set(out["family"]) - set(FAMILY_ORDER))
    if missing or extra or bad:
        raise ValueError(
            "Final family mapping failed audit.\n"
            f"Missing WP: {missing}\nExtra WP: {extra}\nUnexpected family labels: {bad}"
        )
    return out


# =============================================================================
# DAILY WP CLASSIFICATIONS AND LAGS
# =============================================================================

def read_classifications(path: Path, mapping: pd.DataFrame) -> pd.DataFrame:
    assert_file(path, "Met Office classification file")
    header_row = None
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for i, line in enumerate(f):
            parts = [p.strip().lower() for p in line.rstrip("\n").split(",")]
            if {"day", "month", "year", "regime"}.issubset(parts):
                header_row = i
                break
    if header_row is None:
        raise ValueError("Could not find day/month/year/regime header in classification CSV.")

    df = pd.read_csv(path, skiprows=header_row)
    for c in ["day", "month", "year", "regime"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df["date"] = pd.to_datetime(
        dict(year=df["year"], month=df["month"], day=df["day"]), errors="coerce"
    )
    df = df.dropna(subset=["date", "regime"]).copy()
    df["regime"] = df["regime"].astype(int)

    if df["date"].duplicated().any():
        dup = df[df["date"].duplicated(keep=False)].sort_values("date")
        raise ValueError(
            "Daily WP classification has duplicate dates. First duplicates:\n"
            + dup.head(20).to_string(index=False)
        )

    out = df[["date", "regime"]].sort_values("date").reset_index(drop=True)
    out = out.merge(mapping, on="regime", how="left", validate="many_to_one")
    if out["family"].isna().any():
        raise ValueError("Some WP values could not be mapped to group_final4.")
    return out


def make_daily_lags(daily: pd.DataFrame) -> pd.DataFrame:
    base = daily[["date", "regime", "family"]].copy()
    out = None
    for lag in LAGS:
        tmp = base.copy()
        if lag < 0:
            tmp["date"] = tmp["date"] + pd.Timedelta(days=abs(lag))
        elif lag > 0:
            tmp["date"] = tmp["date"] - pd.Timedelta(days=lag)
        lab = "lag0" if lag == 0 else f"lagm{abs(lag)}"
        tmp = tmp.rename(columns={
            "regime": f"regime_{lab}",
            "family": f"family_{lab}",
        })
        out = tmp if out is None else out.merge(tmp, on="date", how="outer")
    out = out.sort_values("date").reset_index(drop=True)
    out["year"] = out["date"].dt.year
    out["month"] = out["date"].dt.month
    return out


# =============================================================================
# CANONICAL STEP 5 BATHING-WATER POPULATION
# =============================================================================

def read_canonical_samples(path: Path) -> Tuple[pd.DataFrame, Dict[str, str]]:
    assert_file(path, "Canonical Step 5 modelling dataset")
    df = pd.read_csv(path)

    date_col = first_existing(df.columns, ["date", "Date"])
    y_col = first_existing(df.columns, ["y_exceed", "advice_flag", "exceedance"])
    site_id_col = first_existing(
        df.columns, ["site_id", "SMPT_USER_REFERENCE", "site_reference", "site"]
    )
    site_name_col = first_existing(
        df.columns, ["site_name", "SMPT_SHORT_NAME", "beach_name", "site_short_name"]
    )
    ie_col = first_existing(
        df.columns, ["ie", "IE", "ie_value", "intestinal_enterococci"]
    )

    if date_col is None or y_col is None or site_id_col is None:
        raise ValueError(
            "Canonical Step 5 file must contain date, y_exceed and site_id "
            f"(or recognised equivalents). Columns: {list(df.columns)}"
        )

    out = df.copy()
    out["date"] = pd.to_datetime(out[date_col], errors="coerce")
    out["y_exceed"] = pd.to_numeric(out[y_col], errors="coerce")
    out["site_id"] = out[site_id_col].map(normalise_id)
    out["site_name"] = (
        out[site_name_col].astype(str).str.strip() if site_name_col is not None else ""
    )
    if ie_col is not None:
        out["ie"] = pd.to_numeric(out[ie_col], errors="coerce")
    elif "ie" not in out.columns:
        out["ie"] = np.nan

    out = out.dropna(subset=["date"]).copy()
    out = out[
        out["date"].dt.year.between(YEAR_MIN, YEAR_MAX)
        & out["date"].dt.month.isin(MONTHS_KEEP)
    ].copy()
    out = out[out["y_exceed"].isin([0, 1])].copy()
    out["y_exceed"] = out["y_exceed"].astype(int)
    out["year"] = out["date"].dt.year.astype(int)
    out["month"] = out["date"].dt.month.astype(int)
    out["_canonical_row_id"] = np.arange(len(out), dtype=int)

    meta = {
        "date_source": str(date_col),
        "y_source": str(y_col),
        "site_id_source": str(site_id_col),
        "site_name_source": str(site_name_col) if site_name_col else "not present",
        "ie_source": str(ie_col) if ie_col else "not present",
    }
    return out, meta


def canonical_audit(samples: pd.DataFrame, outdir: Path) -> pd.DataFrame:
    rows = [
        {"item": "canonical_rows", "value": len(samples)},
        {"item": "unique_sites", "value": samples["site_id"].nunique()},
        {"item": "unique_sampling_dates", "value": samples["date"].nunique()},
        {"item": "exceedance_rows", "value": int(samples["y_exceed"].sum())},
        {
            "item": "unique_dates_with_at_least_one_exceedance",
            "value": int(samples.groupby("date")["y_exceed"].max().sum()),
        },
        {
            "item": "duplicate_site_date_rows",
            "value": int(samples.duplicated(["site_id", "date"], keep=False).sum()),
        },
        {"item": "missing_site_id", "value": int((samples["site_id"] == "").sum())},
    ]

    if samples["ie"].notna().any():
        mismatch = (
            ((samples["ie"] >= IE_THRESHOLD).astype(int) != samples["y_exceed"])
            & samples["ie"].notna()
        )
        rows.append({"item": "IE63_vs_y_exceed_mismatches", "value": int(mismatch.sum())})
        if mismatch.any():
            samples.loc[mismatch, ["site_id", "site_name", "date", "ie", "y_exceed"]].to_csv(
                outdir / "AUDIT_IE63_y_exceed_mismatches.csv", index=False
            )

    dup = samples[samples.duplicated(["site_id", "date"], keep=False)].copy()
    if not dup.empty:
        dup.sort_values(["site_id", "date"]).to_csv(
            outdir / "AUDIT_duplicate_site_date_rows.csv", index=False
        )

    sites = (
        samples[["site_id", "site_name"]]
        .drop_duplicates()
        .sort_values(["site_name", "site_id"])
        .reset_index(drop=True)
    )
    sites.to_csv(outdir / "AUDIT_canonical_site_list.csv", index=False)
    suspicious = sites[
        sites["site_name"].fillna("").str.contains(SUSPICIOUS_SITE_REGEX, regex=True)
    ].copy()
    suspicious.to_csv(outdir / "AUDIT_suspicious_canonical_site_names.csv", index=False)
    rows.append({"item": "suspicious_canonical_site_names", "value": len(suspicious)})

    by_year = (
        samples.groupby("year")
        .agg(
            n_samples=("date", "size"),
            n_sites=("site_id", "nunique"),
            n_dates=("date", "nunique"),
            n_exceed=("y_exceed", "sum"),
        )
        .reset_index()
    )
    by_year.to_csv(outdir / "AUDIT_canonical_samples_by_year.csv", index=False)

    audit = pd.DataFrame(rows)
    audit.to_csv(outdir / "AUDIT_canonical_summary.csv", index=False)

    if STOP_IF_SUSPICIOUS_SITE_NAMES and len(suspicious) > 0:
        raise RuntimeError(
            "STOPPED BEFORE ANALYSIS: suspicious canonical site names were found.\n"
            "Nothing was automatically removed. Review:\n"
            f"{outdir / 'AUDIT_suspicious_canonical_site_names.csv'}\n"
            "If every flagged site is a legitimate designated bathing water, set "
            "STOP_IF_SUSPICIOUS_SITE_NAMES=False and rerun."
        )
    return audit


# =============================================================================
# RAW BW WORKBOOK AUDIT — AUDIT ONLY, NEVER USED TO BUILD ANALYSIS POPULATION
# =============================================================================

def parse_micro_value(x) -> float:
    if pd.isna(x):
        return np.nan
    if isinstance(x, (int, float, np.integer, np.floating)):
        return float(x)
    m = re.search(r"[-+]?\d*\.?\d+", str(x).strip().replace(",", "."))
    return float(m.group()) if m else np.nan


def choose_bw_sheet(path: Path) -> Tuple[str, pd.DataFrame]:
    xls = pd.ExcelFile(path)
    preferred = ["Sheet2", "2022", "2023", "2024", "Sheet1"]
    order = [s for s in preferred if s in xls.sheet_names] + [
        s for s in xls.sheet_names if s not in preferred
    ]
    for sheet in order:
        try:
            df = pd.read_excel(path, sheet_name=sheet)
        except Exception:
            continue
        date_col = first_existing(df.columns, ["Date", "date"])
        site_col = first_existing(df.columns, ["SMPT_USER_REFERENCE", "site_id"])
        if date_col is not None and site_col is not None:
            return sheet, df
    raise ValueError(f"No usable BW data sheet found in {path.name}; sheets={xls.sheet_names}")


def raw_bw_audit(canonical: pd.DataFrame, raw_paths: Sequence[Path], outdir: Path) -> None:
    summaries = []
    raw_parts = []

    for path in raw_paths:
        if not path.exists():
            summaries.append({"file": str(path), "sheet": "", "status": "MISSING - audit skipped"})
            continue
        try:
            sheet, df = choose_bw_sheet(path)
        except Exception as exc:
            summaries.append({"file": str(path), "sheet": "", "status": f"READ ERROR: {exc}"})
            continue

        date_col = first_existing(df.columns, ["Date", "date"])
        site_id_col = first_existing(df.columns, ["SMPT_USER_REFERENCE", "site_id"])
        site_name_col = first_existing(df.columns, ["SMPT_SHORT_NAME", "site_name"])
        purpose_col = first_existing(df.columns, ["SAMP_PURPOSE_CODE", "sample_purpose"])
        ie_col = first_existing(df.columns, ["3723 IE Conf (CFU/0_1l)", "ie", "IE"])

        tmp = pd.DataFrame()
        tmp["date"] = pd.to_datetime(df[date_col], errors="coerce")
        tmp["site_id"] = df[site_id_col].map(normalise_id)
        tmp["site_name"] = (
            df[site_name_col].astype(str).str.strip() if site_name_col is not None else ""
        )
        tmp["purpose"] = (
            df[purpose_col].astype(str).str.strip().str.upper() if purpose_col is not None else ""
        )
        tmp["ie_raw_audit"] = df[ie_col].apply(parse_micro_value) if ie_col is not None else np.nan
        tmp["source_file"] = path.name
        tmp["source_sheet"] = sheet
        tmp = tmp.dropna(subset=["date"])
        tmp = tmp[
            tmp["date"].dt.year.between(YEAR_MIN, YEAR_MAX)
            & tmp["date"].dt.month.isin(MONTHS_KEEP)
        ].copy()

        n_period = len(tmp)
        ms = tmp[tmp["purpose"] == "MS"].copy() if purpose_col is not None else tmp.copy()
        raw_parts.append(ms)
        summaries.append({
            "file": str(path),
            "sheet": sheet,
            "status": "OK",
            "rows_MaySep_2012_2024": n_period,
            "rows_MS_or_all_if_no_purpose": len(ms),
            "unique_sites_MS": ms["site_id"].nunique(),
            "purpose_column_present": purpose_col is not None,
        })

    pd.DataFrame(summaries).to_csv(outdir / "AUDIT_raw_BW_files_summary.csv", index=False)
    if not raw_parts:
        return

    raw = pd.concat(raw_parts, ignore_index=True)
    can_keys = canonical[["site_id", "date"]].drop_duplicates()
    raw_keys = raw[["site_id", "date"]].drop_duplicates()
    merged = can_keys.merge(raw_keys, on=["site_id", "date"], how="outer", indicator=True)

    pd.DataFrame([{
        "canonical_unique_site_dates": len(can_keys),
        "raw_MS_unique_site_dates": len(raw_keys),
        "matched_site_dates": int((merged["_merge"] == "both").sum()),
        "canonical_not_found_in_raw_MS": int((merged["_merge"] == "left_only").sum()),
        "raw_MS_not_in_canonical": int((merged["_merge"] == "right_only").sum()),
    }]).to_csv(outdir / "AUDIT_raw_vs_canonical_summary.csv", index=False)

    merged[merged["_merge"] == "left_only"].to_csv(
        outdir / "AUDIT_canonical_site_dates_not_found_in_raw_MS.csv", index=False
    )
    merged[merged["_merge"] == "right_only"].to_csv(
        outdir / "AUDIT_raw_MS_site_dates_not_in_canonical.csv", index=False
    )

    raw_names = (
        raw[["site_id", "site_name"]].drop_duplicates()
        .merge(canonical[["site_id"]].drop_duplicates(), on="site_id", how="inner")
    )
    raw_names[
        raw_names["site_name"].fillna("").str.contains(SUSPICIOUS_SITE_REGEX, regex=True)
    ].to_csv(outdir / "AUDIT_suspicious_raw_names_for_canonical_site_ids.csv", index=False)


# =============================================================================
# MERGE CANONICAL SAMPLES WITH LAGGED WP DATA
# =============================================================================

def merge_samples_with_lags(samples: pd.DataFrame, daily_lags: pd.DataFrame, outdir: Path) -> pd.DataFrame:
    lag_cols = []
    for lag in LAGS:
        lab = "lag0" if lag == 0 else f"lagm{abs(lag)}"
        lag_cols += [f"regime_{lab}", f"family_{lab}"]

    out = samples.merge(
        daily_lags[["date"] + lag_cols], on="date", how="left", validate="many_to_one"
    )

    audit = []
    for lag in LAGS:
        lab = "lag0" if lag == 0 else f"lagm{abs(lag)}"
        audit.append({
            "lag": lag,
            "missing_regime": int(out[f"regime_{lab}"].isna().sum()),
            "missing_family": int(out[f"family_{lab}"].isna().sum()),
        })
    pd.DataFrame(audit).to_csv(outdir / "AUDIT_lag_merge_missingness.csv", index=False)

    if USE_COMPLETE_LAG_SAMPLE:
        cols = [
            "family_lag0", "family_lagm1", "family_lagm2", "family_lagm3",
            "regime_lag0", "regime_lagm1", "regime_lagm2", "regime_lagm3",
        ]
        before = len(out)
        out = out.dropna(subset=cols).copy()
        pd.DataFrame([{
            "rows_before_complete_lag_filter": before,
            "rows_after_complete_lag_filter": len(out),
            "rows_removed": before - len(out),
        }]).to_csv(outdir / "AUDIT_complete_lag_sample.csv", index=False)
    return out


# =============================================================================
# ANTECEDENT RADAR P3 — EXCLUDES THE SAMPLING DAY
# =============================================================================

def read_daily_radar(path: Path) -> pd.DataFrame:
    assert_file(path, "Daily radar metrics")
    df = pd.read_csv(path)
    date_col = first_existing(df.columns, ["date", "Date"])
    depth_col = first_existing(df.columns, ["daily_depth_mm", "depth_mm"])
    q95_col = first_existing(df.columns, ["q95_mmph", "intensity_q95_mmph"])
    wf_col = first_existing(df.columns, ["wet_fraction", "wf"])
    if date_col is None or depth_col is None:
        raise ValueError(f"Radar file requires date and daily_depth_mm. Columns={list(df.columns)}")

    out = pd.DataFrame({
        "date": pd.to_datetime(df[date_col], errors="coerce"),
        "radar_depth_mm": pd.to_numeric(df[depth_col], errors="coerce"),
        "radar_q95_mmph": pd.to_numeric(df[q95_col], errors="coerce") if q95_col else np.nan,
        "radar_wet_fraction": pd.to_numeric(df[wf_col], errors="coerce") if wf_col else np.nan,
    }).dropna(subset=["date"])

    return out.groupby("date", as_index=False).agg(
        radar_depth_mm=("radar_depth_mm", "mean"),
        radar_q95_mmph=("radar_q95_mmph", "mean"),
        radar_wet_fraction=("radar_wet_fraction", "mean"),
    )


def add_antecedent_radar(samples: pd.DataFrame, radar: pd.DataFrame, outdir: Path) -> pd.DataFrame:
    out = samples.copy()
    for k in [1, 2, 3]:
        tmp = radar.copy()
        tmp["date"] = tmp["date"] + pd.Timedelta(days=k)
        tmp = tmp.rename(columns={
            "radar_depth_mm": f"radar_depth_m{k}",
            "radar_q95_mmph": f"radar_q95_m{k}",
            "radar_wet_fraction": f"radar_wet_fraction_m{k}",
        })
        out = out.merge(tmp, on="date", how="left", validate="many_to_one")

    depth_cols = [f"radar_depth_m{k}" for k in [1, 2, 3]]
    q95_cols = [f"radar_q95_m{k}" for k in [1, 2, 3]]
    wf_cols = [f"radar_wet_fraction_m{k}" for k in [1, 2, 3]]
    out["antecedent_P3_mm"] = out[depth_cols].sum(axis=1, min_count=3)
    out["antecedent_P3_per10mm"] = out["antecedent_P3_mm"] / 10.0
    out["antecedent_q95_max_mmph"] = out[q95_cols].max(axis=1, skipna=False)
    out["antecedent_wet_fraction_mean"] = out[wf_cols].mean(axis=1, skipna=False)

    pd.DataFrame([{
        "n_samples": len(out),
        "n_complete_antecedent_P3": int(out["antecedent_P3_mm"].notna().sum()),
        "n_missing_antecedent_P3": int(out["antecedent_P3_mm"].isna().sum()),
    }]).to_csv(outdir / "AUDIT_antecedent_radar_merge.csv", index=False)
    return out


# =============================================================================
# DESCRIPTIVE CLIMATOLOGY / COMPOSITION / ENRICHMENT
# =============================================================================

def composition_table(df: pd.DataFrame, unit_label: str, event_only: bool) -> pd.DataFrame:
    x = df[df["y_exceed"] == 1].copy() if event_only else df.copy()
    rows = []
    for lag in LAGS:
        lab = "lag0" if lag == 0 else f"lagm{abs(lag)}"
        col = f"family_{lab}"
        valid = x[col].dropna()
        vc = valid.value_counts()
        for fam in FAMILY_ORDER:
            c = int(vc.get(fam, 0))
            rows.append({
                "unit": unit_label,
                "event_only": event_only,
                "lag": lag,
                "family": fam,
                "count": c,
                "n": len(valid),
                "proportion": c / len(valid) if len(valid) else np.nan,
            })
    return pd.DataFrame(rows)


def unique_date_dataset(samples: pd.DataFrame) -> pd.DataFrame:
    lag_cols = [
        "family_lag0", "family_lagm1", "family_lagm2", "family_lagm3",
        "regime_lag0", "regime_lagm1", "regime_lagm2", "regime_lagm3",
    ]
    for col in lag_cols:
        if (samples.groupby("date")[col].nunique(dropna=True) > 1).any():
            raise ValueError(f"Inconsistent {col} labels within the same date.")

    agg = {"year": "first", "month": "first", "y_exceed": "max", "site_id": "nunique"}
    agg.update({c: "first" for c in lag_cols})
    d = samples.groupby("date", as_index=False).agg(agg).rename(columns={"site_id": "n_sites_sampled"})
    exceed_by_date = samples.groupby("date")["y_exceed"].sum()
    d["n_exceedances"] = d["date"].map(exceed_by_date).astype(int)
    return d


def full_meteorological_climatology(daily_lags: pd.DataFrame) -> pd.DataFrame:
    x = daily_lags[
        daily_lags["date"].dt.year.between(YEAR_MIN, YEAR_MAX)
        & daily_lags["date"].dt.month.isin(MONTHS_KEEP)
    ].copy()
    rows = []
    for lag in LAGS:
        lab = "lag0" if lag == 0 else f"lagm{abs(lag)}"
        col = f"family_{lab}"
        valid = x[col].dropna()
        vc = valid.value_counts()
        for fam in FAMILY_ORDER:
            rows.append({
                "lag": lag,
                "family": fam,
                "count": int(vc.get(fam, 0)),
                "n": len(valid),
                "proportion": vc.get(fam, 0) / len(valid) if len(valid) else np.nan,
            })
    return pd.DataFrame(rows)


def monthly_meteorological_climatology(daily_lags: pd.DataFrame) -> pd.DataFrame:
    x = daily_lags[
        daily_lags["date"].dt.year.between(YEAR_MIN, YEAR_MAX)
        & daily_lags["date"].dt.month.isin(MONTHS_KEEP)
    ].copy()
    x["month"] = x["date"].dt.month
    rows = []
    for lag in LAGS:
        lab = "lag0" if lag == 0 else f"lagm{abs(lag)}"
        col = f"family_{lab}"
        for month, d in x.groupby("month"):
            valid = d[col].dropna()
            vc = valid.value_counts()
            for fam in FAMILY_ORDER:
                rows.append({
                    "month": int(month), "lag": lag, "family": fam,
                    "count": int(vc.get(fam, 0)), "n": len(valid),
                    "proportion": vc.get(fam, 0) / len(valid) if len(valid) else np.nan,
                })
    return pd.DataFrame(rows)


def enrichment_from_tables(events: pd.DataFrame, background: pd.DataFrame, background_name: str) -> pd.DataFrame:
    a = events[["lag", "family", "count", "n", "proportion"]].rename(columns={
        "count": "event_count", "n": "event_n", "proportion": "event_proportion"
    })
    b = background[["lag", "family", "count", "n", "proportion"]].rename(columns={
        "count": "background_count", "n": "background_n", "proportion": "background_proportion"
    })
    out = a.merge(b, on=["lag", "family"], how="left")
    out["background"] = background_name
    out["enrichment_ratio"] = [safe_ratio(a, b) for a, b in zip(out["event_proportion"], out["background_proportion"])]
    return out


def year_month_standardised_expected(samples: pd.DataFrame, unit: str) -> pd.DataFrame:
    rows = []
    for lag in LAGS:
        lab = "lag0" if lag == 0 else f"lagm{abs(lag)}"
        col = f"family_{lab}"
        bg = samples.groupby(["year", "month", col]).size().rename("bg_count").reset_index()
        bg_tot = samples.groupby(["year", "month"]).size().rename("bg_n").reset_index()
        bg = bg.merge(bg_tot, on=["year", "month"], how="left")
        bg["p_bg"] = bg["bg_count"] / bg["bg_n"]

        ev = samples[samples["y_exceed"] == 1].copy()
        ev_strata = ev.groupby(["year", "month"]).size().rename("event_n_stratum").reset_index()
        grid = ev_strata.merge(pd.DataFrame({"family_expected": FAMILY_ORDER}), how="cross")
        bg2 = bg.rename(columns={col: "family_expected"})
        grid = grid.merge(bg2[["year", "month", "family_expected", "p_bg"]],
                          on=["year", "month", "family_expected"], how="left")
        grid["p_bg"] = grid["p_bg"].fillna(0.0)
        grid["expected_count"] = grid["event_n_stratum"] * grid["p_bg"]
        exp = grid.groupby("family_expected")["expected_count"].sum().reindex(FAMILY_ORDER, fill_value=0.0)
        obs = ev[col].value_counts().reindex(FAMILY_ORDER, fill_value=0)
        total = len(ev)
        for fam in FAMILY_ORDER:
            op = obs[fam] / total if total else np.nan
            ep = exp[fam] / total if total else np.nan
            rows.append({
                "unit": unit, "lag": lag, "family": fam,
                "observed_count": int(obs[fam]),
                "expected_count_month_year_standardised": float(exp[fam]),
                "n_event_rows": total,
                "observed_proportion": op,
                "expected_proportion_month_year_standardised": ep,
                "observed_expected_ratio": safe_ratio(op, ep),
            })
    return pd.DataFrame(rows)


# =============================================================================
# PERSISTENCE-CONDITIONED EXPECTATION FROM ALL HISTORICAL WP DAYS
# =============================================================================

def empirical_antecedent_probabilities(daily_lags: pd.DataFrame, lag: int) -> pd.DataFrame:
    if lag not in [-1, -2, -3]:
        raise ValueError("Antecedent lag must be -1, -2 or -3.")
    ant_col = f"family_lagm{abs(lag)}"
    hist = daily_lags[
        daily_lags["date"].dt.year.between(YEAR_MIN, YEAR_MAX)
        & daily_lags["date"].dt.month.isin(MONTHS_KEEP)
    ].copy()
    hist["month"] = hist["date"].dt.month
    hist = hist.dropna(subset=["family_lag0", ant_col])

    counts = (
        hist.groupby(["month", "family_lag0", ant_col]).size().rename("count").reset_index()
        .rename(columns={ant_col: "antecedent_family"})
    )
    totals = hist.groupby(["month", "family_lag0"]).size().rename("n").reset_index()
    grid = pd.MultiIndex.from_product(
        [MONTHS_KEEP, FAMILY_ORDER, FAMILY_ORDER],
        names=["month", "family_lag0", "antecedent_family"]
    ).to_frame(index=False)
    out = grid.merge(counts, on=["month", "family_lag0", "antecedent_family"], how="left")
    out = out.merge(totals, on=["month", "family_lag0"], how="left")
    out["count"] = out["count"].fillna(0).astype(int)
    out["probability"] = np.where(out["n"] > 0, out["count"] / out["n"], np.nan)
    out["lag"] = lag
    return out


def persistence_expected_for_events(event_df: pd.DataFrame, probs: pd.DataFrame, lag: int, unit: str) -> pd.DataFrame:
    ant_col = f"family_lagm{abs(lag)}"
    ev = event_df[event_df["y_exceed"] == 1].copy()
    if ev.empty:
        return pd.DataFrame()

    strata = ev.groupby(["month", "family_lag0"]).size().rename("event_n_stratum").reset_index()
    expected = strata.merge(
        probs[["month", "family_lag0", "antecedent_family", "probability"]],
        on=["month", "family_lag0"], how="left"
    )
    expected["expected_count"] = expected["event_n_stratum"] * expected["probability"]
    exp = expected.groupby("antecedent_family")["expected_count"].sum().reindex(FAMILY_ORDER, fill_value=0.0)
    obs = ev[ant_col].value_counts().reindex(FAMILY_ORDER, fill_value=0)
    n = len(ev)

    rows = []
    for fam in FAMILY_ORDER:
        op = obs[fam] / n
        ep = exp[fam] / n
        rows.append({
            "unit": unit, "lag": lag, "family": fam,
            "observed_count": int(obs[fam]),
            "expected_count_given_lag0_and_month": float(exp[fam]),
            "n_event_rows": n,
            "observed_proportion": op,
            "expected_proportion_given_lag0_and_month": ep,
            "observed_expected_ratio": safe_ratio(op, ep),
        })
    return pd.DataFrame(rows)


# =============================================================================
# MODIFIED POISSON + TWO-WAY CLUSTERED COVARIANCE
# =============================================================================

def _cluster_meat(score_obs: np.ndarray, clusters: np.ndarray) -> np.ndarray:
    scores = pd.DataFrame(score_obs)
    scores["_cluster"] = np.asarray(clusters).astype(str)
    grouped = scores.groupby("_cluster", sort=False).sum(numeric_only=True)
    k = score_obs.shape[1]
    meat = np.zeros((k, k), dtype=float)
    for row in grouped.to_numpy(dtype=float):
        s = row.reshape(-1, 1)
        meat += s @ s.T
    return meat


def two_way_cluster_cov(res, site_ids: np.ndarray, dates: np.ndarray) -> pd.DataFrame:
    score_obs = np.asarray(res.model.score_obs(res.params), dtype=float)
    bread_df = res.cov_params()
    idx = bread_df.index
    bread = bread_df.to_numpy(dtype=float)
    site = np.asarray(site_ids).astype(str)
    day = pd.to_datetime(dates).floor("D").astype(str).to_numpy()
    inter = np.char.add(np.char.add(site, "||"), day)
    cov = bread @ (
        _cluster_meat(score_obs, site)
        + _cluster_meat(score_obs, day)
        - _cluster_meat(score_obs, inter)
    ) @ bread
    return pd.DataFrame(cov, index=idx, columns=idx)


def fit_modified_poisson(data: pd.DataFrame, formula: str, required_cols: Sequence[str]):
    use_cols = list(dict.fromkeys(list(required_cols) + ["y_exceed", "site_id", "date"]))
    d = data[use_cols].copy().dropna()
    if d.empty:
        raise ValueError(f"No complete cases for model: {formula}")
    if d["y_exceed"].nunique() < 2:
        raise ValueError(f"Outcome has only one class for model: {formula}")
    res = smf.glm(formula=formula, data=d, family=sm.families.Poisson()).fit()
    cov = two_way_cluster_cov(res, d["site_id"].to_numpy(), d["date"].to_numpy())
    return res, cov, d


def terms_for_variable(param_names: Iterable[str], varname: str) -> List[str]:
    return [p for p in param_names if f"C({varname}" in p and "[T." in p]


def global_wald(res, cov: pd.DataFrame, terms: Sequence[str], label: str) -> Dict[str, float]:
    terms = [t for t in terms if t in res.params.index]
    if not terms:
        return {"test": label, "chi2": np.nan, "df": 0, "p": np.nan}
    b = res.params.loc[terms].to_numpy(dtype=float)
    V = cov.loc[terms, terms].to_numpy(dtype=float)
    stat = float(b.T @ np.linalg.pinv(V) @ b)
    return {"test": label, "chi2": stat, "df": len(terms), "p": float(chi2.sf(stat, len(terms)))}


def label_from_term(term: str) -> str:
    m = re.search(r"\[T\.(.*)\]$", term)
    return m.group(1) if m else term


def rr_rows(res, cov: pd.DataFrame, terms: Sequence[str], extra: Dict) -> pd.DataFrame:
    se = pd.Series(np.sqrt(np.clip(np.diag(cov), 0, None)), index=cov.index)
    rows = []
    for term in terms:
        beta = float(res.params[term])
        s = float(se[term])
        z = beta / s if s > 0 else np.nan
        p = float(2 * norm.sf(abs(z))) if np.isfinite(z) else np.nan
        row = dict(extra)
        row.update({
            "term": term,
            "family": label_from_term(term),
            "beta_logRR": beta,
            "SE": s,
            "RR": float(np.exp(beta)),
            "CI_low": float(np.exp(beta - 1.959963984540054 * s)),
            "CI_high": float(np.exp(beta + 1.959963984540054 * s)),
            "p": p,
        })
        rows.append(row)
    return pd.DataFrame(rows)


def scalar_effect(res, cov: pd.DataFrame, term: str, label: str, model_name: str) -> Dict:
    if term not in res.params.index:
        return {"model": model_name, "effect": label, "term": term, "RR": np.nan,
                "CI_low": np.nan, "CI_high": np.nan, "p": np.nan}
    beta = float(res.params[term])
    s = float(np.sqrt(max(cov.loc[term, term], 0.0)))
    z = beta / s if s > 0 else np.nan
    p = float(2 * norm.sf(abs(z))) if np.isfinite(z) else np.nan
    return {
        "model": model_name, "effect": label, "term": term,
        "beta_logRR": beta, "SE": s, "RR": float(np.exp(beta)),
        "CI_low": float(np.exp(beta - 1.959963984540054 * s)),
        "CI_high": float(np.exp(beta + 1.959963984540054 * s)), "p": p,
    }


def family_formula(varname: str) -> str:
    ref = REFERENCE_FAMILY.replace("'", "\\'")
    return f"y_exceed ~ C({varname}, Treatment(reference='{ref}')) + C(month) + C(year)"


def run_lagged_rr_models(samples: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    effects, globals_ = [], []
    for lag in LAGS:
        lab = "lag0" if lag == 0 else f"lagm{abs(lag)}"
        var = f"family_{lab}"
        res, cov, d = fit_modified_poisson(samples, family_formula(var), [var, "month", "year"])
        terms = terms_for_variable(res.params.index, var)
        effects.append(rr_rows(res, cov, terms, {"lag": lag, "n": len(d), "model": "lag_family"}))
        g = global_wald(res, cov, terms, f"global family effect at lag {lag}")
        g.update({"lag": lag, "n": len(d)})
        globals_.append(g)
    effects = pd.concat(effects, ignore_index=True)
    effects["q_BH_across_12_lag_family_tests"] = bh_fdr(effects["p"].to_numpy())
    return effects, pd.DataFrame(globals_)


def run_persistence_adjusted_rr_models(samples: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    effects, globals_ = [], []
    ref = REFERENCE_FAMILY.replace("'", "\\'")
    for lag in [-1, -2, -3]:
        ant = f"family_lagm{abs(lag)}"
        formula = (
            f"y_exceed ~ C(family_lag0, Treatment(reference='{ref}')) + "
            f"C({ant}, Treatment(reference='{ref}')) + C(month) + C(year)"
        )
        res, cov, d = fit_modified_poisson(samples, formula, ["family_lag0", ant, "month", "year"])
        terms = terms_for_variable(res.params.index, ant)
        effects.append(rr_rows(res, cov, terms, {
            "antecedent_lag": lag, "n": len(d),
            "model": "antecedent_family_adjusted_for_lag0_family"
        }))
        g = global_wald(res, cov, terms, f"antecedent family at {lag}, adjusted for lag0 family")
        g.update({"antecedent_lag": lag, "n": len(d)})
        globals_.append(g)
    effects = pd.concat(effects, ignore_index=True)
    effects["q_BH_across_9_antecedent_family_tests"] = bh_fdr(effects["p"].to_numpy())
    return effects, pd.DataFrame(globals_)


# =============================================================================
# PRIMING / ANTECEDENT-SEQUENCE MODELS
# =============================================================================

def add_sequence_variables(samples: pd.DataFrame) -> pd.DataFrame:
    out = samples.copy()
    prev_cols = ["family_lagm1", "family_lagm2", "family_lagm3"]
    out["prev3_cyclonic_count"] = out[prev_cols].eq(CYCLONIC_FAMILY).sum(axis=1).astype(float)

    if "p7_mm" in out.columns:
        out["p7_per10mm"] = pd.to_numeric(out["p7_mm"], errors="coerce") / 10.0
    if "api" in out.columns:
        a = pd.to_numeric(out["api"], errors="coerce")
        sd = a.std(skipna=True)
        out["api_z"] = (a - a.mean(skipna=True)) / sd if pd.notna(sd) and sd > 0 else np.nan
    if "swvl1_roll" in out.columns:
        a = pd.to_numeric(out["swvl1_roll"], errors="coerce")
        sd = a.std(skipna=True)
        out["swvl1_roll_z"] = (a - a.mean(skipna=True)) / sd if pd.notna(sd) and sd > 0 else np.nan
    return out


def run_priming_models(samples: pd.DataFrame) -> pd.DataFrame:
    ref = REFERENCE_FAMILY.replace("'", "\\'")
    rows = []

    # P1: antecedent circulation sequence beyond current family.
    f1 = (
        f"y_exceed ~ C(family_lag0, Treatment(reference='{ref}')) + "
        "prev3_cyclonic_count + C(month) + C(year)"
    )
    res1, cov1, d1 = fit_modified_poisson(
        samples, f1, ["family_lag0", "prev3_cyclonic_count", "month", "year"]
    )
    r = scalar_effect(res1, cov1, "prev3_cyclonic_count",
                      "RR per additional Cyclonic day in t-1..t-3",
                      "P1_current_family_plus_prev3_cyclonic_count")
    r["n"] = len(d1)
    rows.append(r)

    # P2: add actual antecedent radar P3 excluding day t.
    if "antecedent_P3_per10mm" in samples.columns:
        f2 = (
            f"y_exceed ~ C(family_lag0, Treatment(reference='{ref}')) + "
            "prev3_cyclonic_count + antecedent_P3_per10mm + C(month) + C(year)"
        )
        res2, cov2, d2 = fit_modified_poisson(
            samples, f2,
            ["family_lag0", "prev3_cyclonic_count", "antecedent_P3_per10mm", "month", "year"]
        )
        for term, label in [
            ("prev3_cyclonic_count", "Cyclonic-day count after antecedent-P3 adjustment"),
            ("antecedent_P3_per10mm", "RR per +10 mm rainfall over t-1..t-3"),
        ]:
            r = scalar_effect(res2, cov2, term, label,
                              "P2_current_family_plus_prev3_cyclonic_count_plus_antecedent_P3")
            r["n"] = len(d2)
            rows.append(r)

    # Sensitivity analyses from Step 5 wetness variables. P7 in the existing
    # Step 5 framework includes day t, so it is not the primary antecedent test.
    sensitivity = []
    if "p7_per10mm" in samples.columns:
        sensitivity.append(("p7_per10mm", "RR per +10 mm Step5 P7", "P3_sensitivity_P7"))
    if "api_z" in samples.columns:
        sensitivity.append(("api_z", "RR per +1 SD Step5 API", "P4_sensitivity_API"))
    if "swvl1_roll_z" in samples.columns:
        sensitivity.append(("swvl1_roll_z", "RR per +1 SD 7-day rolling soil moisture", "P5_sensitivity_soil"))

    for var, label, model_name in sensitivity:
        formula = (
            f"y_exceed ~ C(family_lag0, Treatment(reference='{ref}')) + "
            f"prev3_cyclonic_count + {var} + C(month) + C(year)"
        )
        res, cov, d = fit_modified_poisson(
            samples, formula, ["family_lag0", "prev3_cyclonic_count", var, "month", "year"]
        )
        r1 = scalar_effect(res, cov, "prev3_cyclonic_count", f"Cyclonic count after {var} adjustment", model_name)
        r1["n"] = len(d)
        rows.append(r1)
        r2 = scalar_effect(res, cov, var, label, model_name)
        r2["n"] = len(d)
        rows.append(r2)

    out = pd.DataFrame(rows)
    out["q_BH_within_priming_output"] = bh_fdr(out["p"].to_numpy())
    return out


# =============================================================================
# FIGURES
# =============================================================================

def plot_enrichment(enrichment: pd.DataFrame, outdir: Path, stem: str, title: str) -> None:
    lags = [0, -1, -2, -3]
    fig, ax = plt.subplots(figsize=(9, 5.8))
    for fam in FAMILY_ORDER:
        d = enrichment[enrichment["family"] == fam].set_index("lag").reindex(lags)
        ax.plot(lags, d["enrichment_ratio"].to_numpy(), marker="o", label=fam)
    ax.axhline(1.0, linestyle="--", linewidth=1)
    ax.set_xticks(lags)
    ax.set_xticklabels(["0", "−1", "−2", "−3"])
    ax.set_xlabel("Lag relative to exceedance day")
    ax.set_ylabel("Enrichment ratio")
    ax.set_title(title)
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    save_fig(fig, outdir, stem)


def plot_lag_rr(effects: pd.DataFrame, outdir: Path) -> None:
    lags = [0, -1, -2, -3]
    fig, ax = plt.subplots(figsize=(9, 5.8))
    for fam in [f for f in FAMILY_ORDER if f != REFERENCE_FAMILY]:
        d = effects[effects["family"] == fam].set_index("lag").reindex(lags)
        rr = d["RR"].to_numpy(dtype=float)
        lo = d["CI_low"].to_numpy(dtype=float)
        hi = d["CI_high"].to_numpy(dtype=float)
        ax.errorbar(lags, rr, yerr=np.vstack([rr - lo, hi - rr]), marker="o", capsize=3, label=fam)
    ax.axhline(1.0, linestyle="--", linewidth=1)
    ax.set_xticks(lags)
    ax.set_xticklabels(["0", "−1", "−2", "−3"])
    ax.set_xlabel("Lag relative to sampling day")
    ax.set_ylabel(f"Adjusted RR vs {REFERENCE_FAMILY}")
    ax.set_title("Adjusted exceedance RR by circulation family and lag")
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    save_fig(fig, outdir, "Figure3_lagged_adjusted_RR")


def plot_persistence_ratio(table: pd.DataFrame, outdir: Path, stem: str, title: str) -> None:
    fig, ax = plt.subplots(figsize=(9, 5.8))
    for fam in FAMILY_ORDER:
        d = table[table["family"] == fam].sort_values("lag")
        ax.plot(d["lag"], d["observed_expected_ratio"], marker="o", label=fam)
    ax.axhline(1.0, linestyle="--", linewidth=1)
    ax.set_xticks([-3, -2, -1])
    ax.set_xticklabels(["−3", "−2", "−1"])
    ax.set_xlabel("Antecedent lag")
    ax.set_ylabel("Observed / persistence-conditioned expected")
    ax.set_title(title)
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    save_fig(fig, outdir, stem)


# =============================================================================
# EXPORT
# =============================================================================

def write_summary_workbook(outdir: Path, sheets: Dict[str, pd.DataFrame]) -> Path:
    path = outdir / "reviewerproof_lag_analysis_summary.xlsx"
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        for name, df in sheets.items():
            df.to_excel(writer, sheet_name=name[:31], index=False)
    return path


def write_readme(outdir: Path, canonical_meta: Dict[str, str], samples: pd.DataFrame,
                 unique_dates: pd.DataFrame, priming: pd.DataFrame) -> None:
    lines = [
        "Reviewer-proof lag / climatology / persistence analysis",
        "=====================================================",
        "",
        "CANONICAL POPULATION",
        f"Input: {MODELLING_DATA}",
        f"Rows in final complete-lag sample: {len(samples)}",
        f"Exceedance observations: {int(samples['y_exceed'].sum())}",
        f"Unique sampling dates: {samples['date'].nunique()}",
        f"Unique dates with >=1 exceedance: {int(unique_dates['y_exceed'].sum())}",
        "",
        "Canonical column sources:",
    ]
    lines += [f"  {k}: {v}" for k, v in canonical_meta.items()]
    lines += [
        "",
        "IMPORTANT",
        "The Step 5 modelling_dataset_swew.csv is the ONLY bathing-water sample population",
        "used for analysis. Raw BW workbooks are audit-only and never add rows.",
        "",
        "SITE AUDIT",
        "No site is automatically removed by a word/name rule. If the canonical file",
        "contains RIVER/STREAM/BROOK/POWER STATION/FISH COLUMN/TRAC and the strict",
        "switch is True, the run stops before analysis for manual review.",
        "",
        "CLIMATOLOGY",
        "Outputs include full May-Sep meteorological climatology, canonical sampling",
        "opportunity climatology, and year/month-standardised expected composition.",
        "",
        "PERSISTENCE",
        "P(antecedent family | current family, month) is estimated from ALL daily WP",
        "classification days. Exceedance data are not used to estimate this expectation.",
        "",
        "INFERENCE",
        "Modified Poisson GLMs use month and year fixed effects and two-way clustered",
        "sandwich SE by site and sampling date. BH-FDR is applied to the specific",
        "multi-comparison lag-family tests.",
        "",
        "PRIMING",
        "Primary antecedent rainfall is radar P3 over t-1, t-2, t-3, excluding day t.",
        "This is an association test, not causal mediation.",
        "",
        "SOFTWARE",
        f"Python: {sys.version}",
        f"Platform: {platform.platform()}",
        f"pandas: {pd.__version__}",
        f"numpy: {np.__version__}",
        "",
        "PRIMING OUTPUT",
        priming.to_string(index=False) if not priming.empty else "No priming models produced.",
    ]
    (outdir / "README_REVIEWERPROOF_ANALYSIS.txt").write_text("\n".join(lines), encoding="utf-8")


# =============================================================================
# MAIN
# =============================================================================

def main() -> None:
    np.random.seed(SEED)
    outdir = OUT_BASE / f"reviewerproof_lag_climatology_chain_{stamp()}"
    outdir.mkdir(parents=True, exist_ok=False)

    print("=" * 80)
    print("Reviewer-proof lag / climatology / persistence analysis")
    print("=" * 80)
    print("Output:", outdir)

    # 1. Final audited family mapping + full daily WP sequence.
    mapping = read_family_mapping(FAMILY_ASSIGNMENTS)
    mapping.to_csv(outdir / "AUDIT_final_family_mapping_used.csv", index=False)
    daily = read_classifications(CLASSIFICATIONS, mapping)
    daily_lags = make_daily_lags(daily)

    # 2. Exact Step 5 canonical bathing-water population.
    canonical, canonical_meta = read_canonical_samples(MODELLING_DATA)
    canonical_audit(canonical, outdir)

    # 3. Raw BW files: audit only. They never redefine canonical rows.
    raw_bw_audit(canonical, RAW_BW_FILES, outdir)

    # 4. Date-based lag merge; same complete sample for all four lags.
    samples = merge_samples_with_lags(canonical, daily_lags, outdir)

    # 5. Antecedent radar P3 and circulation-sequence metrics.
    radar = read_daily_radar(DAILY_RADAR_METRICS)
    samples = add_antecedent_radar(samples, radar, outdir)
    samples = add_sequence_variables(samples)
    samples.to_csv(
        outdir / "analysis_sample_level_with_lags_and_antecedent_rainfall.csv.gz",
        index=False, compression="gzip"
    )

    # 6. Sample-level and unique-date descriptive analyses.
    unique_dates = unique_date_dataset(samples)
    unique_dates.to_csv(outdir / "analysis_unique_sampling_dates.csv", index=False)

    sample_bg = composition_table(samples, "sample_observation", False)
    sample_ev = composition_table(samples, "sample_observation", True)
    date_bg = composition_table(unique_dates, "unique_sampling_date", False)
    date_ev = composition_table(unique_dates, "unique_sampling_date", True)

    met_clim = full_meteorological_climatology(daily_lags)
    monthly_met_clim = monthly_meteorological_climatology(daily_lags)

    sample_enrich_sampling = enrichment_from_tables(
        sample_ev, sample_bg, "all canonical sampling opportunities"
    )
    sample_enrich_met = enrichment_from_tables(
        sample_ev, met_clim, "full May-Sep meteorological climatology"
    )
    date_enrich_sampling = enrichment_from_tables(
        date_ev, date_bg, "unique canonical sampling dates"
    )
    date_enrich_met = enrichment_from_tables(
        date_ev, met_clim, "full May-Sep meteorological climatology"
    )

    ym_standard_sample = year_month_standardised_expected(samples, "sample_observation")
    ym_standard_date = year_month_standardised_expected(unique_dates, "unique_sampling_date")

    # 7. Persistence-conditioned expectation.
    transition_tables, pers_sample, pers_date = [], [], []
    for lag in [-1, -2, -3]:
        probs = empirical_antecedent_probabilities(daily_lags, lag)
        transition_tables.append(probs)
        pers_sample.append(persistence_expected_for_events(samples, probs, lag, "sample_observation"))
        pers_date.append(persistence_expected_for_events(unique_dates, probs, lag, "unique_sampling_date"))

    transitions = pd.concat(transition_tables, ignore_index=True)
    persistence_sample = pd.concat(pers_sample, ignore_index=True)
    persistence_date = pd.concat(pers_date, ignore_index=True)

    # 8. Formal inferential models.
    lag_rr, lag_global = run_lagged_rr_models(samples)
    antecedent_rr, antecedent_global = run_persistence_adjusted_rr_models(samples)
    priming = run_priming_models(samples)

    # 9. Export every result as CSV.
    outputs = {
        "sample_background_composition": sample_bg,
        "sample_exceedance_composition": sample_ev,
        "date_background_composition": date_bg,
        "date_exceedance_composition": date_ev,
        "meteorological_climatology": met_clim,
        "monthly_meteorological_climatology": monthly_met_clim,
        "sample_enrichment_sampling": sample_enrich_sampling,
        "sample_enrichment_meteorological": sample_enrich_met,
        "date_enrichment_sampling": date_enrich_sampling,
        "date_enrichment_meteorological": date_enrich_met,
        "monthyear_standardised_sample": ym_standard_sample,
        "monthyear_standardised_date": ym_standard_date,
        "antecedent_transition_probabilities": transitions,
        "persistence_expected_sample": persistence_sample,
        "persistence_expected_date": persistence_date,
        "lagged_modified_poisson_RR": lag_rr,
        "lagged_global_Wald": lag_global,
        "antecedent_RR_adjusted_for_lag0": antecedent_rr,
        "antecedent_global_Wald": antecedent_global,
        "priming_models": priming,
    }
    for name, df in outputs.items():
        df.to_csv(outdir / f"{name}.csv", index=False)

    # 10. Figures.
    plot_enrichment(
        sample_enrich_sampling, outdir,
        "Figure1_enrichment_vs_sampling_climatology",
        "Exceedance-family enrichment relative to canonical sampling climatology",
    )
    plot_enrichment(
        sample_enrich_met, outdir,
        "Figure2_enrichment_vs_meteorological_climatology",
        "Exceedance-family enrichment relative to May-Sep meteorological climatology",
    )
    plot_lag_rr(lag_rr, outdir)
    plot_persistence_ratio(
        persistence_sample, outdir, "Figure4_persistence_adjusted_sample",
        "Antecedent circulation after conditioning on lag-0 family and month",
    )
    plot_persistence_ratio(
        persistence_date, outdir, "Figure5_persistence_adjusted_unique_dates",
        "Unique-date sensitivity: persistence-conditioned antecedent circulation",
    )

    # 11. Compact Excel workbook.
    workbook = write_summary_workbook(outdir, {
        "sample_exceed_comp": sample_ev,
        "sample_background": sample_bg,
        "meteorological_clim": met_clim,
        "monthly_met_clim": monthly_met_clim,
        "enrich_sampling": sample_enrich_sampling,
        "enrich_met": sample_enrich_met,
        "monthyear_standard": ym_standard_sample,
        "persist_sample": persistence_sample,
        "persist_dates": persistence_date,
        "lag_RR": lag_rr,
        "lag_global_Wald": lag_global,
        "antecedent_adj_lag0": antecedent_rr,
        "antecedent_global": antecedent_global,
        "priming": priming,
    })

    write_readme(outdir, canonical_meta, samples, unique_dates, priming)

    manifest = {
        "created": datetime.now().isoformat(),
        "canonical_modelling_data": str(MODELLING_DATA),
        "family_assignments": str(FAMILY_ASSIGNMENTS),
        "daily_radar_metrics": str(DAILY_RADAR_METRICS),
        "classifications": str(CLASSIFICATIONS),
        "raw_bw_files_audit_only": [str(p) for p in RAW_BW_FILES],
        "output_directory": str(outdir),
        "year_min": YEAR_MIN,
        "year_max": YEAR_MAX,
        "months": MONTHS_KEEP,
        "lags": LAGS,
        "reference_family": REFERENCE_FAMILY,
        "n_sample_rows_final": len(samples),
        "n_exceedance_rows": int(samples["y_exceed"].sum()),
        "n_unique_sampling_dates": int(samples["date"].nunique()),
        "n_unique_exceedance_dates": int(unique_dates["y_exceed"].sum()),
    }
    (outdir / "RUN_MANIFEST.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    print("\nDONE")
    print("Output folder:", outdir)
    print("Main workbook:", workbook)
    print("Final sample rows:", len(samples))
    print("Exceedance rows:", int(samples["y_exceed"].sum()))
    print("Unique sampling dates:", samples["date"].nunique())
    print("Unique exceedance dates:", int(unique_dates["y_exceed"].sum()))


if __name__ == "__main__":
    main()
