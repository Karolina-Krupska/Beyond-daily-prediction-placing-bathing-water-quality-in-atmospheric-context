from __future__ import annotations

from pathlib import Path
from datetime import datetime
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm

# ============================================================
# PATHS
# ============================================================

# Folder created by the new reviewer-proof lag/climatology/persistence analysis.
INPUT_DIR = Path(
    r"C:\Users\earth\OneDrive - University of Reading\PHD 2\Chapters\Paper 2\Codes 2\Weather pattern composition at lag 0, −1, −2 and −3\reviewerproof_lag_climatology_chain_20260824_163537"
)

# A new timestamped output folder is created as a SIBLING of the long
# reviewer-proof results folder. This deliberately keeps the Windows path short.
# The previous nested output path exceeded the classic ~260-character Windows limit.
STAMP = datetime.now().strftime("%Y%m%d_%H%M%S")
OUT_DIR = INPUT_DIR.parent / f"HM_{STAMP}"
OUT_DIR.mkdir(parents=True, exist_ok=True)

# Input files from the NEW analysis only.
EXCEED_COMP = INPUT_DIR / "sample_exceedance_composition.csv"
STD_SAMPLE = INPUT_DIR / "monthyear_standardised_sample.csv"
PERSIST_SAMPLE = INPUT_DIR / "persistence_expected_sample.csv"
LAGGED_RR = INPUT_DIR / "lagged_modified_poisson_RR.csv"
ANTECEDENT_RR = INPUT_DIR / "antecedent_RR_adjusted_for_lag0.csv"

# ============================================================
# PLOTTING SETTINGS
# ============================================================

DPI = 400
ANNOTATE = True

FAMILY_ORDER = [
    "Cyclonic Atlantic (frontal)",
    "Showery maritime / unsettled",
    "Convective extremes",
    "Settled anticyclonic quiet",
]

FAMILY_LABELS = [
    "Cyclonic Atlantic\n(frontal)",
    "Showery maritime /\nunsettled",
    "Convective\nextremes",
    "Settled anticyclonic\nquiet",
]

LAG_ORDER = [0, -1, -2, -3]
LAG_LABELS = ["lag 0", "lag −1", "lag −2", "lag −3"]
ANT_LAG_ORDER = [-1, -2, -3]
ANT_LAG_LABELS = ["lag −1", "lag −2", "lag −3"]

plt.rcParams.update({
    "font.family": "sans-serif",
    "font.size": 10.5,
    "axes.titlesize": 12,
    "axes.labelsize": 10.5,
    "xtick.labelsize": 9.5,
    "ytick.labelsize": 9.5,
    "figure.dpi": 120,
    "savefig.dpi": DPI,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})

# ============================================================
# HELPERS
# ============================================================

def require_file(path: Path) -> None:
    if not path.exists():
        raise FileNotFoundError(f"Required file not found:\n{path}")


def pivot_matrix(df: pd.DataFrame, value_col: str, lags, families=FAMILY_ORDER) -> pd.DataFrame:
    p = df.pivot(index="lag", columns="family", values=value_col)
    p = p.reindex(index=lags, columns=families)
    if p.isna().any().any():
        missing = np.argwhere(p.isna().to_numpy())
        raise ValueError(
            f"Missing values after pivot for {value_col}; positions={missing.tolist()}\n{p}"
        )
    return p


def add_panel_label(ax, label: str, title: str) -> None:
    ax.text(
        -0.11, 1.08, label,
        transform=ax.transAxes,
        fontsize=12.5,
        fontweight="bold",
        ha="left", va="bottom",
    )
    ax.text(
        -0.06, 1.08, title,
        transform=ax.transAxes,
        fontsize=12.5,
        fontweight="bold",
        ha="left", va="bottom",
    )


def draw_heatmap(
    ax,
    matrix: pd.DataFrame,
    *,
    xlabels,
    ylabels,
    cmap="viridis",
    vmin=None,
    vmax=None,
    norm=None,
    cbar_label="",
    annotation="value",
    fmt=".2f",
    cbar_fraction=0.045,
    cbar_pad=0.035,
):
    data = matrix.to_numpy(dtype=float)
    im = ax.imshow(
        data,
        aspect="auto",
        interpolation="nearest",
        cmap=cmap,
        vmin=vmin,
        vmax=vmax,
        norm=norm,
    )

    ax.set_xticks(np.arange(len(xlabels)))
    ax.set_xticklabels(xlabels)
    ax.set_yticks(np.arange(len(ylabels)))
    ax.set_yticklabels(ylabels)

    # Thin white separators, similar to the supplied figure.
    ax.set_xticks(np.arange(-0.5, len(xlabels), 1), minor=True)
    ax.set_yticks(np.arange(-0.5, len(ylabels), 1), minor=True)
    ax.grid(which="minor", linewidth=0.7, alpha=0.7)
    ax.tick_params(which="minor", bottom=False, left=False)

    # Keep a visible frame.
    for spine in ax.spines.values():
        spine.set_linewidth(0.9)

    if ANNOTATE:
        # Dynamic text colour according to the normalised image value.
        if norm is not None:
            norm_for_text = norm
        else:
            lo = np.nanmin(data) if vmin is None else vmin
            hi = np.nanmax(data) if vmax is None else vmax
            if hi == lo:
                hi = lo + 1.0
            norm_for_text = plt.Normalize(lo, hi)

        for i in range(data.shape[0]):
            for j in range(data.shape[1]):
                val = data[i, j]
                rgba = im.cmap(norm_for_text(val))
                # Perceived luminance to choose black/white text.
                lum = 0.2126 * rgba[0] + 0.7152 * rgba[1] + 0.0722 * rgba[2]
                txt_colour = "black" if lum > 0.60 else "white"

                if annotation == "percent":
                    txt = f"{100*val:.1f}%"
                elif annotation == "ratio":
                    txt = f"{val:.2f}×"
                elif annotation == "rr":
                    txt = f"{val:.2f}"
                else:
                    txt = format(val, fmt)

                ax.text(
                    j, i, txt,
                    ha="center", va="center",
                    fontsize=9.2,
                    color=txt_colour,
                )

    cbar = ax.figure.colorbar(
        im,
        ax=ax,
        fraction=cbar_fraction,
        pad=cbar_pad,
    )
    cbar.set_label(cbar_label)
    return im, cbar


def save_all(fig, basename: str) -> None:
    # Re-create immediately before writing because OneDrive can occasionally
    # delay folder creation/synchronisation on Windows.
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    for ext, kwargs in [
        ("png", {"dpi": DPI}),
        ("pdf", {}),
        ("svg", {}),
    ]:
        path = OUT_DIR / f"{basename}.{ext}"
        # Helpful diagnostic before matplotlib/Pillow fails on old Windows/Python.
        if len(str(path)) >= 245:
            raise RuntimeError(
                f"Output path is still too long for a reliable Windows save ({len(str(path))} chars):\n{path}\n"
                "Move the output folder closer to the drive root or shorten OUT_DIR."
            )
        fig.savefig(path, bbox_inches="tight", **kwargs)


# ============================================================
# LOAD NEW RESULTS
# ============================================================

for f in [EXCEED_COMP, STD_SAMPLE, PERSIST_SAMPLE, LAGGED_RR, ANTECEDENT_RR]:
    require_file(f)

exceed = pd.read_csv(EXCEED_COMP)
std = pd.read_csv(STD_SAMPLE)
persist = pd.read_csv(PERSIST_SAMPLE)
lag_rr = pd.read_csv(LAGGED_RR)
ant_rr = pd.read_csv(ANTECEDENT_RR)

# ============================================================
# MATRIX 1: EXCEEDANCE-FAMILY COMPOSITION
# P(family at lag | exceedance observation)
# ============================================================

m_composition = pivot_matrix(
    exceed,
    value_col="proportion",
    lags=LAG_ORDER,
)

# ============================================================
# MATRIX 2: MONTH/YEAR-STANDARDISED ENRICHMENT
# observed family frequency / expected sampling-background frequency
# ============================================================

m_enrichment = pivot_matrix(
    std,
    value_col="observed_expected_ratio",
    lags=LAG_ORDER,
)

# ============================================================
# MATRIX 3: PERSISTENCE-CONDITIONED ANTECEDENT COMPOSITION
# observed / expected given lag-0 family and calendar month
# ============================================================

m_persistence = pivot_matrix(
    persist,
    value_col="observed_expected_ratio",
    lags=ANT_LAG_ORDER,
)

# ============================================================
# MATRIX 4: LAGGED MODIFIED-POISSON RR
# Settled family is the reference and therefore RR=1 by definition.
# ============================================================

rr_base = lag_rr[["lag", "family", "RR"]].copy()
ref_rows = pd.DataFrame(
    {
        "lag": LAG_ORDER,
        "family": ["Settled anticyclonic quiet"] * len(LAG_ORDER),
        "RR": [1.0] * len(LAG_ORDER),
    }
)
rr_full = pd.concat([rr_base, ref_rows], ignore_index=True)
m_rr = pivot_matrix(rr_full, value_col="RR", lags=LAG_ORDER)

# ============================================================
# MATRIX 5: ANTECEDENT RR AFTER ADJUSTING FOR LAG-0 FAMILY
# Settled antecedent family is reference RR=1.
# ============================================================

ant_base = ant_rr[["antecedent_lag", "family", "RR"]].rename(
    columns={"antecedent_lag": "lag"}
)
ant_ref = pd.DataFrame(
    {
        "lag": ANT_LAG_ORDER,
        "family": ["Settled anticyclonic quiet"] * len(ANT_LAG_ORDER),
        "RR": [1.0] * len(ANT_LAG_ORDER),
    }
)
ant_full = pd.concat([ant_base, ant_ref], ignore_index=True)
m_ant_rr = pivot_matrix(ant_full, value_col="RR", lags=ANT_LAG_ORDER)

# ============================================================
# FIGURE 1
# Similar visual structure to the supplied heatmap figure, but using
# the NEW reviewer-proof analysis only.
# ============================================================

fig, axes = plt.subplots(
    2, 1,
    figsize=(9.0, 9.2),
    gridspec_kw={"height_ratios": [1.0, 1.0], "hspace": 0.48},
)

# Panel a: raw composition around exceedance observations.
draw_heatmap(
    axes[0],
    m_composition,
    xlabels=FAMILY_LABELS,
    ylabels=LAG_LABELS,
    cmap="viridis",
    vmin=0.0,
    vmax=0.55,
    cbar_label="Conditional probability",
    annotation="percent",
)
add_panel_label(
    axes[0],
    "(a)",
    "Circulation-family composition around exceedance observations",
)
axes[0].set_xlabel("")

# Panel b: month/year standardised enrichment.
# Ratio 1 means the family occurred exactly as often as in the matched
# sampling background; >1 means enriched; <1 means under-represented.
ratio_min = min(0.75, float(np.nanmin(m_enrichment.to_numpy())))
ratio_max = max(1.25, float(np.nanmax(m_enrichment.to_numpy())))
ratio_span = max(1.0 - ratio_min, ratio_max - 1.0)
ratio_norm = TwoSlopeNorm(vmin=1.0 - ratio_span, vcenter=1.0, vmax=1.0 + ratio_span)

draw_heatmap(
    axes[1],
    m_enrichment,
    xlabels=FAMILY_LABELS,
    ylabels=LAG_LABELS,
    cmap="RdBu_r",
    norm=ratio_norm,
    cbar_label="Observed / background frequency",
    annotation="ratio",
)
add_panel_label(
    axes[1],
    "(b)",
    "Enrichment relative to month/year-standardised sampling background",
)
axes[1].set_xlabel("Rainfall-process family")

fig.subplots_adjust(left=0.16, right=0.91, top=0.95, bottom=0.10)
save_all(fig, "Fig1_family_enrichment")
plt.close(fig)

# ============================================================
# FIGURE 2
# Persistence and model-based association, again in heatmap form.
# ============================================================

fig, axes = plt.subplots(
    2, 1,
    figsize=(9.0, 8.5),
    gridspec_kw={"height_ratios": [0.86, 1.0], "hspace": 0.50},
)

# Panel a: persistence-conditioned antecedent ratio.
p_min = min(0.75, float(np.nanmin(m_persistence.to_numpy())))
p_max = max(1.15, float(np.nanmax(m_persistence.to_numpy())))
p_span = max(1.0 - p_min, p_max - 1.0)
p_norm = TwoSlopeNorm(vmin=1.0 - p_span, vcenter=1.0, vmax=1.0 + p_span)

draw_heatmap(
    axes[0],
    m_persistence,
    xlabels=FAMILY_LABELS,
    ylabels=ANT_LAG_LABELS,
    cmap="RdBu_r",
    norm=p_norm,
    cbar_label="Observed / persistence-conditioned expected",
    annotation="ratio",
)
add_panel_label(
    axes[0],
    "(a)",
    "Antecedent circulation after conditioning on lag-0 family and month",
)
axes[0].set_xlabel("")

# Panel b: lag-specific adjusted RRs relative to Settled.
rr_min = min(0.70, float(np.nanmin(m_rr.to_numpy())))
rr_max = max(2.00, float(np.nanmax(m_rr.to_numpy())))
rr_span = max(1.0 - rr_min, rr_max - 1.0)
rr_norm = TwoSlopeNorm(vmin=max(0.01, 1.0 - rr_span), vcenter=1.0, vmax=1.0 + rr_span)

draw_heatmap(
    axes[1],
    m_rr,
    xlabels=FAMILY_LABELS,
    ylabels=LAG_LABELS,
    cmap="RdBu_r",
    norm=rr_norm,
    cbar_label="Adjusted RR vs Settled anticyclonic quiet",
    annotation="rr",
)
add_panel_label(
    axes[1],
    "(b)",
    "Adjusted exceedance relative risk by circulation family and lag",
)
axes[1].set_xlabel("Rainfall-process family")

fig.subplots_adjust(left=0.16, right=0.91, top=0.95, bottom=0.10)
save_all(fig, "Fig2_persistence_RR")
plt.close(fig)

# ============================================================
# FIGURE 3
# Optional compact figure showing the reviewer-critical result directly:
# antecedent family RRs AFTER adjustment for the lag-0 family.
# ============================================================

fig, ax = plt.subplots(figsize=(9.0, 4.2))

ant_min = min(0.70, float(np.nanmin(m_ant_rr.to_numpy())))
ant_max = max(1.70, float(np.nanmax(m_ant_rr.to_numpy())))
ant_span = max(1.0 - ant_min, ant_max - 1.0)
ant_norm = TwoSlopeNorm(vmin=max(0.01, 1.0 - ant_span), vcenter=1.0, vmax=1.0 + ant_span)

draw_heatmap(
    ax,
    m_ant_rr,
    xlabels=FAMILY_LABELS,
    ylabels=ANT_LAG_LABELS,
    cmap="RdBu_r",
    norm=ant_norm,
    cbar_label="Adjusted RR vs Settled antecedent family",
    annotation="rr",
)
add_panel_label(
    ax,
    "",
    "Antecedent circulation-family RR after adjustment for sampling-day family",
)
ax.set_xlabel("Antecedent rainfall-process family")

fig.subplots_adjust(left=0.16, right=0.91, top=0.86, bottom=0.20)
save_all(fig, "Fig3_antecedent_RR")
plt.close(fig)

# ============================================================
# EXPORT MATRICES USED IN THE FIGURES FOR AUDITABILITY
# ============================================================

m_composition.to_csv(OUT_DIR / "M1_composition.csv")
m_enrichment.to_csv(OUT_DIR / "M2_enrichment.csv")
m_persistence.to_csv(OUT_DIR / "M3_persistence.csv")
m_rr.to_csv(OUT_DIR / "M4_lagged_RR.csv")
m_ant_rr.to_csv(OUT_DIR / "M5_antecedent_RR.csv")

readme = OUT_DIR / "README.txt"
readme.write_text(
    "New heatmap figures based ONLY on outputs from the reviewer-proof lag analysis.\n\n"
    "Figure_NEW_family_composition_and_enrichment:\n"
    "  (a) P(family at lag | exceedance observation)\n"
    "  (b) observed / month-year-standardised sampling-background family frequency\n\n"
    "Figure_NEW_persistence_and_adjusted_RR:\n"
    "  (a) observed / expected antecedent family frequency conditional on lag-0 family and month\n"
    "  (b) modified-Poisson RR for family at each lag, relative to Settled anticyclonic quiet\n\n"
    "Figure_NEW_antecedent_RR_adjusted_for_lag0:\n"
    "  antecedent-family RR at lag -1/-2/-3 after adjustment for lag-0 family\n\n"
    "Important: no 30-WP panel is reconstructed here because the NEW reviewer-proof outputs supplied\n"
    "for this plotting step are family-level. This avoids mixing old 30-WP results into the new analysis.\n",
    encoding="utf-8",
)

print("DONE")
print(f"Figures written to:\n{OUT_DIR}")
for p in sorted(OUT_DIR.iterdir()):
    print(" -", p.name)
