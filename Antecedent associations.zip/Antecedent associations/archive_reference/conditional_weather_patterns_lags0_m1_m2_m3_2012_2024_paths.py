import os
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# ============================================================
# EDIT THESE PATHS
# ============================================================

# Step 5 modelling dataset. Must contain at least: date, y_exceed.
# Region is optional; if absent, the script uses "SWEW".
DATA_PATH = r"C:\Users\earth\OneDrive - University of Reading\PHD 2\Chapters\Paper 2\Codes 2\Analytical procedure\Step 5 Models A-J\outputs_step5_models_2012-2024_May-Sep_20260518_195421\modelling_dataset_swew.csv"

# Daily Met Office 30-weather-pattern classification file.
# Must contain: year, month, day, regime.
CLASS_PATH = Path(
    r"C:\Users\earth\OneDrive - University of Reading\PHD 2\Chapters\Paper 2\Codes 2\Weather pattern composition at lag 0, −1, −2 and −3\classifications_30regimes(21) (4).csv"
)

# New output folder. Nothing is overwritten because a timestamped subfolder is created.
OUT_BASE_DIR = r"C:\Users\earth\OneDrive - University of Reading\PHD 2\Chapters\Paper 2\Codes 2\Weather pattern composition at lag 0, −1, −2 and −3"

# Lags to examine.
# lag 0  = weather pattern on the sampling/failure day
# lag -1 = weather pattern one day before the sampling/failure day
# lag -2 = weather pattern two days before
# lag -3 = weather pattern three days before
LAGS = [0, -1, -2, -3]

# Analysis period: bathing season, 2012-2024.
START_DATE = "2012-05-01"
END_DATE = "2024-09-30"
ANALYSIS_MONTHS = [5, 6, 7, 8, 9]

# Use the same set of exceedance events across all lags.
# This is best for comparing lag 0, -1, -2 and -3, because differences cannot be caused by
# a slightly different event sample at each lag.
COMPARE_SAME_EVENTS_ALL_LAGS = True

EVENT_COL = "y_exceed"
DPI = 250


# ============================================================
# 30-regime to 4-family mapping
# ============================================================

REGIME_TO_GROUP_4: Dict[int, str] = {
    1: "Cyclonic Atlantic (frontal)",
    2: "Showery maritime / unsettled",
    3: "Convective extremes",
    4: "Showery maritime / unsettled",
    5: "Cyclonic Atlantic (frontal)",
    6: "Convective extremes",
    7: "Cyclonic Atlantic (frontal)",
    8: "Cyclonic Atlantic (frontal)",
    9: "Convective extremes",
    10: "Convective extremes",
    11: "Cyclonic Atlantic (frontal)",
    12: "Convective extremes",
    13: "Settled anticyclonic quiet",
    14: "Showery maritime / unsettled",
    15: "Showery maritime / unsettled",
    16: "Convective extremes",
    17: "Convective extremes",
    18: "Convective extremes",
    19: "Cyclonic Atlantic (frontal)",
    20: "Showery maritime / unsettled",
    21: "Cyclonic Atlantic (frontal)",
    22: "Cyclonic Atlantic (frontal)",
    23: "Settled anticyclonic quiet",
    24: "Cyclonic Atlantic (frontal)",
    25: "Settled anticyclonic quiet",
    26: "Showery maritime / unsettled",
    27: "Convective extremes",
    28: "Cyclonic Atlantic (frontal)",
    29: "Cyclonic Atlantic (frontal)",
    30: "Cyclonic Atlantic (frontal)",
}

FAMILY_ORDER = [
    "Cyclonic Atlantic (frontal)",
    "Showery maritime / unsettled",
    "Convective extremes",
    "Settled anticyclonic quiet",
]

REGIMES = list(range(1, 31))


# ============================================================
# Helpers
# ============================================================

def timestamp() -> str:
    return pd.Timestamp.now().strftime("%Y%m%d_%H%M%S")


def lag_label(lag: int) -> str:
    if lag == 0:
        return "lag0"
    return f"lagm{abs(lag)}"


def lag_title(lag: int) -> str:
    if lag == 0:
        return "lag 0"
    if lag == -1:
        return "lag −1"
    if lag == -2:
        return "lag −2"
    if lag == -3:
        return "lag −3"
    return f"lag {lag}"


def lag_description(lag: int) -> str:
    if lag == 0:
        return "on failure days"
    if lag == -1:
        return "one day before failure days"
    if lag == -2:
        return "two days before failure days"
    if lag == -3:
        return "three days before failure days"
    return f"{abs(lag)} days before failure days"


def make_lagged_regime_table(class_path: str, lags: List[int]) -> pd.DataFrame:
    cl = pd.read_csv(class_path, comment="#")
    needed = {"year", "month", "day", "regime"}
    missing = needed - set(cl.columns)
    if missing:
        raise ValueError(f"Classification file missing columns: {missing}")

    cl["date"] = pd.to_datetime(dict(year=cl["year"], month=cl["month"], day=cl["day"]))
    cl = cl[["date", "regime"]].copy()
    cl["regime"] = pd.to_numeric(cl["regime"], errors="coerce")
    cl = cl.dropna(subset=["regime"]).copy()
    cl["regime"] = cl["regime"].astype(int)

    out = None

    for lag in lags:
        tmp = cl.copy()

        # For lag -k, shift the classification date forward by k days, so that merging
        # on sample date D attaches the regime from D-k.
        if lag < 0:
            tmp["date"] = tmp["date"] + pd.Timedelta(days=abs(lag))
        elif lag > 0:
            tmp["date"] = tmp["date"] - pd.Timedelta(days=lag)

        col = f"regime_{lag_label(lag)}"
        tmp = tmp.rename(columns={"regime": col})

        if out is None:
            out = tmp
        else:
            out = out.merge(tmp, on="date", how="outer")

    return out


def conditional_probs(events_df: pd.DataFrame, region_col: str, cat_col: str, categories, region_order):
    ct = (
        events_df.groupby([region_col, cat_col]).size().unstack(fill_value=0)
        .reindex(index=region_order, fill_value=0)
        .reindex(columns=categories, fill_value=0)
    )
    probs = ct.div(ct.sum(axis=1).replace(0, np.nan), axis=0)
    return probs.fillna(0), ct


def plot_heatmap(matrix: pd.DataFrame, title: str, xlabel: str, outfile: Path):
    fig, ax = plt.subplots(figsize=(14, max(3.5, 0.28 * len(matrix.index))))
    im = ax.imshow(matrix.values, aspect="auto")
    ax.set_title(title)
    ax.set_ylabel("Region")
    ax.set_xlabel(xlabel)

    ax.set_yticks(np.arange(len(matrix.index)))
    ax.set_yticklabels(matrix.index)

    ax.set_xticks(np.arange(len(matrix.columns)))
    ax.set_xticklabels(matrix.columns, rotation=90 if len(matrix.columns) > 10 else 0)

    cbar = fig.colorbar(im, ax=ax)
    cbar.set_label("Conditional probability")
    plt.tight_layout()
    fig.savefig(outfile, dpi=DPI, bbox_inches="tight")
    plt.close(fig)


def plot_lag_panel(lag_matrices: Dict[int, pd.DataFrame], title: str, xlabel: str, outfile: Path):
    """Plot one combined heatmap: lags as rows, categories as columns. Assumes one region or region already aggregated."""
    rows = []
    row_labels = []

    for lag in LAGS:
        mat = lag_matrices[lag]
        # If several regions exist, average is not used; instead use all regions with lag label.
        # For SWEW there is normally one row.
        for region in mat.index:
            rows.append(mat.loc[region].to_numpy(dtype=float))
            row_labels.append(f"{region}, {lag_title(lag)}")

    panel = pd.DataFrame(rows, index=row_labels, columns=lag_matrices[LAGS[0]].columns)

    fig_width = 14 if len(panel.columns) <= 4 else 16
    fig_height = max(3.5, 0.45 * len(panel.index) + 1.5)

    fig, ax = plt.subplots(figsize=(fig_width, fig_height))
    im = ax.imshow(panel.values, aspect="auto")
    ax.set_title(title)
    ax.set_ylabel("Lag relative to failure day")
    ax.set_xlabel(xlabel)

    ax.set_yticks(np.arange(len(panel.index)))
    ax.set_yticklabels(panel.index)

    ax.set_xticks(np.arange(len(panel.columns)))
    ax.set_xticklabels(panel.columns, rotation=90 if len(panel.columns) > 10 else 0)

    cbar = fig.colorbar(im, ax=ax)
    cbar.set_label("Conditional probability")
    plt.tight_layout()
    fig.savefig(outfile, dpi=DPI, bbox_inches="tight")
    plt.close(fig)

    return panel


# ============================================================
# Main
# ============================================================

def main() -> None:
    outdir = Path(OUT_BASE_DIR) / f"conditional_weather_patterns_lags_{timestamp()}"
    outdir.mkdir(parents=True, exist_ok=False)

    # -------------------------
    # Load modelling data
    # -------------------------
    df = pd.read_csv(DATA_PATH)
    df["date"] = pd.to_datetime(df["date"], errors="coerce", dayfirst=True)
    df = df.dropna(subset=["date"]).copy()

    # Enforce the updated analysis window. This keeps the conditional analysis
    # consistent with the new Step 5 modelling dataset: May-Sep, 2012-2024.
    df = df[(df["date"] >= pd.Timestamp(START_DATE)) & (df["date"] <= pd.Timestamp(END_DATE))].copy()
    df = df[df["date"].dt.month.isin(ANALYSIS_MONTHS)].copy()

    if EVENT_COL not in df.columns:
        raise ValueError(f"Expected event column '{EVENT_COL}' not found in modelling data.")

    if "region" not in df.columns:
        df["region"] = "SWEW"

    df[EVENT_COL] = pd.to_numeric(df[EVENT_COL], errors="coerce").fillna(0).astype(int)

    # -------------------------
    # Merge lagged weather patterns
    # -------------------------
    lagged = make_lagged_regime_table(CLASS_PATH, LAGS)
    df = df.merge(lagged, on="date", how="left")

    # If the modelling dataset already has regime, use it as fallback only for lag 0.
    if "regime" in df.columns and "regime_lag0" in df.columns:
        df["regime_lag0"] = df["regime_lag0"].fillna(df["regime"])

    # Family columns for all lags
    regime_cols = [f"regime_{lag_label(lag)}" for lag in LAGS]
    family_cols = []

    for lag in LAGS:
        rcol = f"regime_{lag_label(lag)}"
        fcol = f"family_{lag_label(lag)}"
        df[rcol] = pd.to_numeric(df[rcol], errors="coerce")
        df[fcol] = df[rcol].map(REGIME_TO_GROUP_4)
        family_cols.append(fcol)

    # -------------------------
    # Select exceedance events
    # -------------------------
    events = df[df[EVENT_COL] == 1].copy()

    if COMPARE_SAME_EVENTS_ALL_LAGS:
        events = events.dropna(subset=regime_cols + family_cols).copy()

    region_order = events["region"].value_counts().index.tolist()
    if not region_order:
        raise ValueError("No exceedance events available after applying lag filters.")

    # -------------------------
    # Compute and plot per lag
    # -------------------------
    fam_mats = {}
    reg_mats = {}
    event_count_rows = []

    for lag in LAGS:
        rcol = f"regime_{lag_label(lag)}"
        fcol = f"family_{lag_label(lag)}"

        ev = events.copy()
        if not COMPARE_SAME_EVENTS_ALL_LAGS:
            ev = ev.dropna(subset=[rcol, fcol]).copy()

        ev[rcol] = ev[rcol].astype(int)

        fam_probs, fam_counts = conditional_probs(ev, "region", fcol, FAMILY_ORDER, region_order)
        reg_probs, reg_counts = conditional_probs(ev, "region", rcol, REGIMES, region_order)

        fam_mats[lag] = fam_probs
        reg_mats[lag] = reg_probs

        lab = lag_label(lag)

        fam_probs.to_csv(outdir / f"conditional_probs_family_{lab}.csv")
        fam_counts.to_csv(outdir / f"conditional_counts_family_{lab}.csv")
        reg_probs.to_csv(outdir / f"conditional_probs_regime_{lab}.csv")
        reg_counts.to_csv(outdir / f"conditional_counts_regime_{lab}.csv")

        plot_heatmap(
            fam_probs,
            f"Conditional probabilities for weather-pattern families {lag_description(lag)} ({lag_title(lag)})",
            "Family (4-group)",
            outdir / f"conditional_wp_families_{lab}.png",
        )

        plot_heatmap(
            reg_probs,
            f"Conditional probabilities for weather patterns (WP 1–30) {lag_description(lag)} ({lag_title(lag)})",
            "Weather Pattern (1–30)",
            outdir / f"conditional_wp_regimes_{lab}.png",
        )

        event_count_rows.append({
            "lag": lag,
            "lag_label": lab,
            "n_exceedance_events_used": len(ev),
            "n_regions": ev["region"].nunique(),
            "same_event_sample_all_lags": COMPARE_SAME_EVENTS_ALL_LAGS,
        })

    # -------------------------
    # Combined lag panels — recommended for paper/supplement
    # -------------------------
    fam_panel = plot_lag_panel(
        fam_mats,
        "Conditional weather-pattern family composition before and on exceedance days",
        "Family (4-group)",
        outdir / "conditional_wp_families_lags0_m1_m2_m3_PANEL.png",
    )
    fam_panel.to_csv(outdir / "conditional_probs_family_lags_PANEL.csv")

    reg_panel = plot_lag_panel(
        reg_mats,
        "Conditional 30-weather-pattern composition before and on exceedance days",
        "Weather Pattern (1–30)",
        outdir / "conditional_wp_regimes_lags0_m1_m2_m3_PANEL.png",
    )
    reg_panel.to_csv(outdir / "conditional_probs_regime_lags_PANEL.csv")

    pd.DataFrame(event_count_rows).to_csv(outdir / "event_counts_by_lag.csv", index=False)

    readme = outdir / "README.txt"
    readme.write_text(
        "Conditional weather-pattern analysis for exceedance events.\n\n"
        "Interpretation:\n"
        "- These are P(weather pattern or family | exceedance event), not P(exceedance | weather pattern).\n"
        "- lag 0 is the circulation state on the sampling/exceedance day.\n"
        "- lag -1, -2 and -3 are antecedent circulation states 1, 2 and 3 days before the exceedance day.\n"
        "- COMPARE_SAME_EVENTS_ALL_LAGS=True means the same exceedance-event sample is used for all lag panels.\n"
        f"- Analysis period: {START_DATE} to {END_DATE}; months={ANALYSIS_MONTHS}.\n\n"
        f"Input modelling data: {DATA_PATH}\n"
        f"Input classification data: {CLASS_PATH}\n"
        f"Lags: {LAGS}\n",
        encoding="utf-8",
    )

    print("Done. Outputs saved in:", outdir)
    print("Exceedance events used:", len(events))
    print("Regions:", events["region"].nunique())


if __name__ == "__main__":
    main()
