"""Open in IDLE and press F5 to redraw figures from saved results only."""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'code'))
if __name__=='__main__':
    from figures import generate_figures,verify_figure_exports
    from combined_figure import verify_combined
    generate_figures(ROOT)
    print(verify_figure_exports(ROOT))
    print(verify_combined(ROOT))
    print('All Step7 figures generated from saved results; no models refitted.')
