# Step 7 figure update

Added the combined composition/enrichment/rainfall-adjustment figure, source tables and caption. Both the full analysis entry point and make_figures_only.py generate it automatically. Existing scientific result files are byte-for-byte unchanged. The original five figures remain available.

# What changed in this revision

1. Rebuilt outcomes independently from the selected corrected Step 5 workbook and reconciled every site-day with both selected references.
2. Used actual historical calendar dates for days D, D-1, D-2 and D-3, including late April. Missing rainfall remains missing.
3. Preserved descriptive family composition, month/year standardisation and persistence-conditioned expectations, with explicit denominators.
4. Added site fixed intercepts, month/year and sampling-day family adjustment; explicitly reported zero-event sites.
5. Compared antecedent Cyclonic exposure before and after rainfall adjustment on identical observations.
6. Verified the profiled fits and site/date covariance against explicit-site-dummy statsmodels fits.
7. Ran date-balanced and categorical-count sensitivities, plus 2,000 paired whole-year resampling bundles with three refits per bundle.
8. Applied Holm adjustment to the nine supporting lag-family tests.
9. Produced one main and four supplementary figure sets from current tables, with 600-dpi PNGs, editable PDF/SVG, captions and plotted source tables.
10. Supplied a single IDLE F5 entry point, frozen input inventory, executed tests, logs and reviewer-style limitations.

Steps 3-6 predictive models and simulations were not refitted or regenerated. The old observational cohort and old figures were not reused as replacement results. See RESULTS.md for the new findings and LIMITATIONS.md for remaining scientific concerns.
