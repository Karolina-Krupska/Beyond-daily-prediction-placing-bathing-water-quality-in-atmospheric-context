"""Open this file in IDLE, then Run > Run Module (F5).

The ZIP is self-contained. No other research-step scripts need to be run.
The main guard is necessary for Windows bootstrap worker processes.
"""
import os
# One BLAS thread per worker prevents nested process/thread oversubscription.
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
os.environ['MKL_NUM_THREADS']='1'
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'code'))

def main():
    import json,time,platform,contextlib,traceback
    import numpy as np
    import pandas as pd
    from cohort import rebuild
    from exposures import build_exposures,exposure_audit,save_exposure_support
    from descriptive import run_descriptive
    from models import fit_suite
    from bootstrap import run_bootstrap
    class Tee:
        def __init__(self,*streams): self.streams=streams
        def write(self,s):
            for stream in self.streams: stream.write(s);stream.flush()
            return len(s)
        def flush(self):
            for stream in self.streams: stream.flush()
    (ROOT/'logs').mkdir(exist_ok=True)
    config=json.loads((ROOT/'config.json').read_text())
    with (ROOT/'logs/execution.log').open('w',encoding='utf-8') as log:
      with contextlib.redirect_stdout(Tee(sys.stdout,log)),contextlib.redirect_stderr(Tee(sys.stderr,log)):
        tic=time.perf_counter()
        print('Observed antecedent analysis started',time.strftime('%Y-%m-%d %H:%M:%S UTC',time.gmtime()),flush=True)
        print('Python',platform.python_version(),'configuration',config,flush=True)
        try:
            from provenance import verify_frozen_inputs
            print('Verified frozen input files',verify_frozen_inputs(ROOT),flush=True)
            c=rebuild(ROOT)
            d=build_exposures(c); d.to_csv(ROOT/'data/analysis_site_days.csv',index=False)
            audit=exposure_audit(d)
            (ROOT/'results/exposure_audit.json').write_text(json.dumps(audit,indent=2,default=str))
            save_exposure_support(d,ROOT/'results/audit')
            print('Exposure audit',audit,flush=True)
            print('Descriptive analysis',run_descriptive(d,ROOT/'results/descriptive'),flush=True)
            fits,full,common=fit_suite(d,ROOT/'results')
            saved=ROOT/'results/fitted_associations';saved.mkdir(exist_ok=True)
            high=[]
            for name,f in fits.items():
                np.savez_compressed(saved/(name+'.npz'),beta=f.beta,covariance=f.cov,
                  terms=np.array(f.names),site_intercepts=f.alpha,sites=np.array(f.sites))
                sample=common if name.endswith('common') or name.startswith('DateBalanced') else full
                sample=sample.loc[~sample.site_id.isin(f.metadata['boundary_zero_event_sites'])].reset_index(drop=True)
                if len(sample)!=len(f.mu): raise AssertionError('Prediction audit alignment mismatch')
                sel=f.mu>1
                rows=sample.loc[sel,['site_id','date','y_exceed']].copy()
                rows['model']=name;rows['fitted_mean']=f.mu[sel];high.append(rows)
            pd.concat(high,ignore_index=True).to_csv(ROOT/'results/fitted_means_above_one.csv',index=False)
            b=run_bootstrap(ROOT,fits,config['whole_year_bootstrap_replicates'],
                            config['whole_year_bootstrap_seed'],config['bootstrap_workers'])
            print('Whole-year intervals\n',b.to_string(index=False),flush=True)
            from figures import generate_figures
            print('Figures',generate_figures(ROOT),flush=True)
            # Reports and validation are part of the same entry point.
            from reporting import write_reports
            write_reports(ROOT)
            from verify import verify_all
            result=verify_all(ROOT)
            print('Verification',result,flush=True)
            import importlib.metadata
            versions={x:importlib.metadata.version(x) for x in ['numpy','pandas','scipy','statsmodels','matplotlib','openpyxl']}
            complete={'status':'completed','python':platform.python_version(),'software':versions,
              'runtime_seconds':time.perf_counter()-tic,'configuration':config,
              'scope':'observational association; not Step5 predictive refitting or Step6 simulation',
              'limitations_require_reading':'reports/REVIEW_REPORT.md'}
            (ROOT/'results/RUN_COMPLETION.json').write_text(json.dumps(complete,indent=2))
            if (ROOT/'results/RUN_FAILURE.txt').exists():
                (ROOT/'results/RUN_FAILURE.txt').unlink()
            print('Completed. Figures:',ROOT/'figures',flush=True)
        except Exception:
            traceback.print_exc()
            (ROOT/'results/RUN_FAILURE.txt').write_text(traceback.format_exc())
            raise

if __name__=='__main__':
    import multiprocessing
    multiprocessing.freeze_support()
    main()
