# Observed antecedent circulation and bathing-water exceedances

This is the revised observational lag-analysis package. It is separate from Steps 3–6 simulations and predictive-model validation.

## Run in Windows IDLE

1. Extract the complete ZIP to a normal local folder. Do not run inside the compressed ZIP.
2. Install Python 3.12 and the packages in `requirements.txt` in the same Python environment used by IDLE. If needed, open Windows Command Prompt in this extracted folder and run `py -3.12 -m pip install -r requirements.txt` once.
3. In IDLE choose **File → Open**, select `run_antecedent_analysis.py`, then **Run → Run Module (F5)**.
4. Wait for the completion message. One entry point rebuilds observations, exposures, association fits, paired whole-year refits, figures, reports and verification. No Step 3, 4, 5 or 6 scripts need to be run first.

The configuration defaults to 2,000 whole-year bundles and three worker processes. The main guard supports Windows worker creation; set `bootstrap_workers` to one in `config.json` if the local environment cannot start workers. Changing worker count does not change the saved resampling plan or statistical specification. Do not change the primary exposure or tests after seeing results without recording the change.

For a figure-only redraw without refitting models, open `make_figures_only.py` in IDLE and press F5. The full-analysis entry point above also generates the combined figure automatically.

## Main figure and source tables

`figures/Figure_Combined_Circulation_and_Rainfall` (PNG, PDF and SVG) is the selected combined publication figure: two descriptive heatmaps and the matched rainfall-adjustment comparison. It is generated automatically by the same F5 entry point. The previous `figures/Figure_1_Antecedent_Cyclonic_association` is retained as an alternative. It compares the same three point estimates using site/date clustered intervals and whole-year-refit intervals. See the figure index and captions for exact source tables and interpretation.

Supplementary Figures S1–S4 show lag-family contrasts, descriptive composition/persistence, sampling-balance sensitivity and count-form sensitivity. Each figure has a plotted source CSV and a separate caption. PNGs are exported at 600 dpi at 180 mm width; PDF and SVG preserve editable text.

## Read before interpreting

- `RESULTS.md`: actual estimates and uncertainty from the executed tables.
- `METHODS.md`: cohort, timing, adjustment and inference definitions.
- `LIMITATIONS.md`: remaining observational and working-model limitations.
- `reports/REVIEW_REPORT.md`: completed corrections versus unresolved issues.
- `results/RUN_COMPLETION.json`, logs and verification files: execution evidence.

Required selected inputs and unchanged reference files are included; large simulation arrays and fitted Step 5 predictive models are unnecessary and intentionally excluded. Historical reference code is inactive. No old modelling CSV from `archive_superseded` is used as current input.

Results apply to observed sampled site-days, not issued warnings or observed contamination-episode duration. Modified-Poisson coefficients are working-model relative associations; some fitted means exceed one and must not be used as calibrated probabilities.
