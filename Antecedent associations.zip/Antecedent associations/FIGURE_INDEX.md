# Step 7 figure index

Selected combined publication figure: **figures/Figure_Combined_Circulation_and_Rainfall.pdf**. Panels a/b are descriptive heatmaps; panel c is the matched rainfall-adjustment comparison.

All figures are new plots of the executed observational analysis. PNG: 600 dpi at 180 mm width; PDF/SVG: vector output with editable text.

| Role | Figure | Purpose |
| --- | --- | --- |
| Main candidate | [Figure_1_Antecedent_Cyclonic_association](figures/Figure_1_Antecedent_Cyclonic_association.pdf) | Antecedent Cyclonic association before and after rainfall adjustment; two uncertainty methods |
| Supplement S1 | [Figure_S1_Adjusted_lag_family_associations](figures/Figure_S1_Adjusted_lag_family_associations.pdf) | Three antecedent lags; adjusted family associations and Holm symbols |
| Supplement S2 | [Figure_S2_Antecedent_composition](figures/Figure_S2_Antecedent_composition.pdf) | Exceedance composition, sampled background and persistence-conditioned reference |
| Supplement S3 | [Figure_S3_Sampling_balance_sensitivity](figures/Figure_S3_Sampling_balance_sensitivity.pdf) | Equal-site-day versus date-balanced weighting |
| Supplement S4 | [Figure_S4_Categorical_exposure](figures/Figure_S4_Categorical_exposure.pdf) | Categorical previous-three-day Cyclonic count relative to zero |

Each figure has a matching `_source.csv` in `figures/` and a separate `.txt` caption in `captions/`. Pointwise intervals and adjusted tests are distinct. Read METHODS.md and LIMITATIONS.md before using the figures.
