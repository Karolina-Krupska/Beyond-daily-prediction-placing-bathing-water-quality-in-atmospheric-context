# Observational cohort reconstruction and review

The corrected workbook from the user-selected `Step5_final (2)(2).zip` was independently parsed and aggregated without fitting or loading any predictive model. Its bytes match the workbook embedded in the selected Step 6 package (SHA-256 recorded in `cohort_input_inventory.json`).

## Confirmed reconstruction

- 35,672 source records; 35,621 records fall within May–September 2012–2024.
- 35,590 classifiable records and 31 records without a classifiable result.
- 35,518 evaluable site-days at 194 approved sites, including 3,727 exceedance site-days across 1,616 sampling dates.
- All 35,518 rows exactly match the selected Step 5 current observational dataset on site, date, outcome, source-record counts, evaluable counts, routine-sampling indicator, year, month and row identifier.
- All site-day outcomes also match the corrected association reference retained by Step 5.
- Twelve site-days with no classifiable outcome are excluded. Nineteen site-days with at least one classifiable outcome and missing companion records remain, preserving the approved aggregation rule.
- No repeated site/date/laboratory identifiers occur. Multiple distinct records on a site-day are aggregated by the approved rule: any classifiable exceedance makes the site-day outcome one.
- No name-based eligibility filter was introduced. Approved estuarine sites remain included; the retained register and record aliases are supplied.

## Matters retained for review

Five approved site identifiers have two source-coordinate pairs, reflecting differences between original yearly workbooks. All supplied coordinates are inside the approved geographical box. The record-level coordinates and their original provenance are preserved, with the variation explicitly listed; no replacement coordinate was invented and no site excluded on this basis. These small source-coordinate differences do not change the common regional daily predictor join.

Eight sites have no observed exceedance across 746 site-days. They remain in the observational dataset. Their treatment in a site-fixed-effect model must be documented separately, because a Poisson site intercept for an all-zero site is at the boundary and supplies no finite within-site slope information. No site has an all-one outcome; 46 sites have fewer than five exceedances.

The canonical cohort includes 35,438 site-days with at least one routine (`MS`) sample and 80 without such a sample. Source sampling-purpose counts are supplied. No extra sampling-purpose exclusion was imposed.

## Interpretation limits

The aggregation represents whether any classifiable valid sample that day exceeded the threshold. It is not a continuous daily measurement, a site-wide concentration estimate or an issued warning. Retaining a partially missing site-day follows the selected Step 5 convention; it does not recover the missing companion values. The supplied register and source selection notes determine eligibility; this rebuild does not independently re-establish designation status from external sources.
