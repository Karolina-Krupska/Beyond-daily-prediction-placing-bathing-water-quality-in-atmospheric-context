# Methods: antecedent-circulation analysis

## Observations and provenance

The analysis used the user-selected corrected Step 5 cohort, rebuilt independently from its bathing-water workbook using the approved eligibility and aggregation rules. Sites were retained within 49–52°N and 6–2°W according to the approved register, including approved estuarine sites. Names alone did not determine eligibility. Intestinal enterococci ≥63 CFU 100 mL⁻¹ defined an exceedance. Missing outcomes were not treated as non-exceedances; censoring qualifiers were classified only where they determined the threshold relationship. Multiple valid records within a site-day were aggregated using the approved any-exceedance rule. Wholly unevaluable site-days were excluded and partial missingness retained in the audit.

The historical Step 4 daily calendar and explicit 30-to-four-family mapping supplied circulation and rainfall exposures. The selected Step 4 calendar and mapping were byte-identical to their embedded Step 6 copies. The Step 5 archive and workbook were checked against Step 6 provenance and embedded inputs. Archive and member hashes are retained in the provenance records. No Step 5 predictive models were refitted and no weather simulations or Step 6 results were changed.

## Calendar-date exposures

For each sampled site-day D, historical families on D, D−1, D−2 and D−3 were joined by calendar date using validated many-to-one joins. April dates supplied antecedent support to early-May observations. The primary exposure was the count of Cyclonic Atlantic families during D−3 to D−1 (0–3). This measures antecedent exposure, not necessarily a consecutive circulation run. Antecedent rainfall was the sum of daily depth over the same three dates, requiring all three values. Missing dates or rainfall were never filled with zero or bridged across seasonal gaps.

## Descriptive references

Exceedance composition, P(antecedent family | sampled exceedance), was compared with the distribution among all eligible sampled site-days and historical calendar dates. Month/year-standardised composition used the eligible sampled-site-day month/year weights. The persistence-conditioned reference estimated P(antecedent family | sampling-day calendar month, sampling-day family) empirically from historical evaluation dates pooled across 2012–2024. Its expected composition was averaged over the relevant observed site-days; multiple sampled sites on a date contributed separately. The same-period reference is descriptive and is not a causal null or independent validation. Sparse conditioning-cell support is reported.

## Association models

Modified Poisson regression with log link included site-specific intercepts, sampling-day family, calendar month and year. M0 omitted the primary antecedent exposure; M1 added the count of preceding Cyclonic Atlantic days; M2 additionally included antecedent rainfall per 10 mm. M1 was fitted both on the broader eligible sample and on exactly the same rainfall-complete sample used by M2. Site intercepts were profiled analytically, yielding the same Poisson maximum-likelihood slope estimates as explicit site dummies. No-event sites have limiting intercepts of −∞ and no slope information; their numbers and observations were reported, not described as ordinary finite intercepts.

Two-way site/date cluster sandwich covariance used inclusion–exclusion of the site, date and site×date score sums, with component-wise G/(G−1) × (N−1)/(N−K) corrections; K included absorbed site intercepts. The profile score and Hessian were benchmarked against explicit-dummy statsmodels GLMs and the official two-group covariance implementation under equivalent settings. Covariance validity and target variances were checked; negative variances were not clipped.

The primary two-sided hypothesis was that the M1 broader-cohort Cyclonic-count coefficient equals zero. Supporting models included antecedent family at each lag separately, retaining sampling-day family and the same site/calendar adjustments. Holm correction applied across the nine supporting family contrasts (three non-reference families × three lags). Pointwise 95% coefficient intervals were not treated as multiplicity-adjusted tests. Rainfall-adjustment, date-balance and categorical-count analyses were supporting sensitivity estimates, not a search for a favourable primary test.

## Dependence and sensitivity

Date-balanced models weighted site-days inversely by the number of eligible sites sampled on their date, normalising the mean weight to one. A categorical-count model assessed the assumption that log association changes linearly with the 0–3 Cyclonic count. The prespecified secondary shape contrast tested b₂=2b₁ and b₃=3b₁ using the valid two-dimensional covariance block.

Whole-year resampling drew 13 years with replacement per bundle, retaining all sites and seasonal sequences jointly and applying the same multiplicities to all three primary fits. All association models were refitted within each of 2,000 bundles (seed 20261109). Unsupported year levels were omitted from each refit's treatment coding. Failed fits, coefficient distributions, percentile intervals, bias, skewness and first/second-half interval diagnostics were retained. These pointwise intervals propagate association-model refitting under year exchangeability; they do not model measurement error, family-construction uncertainty or long-term change.

## References

- Zou G. A modified Poisson regression approach to prospective studies with binary data. *American Journal of Epidemiology* 159, 702–706 (2004). https://doi.org/10.1093/aje/kwh090
- statsmodels, `cov_cluster_2groups`: https://www.statsmodels.org/stable/generated/statsmodels.stats.sandwich_covariance.cov_cluster_2groups.html

The benchmark used installed statsmodels 0.14.6; version-specific numerical checks are retained rather than assuming documentation alone establishes correctness.
