"""Numerical integration checks and meaningful outcome/exposure/model tests."""
import hashlib,json,io,unittest
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import norm

def verify_all(root):
    from statsmodels.stats.multitest import multipletests
    root=Path(root); checks=[]
    def check(name,condition):
        checks.append({'check':name,'passed':bool(condition)})
        if not condition: raise AssertionError(name)
    a=pd.read_csv(root/'data/analysis_site_days.csv',parse_dates=['date'])
    c=pd.read_csv(root/'results/coefficients.csv')
    check('unique_site_days',not a.duplicated(['site_id','date']).any())
    check('outcomes_explicitly_binary',a.y_exceed.isin([0,1]).all())
    recon=json.loads((root/'results/audit/outcome_reconciliation.json').read_text())
    # Cohort module itself raises on any difference, and a fresh key comparison
    # below is independent of the report's naming conventions.
    ref=pd.read_csv(root/'inputs/step5/current_modelling_dataset_REFERENCE.csv',parse_dates=['date'])
    j=a[['site_id','date','y_exceed']].merge(ref[['site_id','date','y_exceed']],on=['site_id','date'],
      suffixes=('_new','_step5'),how='outer',validate='one_to_one',indicator=True)
    check('exact_selected_step5_cohort_and_outcomes',j._merge.eq('both').all() and j.y_exceed_new.eq(j.y_exceed_step5).all())
    for k in [1,2,3]:
        check(f'calendar_lag_{k}_dates',(pd.to_datetime(a[f'source_date_lag{k}'])==a.date-pd.Timedelta(days=k)).all())
    check('RR_exp_beta',np.allclose(c.rr,np.exp(c.beta),rtol=1e-12))
    valid=c.covariance_valid
    check('normal_interval_low',np.allclose(c.loc[valid,'ci_low'],np.exp(c.loc[valid,'beta']-norm.ppf(.975)*c.loc[valid,'se']),rtol=1e-10))
    check('normal_interval_high',np.allclose(c.loc[valid,'ci_high'],np.exp(c.loc[valid,'beta']+norm.ppf(.975)*c.loc[valid,'se']),rtol=1e-10))
    check('normal_test_p_values',np.allclose(c.loc[valid,'p_value'],2*norm.sf(abs(c.loc[valid,'beta']/c.loc[valid,'se'])),rtol=1e-10,atol=1e-15))
    sel=c.model.str.startswith('Lag')&c.term.str.match(r'family_lag[123]\[')
    check('nine_supporting_lag_contrasts',sel.sum()==9)
    check('Holm_supporting_family',np.allclose(c.loc[sel,'p_holm'],multipletests(c.loc[sel,'p_value'],method='holm')[1]))
    meta=json.loads((root/'results/model_diagnostics.json').read_text())
    check('matched_rain_cohort_counts',all(meta['M1_common'][x]==meta['M2_common'][x] for x in ['n','n_events','n_sites','n_years','n_cohort']))
    check('all_fits_converged',all(x['converged'] for x in meta.values()))
    benchmark=json.loads((root/'results/statsmodels_benchmark.json').read_text())
    check('independent_explicit_dummy_covariance_benchmarks',all(x['passed'] for x in benchmark.values()))
    above=pd.read_csv(root/'results/fitted_means_above_one.csv')
    check('above_one_not_clipped_and_audited',all(int(above.model.eq(k).sum())==v['fitted_above_one'] for k,v in meta.items()))
    b=pd.read_csv(root/'results/year_bootstrap_draws.csv.gz')
    intervals=pd.read_csv(root/'results/year_bootstrap_intervals.csv')
    plan=np.load(root/'results/whole_year_resampling_plan.npz')
    config=json.loads((root/'config.json').read_text()); B=config['whole_year_bootstrap_replicates']
    check('whole_year_plan_size_and_multiplicity',plan['multiplicities'].shape==(B,13) and (plan['multiplicities'].sum(axis=1)==13).all())
    check('paired_three_fit_draws',b.groupby('replicate').model.nunique().eq(3).all() and b.replicate.nunique()==B)
    for _,row in intervals.iterrows():
        draw=b.loc[b.model.eq(row.model)&b.converged,'beta']
        check('saved_percentile_interval_'+row.model,np.allclose([row.ci_low,row.ci_high],np.exp(np.quantile(draw,[.025,.975])),rtol=1e-12))
    inventory=pd.read_csv(root/'inputs/INPUT_MANIFEST.csv')
    check('all_input_bytes_match_frozen_inventory',all(hashlib.file_digest((root/row.path).open('rb'),'sha256').hexdigest()==row.sha256 for row in inventory.itertuples()))
    from combined_figure import verify_combined
    check('combined_figure_matches_current_results',verify_combined(root)['status']=='passed')
    from figures import verify_figure_exports
    figure_checks=verify_figure_exports(root)
    check('all_figure_sources_intervals_symbols_and_exports',figure_checks['status']=='passed')
    # Discover and execute the exposure + independently implemented model tests.
    suite=unittest.TestLoader().discover(str(root/'code'),pattern='test_*.py')
    stream=io.StringIO(); result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    (root/'logs/numerical_tests.log').write_text(stream.getvalue())
    check('unit_and_independent_model_tests',result.wasSuccessful())
    from test_models_independent import run as independent_model_checks
    independent=independent_model_checks()
    (root/'reports/INDEPENDENT_MODEL_REVIEW.json').write_text(json.dumps(independent,indent=2))
    check('independently_initialised_model_and_weighting_checks',independent['passed'])
    # Outcome parser boundaries, independently of the cohort's observed values.
    from cohort import classify
    for value,expected in [(62,0),(63,1),('<63',0),('>=63',1),('>63',1)]:
        check('threshold_'+str(value),classify(value)[0]==expected)
    for value in [None,'<=63','<64','>62','unreadable']:
        check('ambiguous_or_missing_not_zero_'+str(value),pd.isna(classify(value)[0]))
    report={'integration_checks':checks,'integration_passed':sum(x['passed'] for x in checks),
      'unit_tests_run':result.testsRun,'unit_failures':len(result.failures),'unit_errors':len(result.errors),
      'independent_numerical_checks_run':len(independent['checks']),
      'all_executed_checks_passed':all(x['passed'] for x in checks) and result.wasSuccessful(),
      'scope':'Numerical/code correctness checks do not prove scientific validity or model adequacy.'}
    (root/'reports/VERIFICATION.json').write_text(json.dumps(report,indent=2))
    return report
