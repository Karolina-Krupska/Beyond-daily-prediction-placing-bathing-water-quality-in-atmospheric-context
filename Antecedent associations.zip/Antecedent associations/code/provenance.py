"""Fail before preparation if a required, explicitly selected input changed."""
import hashlib
import pandas as pd

def verify_frozen_inputs(root):
    inventory=pd.read_csv(root/'inputs/INPUT_MANIFEST.csv')
    for row in inventory.itertuples():
        p=root/row.path
        if not p.is_file(): raise FileNotFoundError('Required frozen input missing: '+row.path)
        if hashlib.file_digest(p.open('rb'),'sha256').hexdigest()!=row.sha256:
            raise ValueError('Input differs from selected version: '+row.path)
    return len(inventory)
