"""Paired whole-year refitting sensitivity, preserving all sites/date sequences.

Resampling uses year multiplicities, not independent site-days. The exact same
draw is used for the three primary fits. Covariance is not re-estimated inside
draws because percentile intervals use the refitted coefficients themselves.
"""
import json
import time
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import numpy as np
import pandas as pd
from scipy import stats
from models import fit_poisson

_DATA=None; _START=None

def _init_worker(data_path,start):
    global _DATA,_START
    _DATA=pd.read_csv(data_path,parse_dates=['date']); _START=start

def _one(task):
    replicate,years,counts=task
    d=_DATA; weights=d.year.map(dict(zip(years,counts))).to_numpy(float)
    common=d.rain_previous3_mm.notna().to_numpy(); results=[]
    for name,mode,mask in [('M1_full','M1',np.ones(len(d),dtype=bool)),
                           ('M1_common','M1',common),('M2_common','M2',common)]:
        try:
            f=fit_poisson(d.loc[mask],mode,weights=weights[mask],covariance=False,start=_START[name])
            j=f.names.index('cyclonic_previous3')
            results.append({'replicate':replicate,'model':name,'beta':f.beta[j],
              'converged':True,'failure':'','unique_years':f.metadata['n_years'],
              'informative_sites':f.metadata['n_sites'],
              'boundary_sites':len(f.metadata['boundary_zero_event_sites']),
              'max_fitted_probability':f.metadata['max_fitted_probability']})
        except Exception as e:
            results.append({'replicate':replicate,'model':name,'beta':np.nan,
              'converged':False,'failure':type(e).__name__+': '+str(e),
              'unique_years':int((counts>0).sum())})
    return results

def run_bootstrap(root,fits,replicates=2000,seed=20261109,workers=2):
    root=Path(root); out=root/'results'; tic=time.perf_counter()
    data_path=root/'data/analysis_site_days.csv'; d=pd.read_csv(data_path)
    years=np.sort(d.year.unique()); rng=np.random.default_rng(seed)
    draws=rng.multinomial(len(years),np.ones(len(years))/len(years),size=replicates)
    np.savez_compressed(out/'whole_year_resampling_plan.npz',years=years,multiplicities=draws,seed=seed)
    starts={name:dict(zip(fits[name].names,fits[name].beta)) for name in ['M1_full','M1_common','M2_common']}
    tasks=[(i,years,row) for i,row in enumerate(draws)]
    rows=[]; print('Starting',replicates,'whole-year bundles x three refits; workers=',workers,flush=True)
    if workers==1:
        _init_worker(data_path,starts); iterator=map(_one,tasks)
        for i,result in enumerate(iterator,1):
            rows.extend(result)
            if i%100==0: print('Year bootstrap',i,'/',replicates,'elapsed',round(time.perf_counter()-tic,1),'s',flush=True)
    else:
        with ProcessPoolExecutor(max_workers=workers,initializer=_init_worker,initargs=(data_path,starts)) as pool:
            for i,result in enumerate(pool.map(_one,tasks,chunksize=10),1):
                rows.extend(result)
                if i%100==0: print('Year bootstrap',i,'/',replicates,'elapsed',round(time.perf_counter()-tic,1),'s',flush=True)
    table=pd.DataFrame(rows); table.to_csv(out/'year_bootstrap_draws.csv.gz',index=False)
    summaries=[]
    for name,g in table.groupby('model',sort=False):
        b=g.loc[g.converged,'beta'].to_numpy(); f=fits[name]
        observed=float(f.beta[f.names.index('cyclonic_previous3')])
        if len(b)<.95*replicates: raise RuntimeError('Too many failed refits; retain draw audit and report instability')
        lo,hi=np.quantile(b,[.025,.975]); se=np.std(b,ddof=1)
        halves=np.array_split(b,2)
        summaries.append({'model':name,'term':'cyclonic_previous3','beta':observed,'rr':np.exp(observed),
          'ci_low':np.exp(lo),'ci_high':np.exp(hi),'log_ci_low':lo,'log_ci_high':hi,
          'bootstrap_se':se,'bootstrap_bias':float(b.mean()-observed),
          'bias_over_se':float((b.mean()-observed)/se),'skewness':float(stats.skew(b,bias=False)),
          'valid_replicates':len(b),'failed_replicates':replicates-len(b),
          'first_half_ci_low':float(np.exp(np.quantile(halves[0],.025))),
          'first_half_ci_high':float(np.exp(np.quantile(halves[0],.975))),
          'second_half_ci_low':float(np.exp(np.quantile(halves[1],.025))),
          'second_half_ci_high':float(np.exp(np.quantile(halves[1],.975))),
          'interval':'pointwise percentile; whole-year resampling with all three models refitted',
          'n':f.metadata['n'],'n_events':f.metadata['n_events'],'n_sites':f.metadata['n_sites']})
    pd.DataFrame(summaries).to_csv(out/'year_bootstrap_intervals.csv',index=False)
    # Paired change in log association is descriptive, not evidence of mediation.
    wide=table.pivot(index='replicate',columns='model',values='beta').dropna()
    change=wide.M2_common-wide.M1_common
    (out/'year_bootstrap_metadata.json').write_text(json.dumps({
      'seed':seed,'replicates':replicates,'workers':workers,'sampled_years':years.tolist(),
      'failure_rows':int((~table.converged).sum()),'successful_paired_bundles':len(wide),
      'draw_unit':'whole observed year, including all sampled sites and entire seasonal sequence',
      'same_draw_for_three_models':True,'models_refitted':True,
      'fixed': ['approved cohort preparation rules','weather classification and family mapping','historical measured predictors'],
      'assumptions':'13 years treated approximately exchangeable; does not model trends/between-year dependence; repeated sites across years remain a limitation',
      'paired_log_association_change_mean':float(change.mean()),
      'paired_log_association_change_percentiles':np.quantile(change,[.025,.975]).tolist(),
      'runtime_seconds':time.perf_counter()-tic},indent=2))
    return pd.DataFrame(summaries)
