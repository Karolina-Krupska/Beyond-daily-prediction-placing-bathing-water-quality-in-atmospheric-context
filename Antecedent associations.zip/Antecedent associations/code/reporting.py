"""Copy-ready reporting from the executed authoritative result tables."""
from pathlib import Path
import json
import pandas as pd


def _j(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def _interval(row):
    return f"{row.rr:.3f} (95% CI {row.ci_low:.3f}–{row.ci_high:.3f})"


def write_reports(root):
    root=Path(root); res=root/'results'; reports=root/'reports'
    reports.mkdir(exist_ok=True)
    coef=pd.read_csv(res/'coefficients.csv')
    boot=pd.read_csv(res/'year_bootstrap_intervals.csv')
    cohort=_j(res/'audit/cohort_summary.json')
    exposure=_j(res/'exposure_audit.json')
    diag=_j(res/'model_diagnostics.json')
    bench=_j(res/'statsmodels_benchmark.json')
    bmeta=_j(res/'year_bootstrap_metadata.json')
    shape=_j(res/'exposure_linearity_diagnostic.json')
    config=_j(root/'config.json')
    primary=coef.loc[coef.term.eq('cyclonic_previous3')].set_index('model')
    b=boot.set_index('model')
    lag=coef.loc[coef.model.str.match(r'Lag[123]') & coef.term.str.match(r'family_lag[123]\[')].copy()
    point_table=[]
    for name,label in [('M1_full','Broader cohort; no antecedent-rainfall adjustment'),
                       ('M1_common','Rainfall-complete cohort; no antecedent-rainfall adjustment'),
                       ('M2_common','Rainfall-complete cohort; antecedent-rainfall adjustment')]:
        p=primary.loc[name]; q=b.loc[name]
        point_table.append(f"| {label} | {_interval(p)} | {_interval(q)} | {int(p.n):,} | {int(p.n_events):,} |")
    rain_diag=diag['M2_common']
    adjusted_year_includes=bool(b.loc['M2_common','ci_low']<=1<=b.loc['M2_common','ci_high'])
    original_year_includes=bool(b.loc['M1_full','ci_low']<=1<=b.loc['M1_full','ci_high'])
    unchanged_year_text=("The whole-year refitting interval also excluded one before rainfall adjustment."
        if not original_year_includes else "The whole-year refitting interval included one before rainfall adjustment, weakening evidence from the site/date normal approximation.")
    adjusted_year_text=("The rainfall-adjusted whole-year interval included one, so the analysis does not establish an additional antecedent-Cyclonic association beyond the specified rainfall and adjustment terms."
        if adjusted_year_includes else "The rainfall-adjusted whole-year interval excluded one; the magnitude and dependence assumptions still require cautious interpretation.")
    results=f"""# Results: observed antecedent circulation

The independently rebuilt corrected cohort contained {cohort['evaluable_site_days']:,} sampled site-days from {cohort['sites']} sites, with {cohort['exceedance_site_days']:,} intestinal-enterococci exceedances on {cohort['sampling_dates']:,} sampling dates. All lagged families were available. Three-day antecedent rainfall was complete for {exposure['rain_previous3_complete_site_days']:,} site-days and missing for {exposure['rain_previous3_missing_site_days']:,}.

Eight sites had no exceedances. Their site-specific Poisson intercepts lie at a separation boundary and provide no slope information. They remain in the cohort audit; the broader slope estimation used {diag['M1_full']['n']:,} site-days from {diag['M1_full']['n_sites']} informative sites. The matched rainfall-complete fits used {diag['M2_common']['n']:,} site-days, including {diag['M2_common']['n_events']:,} exceedances, from the same {diag['M2_common']['n_sites']} informative sites.

Each additional Cyclonic Atlantic day during D−3 to D−1 was associated with a relative exceedance association of {_interval(primary.loc['M1_full'])}, after adjustment for sampling-day family, site, month and year. On the identical rainfall-complete sample, this estimate changed from {_interval(primary.loc['M1_common'])} without antecedent-rainfall adjustment to {_interval(primary.loc['M2_common'])} after adding the preceding three-day rainfall total.

{unchanged_year_text} {adjusted_year_text} The change after rainfall adjustment is consistent with substantial overlap between the circulation exposure and measured antecedent rainfall; it does not establish mediation or a causal pathway.

| Model and observational population | Site/date clustered interval | Whole-year refit interval | Informative site-days | Exceedances |
| --- | --- | --- | ---: | ---: |
"""+'\n'.join(point_table)+f"""

Date-balanced sensitivity estimates were {_interval(primary.loc['DateBalanced_M1'])} before antecedent-rainfall adjustment and {_interval(primary.loc['DateBalanced_M2'])} after it. This weighting gives each sampled date equal aggregate weight before boundary-site handling, rather than allowing dates with more sampled sites to contribute proportionately more observations. It targets a different monitored-date population and does not make monitoring random.

The categorical-count departure-from-linearity diagnostic gave χ²={shape['chi_square']:.3f} on {shape['df']} degrees of freedom (p={shape['p_value']:.4f}). This supporting diagnostic does not prove the log-linear assumption. The categorical contrasts and exposure support are shown separately in Figure S4 and the source tables.

Across the nine prespecified supporting lag-family contrasts, {int(lag.p_holm.lt(.05).sum())} had Holm-adjusted p<0.05. Their effect estimates, pointwise intervals and adjusted p-values are in `results/coefficients.csv`; these are separate from the single primary count-exposure test. No significance test was attached to the descriptive composition or persistence-reference figures.

The whole-year sensitivity used {bmeta['replicates']:,} paired year-resampling bundles and refitted three models per bundle. There were {bmeta['failure_rows']} failed model-refit rows; {bmeta['successful_paired_bundles']:,} bundles yielded complete paired results. Results retain the limitations of 13 approximately exchangeable years.

The modified-Poisson working model produced {rain_diag['fitted_above_one']} fitted means above one in the rainfall-adjusted informative sample; its maximum was {rain_diag['max_fitted_probability']:.3f}. These values were not clipped. The estimates are reported as working-model relative associations, not calibrated absolute probabilities.
"""
    methods=f"""# Methods: antecedent-circulation analysis

## Observations and provenance

The analysis used the user-selected corrected Step 5 cohort, rebuilt independently from its bathing-water workbook using the approved eligibility and aggregation rules. Sites were retained within 49–52°N and 6–2°W according to the approved register, including approved estuarine sites. Names alone did not determine eligibility. Intestinal enterococci ≥63 CFU 100 mL⁻¹ defined an exceedance. Missing outcomes were not treated as non-exceedances; censoring qualifiers were classified only where they determined the threshold relationship. Multiple valid records within a site-day were aggregated using the approved any-exceedance rule. Wholly unevaluable site-days were excluded and partial missingness retained in the audit.

The historical Step 4 daily calendar and explicit 30-to-four-family mapping supplied circulation and rainfall exposures. The selected Step 4 calendar and mapping were byte-identical to their embedded Step 6 copies. The Step 5 archive and workbook were checked against Step 6 provenance and embedded inputs. Archive and member hashes are retained in the provenance records. No Step 5 predictive models were refitted and no weather simulations or Step 6 results were changed.

## Calendar-date exposures

For each sampled site-day D, historical families on D, D−1, D−2 and D−3 were joined by calendar date using validated many-to-one joins. April dates supplied antecedent support to early-May observations. The primary exposure was the count of Cyclonic Atlantic families during D−3 to D−1 (0–3). This measures antecedent exposure, not necessarily a consecutive circulation run. Antecedent rainfall was the sum of daily depth over the same three dates, requiring all three values. Missing dates or rainfall were never filled with zero or bridged across seasonal gaps.

## Descriptive references

Exceedance composition, P(antecedent family | sampled exceedance), was compared with the distribution among all eligible sampled site-days and historical calendar dates. Month/year-standardised composition used the eligible sampled-site-day month/year weights. The persistence-conditioned reference estimated P(antecedent family | sampling-day calendar month, sampling-day family) empirically from historical evaluation dates pooled across 2012–2024. Its expected composition was averaged over the relevant observed site-days; multiple sampled sites on a date contributed separately. The same-period reference is descriptive and is not a causal null or independent validation. Sparse conditioning-cell support is reported.

## Association models

Modified Poisson regression with log link included site-specific intercepts, sampling-day family, calendar month and year. M0 omitted the primary antecedent exposure; M1 added the count of preceding Cyclonic Atlantic days; M2 additionally included antecedent rainfall per 10 mm. M1 was fitted both on the broader eligible sample and on exactly the same rainfall-complete sample used by M2. Site intercepts were profiled analytically, yielding the same Poisson maximum-likelihood slope estimates as explicit site dummies. No-event sites have limiting intercepts of −∞ and no slope information; their numbers and observations were reported, not described as ordinary finite intercepts.

Two-way site/date cluster sandwich covariance used inclusion–exclusion of the site, date and site×date score sums, with component-wise G/(G−1) × (N−1)/(N−K) corrections; K included absorbed site intercepts. The profile score and Hessian were benchmarked against explicit-dummy statsmodels GLMs and the official two-group covariance implementation under equivalent settings. Covariance validity and target variances were checked; negative variances were not clipped.

The primary two-sided hypothesis was that the M1 broader-cohort Cyclonic-count coefficient equals zero. Supporting models included antecedent family at each lag separately, retaining sampling-day family and the same site/calendar adjustments. Holm correction applied across the nine supporting family contrasts (three non-reference families × three lags). Pointwise 95% coefficient intervals were not treated as multiplicity-adjusted tests. Rainfall-adjustment, date-balance and categorical-count analyses were supporting sensitivity estimates, not a search for a favourable primary test.

## Dependence and sensitivity

Date-balanced models weighted site-days inversely by the number of eligible sites sampled on their date, normalising the mean weight to one. A categorical-count model assessed the assumption that log association changes linearly with the 0–3 Cyclonic count. The prespecified secondary shape contrast tested b₂=2b₁ and b₃=3b₁ using the valid two-dimensional covariance block.

Whole-year resampling drew 13 years with replacement per bundle, retaining all sites and seasonal sequences jointly and applying the same multiplicities to all three primary fits. All association models were refitted within each of {config['whole_year_bootstrap_replicates']:,} bundles (seed {config['whole_year_bootstrap_seed']}). Unsupported year levels were omitted from each refit's treatment coding. Failed fits, coefficient distributions, percentile intervals, bias, skewness and first/second-half interval diagnostics were retained. These pointwise intervals propagate association-model refitting under year exchangeability; they do not model measurement error, family-construction uncertainty or long-term change.

## References

- Zou G. A modified Poisson regression approach to prospective studies with binary data. *American Journal of Epidemiology* 159, 702–706 (2004). https://doi.org/10.1093/aje/kwh090
- statsmodels, `cov_cluster_2groups`: https://www.statsmodels.org/stable/generated/statsmodels.stats.sandwich_covariance.cov_cluster_2groups.html

The benchmark used installed statsmodels 0.14.6; version-specific numerical checks are retained rather than assuming documentation alone establishes correctness.
"""
    limitations=f"""# Limitations and interpretation

This analysis concerns historical observations on monitored site-days. It does not evaluate issued warnings, advice against bathing or operational forecast performance. Associations do not establish causation or mediation, and are not evidence of incremental predictive skill without a separate validated prediction comparison.

Site intercepts adjust for stable baseline differences between sites. They do not remove time-varying site confounding, non-random monitoring or differences in sampling purpose. Sampling-day family adjustment is not adjustment for all sampling-day meteorology. All eight no-event sites remain in the observational audit but do not inform within-site Poisson slopes.

Site/date covariance addresses repeated sites and contemporaneously shared conditions; it does not necessarily capture cross-site dependence on adjacent dates. Whole-year refitting preserves observed seasonal sequences, but only 13 years are available and are treated as approximately exchangeable. Trends, between-year dependence and persistent site effects spanning years remain potential limitations. The bootstrap is not additional independent evidence and its intervals are pointwise.

Antecedent-rainfall missingness removes {exposure['rain_previous3_missing_site_days']:,} site-days from the matched rainfall comparison. The historical calendar has 74 missing rainfall dates. Complete-case results need not represent the unobserved dates; agreement of estimates before adjustment across broader and common cohorts does not prove missingness is harmless. The matched M1/M2 design distinguishes sample change from covariate adjustment but does not identify a causal mediation effect.

The modified-Poisson model is a working log-mean association model for binary outcomes. In M2, {rain_diag['fitted_above_one']} informative site-days have fitted means above one (maximum {rain_diag['max_fitted_probability']:.3f}), demonstrating that it is unsuitable here as a calibrated absolute-probability model. No values were clipped. Relative coefficients, their model assumptions and diagnostic limitations must be considered together. The count-linearity test cannot prove that a linear effect is correct.

Circulation families and rainfall summaries describe the regional domain. A Cyclonic day is not proof of local rainfall or a particular pollution source, and a count of Cyclonic days is not a duration of continuous circulation or contamination. The empirical persistence reference uses the same historical period; its July/Settled conditioning cell has only 10 dates and should be interpreted cautiously. Five approved site identifiers have source-coordinate variation within the domain; original provenance was retained rather than silently assigning a new location.

This observational step supplies context for the storyline experiments. It does not automatically validate simulated rainfall persistence, donor selection or hydrological processes. Separate Step 4/6 limitations, including underestimated rainfall persistence, rare donor pools and the absence of a dynamical water balance, remain relevant to those simulation findings, not as errors generated by this observational step.
"""
    review=f"""# Reviewer-style review

## Completed corrections and checks

- Independently rebuilt and exactly reconciled {cohort['evaluable_site_days']:,} site-day outcomes against the selected current Step 5 dataset and corrected association reference.
- Preserved approved estuarine sites, threshold/censoring rules and partial-missing observations; excluded {cohort['all_outcome_missing_site_days']} wholly unevaluable site-days.
- Verified complete date-joined family lags and April support; constructed three-day rainfall only from three nonmissing antecedent values.
- Replaced row-order mapping, duplicate averaging and silent covariance clipping with explicit validation and auditable inputs.
- Added site intercepts and reported eight no-event sites as boundary cases; clustering is no longer described as site-baseline adjustment.
- Compared M1/M2 on identical rainfall-complete observations and retained the broader-cohort estimate separately.
- Verified profile estimates/covariance against explicit-dummy statsmodels implementations. Largest actual benchmark coefficient discrepancy: {max(v['max_abs_beta_difference'] for v in bench.values()):.3g}; covariance discrepancy: {max(v['max_abs_covariance_difference'] for v in bench.values()):.3g}.
- Executed date-balanced, categorical-count and {bmeta['replicates']:,}-bundle whole-year refitting sensitivities. Bootstrap failure rows: {bmeta['failure_rows']}.
- Retained nine lag contrasts with Holm adjustment; kept unadjusted pointwise intervals distinct from adjusted tests.
- Regenerated figures from current result tables and exported plotted sources. Visual QA and numerical verification records identify the actual checks performed.
- Independent synthetic-data checks identified and corrected an initial missing-outcome guard issue before scientific conclusions; valid cohort outcomes were unaffected.

## Main scientific assessment

The antecedent-Cyclonic association is materially reduced after adjustment for observed preceding rainfall on the same sample. {adjusted_year_text} The observed antecedent association substantially overlaps with the specified rainfall summary; these data do not establish a distinct rainfall-independent circulation mechanism. This result should complement the Step 5/6 evidence rather than be advertised as proof of better warnings.

## Unresolved limitations

- Modified-Poisson fitted means exceed one for some observations; no calibrated absolute-probability claim is supported.
- Thirteen-year resampling uncertainty and site/date covariance have different dependence assumptions; neither captures every source of uncertainty.
- Missing rainfall, non-random monitoring, sparse sites and a sparse persistence cell remain.
- Family mapping, measurement and domain aggregation uncertainty are not propagated.
- No operational warning records or prospective evaluation were available or analysed.

Publication suitability requires substantive judgement. Numerical agreement and sharp figure exports do not guarantee journal acceptance or resolve these limitations. Exact executed verification results are recorded separately, without a predetermined pass count.
"""
    readme="""# Observed antecedent circulation and bathing-water exceedances

This is the revised observational lag-analysis package. It is separate from Steps 3–6 simulations and predictive-model validation.

## Run in Windows IDLE

1. Extract the complete ZIP to a normal local folder. Do not run inside the compressed ZIP.
2. Install Python 3.12 and the packages in `requirements.txt` in the same Python environment used by IDLE. If needed, open Windows Command Prompt in this extracted folder and run `py -3.12 -m pip install -r requirements.txt` once.
3. In IDLE choose **File → Open**, select `run_antecedent_analysis.py`, then **Run → Run Module (F5)**.
4. Wait for the completion message. One entry point rebuilds observations, exposures, association fits, paired whole-year refits, figures, reports and verification. No Step 3, 4, 5 or 6 scripts need to be run first.

The configuration defaults to 2,000 whole-year bundles and three worker processes. The main guard supports Windows worker creation; set `bootstrap_workers` to one in `config.json` if the local environment cannot start workers. Changing worker count does not change the saved resampling plan or statistical specification. Do not change the primary exposure or tests after seeing results without recording the change.

For a figure-only redraw without refitting models, open `make_figures_only.py` in IDLE and press F5. The full-analysis entry point above also generates the combined figure automatically.

## Main figure and source tables

`figures/Figure_Combined_Circulation_and_Rainfall` (PNG, PDF and SVG) is the selected combined publication figure: two descriptive heatmaps and the matched rainfall-adjustment comparison. It is generated automatically by the same F5 entry point. The previous `figures/Figure_1_Antecedent_Cyclonic_association` is retained as an alternative. It compares the same three point estimates using site/date clustered intervals and whole-year-refit intervals. See the figure index and captions for exact source tables and interpretation.

Supplementary Figures S1–S4 show lag-family contrasts, descriptive composition/persistence, sampling-balance sensitivity and count-form sensitivity. Each figure has a plotted source CSV and a separate caption. PNGs are exported at 600 dpi at 180 mm width; PDF and SVG preserve editable text.

## Read before interpreting

- `RESULTS.md`: actual estimates and uncertainty from the executed tables.
- `METHODS.md`: cohort, timing, adjustment and inference definitions.
- `LIMITATIONS.md`: remaining observational and working-model limitations.
- `reports/REVIEW_REPORT.md`: completed corrections versus unresolved issues.
- `results/RUN_COMPLETION.json`, logs and verification files: execution evidence.

Required selected inputs and unchanged reference files are included; large simulation arrays and fitted Step 5 predictive models are unnecessary and intentionally excluded. Historical reference code is inactive. No old modelling CSV from `archive_superseded` is used as current input.

Results apply to observed sampled site-days, not issued warnings or observed contamination-episode duration. Modified-Poisson coefficients are working-model relative associations; some fitted means exceed one and must not be used as calibrated probabilities.
"""
    for name,text in [('RESULTS.md',results),('METHODS.md',methods),('LIMITATIONS.md',limitations),('README.md',readme),('reports/REVIEW_REPORT.md',review)]:
        (root/name).write_text(text,encoding='utf-8')
    (root/'requirements.txt').write_text('numpy==2.3.5\npandas==2.2.3\nscipy==1.17.0\nstatsmodels==0.14.6\nmatplotlib==3.10.8\nopenpyxl==3.1.5\n',encoding='utf-8')
    (reports/'REPORT_SOURCE_RECORD.json').write_text(json.dumps({
      'sources':['results/coefficients.csv','results/year_bootstrap_intervals.csv','results/model_diagnostics.json','results/statsmodels_benchmark.json','results/audit/cohort_summary.json','results/exposure_audit.json','results/exposure_linearity_diagnostic.json','results/year_bootstrap_metadata.json'],
      'generated_from_executed_results':True,'bootstrap_adjusted_interval_includes_one':adjusted_year_includes},indent=2))
    print('Methods, results, limitations and reviewer report written from current tables.',flush=True)
