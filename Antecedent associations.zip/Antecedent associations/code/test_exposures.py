"""Boundary tests for actual calendar joins and descriptive denominators."""
import tempfile
import unittest
from pathlib import Path
import numpy as np
import pandas as pd
try:
    from .exposures import CYCLONIC, FAMILIES, _attach_calendar, build_exposures, load_calendar
    from .descriptive import run_descriptive
except ImportError:
    from exposures import CYCLONIC, FAMILIES, _attach_calendar, build_exposures, load_calendar
    from descriptive import run_descriptive


class ExposureTests(unittest.TestCase):
    def setUp(self):
        self.cal = pd.DataFrame({
            "date": pd.to_datetime(["2012-04-28", "2012-04-29", "2012-04-30", "2012-05-01", "2012-05-02"]),
            "family": [FAMILIES[1], CYCLONIC, FAMILIES[2], CYCLONIC, FAMILIES[3]],
            "regime": [2, 1, 3, 1, 13],
            "depth_mm": [99., 1., 2., 4., 99.],
        })
        self.cohort = pd.DataFrame({"site_id": ["test-site"], "date": ["2012-05-02"], "y_exceed": [1]})

    def test_calendar_lags_exclude_sampling_day_rain(self):
        d = _attach_calendar(self.cohort, self.cal)
        self.assertEqual(d.rain_previous3_mm.iloc[0], 7.)
        self.assertEqual(d.cyclonic_previous3.iloc[0], 2.)
        self.assertEqual(d.source_date_lag3.iloc[0], pd.Timestamp("2012-04-29"))

    def test_missing_date_is_not_replaced_with_previous_row(self):
        d = _attach_calendar(self.cohort, self.cal.loc[self.cal.date.ne(pd.Timestamp("2012-04-30"))])
        self.assertTrue(pd.isna(d.family_lag2.iloc[0]))
        self.assertTrue(pd.isna(d.rain_previous3_mm.iloc[0]))
        self.assertTrue(pd.isna(d.cyclonic_previous3.iloc[0]))

    def test_missing_rain_is_not_zero(self):
        c = self.cal.copy()
        c.loc[c.date.eq(pd.Timestamp("2012-04-30")), "depth_mm"] = np.nan
        d = _attach_calendar(self.cohort, c)
        self.assertTrue(pd.isna(d.rain_previous3_mm.iloc[0]))
        self.assertEqual(d.cyclonic_previous3.iloc[0], 2.)

    def test_duplicate_predictor_date_stops(self):
        with self.assertRaises(ValueError):
            _attach_calendar(self.cohort, pd.concat([self.cal, self.cal.iloc[[0]]]))

    def test_missing_outcome_stops(self):
        c = self.cohort.copy(); c["y_exceed"] = np.nan
        with self.assertRaises(ValueError):
            _attach_calendar(c, self.cal)

    def test_duplicate_site_day_stops(self):
        with self.assertRaises(ValueError):
            _attach_calendar(pd.concat([self.cohort, self.cohort]), self.cal)

    def test_conflicting_cohort_family_stops(self):
        c = self.cohort.copy(); c["family"] = CYCLONIC
        with self.assertRaises(ValueError):
            _attach_calendar(c, self.cal)

    def test_actual_selected_calendar_and_descriptive_normalisation(self):
        cal = load_calendar()
        self.assertEqual(len(cal), 2379)
        # Synthetic outcomes below exercise denominators only, in a temporary
        # directory; they are never delivered as observed scientific results.
        c = cal.loc[cal.month.between(5, 9), ["date"]].copy()
        c["site_id"] = "unit-test-only"
        c["y_exceed"] = (np.arange(len(c)) % 3 == 0).astype(int)
        d = build_exposures(c)
        self.assertTrue(d.complete_family_lags.all())
        with tempfile.TemporaryDirectory() as temp:
            meta = run_descriptive(d, temp)
            a = pd.read_csv(Path(temp) / "composition_backgrounds.csv")
            b = pd.read_csv(Path(temp) / "persistence_conditioned_composition.csv")
            cells = pd.read_csv(Path(temp) / "persistence_conditioning_cells.csv")
            for field in ["sample_background_proportion", "exceedance_composition_proportion", "calendar_background_proportion"]:
                np.testing.assert_allclose(a.groupby("lag_days")[field].sum(), 1.)
            np.testing.assert_allclose(b.groupby(["population", "lag_days"])["persistence_expected_composition"].sum(), 1.)
            np.testing.assert_allclose(cells.groupby(["lag_days", "sampling_day_month", "sampling_day_family"])["conditional_probability"].sum(), 1.)
            self.assertEqual(meta["historical_evaluation_dates"], 1989)
            self.assertEqual(meta["month_year_strata_without_events"], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
