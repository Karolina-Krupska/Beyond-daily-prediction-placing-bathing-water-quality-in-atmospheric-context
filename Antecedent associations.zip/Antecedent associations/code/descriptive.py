"""Descriptive composition, sampled-background standardisation and persistence.

No p-values are attached to these descriptive comparisons. The empirical
persistence reference uses observed historical dates, not simulated weather.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
try:
    from .exposures import FAMILIES, load_calendar
except ImportError:
    from exposures import FAMILIES, load_calendar


def _safe_ratio(a, b):
    return float(a / b) if b > 0 else np.nan


def run_descriptive(df, output_dir, calendar_path=None, mapping_path=None):
    """Write current descriptive tables and return their definitions/audit."""
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    cal = load_calendar(calendar_path, mapping_path)
    d = df.loc[df.complete_family_lags].copy()
    if len(d) == 0 or d.y_exceed.sum() == 0:
        raise ValueError("Descriptive event composition needs nonempty complete-lag observations and exceedances")
    if not d.y_exceed.isin([0, 1]).all():
        raise ValueError("Missing/ambiguous outcomes must not enter descriptive denominators")
    # Evaluation dates D are May-September. April contributes only their lags.
    weather = cal.loc[cal.month.between(5, 9), ["date", "year", "month", "family"]].rename(columns={"family": "family_lag0"})
    for lag in range(1, 4):
        part = cal[["date", "family"]].copy()
        part.date = part.date + pd.Timedelta(days=lag)
        weather = weather.merge(part.rename(columns={"family": f"family_lag{lag}"}), on="date", how="left", validate="one_to_one")
    if weather[[f"family_lag{k}" for k in range(4)]].isna().any().any():
        raise ValueError("Evaluation calendar lacks required late-April classification support")
    events = d.loc[d.y_exceed.eq(1)]
    composition = []
    for lag in range(4):
        field = f"family_lag{lag}"
        for fam in FAMILIES:
            ns = int(d[field].eq(fam).sum())
            ne = int(events[field].eq(fam).sum())
            nw = int(weather[field].eq(fam).sum())
            ps, pe, pw = ns / len(d), ne / len(events), nw / len(weather)
            composition.append({
                "lag_days": -lag, "family": fam,
                "sampled_site_days_family": ns, "sampled_site_days_total": len(d),
                "exceedance_site_days_family": ne, "exceedance_site_days_total": len(events),
                "calendar_days_family": nw, "calendar_days_total": len(weather),
                "sample_background_proportion": ps,
                "exceedance_composition_proportion": pe,
                "calendar_background_proportion": pw,
                "event_to_sample_composition_ratio": _safe_ratio(pe, ps),
                "event_minus_sample_composition_pp": 100 * (pe - ps),
                "crude_exceedance_proportion_given_family": _safe_ratio(ne, ns),
                "zero_sample_denominator": ns == 0,
            })
    pd.DataFrame(composition).to_csv(out / "composition_backgrounds.csv", index=False)
    # Fixed common month/year weights from eligible sampled site-days.
    strata = d.groupby(["year", "month"], observed=True).agg(
        sampled_site_days=("y_exceed", "size"), exceedance_site_days=("y_exceed", "sum")
    ).reset_index()
    strata["weight_all_sampled_site_days"] = strata.sampled_site_days / len(d)
    strata["standardisation_eligible"] = strata.exceedance_site_days.gt(0)
    eligible = strata.loc[strata.standardisation_eligible].copy()
    retained_mass = float(eligible.weight_all_sampled_site_days.sum())
    eligible["standardisation_weight"] = eligible.weight_all_sampled_site_days / retained_mass
    strata = strata.merge(eligible[["year", "month", "standardisation_weight"]], on=["year", "month"], how="left", validate="one_to_one")
    strata.to_csv(out / "month_year_standardisation_weights.csv", index=False)
    detailed, standardised = [], []
    for lag in range(4):
        field = f"family_lag{lag}"
        for fam in FAMILIES:
            ps, pe = 0., 0.
            for row in eligible.itertuples(index=False):
                s = d.loc[d.year.eq(row.year) & d.month.eq(row.month)]
                e = s.loc[s.y_exceed.eq(1)]
                sf, ef = int(s[field].eq(fam).sum()), int(e[field].eq(fam).sum())
                sp, ep = sf / len(s), ef / len(e)
                ps += row.standardisation_weight * sp
                pe += row.standardisation_weight * ep
                detailed.append({"lag_days": -lag, "family": fam, "year": row.year, "month": row.month,
                                 "sample_count": sf, "sample_total": len(s), "event_count": ef, "event_total": len(e),
                                 "stratum_weight": row.standardisation_weight, "sample_proportion": sp, "event_proportion": ep})
            standardised.append({"lag_days": -lag, "family": fam,
                                 "standardised_sample_proportion": ps, "standardised_event_composition": pe,
                                 "standardised_event_to_sample_ratio": _safe_ratio(pe, ps),
                                 "standardised_difference_pp": 100 * (pe - ps),
                                 "retained_original_weight_mass": retained_mass,
                                 "included_month_year_strata": len(eligible)})
    pd.DataFrame(detailed).to_csv(out / "month_year_composition_detail.csv", index=False)
    pd.DataFrame(standardised).to_csv(out / "month_year_standardised_composition.csv", index=False)
    # Empirical persistence reference P(F_{D-k}|month_D,F_D), pooled over 13
    # years. Every event site-day receives the expectation for its own D cell.
    cells, persistence = [], []
    for lag in range(4):
        field = f"family_lag{lag}"
        lookup = {}
        for (month, current), group in weather.groupby(["month", "family_lag0"], observed=True):
            cell = {}
            for fam in FAMILIES:
                n = int(group[field].eq(fam).sum())
                p = n / len(group)
                cell[fam] = p
                cells.append({"lag_days": -lag, "sampling_day_month": int(month), "sampling_day_family": current,
                              "antecedent_family": fam, "historical_conditioning_days": len(group),
                              "historical_antecedent_days": n, "conditional_probability": p,
                              "cell_below_20_calendar_days": len(group) < 20})
            lookup[(int(month), current)] = cell
        for fam in FAMILIES:
            for population, frame in [("all_sampled_site_days", d), ("exceedance_site_days", events)]:
                expected = []
                min_support = np.inf
                for (month, current), block in frame.groupby(["month", "family_lag0"], observed=True):
                    key = (int(month), current)
                    if key not in lookup:
                        raise ValueError(f"No persistence conditioning cell for {key}")
                    expected.append(len(block) * lookup[key][fam])
                    support = int((weather.month.eq(month) & weather.family_lag0.eq(current)).sum())
                    min_support = min(min_support, support)
                exp_count = float(sum(expected))
                obs_count = int(frame[field].eq(fam).sum())
                persistence.append({"lag_days": -lag, "family": fam, "population": population,
                                    "observed_site_days": obs_count, "expected_site_days": exp_count,
                                    "population_site_days": len(frame),
                                    "observed_composition": obs_count / len(frame),
                                    "persistence_expected_composition": exp_count / len(frame),
                                    "observed_minus_expected_pp": 100 * (obs_count - exp_count) / len(frame),
                                    "observed_to_expected_ratio": _safe_ratio(obs_count, exp_count),
                                    "minimum_used_conditioning_days": int(min_support)})
    pd.DataFrame(cells).to_csv(out / "persistence_conditioning_cells.csv", index=False)
    pd.DataFrame(persistence).to_csv(out / "persistence_conditioned_composition.csv", index=False)
    audit = {
        "complete_lag_site_days": len(d), "exceedance_site_days": len(events),
        "historical_evaluation_dates": len(weather),
        "month_year_strata_total": len(strata), "month_year_strata_without_events": int((~strata.standardisation_eligible).sum()),
        "standardisation_original_weight_retained": retained_mass,
        "standardisation": "Both composition distributions standardised to eligible sampled-site-day month/year weights; strata without events excluded from both and weights renormalised, if any.",
        "persistence_conditioning": "P(antecedent family | sampling-day calendar month, sampling-day family), empirical historical May-September dates pooled across 2012-2024; April only provides preceding dates.",
        "persistence_population_weighting": "Average cell expectation over individual site-days in the stated population; dates with multiple sampled sites contribute once per sampled site-day.",
        "persistence_reference_limitation": "Descriptive empirical reference estimated from the same historical period; not a causal null, independent validation, or generator test.",
        "descriptive_inference": "No significance tests or confidence intervals attached to composition/enrichment tables.",
        "probability_direction": "Exceedance composition is P(family at lag | sampled exceedance); crude exceedance proportion, in a separate column, is P(exceedance | family at lag, sampled site-day).",
    }
    (out / "DESCRIPTIVE_DEFINITIONS.json").write_text(json.dumps(audit, indent=2), encoding="utf-8")
    return audit
