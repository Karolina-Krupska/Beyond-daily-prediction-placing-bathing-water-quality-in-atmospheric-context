"""Publication figures from saved authoritative result tables only.

No statistical models or confidence intervals are estimated here. Each plotted
table is exported beside its figure, and all graphic text remains editable in
the SVG/PDF exports. Run generate_figures(root) after the analysis completes.
"""
from pathlib import Path
import json
import re
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter, LogLocator

MM = 1 / 25.4
WIDTH = 180 * MM
COLORS = {"M1_full": "#0072B2", "M1_common": "#0072B2", "M2_common": "#D55E00",
          "DateBalanced_M1": "#009E73", "DateBalanced_M2": "#CC79A7"}
FAMILIES = ["Cyclonic Atlantic (frontal)", "Showery maritime / unsettled", "Convective extremes", "Settled anticyclonic quiet"]
SHORT = {FAMILIES[0]: "Cyclonic Atlantic", FAMILIES[1]: "Showery maritime", FAMILIES[2]: "Convective", FAMILIES[3]: "Settled"}


def _style():
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8.5,
        "axes.titlesize": 9, "axes.labelsize": 8.5, "xtick.labelsize": 8,
        "ytick.labelsize": 8.5, "legend.fontsize": 7.5,
        "pdf.fonttype": 42, "ps.fonttype": 42, "svg.fonttype": "none",
        "axes.spines.top": False, "axes.spines.right": False,
        "axes.linewidth": .7, "lines.linewidth": 1.3, "savefig.facecolor": "white"})


def _valid(v):
    return str(v).lower() in ("true", "1", "1.0")


def _stars(p):
    if pd.isna(p): return "not estimable"
    return "***" if p < .001 else "**" if p < .01 else "*" if p < .05 else "ns"


def _limits(rows):
    vals = []
    for c in ["rr", "ci_low", "ci_high"]:
        if c in rows:
            vals.extend(pd.to_numeric(rows[c], errors="coerce").dropna().tolist())
    vals = np.array([v for v in vals if np.isfinite(v) and v > 0] + [1.])
    lo, hi = np.log(vals.min()), np.log(vals.max())
    span = max(hi-lo, .2)
    return np.exp(lo - .12 * span), np.exp(hi + .12 * span)


def _axis(ax, xlim, ylabel=None):
    ax.set_xscale("log"); ax.set_xlim(xlim)
    if xlim[1]/xlim[0] < 1.6:
        span=xlim[1]-xlim[0]
        step=.02 if span < .12 else .05 if span < .3 else .1
        ticks=[round(v,4) for v in np.arange(np.ceil(xlim[0]/step)*step,xlim[1],step)]
        if len(ticks)>5:ticks=ticks[::2]
        if xlim[0]<1<xlim[1] and not any(np.isclose(1,v) for v in ticks):ticks.append(1.)
        ticks=sorted(ticks)
    else:
        ticks = sorted(set([1.] + [v for v in [.25, .5, .75, 1.25, 1.5, 2., 3., 4.] if xlim[0] < v < xlim[1]]))
    if len(ticks) < 3:
        ticks = sorted(set(ticks + [round(xlim[0] * 1.1, 2), round(xlim[1] / 1.1, 2)]))
    if len(ticks) > 4: ticks = [v for v in ticks if v != 1.25]
    if len(ticks) > 6: ticks = [v for v in ticks if v in [.25,.5,1,1.5,2,4]]
    ax.set_xticks(ticks); ax.set_xticklabels([f"{v:g}" for v in ticks])
    ax.minorticks_off(); ax.axvline(1, color="#6B6B6B", ls=(0,(3,3)), lw=.9, zorder=0)
    ax.grid(axis="x", color="#E3E6E8", lw=.6, zorder=-1)
    ax.spines["left"].set_visible(False); ax.tick_params(axis="y", length=0, pad=7)
    ax.set_xlabel("Relative association (log scale)")


def _point(ax, y, row, color, marker="o"):
    rr = float(row.rr)
    if not np.isfinite(rr) or rr <= 0: return
    valid = all(np.isfinite(float(row[c])) and float(row[c]) > 0 for c in ["ci_low", "ci_high"])
    if "covariance_valid" in row.index: valid = valid and _valid(row.covariance_valid)
    if valid:
        lo, hi = float(row.ci_low), float(row.ci_high)
        if lo > rr or hi < rr:
            # Percentile intervals need not bracket the original point estimate.
            ax.plot([lo,hi], [y,y], color=color, lw=1.5, solid_capstyle="butt", zorder=2)
            ax.plot(rr,y,marker=marker,ms=5,color=color,zorder=3)
        else:
            ax.errorbar(rr,y,xerr=[[rr-lo],[hi-rr]],fmt=marker,ms=5,color=color,
                        elinewidth=1.5,capsize=2,capthick=.9,zorder=3)
    else:
        ax.plot(rr,y,marker="x",ms=5,color=color,zorder=3)


def _export(fig, name, source, root, caption, metadata):
    out = root / "figures"; cap = root / "captions"
    out.mkdir(exist_ok=True,parents=True); cap.mkdir(exist_ok=True,parents=True)
    fig.canvas.draw()
    # Every text object must fit the canvas; this catches accidental clipping.
    renderer = fig.canvas.get_renderer(); box = fig.bbox
    clipped = []
    for t in fig.findobj(matplotlib.text.Text):
        if not t.get_visible() or not t.get_text(): continue
        b = t.get_window_extent(renderer)
        if b.width and b.height and (b.x0 < box.x0-1 or b.y0 < box.y0-1 or b.x1 > box.x1+1 or b.y1 > box.y1+1):
            clipped.append(t.get_text())
    if clipped: raise ValueError(f"Text outside figure canvas in {name}: {clipped}")
    for ext in ["pdf", "svg", "png"]:
        fig.savefig(out/f"{name}.{ext}", dpi=600, metadata={"Creator":"Antecedent circulation analysis"} if ext=="pdf" else None)
    source.to_csv(out/f"{name}_source.csv",index=False)
    (cap/f"{name}.txt").write_text(caption+"\n",encoding="utf-8")
    metadata.append({"figure":name,"width_mm":fig.get_figwidth()/MM,"height_mm":fig.get_figheight()/MM,
                     "png_dpi":600,"source_rows":len(source),"clipped_text":clipped,
                     "formats":["png","pdf","svg"],"caption":f"captions/{name}.txt"})
    plt.close(fig)


def main_figure(root, coef, boot, metadata):
    models=["M1_full","M1_common","M2_common"]
    a=coef[(coef.model.isin(models)) & (coef.term=="cyclonic_previous3")].copy()
    if set(a.model)!=set(models): raise ValueError("Missing primary coefficients for main figure")
    a=a.set_index("model").loc[models].reset_index(); a["interval_method"]="Site/date clustered Wald"
    b=boot[(boot.model.isin(models)) & (boot.term=="cyclonic_previous3")].copy()
    if set(b.model)!=set(models): raise ValueError("Missing whole-year intervals for main figure")
    b=b.set_index("model").loc[models].reset_index(); b["interval_method"]="Whole-year refit percentile"
    for i in range(3):
        if not np.isclose(a.iloc[i].rr,b.iloc[i].rr,rtol=1e-10,atol=1e-12):
            raise ValueError("Bootstrap point estimate differs from original model")
    fig,axes=plt.subplots(1,2,figsize=(WIDTH,83*MM),sharey=True)
    fig.subplots_adjust(left=.33,right=.98,bottom=.23,top=.72,wspace=.24)
    labels=["Without rainfall adjustment\nBroader cohort", "Without rainfall adjustment\nRainfall-complete cohort", "With rainfall adjustment\nRainfall-complete cohort"]
    limits=_limits(pd.concat([a,b],ignore_index=True)); yy=[2.7,1.35,0.]
    for k,(ax,dat,title) in enumerate(zip(axes,[a,b],["Site/date clustered intervals","Whole-year refit intervals"])):
        _axis(ax,limits); ax.set_ylim(-.65,3.35)
        for y,(_,row) in zip(yy,dat.iterrows()): _point(ax,y,row,COLORS[row.model])
        ax.set_yticks(yy); ax.set_yticklabels(labels if k==0 else [])
        ax.set_title(title,pad=14,loc="left",fontweight="normal")
        ax.text(-.12,1.15,chr(97+k),transform=ax.transAxes,fontweight="bold",fontsize=11)
    # Shared y-axis tick labels must not be overwritten on the right panel.
    axes[0].set_yticks(yy); axes[0].set_yticklabels(labels); axes[1].tick_params(labelleft=False)
    fig.text(.33,.965,"Antecedent Cyclonic exposure",fontsize=11,fontweight="bold",ha="left",va="top")
    fig.text(.33,.89,"Relative association per additional Cyclonic day in the previous three days",fontsize=8,ha="left")
    full=a[a.model=="M1_full"].iloc[0];common=a[a.model=="M1_common"].iloc[0]
    counts=(f"The broader cohort contains {int(full.n_cohort):,} eligible site-days at {int(full.n_sites_cohort)} sites; "
            f"its finite-intercept fit uses {int(full.n):,} site-days at {int(full.n_sites)} sites, with {int(full.n_events):,} exceedances. "
            f"The rainfall-complete cohort contains {int(common.n_cohort):,} eligible site-days; both finite-intercept fits use "
            f"{int(common.n):,} site-days at {int(common.n_sites)} sites, with {int(common.n_events):,} exceedances")
    caption=("Figure 1. Antecedent Cyclonic exposure and observed intestinal enterococci exceedance (≥63 CFU 100 mL⁻¹). "
      "Points are modified-Poisson relative associations per additional Cyclonic Atlantic day during D-3 to D-1. "
      "All models adjust for sampling-day weather family, site intercepts, month and year. The first row uses the broader eligible cohort; "
      "the second and third use identical rainfall-complete observations, with the third additionally adjusting for previous-three-day rainfall. "
      "Panel a shows pointwise 95% site/date-clustered Wald intervals. Panel b shows pointwise 95% percentile intervals from whole-year resampling with model refitting. "
      "The dashed reference is a relative association of one. The intervals describe distinct dependence treatments and are not multiplicity-adjusted. "
      "Only 13 observed years are available; site/date clustering does not guarantee control of adjacent-day shared-weather dependence, and year resampling relies on approximate exchangeability of years. "
      "All-zero-outcome sites are handled as a Poisson fixed-effect boundary and provide no slope information; fit diagnostics identify these explicitly. "
      +counts+". Associations are observational among sampled site-days and do not establish causation or operational forecast benefit.")
    _export(fig,"Figure_1_Antecedent_Cyclonic_association",pd.concat([a,b],ignore_index=True),root,caption,metadata)


def lag_figure(root,coef,metadata):
    allrows=coef[coef.model.isin(["Lag1","Lag2","Lag3"])].copy()
    allrows=allrows[allrows.apply(lambda r: r.term.startswith(f"family_lag{r.model[-1]}["),axis=1)]
    allrows["significance_symbol"]=allrows.p_holm.map(_stars)
    if len(allrows)!=9: raise ValueError(f"Expected nine supporting lag-family coefficients, found {len(allrows)}")
    fig,axes=plt.subplots(1,3,figsize=(WIDTH,79*MM),sharey=True)
    fig.subplots_adjust(left=.205,right=.96,bottom=.24,top=.70,wspace=.38)
    xlim=_limits(allrows)
    for lag,ax in enumerate(axes,1):
        dat=allrows[allrows.model==f"Lag{lag}"]
        _axis(ax,xlim); ax.set_xlabel("Relative association"); ax.set_ylim(-.6,2.65)
        for j,fam in enumerate(FAMILIES[:3]):
            hits=dat[dat.term.str.contains(fam,regex=False)]
            if len(hits)!=1: raise ValueError(f"Cannot resolve lag {lag}, family {fam}")
            row=hits.iloc[0]; y=2-j; _point(ax,y,row,["#0072B2","#009E73","#D55E00"][j])
            ax.text(1.025,y,_stars(row.p_holm),transform=ax.get_yaxis_transform(),va="center",fontsize=7)
        ax.set_yticks([2,1,0]); ax.set_yticklabels([SHORT[f] for f in FAMILIES[:3]])
        if lag>1: ax.tick_params(labelleft=False)
        ax.set_title(f"Day -{lag}",pad=13,loc="left")
        ax.text(-.15,1.15,chr(96+lag),transform=ax.transAxes,fontweight="bold",fontsize=11)
    fig.text(.205,.96,"Antecedent weather-family associations",fontsize=11,fontweight="bold",va="top")
    fig.text(.205,.875,"Reference: settled anticyclonic family at the corresponding lag",fontsize=8)
    caption=("Figure S1. Adjusted associations between preceding weather families and observed IE exceedance. "
      "Separate modified-Poisson models for days -1, -2 and -3 adjust for sampling-day family, site intercepts, month and year. "
      "Points and horizontal lines show relative associations and pointwise 95% site/date-clustered Wald intervals. "
      "Settled anticyclonic conditions at the corresponding lag are the reference, set to one by model parameterisation. "
      "Symbols use Holm-adjusted p-values across the nine supporting lag-family contrasts: * p<0.05, ** p<0.01, *** p<0.001; ns, not statistically significant. "
      "Pointwise intervals and adjusted tests answer different inferential questions. Invalid intervals, if present, are not drawn and are marked with a cross. "
      "These are supporting observational associations; persistence and antecedent rainfall can contribute to them.")
    _export(fig,"Figure_S1_Adjusted_lag_family_associations",allrows,root,caption,metadata)


def sensitivity_figure(root,coef,metadata):
    models=["M1_common","DateBalanced_M1","M2_common","DateBalanced_M2"]
    dat=coef[(coef.model.isin(models)) & (coef.term=="cyclonic_previous3")].copy()
    if set(dat.model)!=set(models): return
    dat=dat.set_index("model").loc[models].reset_index()
    fig,ax=plt.subplots(figsize=(WIDTH,78*MM));fig.subplots_adjust(left=.38,right=.96,bottom=.24,top=.78)
    _axis(ax,_limits(dat)); labels=["Site-day weighted, without rainfall", "Date balanced, without rainfall", "Site-day weighted, with rainfall", "Date balanced, with rainfall"]
    for y,(_,row) in zip([3,2,1,0],dat.iterrows()): _point(ax,y,row,COLORS[row.model])
    ax.set_yticks([3,2,1,0]);ax.set_yticklabels(labels);ax.set_ylim(-.6,3.6)
    fig.text(.38,.96,"Sensitivity to sampling-date balance",fontsize=11,fontweight="bold",va="top")
    fig.text(.38,.865,"Relative association per additional antecedent Cyclonic day",fontsize=8)
    caption=("Figure S3. Sensitivity of the antecedent Cyclonic association to unequal sampling across dates. "
      "All fits use the same rainfall-complete site-days and adjust for sampling-day family, site intercepts, month and year. "
      "Date-balanced fits weight each site-day inversely by the number of eligible sites sampled on that date; consequently they give dates equal total weight "
      "and estimate a different sampled-population association. This does not make the monitoring design random. "
      "Points and lines show relative associations per additional Cyclonic day in D-3 to D-1 and pointwise 95% site/date-clustered intervals. "
      "No new significance tests are assigned to differences between these estimates.")
    _export(fig,"Figure_S3_Sampling_balance_sensitivity",dat,root,caption,metadata)


def categorical_figure(root,coef,metadata):
    dat=coef[coef.term.str.startswith("Cyclonic_count[")].copy()
    if dat.empty:return
    dat["count"]=dat.term.str.extract(r"\[(\d+)\]").astype(int)
    dat=dat.sort_values("count")
    if len(dat)>3:
        if "Categorical" in set(dat.model):dat=dat[dat.model=="Categorical"]
        else:return
    fig,ax=plt.subplots(figsize=(WIDTH,75*MM));fig.subplots_adjust(left=.31,right=.96,bottom=.24,top=.77)
    _axis(ax,_limits(dat)); ax.set_ylim(-.6,2.6)
    for _,r in dat.iterrows():_point(ax,3-r["count"],r,"#0072B2")
    ax.set_yticks([2,1,0]);ax.set_yticklabels(["1 Cyclonic day","2 Cyclonic days","3 Cyclonic days"])
    fig.text(.31,.96,"Exposure-form sensitivity",fontsize=11,fontweight="bold",va="top")
    fig.text(.31,.86,"Reference: no Cyclonic days in D-3 to D-1",fontsize=8)
    caption=("Figure S4. Categorical antecedent Cyclonic exposure. Relative associations compare one, two and three Cyclonic Atlantic days "
      "during D-3 to D-1 with zero such days. The model adjusts for sampling-day family, site intercepts, month and year "
      "on the broader eligible cohort, without antecedent-rainfall adjustment. Points and lines show estimates and pointwise 95% site/date-clustered Wald intervals. "
      "This prespecified sensitivity examines the primary log-linear count assumption; a count does not distinguish consecutive runs or order. "
      "Supporting exposure counts are provided in the analysis tables. No significance stars are assigned to individual count categories.")
    _export(fig,"Figure_S4_Categorical_exposure",dat,root,caption,metadata)


def composition_figure(root,metadata):
    dat=pd.read_csv(root/"results/descriptive/composition_backgrounds.csv")
    per=pd.read_csv(root/"results/descriptive/persistence_conditioned_composition.csv")
    per=per[per.population=="exceedance_site_days"]
    dat=dat[dat.lag_days.isin([-1,-2,-3])].merge(
        per[["lag_days","family","persistence_expected_composition","expected_site_days","minimum_used_conditioning_days"]],
        on=["lag_days","family"],validate="one_to_one")
    rows=[]
    for _,r in dat.iterrows():
        for series,col,num,den in [
            ("All sampled site-days","sample_background_proportion","sampled_site_days_family","sampled_site_days_total"),
            ("Exceedance site-days","exceedance_composition_proportion","exceedance_site_days_family","exceedance_site_days_total"),
            ("Persistence expectation","persistence_expected_composition","expected_site_days","exceedance_site_days_total")]:
            rows.append({"lag_days":r.lag_days,"family":r.family,"series":series,"proportion":r[col],
                         "numerator_or_expected_count":r[num],"denominator":r[den],
                         "minimum_used_conditioning_days":r.minimum_used_conditioning_days})
    source=pd.DataFrame(rows)
    fig,axes=plt.subplots(1,3,figsize=(WIDTH,88*MM),sharey=True)
    fig.subplots_adjust(left=.205,right=.95,bottom=.31,top=.70,wspace=.25)
    series=[("All sampled site-days","#7A8288","s",-.20),
            ("Exceedance site-days","#0072B2","o",0),
            ("Persistence expectation","#D55E00","D",.20)]
    handles=[]
    xmax=max(.5,np.ceil(source.proportion.max()*10)/10+.05)
    for lag,ax in enumerate(axes,1):
        for name,color,marker,offset in series:
            sub=source[(source.lag_days==-lag)&(source.series==name)].set_index("family").loc[FAMILIES]
            h=ax.scatter(sub.proportion*100,np.arange(4)[::-1]+offset,s=20,color=color,marker=marker,label=name,zorder=3)
            if lag==1:handles.append(h)
        ax.set_xlim(0,xmax*100);ax.set_xticks(np.arange(0,xmax*100+1e-6,20));ax.set_ylim(-.5,3.5)
        ax.set_yticks([3,2,1,0]);ax.set_yticklabels([SHORT[f] for f in FAMILIES])
        if lag>1:ax.tick_params(labelleft=False)
        ax.tick_params(axis="y",length=0,pad=7);ax.spines["left"].set_visible(False)
        ax.grid(axis="x",color="#E3E6E8",lw=.6);ax.set_axisbelow(True)
        ax.set_xlabel("Composition (%)")
        ax.set_title(f"Day -{lag}",pad=13,loc="left")
        ax.text(-.15,1.15,chr(96+lag),transform=ax.transAxes,fontweight="bold",fontsize=11)
    fig.text(.205,.96,"Antecedent family composition",fontsize=11,fontweight="bold",va="top")
    fig.text(.205,.87,"Observed composition and the circulation-persistence benchmark",fontsize=8)
    fig.legend(handles,[s[0] for s in series],loc="lower center",bbox_to_anchor=(.56,.04),ncol=3,
               frameon=False,columnspacing=1.4,handletextpad=.5)
    caption=("Figure S2. Weather-family composition on the three days preceding sampled site-days. "
      "Grey squares describe all sampled site-days; blue circles describe site-days with observed IE ≥63 CFU 100 mL⁻¹. "
      "Orange diamonds show the antecedent-family composition expected by averaging empirical historical-calendar probabilities "
      "conditional on the month and sampling-day family of each exceedance site-day. The same exceedance-site-day weighting is retained in the expected composition. "
      "These are proportions of antecedent families, P(family at D-k | sampled population), not exceedance probabilities given a family. "
      "No confidence intervals or significance tests are implied by this descriptive display. The persistence expectation is an empirical benchmark and does not establish a causal null model. "
      "Conditioning-cell support, denominators, calendar climatology and month/year-standardised summaries are provided in the accompanying tables.")
    _export(fig,"Figure_S2_Antecedent_composition",source,root,caption,metadata)


def generate_figures(root):
    root=Path(root);_style(); metadata=[]
    coef=pd.read_csv(root/"results/coefficients.csv")
    boot=pd.read_csv(root/"results/year_bootstrap_intervals.csv")
    main_figure(root,coef,boot,metadata)
    lag_figure(root,coef,metadata)
    sensitivity_figure(root,coef,metadata)
    categorical_figure(root,coef,metadata)
    # Descriptive plot is generated below when descriptive tables are available.
    if (root/"results/descriptive/composition_backgrounds.csv").exists():
        composition_figure(root,metadata)
    (root/"figures/figure_metadata.json").write_text(json.dumps(metadata,indent=2))
    from combined_figure import generate_combined
    generate_combined(root)
    return metadata


def verify_figure_exports(root):
    """Numerically reconcile plotted source tables and inspect export properties."""
    from PIL import Image
    import xml.etree.ElementTree as ET
    root=Path(root);out=root/"figures"; checks=[]
    coef=pd.read_csv(root/"results/coefficients.csv").set_index(["model","term"])
    boot=pd.read_csv(root/"results/year_bootstrap_intervals.csv").set_index(["model","term"])
    meta=json.loads((out/"figure_metadata.json").read_text())
    for record in meta:
        name=record["figure"];source=pd.read_csv(out/f"{name}_source.csv")
        count=0
        if "model" in source:
            for _,r in source.iterrows():
                reference=boot if r.get("interval_method","")=="Whole-year refit percentile" else coef
                ref=reference.loc[(r.model,r.term)]
                for c in ["rr","ci_low","ci_high"]:
                    if not np.isclose(r[c],ref[c],rtol=1e-12,atol=1e-14,equal_nan=True):
                        raise AssertionError(f"Plotted {name} {r.model} {r.term} {c} differs from result table")
                    count+=1
                if "significance_symbol" in source and r.significance_symbol!=_stars(ref.p_holm):
                    raise AssertionError(f"Significance symbol mismatch in {name}")
        elif "proportion" in source:
            expected=source.numerator_or_expected_count/source.denominator
            if not np.allclose(source.proportion,expected,rtol=1e-12,atol=1e-14):
                raise AssertionError("Composition markers differ from their numerators/denominators")
            count+=len(source)
        with Image.open(out/f"{name}.png") as im:
            expected_width=record["width_mm"]/25.4*600
            expected_height=record["height_mm"]/25.4*600
            if abs(im.width-expected_width)>1 or abs(im.height-expected_height)>1:
                raise AssertionError(f"PNG intended dimensions differ for {name}")
            if any(abs(d-600)>.1 for d in im.info.get("dpi",[0,0])):
                raise AssertionError(f"PNG DPI metadata differs for {name}")
        svg=ET.parse(out/f"{name}.svg")
        if not svg.findall(".//{http://www.w3.org/2000/svg}text"):
            raise AssertionError(f"SVG has no editable text: {name}")
        if not (out/f"{name}.pdf").read_bytes().startswith(b"%PDF-"):
            raise AssertionError(f"Invalid PDF header: {name}")
        checks.append({"figure":name,"source_values_reconciled":count,"png_dimensions_and_dpi":"passed",
                       "editable_svg_text":"passed","pdf_header":"passed","clipped_text":record["clipped_text"]})
    result={"status":"passed","figures":len(checks),"checks":checks,
            "scope":"Source-table reconciliation and export properties; PDF renders are separately visually inspected."}
    (root/"reports/FIGURE_EXPORT_VERIFICATION.json").write_text(json.dumps(result,indent=2))
    return result


if __name__=="__main__":
    generate_figures(Path(__file__).resolve().parents[1])
