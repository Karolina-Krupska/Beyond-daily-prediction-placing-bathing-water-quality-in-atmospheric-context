"""Rebuild the approved observed site-day cohort without fitting predictive models.

The deterministic outcome and aggregation rules reproduce selected Step 5's
prepare.py, retained unchanged under inputs/step5 as a reference.  No name-based
eligibility filter, rainfall availability filter or outcome imputation is added.
"""
from pathlib import Path
import hashlib
import json
import re
import numpy as np
import pandas as pd

IE_COLUMN = '3723 IE Conf (CFU/0_1l)'


def classify(value, threshold=63):
    """Preserve Step 5 censoring rules; an indeterminate outcome remains missing."""
    if pd.isna(value):
        return np.nan, 'missing'
    s = str(value).strip().replace(',', '')
    match = re.fullmatch(r'(<=|>=|<|>|≤|≥)?\s*([0-9]+(?:\.[0-9]+)?)', s)
    if not match:
        return np.nan, 'uninterpretable'
    qualifier, number = match.groups()
    x = float(number)
    if qualifier in ['<', '≤', '<=']:
        if x < threshold or (qualifier == '<' and x == threshold):
            return 0., 'left_censored_classifiable'
        return np.nan, 'threshold_indeterminate'
    if qualifier in ['>', '≥', '>=']:
        if x >= threshold:
            return 1., 'right_censored_classifiable'
        return np.nan, 'threshold_indeterminate'
    return float(x >= threshold), 'numeric'


def _csv(frame, path):
    frame.to_csv(path, index=False)


def rebuild(root):
    """Return the canonical site-day frame and write auditable reconciliation files.

    API: rebuild(Path(package_root)) -> pandas.DataFrame.  The returned outcome
    frame contains every approved evaluable site-day; it is not restricted to
    sites informative for a subsequent fixed-effect model.
    """
    root = Path(root)
    inputs = root / 'inputs' / 'step5'
    out = root / 'results' / 'audit'
    out.mkdir(parents=True, exist_ok=True)
    (root / 'data').mkdir(parents=True, exist_ok=True)
    book = inputs / 'bathing_water_records_2012_2024.xlsx'
    sheets = pd.read_excel(book, sheet_name=None)
    d, register = sheets['Records'].copy(), sheets['Site_register'].copy()
    required = ['site_id', 'Date', IE_COLUMN, 'lat', 'lon',
                'SMPT_USER_REFERENCE', 'SMPT_SHORT_NAME', 'SAMP_LAB_REF_NO',
                'SAMP_PURPOSE_CODE', 'coordinate_basis', 'coordinate_source']
    missing = set(required) - set(d)
    if missing:
        raise ValueError(f'Missing authoritative columns: {sorted(missing)}')
    if d.site_id.isna().any() or register.site_id.isna().any():
        raise ValueError('Missing site identifier in authoritative workbook')
    d['site_id'] = d.site_id.astype(str)
    allowed = set(register.site_id.astype(str))
    if not set(d.site_id).issubset(allowed):
        raise ValueError('Records contain sites absent from approved register')
    if not pd.api.types.is_datetime64_any_dtype(d.Date):
        raise ValueError('Workbook dates must be typed dates; do not guess a day/month format')
    d['date'] = d.Date.dt.normalize()
    if d.date.isna().any():
        raise ValueError('Missing sampling date')
    if d[['lat', 'lon']].isna().any().any():
        raise ValueError('Missing coordinates in approved workbook')
    if not (d.lat.between(49, 52) & d.lon.between(-6, -2)).all():
        raise ValueError('Approved workbook contains out-of-domain records')
    d['source_record_id'] = np.arange(len(d)) + 2
    # Repeated laboratory identifiers require a source decision; distinct valid
    # samples on one site-day are handled by the approved aggregation below.
    duplicate = d.duplicated(['site_id', 'date', 'SAMP_LAB_REF_NO'], keep=False)
    duplicate &= d.SAMP_LAB_REF_NO.notna()
    _csv(d.loc[duplicate], out / 'repeated_site_date_lab.csv')
    if duplicate.any():
        raise ValueError('Repeated site/date/laboratory identifiers require resolution')
    parsed = d[IE_COLUMN].map(classify)
    d['outcome_record'] = [p[0] for p in parsed]
    d['outcome_status'] = [p[1] for p in parsed]
    alias_cols = ['site_id', 'SMPT_USER_REFERENCE', 'SMPT_SHORT_NAME', 'lat',
                  'lon', 'coordinate_basis', 'coordinate_source']
    aliases = d[alias_cols].drop_duplicates()
    _csv(aliases, out / 'site_alias_coordinates.csv')
    variation = d.groupby('site_id')[['lat', 'lon']].nunique().reset_index()
    variation = variation.loc[variation.lat.gt(1) | variation.lon.gt(1)]
    _csv(variation, out / 'sites_with_coordinate_variation.csv')
    # Approved source coordinates are preserved; differing alias coordinates do
    # not trigger name-based exclusions or an invented replacement coordinate.
    _csv(register, out / 'approved_site_register.csv')
    for sheet in ['Excluded_records', 'Selection_notes']:
        if sheet in sheets:
            _csv(sheets[sheet], out / f'approved_{sheet.lower()}.csv')
    _csv(d.groupby('outcome_status', dropna=False).size().rename('records').reset_index(),
         out / 'outcome_qualifier_summary_all_records.csv')
    season = d.date.dt.year.between(2012, 2024) & d.date.dt.month.between(5, 9)
    _csv(d.loc[~season], out / 'outside_season.csv')
    raw_rows = len(d)
    d = d.loc[season].copy()
    _csv(d.loc[d.outcome_record.isna()], out / 'unevaluable_IE_records.csv')
    d.to_csv(out / 'in_season_records_with_qualifiers.csv.gz', index=False)
    g = d.groupby(['site_id', 'date'], sort=True).agg(
        y_exceed=('outcome_record', 'max'),
        n_records=('source_record_id', 'size'),
        n_evaluable=('outcome_record', 'count'),
        any_routine=('SAMP_PURPOSE_CODE', lambda x: x.eq('MS').any())
    ).reset_index()
    _csv(g.loc[g.n_records.gt(1)], out / 'multiple_record_site_days.csv')
    _csv(g.loc[g.n_evaluable.eq(0)], out / 'site_days_without_evaluable_IE.csv')
    all_missing = int(g.n_evaluable.eq(0).sum())
    g = g.loc[g.n_evaluable.gt(0)].copy()
    g['y_exceed'] = g.y_exceed.astype(int)
    g['year'], g['month'] = g.date.dt.year, g.date.dt.month
    g = g.sort_values(['date', 'site_id']).reset_index(drop=True)
    g['row_id'] = np.arange(len(g))
    if g.duplicated(['site_id', 'date']).any() or not g.y_exceed.isin([0, 1]).all():
        raise AssertionError('Invalid rebuilt site-day keys or outcomes')
    canonical = pd.read_csv(inputs / 'current_modelling_dataset_REFERENCE.csv',
                            dtype={'site_id': str})
    canonical['date'] = pd.to_datetime(canonical.date, format='%Y-%m-%d', errors='raise')
    cols = list(g)
    pd.testing.assert_frame_equal(g[cols], canonical[cols], check_dtype=False,
                                  check_exact=True)
    reference = pd.read_csv(inputs / 'previous_site_day_REFERENCE.csv', dtype={'site_id': str})
    reference['Date'] = pd.to_datetime(reference.Date, format='%Y-%m-%d', errors='raise')
    chk = g[['site_id', 'date', 'y_exceed']].merge(
        reference[['site_id', 'Date', 'exceedance']], left_on=['site_id', 'date'],
        right_on=['site_id', 'Date'], how='outer', validate='one_to_one', indicator=True)
    if not chk._merge.eq('both').all() or not chk.y_exceed.eq(chk.exceedance).all():
        raise AssertionError('Rebuilt cohort disagrees with corrected source outcomes')
    annual = g.groupby('year').agg(site_days=('y_exceed', 'size'),
        exceedances=('y_exceed', 'sum'), sites=('site_id', 'nunique'),
        sampling_dates=('date', 'nunique')).reset_index()
    annual['exceedance_fraction'] = annual.exceedances / annual.site_days
    _csv(annual, out / 'annual_cohort.csv')
    site = g.groupby('site_id').agg(site_days=('y_exceed', 'size'),
        exceedances=('y_exceed', 'sum')).reset_index()
    site['zero_exceedance_site'] = site.exceedances.eq(0)
    site['all_exceedance_site'] = site.exceedances.eq(site.site_days)
    site['fewer_than_five_exceedances'] = site.exceedances.lt(5)
    _csv(site, out / 'site_outcome_support.csv')
    _csv(d.groupby('SAMP_PURPOSE_CODE', dropna=False).agg(records=('source_record_id', 'size'),
        evaluable_records=('outcome_record', 'count'), exceedance_records=('outcome_record', 'sum')
        ).reset_index(), out / 'sampling_purpose_summary.csv')
    estuary = aliases.loc[aliases.SMPT_SHORT_NAME.str.contains('estuary', case=False, na=False)]
    estuary = estuary.merge(site, on='site_id', how='left', validate='many_to_one')
    _csv(estuary, out / 'approved_estuarine_sites_retained.csv')
    summary = dict(workbook_rows=raw_rows, in_season_records=len(d),
        evaluable_records=int(d.outcome_record.notna().sum()),
        unevaluable_records=int(d.outcome_record.isna().sum()),
        evaluable_site_days=len(g), sites=int(g.site_id.nunique()),
        exceedance_site_days=int(g.y_exceed.sum()), sampling_dates=int(g.date.nunique()),
        all_outcome_missing_site_days=all_missing,
        partial_missing_evaluable_site_days=int(g.n_evaluable.lt(g.n_records).sum()),
        repeated_site_date_lab_records=int(duplicate.sum()),
        zero_exceedance_sites=int(site.zero_exceedance_site.sum()),
        zero_exceedance_site_days=int(site.loc[site.zero_exceedance_site, 'site_days'].sum()),
        all_exceedance_sites=int(site.all_exceedance_site.sum()),
        sites_with_coordinate_variation=len(variation))
    (out / 'cohort_summary.json').write_text(json.dumps(summary, indent=2))
    _csv(pd.DataFrame([{'stage': k, 'count': v} for k, v in summary.items()]),
         out / 'observation_flow.csv')
    (out / 'outcome_reconciliation.json').write_text(json.dumps({
        'current_step5_cohort_exact_match': True,
        'corrected_association_reference_exact_match': True,
        'compared_fields': cols, 'rows_compared': len(g),
        'aggregation': 'Maximum classifiable binary outcome per site-day; any valid exceedance counts as one.',
        'partial_missing_rule': 'Retain site-day with at least one classifiable result; flag missing companion records.',
        'all_missing_rule': 'Exclude site-day with no classifiable result; never set outcome to zero.',
        'workbook_sha256': hashlib.sha256(book.read_bytes()).hexdigest()
    }, indent=2))
    _csv(g, root / 'data' / 'observational_site_days.csv')
    return g


if __name__ == '__main__':
    result = rebuild(Path(__file__).resolve().parents[1])
    print(f'Rebuilt and exactly reconciled {len(result):,} observed site-days.')
