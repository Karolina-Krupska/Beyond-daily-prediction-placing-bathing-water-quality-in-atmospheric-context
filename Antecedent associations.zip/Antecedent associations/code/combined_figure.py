"""Combine verified descriptive heatmaps and matched rainfall-adjustment results.
No fitting, resampling or replacement observations are performed here.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize,TwoSlopeNorm
from matplotlib.ticker import PercentFormatter


def generate_combined(root):
    root=Path(root); R=root/"figures"
    
    families=['Cyclonic Atlantic (frontal)','Showery maritime / unsettled','Convective extremes','Settled anticyclonic quiet']
    labels=['Cyclonic Atlantic\n(frontal)','Showery maritime /\nunsettled','Convective\nextremes','Settled anticyclonic\nquiet']
    lags=[0,-1,-2,-3]
    a=pd.read_csv(root/'results/descriptive/composition_backgrounds.csv');b=pd.read_csv(root/'results/descriptive/month_year_standardised_composition.csv')
    d=pd.read_csv(root/'results/year_bootstrap_intervals.csv').set_index('model').loc[['M1_common','M2_common']]
    def matrix(frame,c):return frame.pivot(index='lag_days',columns='family',values=c).reindex(index=lags,columns=families).to_numpy()
    A=matrix(a,'exceedance_composition_proportion');B=matrix(b,'standardised_event_to_sample_ratio')
    assert np.allclose(A.sum(axis=1),1) and (B>.6).all() and (B<1.4).all()
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8.5,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none'})
    fig=plt.figure(figsize=(180/25.4,225/25.4))
    axes=[]
    for i,(values,bottom,cmap,norm,title,barlabel,fmt) in enumerate([
     (A,.735,'cividis',Normalize(0,.60),'Descriptive: circulation around exceedance observations',
      'Share of exceedance observations',lambda x:f'{x:.1%}'),
     (B,.425,'RdBu_r',TwoSlopeNorm(vmin=.60,vcenter=1,vmax=1.40),
      'Descriptive: enrichment relative to sampling background\n(month- and year-standardised)',
      'Standardised composition ratio',lambda x:f'{x:.2f}×')]):
     ax=fig.add_axes([.17,bottom,.66,.175]);cx=fig.add_axes([.855,bottom,.018,.175]);axes.append(ax)
     im=ax.imshow(values,cmap=cmap,norm=norm,aspect='auto')
     ax.set_xticks(range(4),labels);ax.set_yticks(range(4),['Lag 0','Lag −1','Lag −2','Lag −3'])
     ax.tick_params(axis='both',length=0,pad=7,labelsize=8)
     ax.set_title(title,loc='left',fontsize=9.2,pad=17)
     ax.text(-.17,1.18,chr(97+i),transform=ax.transAxes,fontsize=12,weight='bold',va='bottom')
     ax.set_xticks(np.arange(-.5,4,1),minor=True);ax.set_yticks(np.arange(-.5,4,1),minor=True)
     ax.grid(which='minor',color='white',lw=.7);ax.tick_params(which='minor',length=0)
     for spine in ax.spines.values():spine.set_visible(False)
     for y in range(4):
      for x in range(4):
       luminance=np.dot(im.cmap(im.norm(values[y,x]))[:3],[.2126,.7152,.0722])
       ax.text(x,y,fmt(values[y,x]),ha='center',va='center',fontsize=9,
        color='white' if luminance<.47 else '#14212B')
     cb=fig.colorbar(im,cax=cx);cb.outline.set_visible(False);cb.ax.tick_params(labelsize=7.5,length=2)
     cb.set_label(barlabel,fontsize=8,labelpad=8)
     if i==0:cb.formatter=PercentFormatter(1,decimals=0);cb.set_ticks([0,.15,.30,.45,.60]);cb.update_ticks()
     else:cb.set_ticks([.6,.8,1,1.2,1.4])
    
    ax=fig.add_axes([.17,.115,.66,.175]);axes.append(ax)
    ax.text(-.17,1.18,'c',transform=ax.transAxes,fontsize=12,weight='bold',va='bottom')
    ax.set_title('Adjusted analysis: antecedent Cyclonic exposure',loc='left',fontsize=9.2,pad=17)
    p=(d.rr.to_numpy()-1)*100;lo=(d.ci_low.to_numpy()-1)*100;hi=(d.ci_high.to_numpy()-1)*100
    colours=['#0072B2','#D55E00']
    ax.bar([0,1],p,color=colours,width=.46,zorder=3)
    ax.errorbar([0,1],p,yerr=[p-lo,hi-p],fmt='none',ecolor='#243746',capsize=4,lw=1.3,zorder=4)
    for i in [0,1]:ax.text(i,hi[i]+1.1,f'{p[i]:+.1f}%',ha='center',fontsize=10,weight='bold',color=colours[i])
    ax.set_xticks([0,1],['Before antecedent-rainfall\nadjustment','After antecedent-rainfall\nadjustment'])
    ax.tick_params(axis='x',length=0,pad=7,labelsize=8)
    ax.set_ylim(-5,26);ax.set_xlim(-.65,1.65);ax.set_yticks([0,10,20]);ax.set_ylabel('Relative change (%)',fontsize=8.5)
    ax.axhline(0,color='#64717A',lw=.9);ax.grid(axis='y',color='#E5E9EC',zorder=0);ax.set_axisbelow(True)
    for spine in ['top','right']:ax.spines[spine].set_visible(False)
    fig.text(.17,.032,'Panel c: per additional Cyclonic day in the preceding three days; same observations.',fontsize=7.6,color='#55616C')
    fig.text(.17,.013,'Whiskers: 95% whole-year refit intervals. Relative changes are not percentage-point changes.',fontsize=7.6,color='#55616C')
    stem='Figure_Combined_Circulation_and_Rainfall'
    for ext in ['png','pdf','svg']:fig.savefig(R/f'{stem}.{ext}',dpi=600,facecolor='white')
    plt.close(fig)
    a.merge(b,on=['lag_days','family'],validate='one_to_one').to_csv(R/'Figure_Combined_Circulation_and_Rainfall_heatmap_source.csv',index=False)
    pd.DataFrame({'model':d.index,'rr':d.rr,'ci_low':d.ci_low,'ci_high':d.ci_high,
     'change_percent':p,'ci_low_percent':lo,'ci_high_percent':hi}).to_csv(R/'Figure_Combined_Circulation_and_Rainfall_association_source.csv',index=False)
    (root/'captions/Figure_Combined_Circulation_and_Rainfall.txt').write_text('''Circulation around observed exceedances and the antecedent association after rainfall adjustment, May–September 2012–2024.
    (a) Family composition among 3,727 sampled site-day intestinal-enterococci exceedances (≥63 CFU 100 mL−1) at lag 0 and the preceding three calendar days. Rows sum to 100% before rounding. Composition represents P(family at lag | sampled exceedance), not P(exceedance | family).
    (b) Ratio of month/year-standardised exceedance composition to standardised sampling-opportunity composition. Both use common weights derived from 35,518 eligible sampled site-days in 63 observed month/year strata. 1 denotes equal representation; greater/less than 1 denotes over-/under-representation. These are descriptive ratios, without site or rainfall adjustment, and colours do not indicate significance. The standardised ratios are not calculated directly from raw panel a percentages.
    (c) Model-implied relative percentage change per additional Cyclonic Atlantic day in D−3..D−1, using matched rainfall-complete observations. Both modified-Poisson models include site intercepts, sampling-day family, month and year; the orange model additionally includes rainfall accumulated during D−3..D−1. Whiskers show pointwise95% percentile intervals from 2,000 paired whole-year bootstrap bundles with model refitting. These correspond to relative associations 1.139 (1.073–1.211) before and 1.033 (0.976–1.099) after rainfall adjustment. The eligible rainfall-complete cohort comprises 34,139 site-days at 194 sites; slope estimation uses 33,418 site-days, 3,592 exceedances and 186 informative sites. Eight zero-event sites remain in the observational audit and descriptive sampling background but provide no slope information to the site-fixed-effect models.
    Panels a/b describe over-representation; panel c tests a different, adjusted association. A confidence interval including no association does not establish that the true effect is zero. The figure does not demonstrate causation, mediation, calibrated absolute probabilities or operational warning improvement. Modified-Poisson fitted means above one are documented in the full analysis limitations. This figure uses existing verified tables; no models were refitted for this export.
    ''')
    return verify_combined(root)

def verify_combined(root):
    from PIL import Image
    root=Path(root);R=root/'figures'
    h=pd.read_csv(R/'Figure_Combined_Circulation_and_Rainfall_heatmap_source.csv')
    c=pd.read_csv(R/'Figure_Combined_Circulation_and_Rainfall_association_source.csv')
    a=pd.read_csv(root/'results/descriptive/composition_backgrounds.csv')
    b=pd.read_csv(root/'results/descriptive/month_year_standardised_composition.csv')
    expected=a.merge(b,on=['lag_days','family'],validate='one_to_one')
    pd.testing.assert_frame_equal(h,expected,check_exact=False,rtol=1e-12,atol=1e-14)
    ref=pd.read_csv(root/'results/year_bootstrap_intervals.csv').set_index('model')
    assert len(c)==2
    for row in c.itertuples():
        d=ref.loc[row.model]
        assert np.allclose([row.change_percent,row.ci_low_percent,row.ci_high_percent],[(d.rr-1)*100,(d.ci_low-1)*100,(d.ci_high-1)*100])
    with Image.open(R/'Figure_Combined_Circulation_and_Rainfall.png') as im:
        assert all(abs(v-600)<.1 for v in im.info['dpi'])
    assert '<text' in (R/'Figure_Combined_Circulation_and_Rainfall.svg').read_text()
    assert (R/'Figure_Combined_Circulation_and_Rainfall.pdf').read_bytes().startswith(b'%PDF-')
    report={'status':'passed','heatmap_cells':32,'association_values':6,'new_model_fits':0,'source':'current resulttables','formats':['600dpiPNG','editablePDF','editableSVG']}
    (root/'reports/COMBINED_FIGURE_VERIFICATION.json').write_text(json.dumps(report,indent=2))
    return report
