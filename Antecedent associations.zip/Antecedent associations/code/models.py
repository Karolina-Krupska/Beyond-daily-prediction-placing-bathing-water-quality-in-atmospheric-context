"""Site-fixed-effect modified Poisson models, profiled exactly over site intercepts.

The profile fit and two-way covariance are benchmarked against statsmodels GLM
with explicit site dummies. No covariance diagonal is clipped or repaired.
"""
from dataclasses import dataclass
import json
import time
import numpy as np
import pandas as pd
from scipy import linalg, stats

FAMILIES = ['Cyclonic Atlantic (frontal)', 'Showery maritime / unsettled',
            'Convective extremes', 'Settled anticyclonic quiet']

@dataclass
class Fit:
    beta: np.ndarray
    names: list
    cov: object
    mu: np.ndarray
    X: np.ndarray
    y: np.ndarray
    weights: np.ndarray
    site: np.ndarray
    date: np.ndarray
    sites: list
    alpha: np.ndarray
    hessian: np.ndarray
    scores: object
    metadata: dict

def design(d, mode='M1', lag=None):
    """Explicit treatment coding; settled family, earliest year/month are references."""
    a = {}; refs = {}
    for col in ['year', 'month']:
        values = sorted(d[col].unique()); refs[col] = str(values[0])
        for value in values[1:]: a[f'{col}[{value}]'] = (d[col].to_numpy() == value).astype(float)
    for col in ['family_lag0'] + ([f'family_lag{lag}'] if lag else []):
        if not d[col].isin(FAMILIES).all(): raise ValueError('Unknown or absent family: '+col)
        refs[col] = FAMILIES[-1]
        for value in FAMILIES[:-1]: a[f'{col}[{value}]'] = (d[col].to_numpy()==value).astype(float)
    if mode in ['M1','M2']: a['cyclonic_previous3'] = d.cyclonic_previous3.to_numpy(float)
    if mode == 'Categorical':
        for k in [1,2,3]: a[f'Cyclonic_count[{k}]'] = (d.cyclonic_previous3.to_numpy()==k).astype(float)
    if mode == 'M2':
        a['rain_previous3_per10mm'] = d.rain_previous3_mm.to_numpy(float)/10.
    return np.column_stack(list(a.values())), list(a), refs

def _group_sum(a, g, ng):
    out = np.zeros((ng,)+a.shape[1:]); np.add.at(out,g,a); return out

def fit_poisson(d, mode='M1', lag=None, weights=None, covariance=True, start=None):
    """Profile Poisson FE via damped Newton iterations; case weights are explicit.

    No-event sites have intercept -infinity in the limiting FE fit and no slope
    information. They are retained in cohort audits, removed from slope fitting,
    and reported. Year bootstrap frequency weights are handled by the same API.
    """
    tic=time.perf_counter(); d=d.copy().reset_index(drop=True)
    w=np.ones(len(d)) if weights is None else np.asarray(weights,float)
    if len(w)!=len(d) or np.any(~np.isfinite(w)) or np.any(w<0): raise ValueError('Invalid weights')
    keep=w>0; d=d.loc[keep].reset_index(drop=True); w=w[keep]
    if not np.isin(d.y_exceed.to_numpy(),[0,1]).all():
        raise ValueError('Missing or invalid outcome; never convert to zero or a boundary site')
    if d[['site_id','date']].isna().any().any(): raise ValueError('Missing model identifier/date')
    initial_n=len(d); initial_sites=d.site_id.nunique()
    totals=d.assign(wy=w*d.y_exceed.to_numpy()).groupby('site_id').wy.sum()
    zero_sites=totals.index[totals.eq(0)].tolist(); informative=~d.site_id.isin(zero_sites).to_numpy()
    boundary_n=int((~informative).sum()); d=d.loc[informative].reset_index(drop=True); w=w[informative]
    if not len(d): raise ValueError('No slope-informative sites')
    X,names,refs=design(d,mode,lag); y=d.y_exceed.to_numpy(float)
    if not np.isin(y,[0,1]).all() or not np.isfinite(X).all(): raise ValueError('Invalid model data')
    site,sites=pd.factorize(d.site_id,sort=True); date=pd.factorize(d.date,sort=True)[0]
    ns=len(sites); sy=np.bincount(site,weights=w*y,minlength=ns)
    def calc(beta, need_hessian=True):
        eta=X@beta
        if np.max(np.abs(eta))>600: raise FloatingPointError('Non-finite profile predictor')
        e=np.exp(eta); den=np.bincount(site,weights=w*e,minlength=ns)
        if (den<=0).any(): raise FloatingPointError('Invalid site denominator')
        alpha=np.log(sy/den); mu=np.exp(eta+alpha[site])
        obj=float(np.dot(sy,np.log(den))-np.dot(w*y,eta))
        grad=X.T@(w*(mu-y))
        if not need_hessian: return obj,grad,mu,alpha,None,None
        wx=w*mu; xbar=_group_sum(wx[:,None]*X,site,ns)/sy[:,None]
        centered=X-xbar[site]
        H=(centered.T*wx)@centered
        return obj,grad,mu,alpha,H,centered
    beta=np.array([start.get(n,0.) for n in names]) if isinstance(start,dict) else np.zeros(X.shape[1])
    converged=False
    for iteration in range(1,61):
        obj,grad,mu,alpha,H,centered=calc(beta)
        if np.max(np.abs(grad))<1e-7: converged=True; break
        eig=linalg.eigvalsh(H)
        if eig[0]<=max(eig[-1]*1e-12,1e-12): raise ValueError('Rank-deficient profiled design')
        step=linalg.solve(H,grad,assume_a='pos'); scale=1.
        for trial in range(30):
            candidate=beta-scale*step
            try: newobj=calc(candidate,False)[0]
            except FloatingPointError: newobj=np.inf
            if newobj<=obj-1e-4*scale*np.dot(grad,step)+1e-10: break
            scale*=.5
        else: raise RuntimeError('Profile line search failed')
        beta=candidate
        if np.max(np.abs(scale*step))<1e-9 and np.max(np.abs(grad))<1e-5:
            converged=True; break
    obj,grad,mu,alpha,H,centered=calc(beta)
    if np.max(np.abs(grad))<1e-5: converged=True
    if not converged: raise RuntimeError('Profile Poisson failed to converge')
    cov=None; scores=None; covariance_meta={}
    if covariance:
        bread=linalg.inv(H); scores=(w*(y-mu))[:,None]*centered
        n=len(y); p=len(beta)+ns
        def meat(g):
            ng=int(g.max()+1)
            if ng<=1: raise ValueError('Too few covariance clusters')
            s=_group_sum(scores,g,ng)
            return (s.T@s)*(ng/(ng-1))*((n-1)/(n-p))
        joint=pd.factorize(pd.MultiIndex.from_arrays([site,date]))[0]
        cov=bread@(meat(site)+meat(date)-meat(joint))@bread
        cov=(cov+cov.T)/2
        ceig=linalg.eigvalsh(cov)
        covariance_meta={'min_slope_covariance_eigenvalue':float(ceig[0]),
          'slope_covariance_psd':bool(ceig[0]>=-1e-10),
          'nonpositive_slope_variances':int((np.diag(cov)<=0).sum()),
          'site_clusters':ns,'date_clusters':int(date.max()+1),
          'correction':'G/(G-1)*(N-1)/(N-K), K includes site intercepts; separate correction per component'}
    metadata={'mode':mode,'lag':lag,'converged':converged,'iterations':iteration,
      'max_abs_profile_score':float(np.max(np.abs(grad))),
      'n_cohort':initial_n,'n':len(y),'n_events':int(y.sum()),
      'n_sites_cohort':int(initial_sites),'n_sites':ns,'n_years':int(d.year.nunique()),
      'boundary_zero_event_sites':zero_sites,'boundary_zero_event_rows':boundary_n,
      'max_fitted_probability':float(mu.max()),'fitted_above_one':int((mu>1).sum()),
      'year_month_references':refs,'weight_sum':float(w.sum()),
      'hessian_condition':float(np.linalg.cond(H)),
      'runtime_seconds':time.perf_counter()-tic,**covariance_meta}
    return Fit(beta,names,cov,mu,X,y,w,site,date,list(sites),alpha,H,scores,metadata)

def coefficient_rows(fit, model):
    rows=[]
    for j,name in enumerate(fit.names):
        b=fit.beta[j]; v=fit.cov[j,j] if fit.cov is not None else np.nan
        valid=bool(np.isfinite(v) and v>0); se=np.sqrt(v) if valid else np.nan
        rows.append({'model':model,'term':name,'beta':b,'se':se,'rr':np.exp(b),
          'ci_low':np.exp(b-1.95996398454*se) if valid else np.nan,
          'ci_high':np.exp(b+1.95996398454*se) if valid else np.nan,
          'p_value':2*stats.norm.sf(abs(b/se)) if valid else np.nan,
          'p_holm':np.nan,'covariance_valid':valid,
          **{k:fit.metadata[k] for k in ['n','n_events','n_sites','n_years','n_cohort','n_sites_cohort','slope_covariance_psd']}})
    return rows

def benchmark_statsmodels(fit):
    """Independent explicit site-dummy GLM + official two-cluster sandwich."""
    import statsmodels.api as sm
    from statsmodels.stats.sandwich_covariance import cov_cluster_2groups
    Z=np.eye(len(fit.sites))[fit.site]; A=np.column_stack([Z,fit.X])
    result=sm.GLM(fit.y,A,family=sm.families.Poisson(),freq_weights=fit.weights).fit(
        start_params=np.r_[fit.alpha,fit.beta],maxiter=100,tol=1e-10)
    # For weighted estimating equations, the official tuple route uses the exact
    # case-weighted observation scores; automatic freq-weight corrections would
    # target replication weights instead of our date-balancing estimand.
    scores=A*(fit.weights*(fit.y-result.mu))[:,None]
    H=(A.T*(fit.weights*result.mu))@A
    c=cov_cluster_2groups((scores,linalg.inv(H)),fit.site,fit.date,use_correction=True)[0]
    p=len(fit.beta)
    out={'statsmodels_version':__import__('statsmodels').__version__,
      'max_abs_beta_difference':float(np.max(np.abs(result.params[-p:]-fit.beta))),
      'max_abs_covariance_difference':float(np.max(np.abs(c[-p:,-p:]-fit.cov))),
      'max_abs_prediction_difference':float(np.max(np.abs(result.mu-fit.mu))),
      'glm_converged':bool(result.converged),'equivalent_finite_sample_correction':True}
    out['passed']=bool(out['max_abs_beta_difference']<1e-6 and out['max_abs_covariance_difference']<1e-7 and out['glm_converged'])
    if not out['passed']: raise AssertionError('Statsmodels benchmark failed: '+str(out))
    return out

def fit_suite(df, output_dir):
    from pathlib import Path
    from statsmodels.stats.multitest import multipletests
    output_dir=Path(output_dir); output_dir.mkdir(parents=True,exist_ok=True)
    full=df.dropna(subset=['family_lag0','family_lag1','family_lag2','family_lag3','cyclonic_previous3']).copy()
    common=full.dropna(subset=['rain_previous3_mm']).copy()
    fits={}; specs=[('M0_full',full,'M0',None,None),('M1_full',full,'M1',None,None),
      ('M1_common',common,'M1',None,None),('M2_common',common,'M2',None,None),
      ('Categorical',full,'Categorical',None,None)]
    for lag in [1,2,3]: specs.append((f'Lag{lag}',full,'M0',lag,None))
    counts=common.groupby('date').site_id.transform('size').to_numpy()
    weights=1/counts; weights=weights/weights.mean()
    specs += [('DateBalanced_M1',common,'M1',None,weights),('DateBalanced_M2',common,'M2',None,weights)]
    rows=[]
    for name,d,mode,lag,w in specs:
        print('Fitting',name,'cohort',len(d),flush=True)
        fit=fit_poisson(d,mode,lag,w); fits[name]=fit
        rows.extend(coefficient_rows(fit,name))
        print(name,fit.metadata,flush=True)
    table=pd.DataFrame(rows)
    selection=table.model.str.startswith('Lag') & table.term.str.match(r'family_lag[123]\[')
    p=table.loc[selection,'p_value']
    if len(p)!=9 or p.isna().any(): raise ValueError('Nine valid supporting lag tests required, otherwise report failure explicitly')
    table.loc[selection,'p_holm']=multipletests(p,method='holm')[1]
    table.to_csv(output_dir/'coefficients.csv',index=False)
    (output_dir/'model_diagnostics.json').write_text(json.dumps({k:v.metadata for k,v in fits.items()},indent=2))
    benchmark={}
    for name in ['M1_full','M1_common','M2_common','DateBalanced_M2']:
        print('Benchmarking',name,flush=True); benchmark[name]=benchmark_statsmodels(fits[name])
    (output_dir/'statsmodels_benchmark.json').write_text(json.dumps(benchmark,indent=2))
    # Defined, estimable joint categorical-vs-linear departure: b2=2*b1,b3=3*b1.
    f=fits['Categorical']; ids=[f.names.index(f'Cyclonic_count[{k}]') for k in [1,2,3]]
    R=np.array([[-2.,1.,0.],[-3.,0.,1.]])
    contrast=R@f.beta[ids]; V=R@f.cov[np.ix_(ids,ids)]@R.T
    eig=linalg.eigvalsh(V); valid=bool(eig[0]>1e-12 and np.linalg.matrix_rank(V)==2)
    chi=float(contrast@linalg.solve(V,contrast)) if valid else None
    (output_dir/'exposure_linearity_diagnostic.json').write_text(json.dumps({
      'hypothesis':'categorical log-RR at counts2 and3 equals 2 and3 times log-RR at count1',
      'valid_covariance':valid,'eigenvalues':eig.tolist(),'df':2,'chi_square':chi,
      'p_value':float(stats.chi2.sf(chi,2)) if valid else None,
      'scope':'prespecified secondary shape diagnostic, not selection of primary exposure form'},indent=2))
    return fits,full,common
