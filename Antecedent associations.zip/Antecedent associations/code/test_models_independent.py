"""Independent synthetic checks of profiled site-fixed-effect Poisson fits.

Uses generated data only; does not fit any historical microbiological data.
"""
import json
from pathlib import Path
import sys
import numpy as np
import pandas as pd
from scipy import linalg
sys.path.insert(0,str(Path(__file__).parent))
from models import fit_poisson, design


def synthetic():
    rng=np.random.default_rng(7341)
    nd=240;ns=16
    years=np.repeat([2012,2013,2014,2015],60)
    dates=np.concatenate([pd.date_range(f'{y}-05-01',periods=60).to_numpy() for y in [2012,2013,2014,2015]])
    family=rng.choice(['Cyclonic Atlantic (frontal)','Showery maritime / unsettled','Convective extremes','Settled anticyclonic quiet'],nd)
    count=rng.integers(0,4,nd);rain=rng.gamma(1.3,3,nd)
    d=pd.DataFrame({'site_id':np.tile(np.arange(ns),nd),'date':np.repeat(dates,ns),'year':np.repeat(years,ns),'month':np.repeat(pd.DatetimeIndex(dates).month.to_numpy(),ns),'family_lag0':np.repeat(family,ns),'cyclonic_previous3':np.repeat(count,ns),'rain_previous3_mm':np.repeat(rain,ns)})
    alpha=rng.normal(-2.4,.25,ns)
    lp=alpha[d.site_id.to_numpy()]+.09*d.cyclonic_previous3.to_numpy()+.012*d.rain_previous3_mm.to_numpy()
    d['y_exceed']=rng.binomial(1,np.exp(lp))
    d.loc[d.site_id.eq(15),'y_exceed']=0
    return d


def independent_full_fit(d,mode,w):
    import statsmodels.api as sm
    from statsmodels.stats.sandwich_covariance import cov_cluster_2groups
    d=d.copy();keep=d.groupby('site_id').y_exceed.transform('sum').gt(0).to_numpy();d=d.loc[keep].reset_index(drop=True);w=w[keep]
    X,names,_=design(d,mode);site,levels=pd.factorize(d.site_id,sort=True);date=pd.factorize(d.date)[0]
    A=np.column_stack([np.eye(len(levels))[site],X])
    fit=sm.GLM(d.y_exceed.to_numpy(),A,family=sm.families.Poisson(),freq_weights=w).fit(maxiter=200,tol=1e-11)
    scores=A*(w*(d.y_exceed.to_numpy()-fit.mu))[:,None]
    H=(A.T*(w*fit.mu))@A
    cov=cov_cluster_2groups((scores,linalg.inv(H)),site,date,use_correction=True)[0]
    return fit.params[-len(names):],fit.mu,cov[-len(names):,-len(names):]


def run():
    d=synthetic();records=[]
    def check(name,success,details):
        records.append({'check':name,'passed':bool(success),**details})
        if not success:raise AssertionError(name+': '+str(details))
    fits={}
    for weighted in [False,True]:
        w=np.ones(len(d)) if not weighted else 1.+((d.site_id.to_numpy()%5)*.2)+d.month.to_numpy()*.03
        fit=fit_poisson(d,'M2',weights=w);fits[weighted]=fit
        b,mu,cov=independent_full_fit(d,'M2',w)
        diffs={'max_abs_beta_difference':float(np.max(np.abs(b-fit.beta))),'max_abs_mu_difference':float(np.max(np.abs(mu-fit.mu))),'max_abs_covariance_difference':float(np.max(np.abs(cov-fit.cov)))}
        check(('weighted' if weighted else 'unweighted')+'_independent_full_dummy_fit',diffs['max_abs_beta_difference']<1e-7 and diffs['max_abs_mu_difference']<1e-8 and diffs['max_abs_covariance_difference']<1e-8,diffs)
        check(('weighted' if weighted else 'unweighted')+'_boundary_site_reported',fit.metadata['boundary_zero_event_sites']==[15] and fit.metadata['boundary_zero_event_rows']==240,{'sites':fit.metadata['boundary_zero_event_sites'],'rows':fit.metadata['boundary_zero_event_rows']})
        # Poisson site score equations must balance exactly in each fitted site.
        balance=np.bincount(fit.site,weights=fit.weights*(fit.y-fit.mu))
        check(('weighted' if weighted else 'unweighted')+'_site_score_balance',np.max(np.abs(balance))<1e-9,{'max_abs_site_score':float(np.max(np.abs(balance)))})
    w=1.+((d.site_id.to_numpy()%5)*.2)+d.month.to_numpy()*.03
    doubled=fit_poisson(d,'M2',weights=w*7)
    check('arbitrary_case_weight_normalisation_invariance',np.max(np.abs(doubled.beta-fits[True].beta))<1e-8 and np.max(np.abs(doubled.cov-fits[True].cov))<1e-8,{'max_abs_beta_difference':float(np.max(np.abs(doubled.beta-fits[True].beta))),'max_abs_cov_difference':float(np.max(np.abs(doubled.cov-fits[True].cov)))})
    removed=fit_poisson(d.loc[~d.site_id.eq(15)],'M2')
    check('zero_event_site_has_no_slope_information',np.max(np.abs(removed.beta-fits[False].beta))<1e-10,{'max_abs_beta_difference':float(np.max(np.abs(removed.beta-fits[False].beta)))})
    # Frequency weighted rows must equal explicitly repeated rows for point estimates.
    rw=np.where(d.year.eq(2013),2,1)
    rf=fit_poisson(d,'M2',weights=rw,covariance=False)
    repeated=d.loc[d.index.repeat(rw)].reset_index(drop=True)
    re=fit_poisson(repeated,'M2',covariance=False)
    check('year_multiplicity_equals_explicit_replication',np.max(np.abs(rf.beta-re.beta))<1e-8,{'max_abs_beta_difference':float(np.max(np.abs(rf.beta-re.beta)))})
    invalid=d.copy();invalid.loc[invalid.site_id.eq(15),'y_exceed']=np.nan
    caught=False
    try:fit_poisson(invalid,'M2')
    except ValueError:caught=True
    check('missing_outcomes_rejected_even_in_zero_event_site',caught,{})
    return {'scope':'Independent synthetic-data numerical tests; no historical model fit','review_history':'Initial review exposed all-missing outcomes at one site being treated as a zero-event boundary. Parent corrected validation before site-total calculation; the guard test then passed.','checks':records,'passed':all(x['passed'] for x in records),'software':{'statsmodels':__import__('statsmodels').__version__}}

if __name__=='__main__':
    root=Path(__file__).resolve().parents[1];report=run()
    (root/'reports'/'INDEPENDENT_MODEL_REVIEW.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))
