"""Calendar-date antecedent exposures; no imputation or simulation donors.

The source calendar is retained byte-for-byte in inputs/. All rainfall sums
require three actual preceding calendar days. April is support, not evaluation.
"""
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
FAMILIES = [
    "Cyclonic Atlantic (frontal)",
    "Showery maritime / unsettled",
    "Convective extremes",
    "Settled anticyclonic quiet",
]
CYCLONIC = FAMILIES[0]


def _dates(series):
    if pd.api.types.is_datetime64_any_dtype(series):
        out = pd.to_datetime(series, errors="raise")
    else:
        out = pd.to_datetime(series, format="%Y-%m-%d", errors="raise")
    if out.isna().any() or (out != out.dt.normalize()).any():
        raise ValueError("Dates must be nonmissing, whole calendar dates")
    return out


def load_calendar(calendar_path=None, mapping_path=None):
    """Read and validate the selected complete April-September calendar."""
    calendar_path = Path(calendar_path or ROOT / "inputs/historical_daily_calendar.csv")
    mapping_path = Path(mapping_path or ROOT / "inputs/weather_pattern_family_mapping.csv")
    cal = pd.read_csv(calendar_path)
    mapping = pd.read_csv(mapping_path)
    if set(mapping.columns) != {"regime", "group"}:
        raise ValueError("Mapping must explicitly identify regime and group")
    if mapping.regime.isna().any() or mapping.regime.duplicated().any():
        raise ValueError("Missing or duplicate regime identifiers in family mapping")
    if set(mapping.regime) != set(range(1, 31)) or set(mapping.group) != set(FAMILIES):
        raise ValueError("Mapping must contain exactly regimes 1-30 and the four approved families")
    required = {"date", "regime", "family", "depth_mm", "rainfall_available"}
    if not required.issubset(cal):
        raise ValueError(f"Calendar missing columns: {required - set(cal)}")
    cal["date"] = _dates(cal.date)
    if cal.date.duplicated().any():
        raise ValueError("Duplicate historical predictor dates, including identical duplicates, require resolution")
    expected = pd.DatetimeIndex([])
    for year in range(2012, 2025):
        expected = expected.append(pd.date_range(f"{year}-04-01", f"{year}-09-30"))
    if set(cal.date) != set(expected):
        raise ValueError("Historical calendar must contain every April-September date in 2012-2024, exactly once")
    check = cal.merge(mapping, on="regime", how="left", validate="many_to_one")
    if check.group.isna().any() or not check.family.eq(check.group).all():
        raise ValueError("Historical regime and family assignments conflict with approved mapping")
    depth = pd.to_numeric(cal.depth_mm, errors="raise")
    if ((depth < 0) | np.isinf(depth)).any():
        raise ValueError("Invalid historical rainfall depth")
    if not cal.rainfall_available.isin([True, False]).all():
        raise ValueError("Rainfall availability must be an explicit Boolean")
    if not cal.rainfall_available.eq(depth.notna()).all():
        raise ValueError("Rainfall availability conflicts with historical depth values")
    cal["depth_mm"] = depth
    for field, derived in [("year", cal.date.dt.year), ("month", cal.date.dt.month)]:
        if field in cal and not cal[field].eq(derived).all():
            raise ValueError(f"Historical {field} conflicts with date")
        cal[field] = derived
    return cal.sort_values("date").reset_index(drop=True)


def _attach_calendar(cohort, cal):
    """Internal join routine also used by boundary tests with miniature calendars."""
    df = cohort.copy()
    for field in ["site_id", "date", "y_exceed"]:
        if field not in df:
            raise ValueError(f"Cohort missing {field}")
    df["date"] = _dates(df.date)
    if df.site_id.isna().any() or df.duplicated(["site_id", "date"]).any():
        raise ValueError("Cohort must have nonmissing site identifiers and unique site-days")
    if not df.y_exceed.isin([0, 1]).all():
        raise ValueError("Only explicitly classified binary outcomes can enter this analysis")
    if cal.date.duplicated().any():
        raise ValueError("Predictors must be unique by date before any merge")
    df["year"] = df.date.dt.year
    df["month"] = df.date.dt.month
    if not df.year.between(2012, 2024).all() or not df.month.between(5, 9).all():
        raise ValueError("Evaluation observations must be May-September 2012-2024")
    for lag in range(4):
        part = cal[["date", "family", "regime", "depth_mm"]].copy()
        part[f"source_date_lag{lag}"] = part.date
        part["date"] = part.date + pd.Timedelta(days=lag)
        part = part.rename(columns={k: f"{k}_lag{lag}" for k in ["family", "regime", "depth_mm"]})
        df = df.merge(part, on="date", how="left", validate="many_to_one", sort=False)
        actual = df[f"source_date_lag{lag}"]
        valid = actual.notna()
        if not (actual[valid] == df.loc[valid, "date"] - pd.Timedelta(days=lag)).all():
            raise AssertionError("Lag join does not identify the requested calendar day")
        if not actual[valid].dt.year.eq(df.loc[valid, "year"]).all():
            raise ValueError("An antecedent exposure crosses the annual seasonal boundary")
    if "family" in cohort:
        valid = df.family.notna() & df.family_lag0.notna()
        if not df.loc[valid, "family"].eq(df.loc[valid, "family_lag0"]).all():
            raise ValueError("Existing cohort family conflicts with selected historical calendar")
    if "regime" in cohort:
        valid = df.regime.notna() & df.regime_lag0.notna()
        if not df.loc[valid, "regime"].eq(df.loc[valid, "regime_lag0"]).all():
            raise ValueError("Existing cohort regime conflicts with selected historical calendar")
    family_cols = [f"family_lag{k}" for k in range(4)]
    antecedent_families = [f"family_lag{k}" for k in [1, 2, 3]]
    df["complete_family_lags"] = df[family_cols].notna().all(axis=1)
    count = df[antecedent_families].eq(CYCLONIC).sum(axis=1).astype(float)
    count.loc[~df[antecedent_families].notna().all(axis=1)] = np.nan
    df["cyclonic_previous3"] = count
    df["rain_previous3_mm"] = df[[f"depth_mm_lag{k}" for k in [1, 2, 3]]].sum(axis=1, min_count=3)
    df["complete_rain_previous3"] = df.rain_previous3_mm.notna()
    # These existing source fields are retained solely for timing audits/future
    # explicitly specified sensitivity analyses; they are not primary covariates.
    before = [x for x in ["p7_before_mm", "api_before", "swvl1_roll"] if x in cal]
    if before:
        part = cal[["date"] + before].rename(columns={x: f"historical_{x}" for x in before})
        df = df.merge(part, on="date", how="left", validate="many_to_one", sort=False)
    return df


def build_exposures(cohort, calendar_path=None, mapping_path=None):
    """Return validated site-days with day 0/-1/-2/-3 calendar-date exposures."""
    return _attach_calendar(cohort, load_calendar(calendar_path, mapping_path))


def exposure_audit(df):
    """Auditable counts, without treating missing rainfall as zero."""
    complete = df.complete_family_lags
    return {
        "site_days": int(len(df)),
        "sites": int(df.site_id.nunique()),
        "sampling_dates": int(df.date.nunique()),
        "exceedances": int(df.y_exceed.sum()),
        "complete_family_lag_site_days": int(complete.sum()),
        "missing_any_family_lag_site_days": int((~complete).sum()),
        "rain_previous3_complete_site_days": int(df.rain_previous3_mm.notna().sum()),
        "rain_previous3_missing_site_days": int(df.rain_previous3_mm.isna().sum()),
        "May_1_site_days_using_April_support": int(((df.date.dt.month == 5) & (df.date.dt.day == 1)).sum()),
        "cyclonic_count_support": {str(int(k)): int(v) for k, v in df.cyclonic_previous3.value_counts().sort_index().items()},
        "rainfall_sum_definition": "D-3 to D-1 inclusive; three nonmissing daily values required",
        "cyclonic_count_definition": "Number of Cyclonic Atlantic families on D-3,D-2,D-1; not a consecutive-run measure",
    }


def save_exposure_support(df, output_dir):
    """Save event/support and missingness denominators before model fitting."""
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    tables = []
    for label, subset in [("all_complete_family_lags", df.loc[df.complete_family_lags]),
                          ("rainfall_complete", df.loc[df.complete_family_lags & df.rain_previous3_mm.notna()])]:
        grouped = subset.groupby("cyclonic_previous3", observed=True).agg(
            site_days=("y_exceed", "size"), exceedances=("y_exceed", "sum"),
            sites=("site_id", "nunique"), sampling_dates=("date", "nunique")
        ).reset_index()
        grouped.insert(0, "sample", label)
        grouped["crude_exceedance_proportion"] = grouped.exceedances / grouped.site_days
        tables.append(grouped)
    pd.concat(tables, ignore_index=True).to_csv(out / "exposure_support_by_count.csv", index=False)
    for field, name in [("year", "year"), ("family_lag0", "current_family")]:
        x = df.assign(rain_previous3_missing=df.rain_previous3_mm.isna()).groupby(field, observed=True).agg(
            site_days=("y_exceed", "size"), exceedances=("y_exceed", "sum"),
            missing_antecedent_rainfall_site_days=("rain_previous3_missing", "sum")
        ).reset_index()
        x["missing_fraction"] = x.missing_antecedent_rainfall_site_days / x.site_days
        x.to_csv(out / f"rainfall_missingness_by_{name}.csv", index=False)
