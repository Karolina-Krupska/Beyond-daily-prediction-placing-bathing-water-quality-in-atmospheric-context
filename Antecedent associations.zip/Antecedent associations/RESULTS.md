# Results: observed antecedent circulation

The independently rebuilt corrected cohort contained 35,518 sampled site-days from 194 sites, with 3,727 intestinal-enterococci exceedances on 1,616 sampling dates. All lagged families were available. Three-day antecedent rainfall was complete for 34,139 site-days and missing for 1,379.

Eight sites had no exceedances. Their site-specific Poisson intercepts lie at a separation boundary and provide no slope information. They remain in the cohort audit; the broader slope estimation used 34,772 site-days from 186 informative sites. The matched rainfall-complete fits used 33,418 site-days, including 3,592 exceedances, from the same 186 informative sites.

Each additional Cyclonic Atlantic day during D−3 to D−1 was associated with a relative exceedance association of 1.141 (95% CI 1.087–1.197), after adjustment for sampling-day family, site, month and year. On the identical rainfall-complete sample, this estimate changed from 1.139 (95% CI 1.085–1.197) without antecedent-rainfall adjustment to 1.033 (95% CI 0.981–1.088) after adding the preceding three-day rainfall total.

The whole-year refitting interval also excluded one before rainfall adjustment. The rainfall-adjusted whole-year interval included one, so the analysis does not establish an additional antecedent-Cyclonic association beyond the specified rainfall and adjustment terms. The change after rainfall adjustment is consistent with substantial overlap between the circulation exposure and measured antecedent rainfall; it does not establish mediation or a causal pathway.

| Model and observational population | Site/date clustered interval | Whole-year refit interval | Informative site-days | Exceedances |
| --- | --- | --- | ---: | ---: |
| Broader cohort; no antecedent-rainfall adjustment | 1.141 (95% CI 1.087–1.197) | 1.141 (95% CI 1.074–1.216) | 34,772 | 3,727 |
| Rainfall-complete cohort; no antecedent-rainfall adjustment | 1.139 (95% CI 1.085–1.197) | 1.139 (95% CI 1.073–1.211) | 33,418 | 3,592 |
| Rainfall-complete cohort; antecedent-rainfall adjustment | 1.033 (95% CI 0.981–1.088) | 1.033 (95% CI 0.976–1.099) | 33,418 | 3,592 |

Date-balanced sensitivity estimates were 1.144 (95% CI 1.086–1.204) before antecedent-rainfall adjustment and 1.041 (95% CI 0.986–1.099) after it. This weighting gives each sampled date equal aggregate weight before boundary-site handling, rather than allowing dates with more sampled sites to contribute proportionately more observations. It targets a different monitored-date population and does not make monitoring random.

The categorical-count departure-from-linearity diagnostic gave χ²=5.462 on 2 degrees of freedom (p=0.0651). This supporting diagnostic does not prove the log-linear assumption. The categorical contrasts and exposure support are shown separately in Figure S4 and the source tables.

Across the nine prespecified supporting lag-family contrasts, 7 had Holm-adjusted p<0.05. Their effect estimates, pointwise intervals and adjusted p-values are in `results/coefficients.csv`; these are separate from the single primary count-exposure test. No significance test was attached to the descriptive composition or persistence-reference figures.

The whole-year sensitivity used 2,000 paired year-resampling bundles and refitted three models per bundle. There were 0 failed model-refit rows; 2,000 bundles yielded complete paired results. Results retain the limitations of 13 approximately exchangeable years.

The modified-Poisson working model produced 52 fitted means above one in the rainfall-adjusted informative sample; its maximum was 2.249. These values were not clipped. The estimates are reported as working-model relative associations, not calibrated absolute probabilities.
