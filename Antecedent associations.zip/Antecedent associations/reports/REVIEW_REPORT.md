# Reviewer-style review

## Completed corrections and checks

- Independently rebuilt and exactly reconciled 35,518 site-day outcomes against the selected current Step 5 dataset and corrected association reference.
- Preserved approved estuarine sites, threshold/censoring rules and partial-missing observations; excluded 12 wholly unevaluable site-days.
- Verified complete date-joined family lags and April support; constructed three-day rainfall only from three nonmissing antecedent values.
- Replaced row-order mapping, duplicate averaging and silent covariance clipping with explicit validation and auditable inputs.
- Added site intercepts and reported eight no-event sites as boundary cases; clustering is no longer described as site-baseline adjustment.
- Compared M1/M2 on identical rainfall-complete observations and retained the broader-cohort estimate separately.
- Verified profile estimates/covariance against explicit-dummy statsmodels implementations. Largest actual benchmark coefficient discrepancy: 2.56e-10; covariance discrepancy: 3.65e-12.
- Executed date-balanced, categorical-count and 2,000-bundle whole-year refitting sensitivities. Bootstrap failure rows: 0.
- Retained nine lag contrasts with Holm adjustment; kept unadjusted pointwise intervals distinct from adjusted tests.
- Regenerated figures from current result tables and exported plotted sources. Visual QA and numerical verification records identify the actual checks performed.
- Independent synthetic-data checks identified and corrected an initial missing-outcome guard issue before scientific conclusions; valid cohort outcomes were unaffected.

## Main scientific assessment

The antecedent-Cyclonic association is materially reduced after adjustment for observed preceding rainfall on the same sample. The rainfall-adjusted whole-year interval included one, so the analysis does not establish an additional antecedent-Cyclonic association beyond the specified rainfall and adjustment terms. The observed antecedent association substantially overlaps with the specified rainfall summary; these data do not establish a distinct rainfall-independent circulation mechanism. This result should complement the Step 5/6 evidence rather than be advertised as proof of better warnings.

## Unresolved limitations

- Modified-Poisson fitted means exceed one for some observations; no calibrated absolute-probability claim is supported.
- Thirteen-year resampling uncertainty and site/date covariance have different dependence assumptions; neither captures every source of uncertainty.
- Missing rainfall, non-random monitoring, sparse sites and a sparse persistence cell remain.
- Family mapping, measurement and domain aggregation uncertainty are not propagated.
- No operational warning records or prospective evaluation were available or analysed.

Publication suitability requires substantive judgement. Numerical agreement and sharp figure exports do not guarantee journal acceptance or resolve these limitations. Exact executed verification results are recorded separately, without a predetermined pass count.
